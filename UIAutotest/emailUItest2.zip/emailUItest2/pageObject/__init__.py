# -*- encoding: utf-8 -*-
'''
@File    :   __init__.py.py    
@Contact :   fttxtest@163.com
@License :   (C)Copyright 2017-2018, Liugroup-NLPR-CASIA

@Modify Time      @Author    @Version    @Desciption
------------      -------    --------    -----------
2019/12/26 0026 10:23   dmk      1.0         None
'''
