s = "aliyun"

print(s.upper())
print(s.lower())