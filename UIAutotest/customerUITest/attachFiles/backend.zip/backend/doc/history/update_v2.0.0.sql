# 维护
drop procedure if exists temp_procedure;
create procedure temp_procedure() BEGIN  
		DECLARE i int;
		DECLARE sqltext VARCHAR(2000);
		
		set i = 0;
		WHILE i < 10  DO
			SET @sql1 = CONCAT("update t_email_",i," set is_fw_in = 0 where is_fw_in is null");
			PREPARE sqltext FROM @sql1;
			EXECUTE sqltext;
			DEALLOCATE PREPARE sqltext;
			
			SET @sql2 = CONCAT("update t_email_",i," set is_timing_sent = 0 where is_timing_sent is null");
			PREPARE sqltext FROM @sql2;
			EXECUTE sqltext;
			DEALLOCATE PREPARE sqltext;
			
			SET @sql3 = CONCAT("update t_email_",i," set urgent = 0 where urgent is null");
			PREPARE sqltext FROM @sql3;
			EXECUTE sqltext;
			DEALLOCATE PREPARE sqltext;
			
			SET @sql4 = CONCAT("ALTER TABLE joinf_trade.t_email_",i," MODIFY `urgent` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否紧急:0/否;1/是'");
			PREPARE sqltext FROM @sql4;
			EXECUTE sqltext;
			DEALLOCATE PREPARE sqltext;
			
			SET @sql5 = CONCAT("ALTER TABLE joinf_trade.t_email_",i," ADD `is_asterisk` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否标星:0/否;1/是'");
			PREPARE sqltext FROM @sql5;
			EXECUTE sqltext;
			DEALLOCATE PREPARE sqltext;
			
			set i = i+1;
		END WHILE;
END;
call temp_procedure();
drop procedure if exists temp_procedure;



ALTER TABLE `joinf_trade`.`t_email_audit_rule_log`
ADD COLUMN `request_approval_content` varchar(1000) NULL COMMENT '请审信息' ;

--修改邮件表字段,将废弃字段 “customer_box_id” 修改为 “is_delivery”
--update t_email set customer_box_id = 0;
--ALTER TABLE t_email CHANGE COLUMN customer_box_id is_delivery tinyint(1) NULL DEFAULT NULL COMMENT '是否其他人分发(收件)';

drop procedure if exists temp_procedure;
create procedure temp_procedure() BEGIN
		DECLARE i int;
		DECLARE sqltext VARCHAR(2000);

		set i = 0;
		WHILE i < 10  DO
			SET @sql1 = CONCAT("update t_email_",i," set customer_box_id = 0");
			PREPARE sqltext FROM @sql1;
			EXECUTE sqltext;
			DEALLOCATE PREPARE sqltext;

			SET @sql2 = CONCAT("ALTER TABLE t_email_",i," CHANGE COLUMN customer_box_id is_delivery tinyint(1) NULL DEFAULT NULL COMMENT '是否其他人分发(收件)'");
			PREPARE sqltext FROM @sql2;
			EXECUTE sqltext;
			DEALLOCATE PREPARE sqltext;

			set i = i+1;
		END WHILE;
END;
call temp_procedure();
drop procedure if exists temp_procedure;

--邮件转发/分发日志记录表增加是否已读字段
ALTER TABLE t_email_transfer_log
ADD COLUMN `has_read` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否已读 0:未读/1:已读';

--邮件签名标增加默认标签
ALTER TABLE t_email_signature
ADD COLUMN `default_signature` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否默认签名';





