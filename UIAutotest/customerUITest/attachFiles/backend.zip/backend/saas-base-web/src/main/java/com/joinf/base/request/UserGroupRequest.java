package com.joinf.base.request;


import com.joinf.utils.base.BasePage;

public class UserGroupRequest extends BasePage{
	
}
