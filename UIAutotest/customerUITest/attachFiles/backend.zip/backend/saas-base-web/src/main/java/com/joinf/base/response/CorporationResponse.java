package com.joinf.base.response;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Date;

/**
 * t_corporation
 */
public class CorporationResponse implements Serializable {
    @ApiModelProperty(value ="公司标识")
    private Long id;

    @ApiModelProperty(value ="企业ID")
    private Long companyId;

    @ApiModelProperty(value ="中文名称")
    private String chineseName;

    @ApiModelProperty(value ="英文名称")
    private String englishName;

    @ApiModelProperty(value ="简称")
    private String name;

    @ApiModelProperty(value ="邮政编号")
    private String postCode;

    @ApiModelProperty(value ="")
    private String chineseAddress;

    @ApiModelProperty(value ="英文地址")
    private String englishAddress;

    @ApiModelProperty(value ="海关号")
    private String customsNumber;

    @ApiModelProperty(value ="税务登记号")
    private String taxNumber;

    @ApiModelProperty(value ="FormA号")
    private String forma;

    @ApiModelProperty(value ="产地证注册号")
    private String originCertificate;

    @ApiModelProperty(value ="法人代表信息")
    private String legal;

    @ApiModelProperty(value ="邮件地地址")
    private String email;

    @ApiModelProperty(value ="电话")
    private String telephone;

    @ApiModelProperty(value ="传真")
    private String fax;

    @ApiModelProperty(value ="主页")
    private String website;

    @ApiModelProperty(value ="报检登记号")
    private String inspectionNumber;

    @ApiModelProperty(value ="公司性质")
    private String companyProperty;

    @ApiModelProperty(value ="经营范围")
    private String operatingRange;

    @ApiModelProperty(value ="中文logo")
    private String chineseLogo;

    @ApiModelProperty(value ="英文logo")
    private String englishLogo;

    @ApiModelProperty(value ="有效标志:0/无效;1/有效")
    private Integer flag;

    @ApiModelProperty(value ="创建者ID")
    private Long createId;

    @ApiModelProperty(value ="创建时间")
    private Date createTime;

    @ApiModelProperty(value ="更新者ID")
    private Long updateId;

    @ApiModelProperty(value ="更新时间")
    private Date updateTime;

    @ApiModelProperty(value ="钉钉企业ID")
    private String dingdingCorpId;

    @ApiModelProperty(value ="钉钉凭证密钥")
    private String dingdingCorpSecret;

    @ApiModelProperty(value ="是否默认公司 0：否  1：是")
    private Byte defalultCorporation;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public String getChineseName() {
        return chineseName;
    }

    public void setChineseName(String chineseName) {
        this.chineseName = chineseName == null ? null : chineseName.trim();
    }

    public String getEnglishName() {
        return englishName;
    }

    public void setEnglishName(String englishName) {
        this.englishName = englishName == null ? null : englishName.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getPostCode() {
        return postCode;
    }

    public void setPostCode(String postCode) {
        this.postCode = postCode == null ? null : postCode.trim();
    }

    public String getChineseAddress() {
        return chineseAddress;
    }

    public void setChineseAddress(String chineseAddress) {
        this.chineseAddress = chineseAddress == null ? null : chineseAddress.trim();
    }

    public String getEnglishAddress() {
        return englishAddress;
    }

    public void setEnglishAddress(String englishAddress) {
        this.englishAddress = englishAddress == null ? null : englishAddress.trim();
    }

    public String getCustomsNumber() {
        return customsNumber;
    }

    public void setCustomsNumber(String customsNumber) {
        this.customsNumber = customsNumber == null ? null : customsNumber.trim();
    }

    public String getTaxNumber() {
        return taxNumber;
    }

    public void setTaxNumber(String taxNumber) {
        this.taxNumber = taxNumber == null ? null : taxNumber.trim();
    }

    public String getForma() {
        return forma;
    }

    public void setForma(String forma) {
        this.forma = forma == null ? null : forma.trim();
    }

    public String getOriginCertificate() {
        return originCertificate;
    }

    public void setOriginCertificate(String originCertificate) {
        this.originCertificate = originCertificate == null ? null : originCertificate.trim();
    }

    public String getLegal() {
        return legal;
    }

    public void setLegal(String legal) {
        this.legal = legal == null ? null : legal.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone == null ? null : telephone.trim();
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax == null ? null : fax.trim();
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website == null ? null : website.trim();
    }

    public String getInspectionNumber() {
        return inspectionNumber;
    }

    public void setInspectionNumber(String inspectionNumber) {
        this.inspectionNumber = inspectionNumber == null ? null : inspectionNumber.trim();
    }

    public String getCompanyProperty() {
        return companyProperty;
    }

    public void setCompanyProperty(String companyProperty) {
        this.companyProperty = companyProperty == null ? null : companyProperty.trim();
    }

    public String getOperatingRange() {
        return operatingRange;
    }

    public void setOperatingRange(String operatingRange) {
        this.operatingRange = operatingRange == null ? null : operatingRange.trim();
    }

    public String getChineseLogo() {
        return chineseLogo;
    }

    public void setChineseLogo(String chineseLogo) {
        this.chineseLogo = chineseLogo == null ? null : chineseLogo.trim();
    }

    public String getEnglishLogo() {
        return englishLogo;
    }

    public void setEnglishLogo(String englishLogo) {
        this.englishLogo = englishLogo == null ? null : englishLogo.trim();
    }

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getUpdateId() {
        return updateId;
    }

    public void setUpdateId(Long updateId) {
        this.updateId = updateId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getDingdingCorpId() {
        return dingdingCorpId;
    }

    public void setDingdingCorpId(String dingdingCorpId) {
        this.dingdingCorpId = dingdingCorpId == null ? null : dingdingCorpId.trim();
    }

    public String getDingdingCorpSecret() {
        return dingdingCorpSecret;
    }

    public void setDingdingCorpSecret(String dingdingCorpSecret) {
        this.dingdingCorpSecret = dingdingCorpSecret == null ? null : dingdingCorpSecret.trim();
    }

    public Byte getDefalultCorporation() {
        return defalultCorporation;
    }

    public void setDefalultCorporation(Byte defalultCorporation) {
        this.defalultCorporation = defalultCorporation;
    }
}