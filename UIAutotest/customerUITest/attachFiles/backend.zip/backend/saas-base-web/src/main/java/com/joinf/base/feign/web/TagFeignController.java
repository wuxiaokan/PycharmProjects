package com.joinf.base.feign.web;

import com.joinf.base.web.BaseController;
import com.joinf.dto.TagPersonalParamDto;
import com.joinf.entity.generator.Tag;
import com.joinf.entity.generator.TagPersonal;
import com.joinf.utils.dto.tag.QueryTagListByTypeIdsDto;
import com.joinf.utils.dto.tag.QueryTagRequest;
import com.joinf.utils.dto.tag.TagDto;
import com.joinf.utils.dto.tag.TagEntity;
import com.joinf.utils.dto.tag.TagPersonalDto;
import com.joinf.utils.dto.tag.TagResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author CyNick
 * @Description: 标签外部接口
 * @date 2019 2019-07-16  10:09
 */
@Slf4j
@Api(tags="标签接口", description = "TagFeignController")
@RequestMapping("/feign/tag")
@RestController
public class TagFeignController extends BaseController {

    /**
     * 获取标签列表
     * @param query
     * @return
     */
    @ApiOperation(value="获取对应业务的标签列表", notes="查询标签列表")
    @PostMapping(value = "/getTagList")
    @ResponseBody
    public List<TagResult> getTagList(@RequestBody QueryTagRequest query){
        List<TagResult> tagResultList = tagService.getTagList(query.getType(),query.getCompanyId(), query.getOperatorId());
        return tagResultList;
    }


    /**
     * 新增或修改标签
     * @param tag
     * @return
     */
    @ApiOperation(value="新增或修改标签", notes="新增或修改标签 有ID 的时候为修改，否则为新增")
    @PostMapping(value = "/addOrUpdateTag")
    @ResponseBody
    public int addOrUpdateTag(@RequestBody Tag tag) throws Exception {
        return tagService.addOrUpdateTag(tag);
    }


    /**
     * 删除标签
     * @param tagId
     * @return
     */
    @ApiOperation(value="新增或修改标签", notes="新增或修改标签 有ID 的时候为修改，否则为新增")
    @PostMapping(value = "/deleteTag")
    @ResponseBody
    public boolean deleteTag(@RequestBody Long tagId ) {
        return tagService.delete(tagId);
    }


    /**
     * 删除标签
     * @param tagPersonalParamDto
     * @return
     */
    @ApiOperation(value="批量新增数据和标签的关系", notes="批量新增数据和标签的关系")
    @PostMapping(value = "/createPersonalTagBatch")
    @ResponseBody
    public void createPersonalTagBatch(@RequestBody TagPersonalParamDto tagPersonalParamDto ) throws Exception {
        tagService.addTagBatch(tagPersonalParamDto);
    }




    @ApiOperation(value = "批量新增标签", notes = "批量新增标签")
    @PostMapping("/addTagBatch")
    @ResponseBody
    public List<TagDto> addTagBatch(@RequestBody List<TagDto> dto){
        tagService.insertTagBatch(dto);
        return dto;
    }


    @ApiOperation(value = "批量新增标签和数据的关系", notes = "批量新增标签和数据的关系")
    @PostMapping("/addTagPersonalBatch")
    @ResponseBody
    public void addTagPersonalBatch(@RequestBody List<TagPersonal> tagPersonalList){
        tagService.insertTagPersonalBatch(tagPersonalList);
    }

    @ApiOperation(value = "查询私有标签", notes = "查询私有标签")
    @PostMapping("/selectTagPersonalByCondition")
    @ResponseBody
    public List<TagPersonal> selectTagPersonalByCondition(@RequestBody TagPersonal tagPersonal){
        return tagService.selectTagPersonalByCondition(tagPersonal);
    }

    @ApiOperation(value = "查询标签实体", notes = "查询标签实体")
    @PostMapping("/selectTagEntity")
    @ResponseBody
    public List<TagEntity> selectTagEntity(@RequestBody Tag tag){
        return tagService.selectTagEntity(tag);
    }


    /**
     * 按业务ID数组获取标签列表
     *
     * @param query
     * @return
     */
    @ApiOperation(value="获取对应业务的标签列表", notes="查询标签列表")
    @PostMapping(value = "/getTagListByTypeIds")
    @ResponseBody
    public List<TagPersonalDto> getTagListByTypeIds(@RequestBody QueryTagListByTypeIdsDto query){
        return tagService.getTagListByTypeIds(query);
    }
}
