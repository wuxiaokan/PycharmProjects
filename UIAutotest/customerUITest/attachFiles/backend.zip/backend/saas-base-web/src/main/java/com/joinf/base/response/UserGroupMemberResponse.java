package com.joinf.base.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 
 * @description: 组成员信息
 * @author CyNick
 * @date 2019年7月9日 下午6:50:25
 * @revisionHistory
 */
public class UserGroupMemberResponse {

	@ApiModelProperty(value = "记录的ID")
	private Long id;

	@ApiModelProperty(value = "分组ID")
	private Long groupId;

	@ApiModelProperty(value = "成员的ID")
	private Long memberId;

	@ApiModelProperty(value = "姓名")
	private String name;

	@ApiModelProperty(value = "英文名称")
	private String ename;

	@ApiModelProperty(value = "邮箱")
	private String email;

	@ApiModelProperty(value = "部门")
	private String department;

	@ApiModelProperty(value = "用户类型:[0]系统用户;[1]企业其他联系人")
	private Byte type;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public Long getMemberId() {
		return memberId;
	}

	public void setMemberId(Long memberId) {
		this.memberId = memberId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public Byte getType() {
		return type;
	}

	public void setType(Byte type) {
		this.type = type;
	}

}
