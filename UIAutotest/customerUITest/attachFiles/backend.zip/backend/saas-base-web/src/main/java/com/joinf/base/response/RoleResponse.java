package com.joinf.base.response;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Date;

/**
 * t_role
 */
public class RoleResponse implements Serializable {
    @ApiModelProperty(value ="角色标识")
    private Long id;

    @ApiModelProperty(value ="企业ID")
    private Long companyId;

    @ApiModelProperty(value ="角色名称")
    private String name;

    @ApiModelProperty(value ="描述")
    private String description;


    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
