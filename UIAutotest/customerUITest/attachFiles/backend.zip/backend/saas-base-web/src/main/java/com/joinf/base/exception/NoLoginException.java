package com.joinf.base.exception;

/**
 * Description: 没有登入错误
 *
 * @author lyj
 * @date 2017年12月19日 下午7:02:34
 */
public class NoLoginException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8218764371044748511L;

}
