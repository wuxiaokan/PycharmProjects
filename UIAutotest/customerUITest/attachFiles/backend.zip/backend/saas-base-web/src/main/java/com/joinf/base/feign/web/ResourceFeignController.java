package com.joinf.base.feign.web;

import com.joinf.base.web.BaseController;
import com.joinf.interfaces.RelResourceService;
import com.joinf.interfaces.SystemManagerRuleService;
import com.joinf.utils.dto.QuerySystemManagerRuleParam;
import com.joinf.utils.dto.SystemManageRuleDto;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Map;

/**
 * @description: 资源权限操作服务
 * @author zlx
 * @date 2019年6月29日 下午2:12:12
 * @revisionHistory
 */
@Slf4j
@Api(tags="资源权限操作服务", description = "ResourceFeignController")
@RequestMapping("/feign")
@RestController
public class ResourceFeignController extends BaseController {

	@Resource
	private RelResourceService relResourceService;

	@Resource
	private SystemManagerRuleService systemManagerRuleService;

	@ApiOperation(value = "查询所有权限代码对应的多语言", notes = "查询所有权限代码对应的多语言")
	@GetMapping("/resources/langs")
	@ResponseBody
	public Map<Integer, Map<String, String>> queryAllPermitCodeLangs(){
		return relResourceService.queryAllPermitCodeLangs();
	}

	@ApiOperation(value = "查询用户系统规则", notes = "查询用户系统规则")
	@PostMapping("/system/rules")
	public SystemManageRuleDto selectSystemManagerRule (@RequestBody QuerySystemManagerRuleParam query){
		return systemManagerRuleService.selectSystemManagerRule(query);
	}

}
