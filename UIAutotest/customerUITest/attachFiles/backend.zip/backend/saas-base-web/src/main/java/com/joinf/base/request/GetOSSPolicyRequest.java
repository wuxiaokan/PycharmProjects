package com.joinf.base.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 获取签名请求
 * @date 2018年4月12日 上午10:23:59
 */
public class GetOSSPolicyRequest {

	@ApiModelProperty(value="1:业务员头像,2:业务员头像,3:业务员中英文文签章,4:公司中英文logo," +
			"5:公司印章,6:自定义图片,7:邮件正文中的cid图片,8:邮件签名中的图片,9:邮件eml包," +
			"10:邮件模板,11:身份信息验证附件,12:网店产品详情内嵌文件,13:邮件附件,14:产品主图,15:产品附件," +
			"16:报价附件,17:客户附件,18:供应商附件,19:订单附件,20:云盘中的文件,21:云盘中的文件(个人)," +
			"22:反馈附件,23:报表模板,24:网店产品主图,25:跟进附件  详情见枚举：UploadDataTypeEnum", required=true)
	private Integer type;

	@ApiModelProperty(value = "0:普通(默认) 1:大附件")
	private int bucketType;

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public int getBucketType() {
		return bucketType;
	}

	public void setBucketType(int bucketType) {
		this.bucketType = bucketType;
	}
}
