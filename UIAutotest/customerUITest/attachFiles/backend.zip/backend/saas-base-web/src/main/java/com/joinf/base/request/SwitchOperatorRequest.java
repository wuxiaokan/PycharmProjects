package com.joinf.base.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 切换业务员参数
 * @date 2019年5月17日 下午7:51:55
 */
public class SwitchOperatorRequest {
	
	@ApiModelProperty(value="登陆业务员id")
	private Long lid;
	
	@ApiModelProperty(value="切换业务员id")
	private Long cid;

	public Long getLid() {
		return lid;
	}

	public void setLid(Long lid) {
		this.lid = lid;
	}

	public Long getCid() {
		return cid;
	}

	public void setCid(Long cid) {
		this.cid = cid;
	}

	@Override
	public String toString() {
		return "SwitchOperatorRequest [lid=" + lid + ", cid=" + cid + "]";
	}

	
	

}
