package com.joinf.base.response;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 扩展类
 *
 * @author lyj
 * @date 2017年12月8日 上午10:06:53
 */
public class DictTypeListResponse {

	@ApiModelProperty(value = "主营产品")
	private List<DictTypeResponse> mainProductResponse;
	@ApiModelProperty(value = "跟进阶段")
	private List<DictTypeResponse> folloStepResponse;
	@ApiModelProperty(value = "客户类型")
	private List<DictTypeResponse> custTypeResponse;
	@ApiModelProperty(value = "客户等级")
	private List<DictTypeResponse> custGradeResponse;
	@ApiModelProperty(value = "客户来源")
	private List<DictTypeResponse> custSourceResponse;
	// @ApiModelProperty(value = "客户标签")
	// private List<DictTypeResponse> custTagResponse;
	@ApiModelProperty(value = "洲")
	private List<DictTypeResponse> continentResponse;
	@ApiModelProperty(value = "国家地区")
	private List<DictTypeResponse> countryResponse;
	@ApiModelProperty(value = "业务类型")
	private List<DictTypeResponse> businessResponse;

	public List<DictTypeResponse> getMainProductResponse() {
		return mainProductResponse;
	}

	public void setMainProductResponse(List<DictTypeResponse> mainProductResponse) {
		this.mainProductResponse = mainProductResponse;
	}

	public List<DictTypeResponse> getFolloStepResponse() {
		return folloStepResponse;
	}

	public void setFolloStepResponse(List<DictTypeResponse> folloStepResponse) {
		this.folloStepResponse = folloStepResponse;
	}

	public List<DictTypeResponse> getCustTypeResponse() {
		return custTypeResponse;
	}

	public void setCustTypeResponse(List<DictTypeResponse> custTypeResponse) {
		this.custTypeResponse = custTypeResponse;
	}

	public List<DictTypeResponse> getCustGradeResponse() {
		return custGradeResponse;
	}

	public void setCustGradeResponse(List<DictTypeResponse> custGradeResponse) {
		this.custGradeResponse = custGradeResponse;
	}

	public List<DictTypeResponse> getCustSourceResponse() {
		return custSourceResponse;
	}

	public void setCustSourceResponse(List<DictTypeResponse> custSourceResponse) {
		this.custSourceResponse = custSourceResponse;
	}

	public List<DictTypeResponse> getContinentResponse() {
		return continentResponse;
	}

	public void setContinentResponse(List<DictTypeResponse> continentResponse) {
		this.continentResponse = continentResponse;
	}

	public List<DictTypeResponse> getCountryResponse() {
		return countryResponse;
	}

	public void setCountryResponse(List<DictTypeResponse> countryResponse) {
		this.countryResponse = countryResponse;
	}

	public List<DictTypeResponse> getBusinessResponse() {
		return businessResponse;
	}

	public void setBusinessResponse(List<DictTypeResponse> businessResponse) {
		this.businessResponse = businessResponse;
	}

}
