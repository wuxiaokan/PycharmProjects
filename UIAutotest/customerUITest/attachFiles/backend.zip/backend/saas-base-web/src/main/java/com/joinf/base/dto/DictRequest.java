package com.joinf.base.dto;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @description: 基础数据搜索公共类
 * @author CyNick
 * @date 2019年7月1日 上午9:55:12
 * @revisionHistory
 */
public class DictRequest {

	@ApiModelProperty(value = "基础数据ID: [1] 客户类型,[2] 客户分类,[3]国家/地区,[4] 开户银行,[5] 客户来源,[6] "
			+ "业务类型,[7] 主营产品,[8] 跟进阶段,[9] 统计单位,[10] 币种,[11] 付款条件,[12] "
			+ "价格条款,[14] 提醒时间,[15] 客户等级,[16] 性别,[17] 联系人状态,[18] 运输方式,"
			+ "[19] 佣金方法,[20] 运费计算方式,[22] 计算类型,[23] 计算方式,[24] 日期方式,[26] 职务,"
			+ "[27] 计量单位,[28] 港口,[29] 省份,[33] 供应商类型,[34] 尾款付款方式,[36] 颜色,[37] 网店币种,[38] 网店单位,"
			+ "[42] 跟进方式,[44] 包装方式,[46] 丢单原因", required = true)
	private Long basicDataId;

	@ApiModelProperty(value = "搜索关键字,目前仅 国家地区支持")
	private String key;

	public Long getBasicDataId() {
		return basicDataId;
	}

	public void setBasicDataId(Long basicDataId) {
		this.basicDataId = basicDataId;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

}
