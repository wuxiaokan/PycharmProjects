package com.joinf.base.web;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.joinf.ClientConfig;
import com.joinf.exception.CommonException;
import com.joinf.utils.base.BaseEntityBuilder;
import com.joinf.utils.enums.UploadDataTypeEnum;
import com.joinf.utils.util.JoinfBeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import com.alibaba.fastjson.JSONObject;
import com.joinf.JoinfClientUtils;
import com.joinf.JoinfObsUtils;
import com.joinf.base.request.GetOSSPolicyRequest;
import com.joinf.config.SaasClientConfig;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.dto.session.SessionUser;
import com.joinf.utils.util.Base64Utils;
import com.joinf.utils.util.FileUtil;
import com.obs.services.ObsClient;
import com.obs.services.model.GetObjectRequest;
import com.obs.services.model.ObjectMetadata;
import com.obs.services.model.ObsObject;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Api(tags = "文件直传服务obs", description = "ObsController")
@RestController
public class ObsController extends BaseController{

	@Value("${file.obs.upload.callback}")
	private String obsUploadCallback;
	
	@ApiOperation(value = "获取obs直传签名")
	@GetMapping(value = "obs/policy")
	@ResponseBody
	public BaseResponseEntity<JSONObject> getToken(HttpServletRequest request, GetOSSPolicyRequest req) {
		SessionUser user = getSessionUser(request);

		UploadDataTypeEnum name = UploadDataTypeEnum.getByType(req.getType());
		if(name == null){
			throw  new CommonException("类型不存在");
		}

		Long companyId = user.getUser().getCompanyId();

		Map<String, Object> paramMap = new HashMap<String, Object>();

		// 500秒后过期
		long expireTime = 500;

		String key = FileUtil.getFileKey(companyId.toString(), String.valueOf(req.getType()), null);
		paramMap.put("companyid", companyId);
		paramMap.put("buckettype", req.getBucketType());

		JSONObject resJson = JoinfClientUtils.getPolicy( req.getBucketType()==0?SaasClientConfig.saasClientConfig:SaasClientConfig.bigClientConfig, expireTime, key, obsUploadCallback, paramMap);

		return BaseEntityBuilder.success(resJson);

	}
	
	/**
	 * oss直传回调
	 */
	@GetMapping("/obs/callback")
	public void uploadCallback(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String bucket = request.getParameter("bucket");
		String key = request.getParameter("key");
		String etag = request.getParameter("etag");
		JSONObject result = new JSONObject();
		GetObjectRequest getRequset = new GetObjectRequest(bucket, key);
		getRequset.setIfMatchTag(etag);
		ObsClient client = JoinfObsUtils.getInstance(SaasClientConfig.saasClientConfig);
		ObsObject object =  client.getObject(getRequset);
		ObjectMetadata metadata = object.getMetadata();
		JSONObject json = JSONObject.parseObject(JSONObject.toJSONString(metadata.getMetadata()));
		String companyId = Base64Utils.decodeBase64(json.getString("companyid"));
		int buckettype = json.getIntValue("buckettype");

		Long size = metadata.getContentLength();
		result.put("url", JoinfClientUtils.getUrl(buckettype==0?SaasClientConfig.saasClientConfig:SaasClientConfig.bigClientConfig,key));
		result.put("size", size);
		result.put("key", key);
		result.put("success", true);

		response.getWriter().println(result);
        response.setStatus(HttpServletResponse.SC_OK);
        response.flushBuffer();
	}
}
