package com.joinf.base.dto;

import java.io.Serializable;

/**
 * 查询业务员信息的请求参数
 *
 * @author yzq
 * @date 2019-06-27
 */
public class QueryOperatorRequest implements Serializable {

	private static final long serialVersionUID = -4326716368788258104L;

	private Long companyId;
	private Long operatorId;
	private Long queryOperatorId;
	private Integer type;

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}
	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public Long getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(Long operatorId) {
		this.operatorId = operatorId;
	}

	public Long getQueryOperatorId() {
		return queryOperatorId;
	}

	public void setQueryOperatorId(Long queryOperatorId) {
		this.queryOperatorId = queryOperatorId;
	}
}
