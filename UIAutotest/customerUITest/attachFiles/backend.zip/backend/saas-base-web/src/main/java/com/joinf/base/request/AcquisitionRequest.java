package com.joinf.base.request;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * @author CyNick
 * @Description:
 * @date 2019-08-12 14:12
 */
public class AcquisitionRequest {


    @ApiModelProperty(value ="企业ID")
    private Long companyId;
    @ApiModelProperty(value ="业务员ID")
    private Long operatorId;
    @ApiModelProperty(value ="操作名称")
    private String actionName;
    @ApiModelProperty(value ="操作类型")
    private String actionType;
    @ApiModelProperty(value ="操作时间")
    private String actionTime;
    @ApiModelProperty(value ="操作请求地址")
    private String actionUrl;
    @ApiModelProperty(value ="")
    private String message;
    @ApiModelProperty(value ="参数集合")
    private List<InputData> inputDataList;


    public static class InputData{

        public InputData() {
            super();
        }

        @ApiModelProperty(value ="控件ID")
        private String inputId;
        @ApiModelProperty(value ="控件名称")
        private String inputName;
        @ApiModelProperty(value ="控件类型")
        private String inputType;
        @ApiModelProperty(value ="控件输入或选中value")
        private String inputValue;

        public String getInputId() {
            return inputId;
        }

        public void setInputId(String inputId) {
            this.inputId = inputId;
        }

        public String getInputName() {
            return inputName;
        }

        public void setInputName(String inputName) {
            this.inputName = inputName;
        }

        public String getInputType() {
            return inputType;
        }

        public void setInputType(String inputType) {
            this.inputType = inputType;
        }

        public String getInputValue() {
            return inputValue;
        }

        public void setInputValue(String inputValue) {
            this.inputValue = inputValue;
        }
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public Long getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(Long operatorId) {
        this.operatorId = operatorId;
    }

    public String getActionName() {
        return actionName;
    }

    public void setActionName(String actionName) {
        this.actionName = actionName;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public String getActionTime() {
        return actionTime;
    }

    public void setActionTime(String actionTime) {
        this.actionTime = actionTime;
    }

    public String getActionUrl() {
        return actionUrl;
    }

    public void setActionUrl(String actionUrl) {
        this.actionUrl = actionUrl;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<InputData> getInputDataList() {
        return inputDataList;
    }

    public void setInputDataList(List<InputData> inputDataList) {
        this.inputDataList = inputDataList;
    }
}
