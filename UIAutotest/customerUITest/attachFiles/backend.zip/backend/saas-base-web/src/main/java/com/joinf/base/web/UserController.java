package com.joinf.base.web;

import com.joinf.base.exception.NoLoginException;
import com.joinf.base.request.SwitchOperatorRequest;
import com.joinf.base.response.QueryOperatorResponse;
import com.joinf.dto.QueryOperatorsDto;
import com.joinf.entity.generator.Operator;
import com.joinf.utils.base.BaseEntityBuilder;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.dto.session.SessionUser;
import com.joinf.utils.dto.user.UserInfoDto;
import com.joinf.utils.enums.ResponseCodeEnum;
import com.joinf.utils.util.JoinfBeanUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * 用户信息服务
 * @author zlx
 * @date 2019/7/16 13:27
 * @revisionHistory
 */
@Slf4j
@Api(tags = "用户信息服务", description = "UserController")
@RestController
public class UserController extends BaseController {

	@ApiOperation(value = "查询对应切换人的下属业务员", notes = "下拉框查询")
	@ApiImplicitParam(name = "type", value = "是否包含自己【1】 包含  【0】 不包含", paramType = "path", required = true)
	@GetMapping("/operators/{type}")
	@ResponseBody
	public BaseResponseEntity<List<QueryOperatorResponse>> getOperators(HttpServletRequest request,
																		@PathVariable(value = "type") Integer type) {
		BaseResponseEntity<List<QueryOperatorResponse>> entity = new BaseResponseEntity<>(true);
		SessionUser user = getSessionUser(request);

		List<QueryOperatorResponse> queryOperatorResponses = null;
		Long switchOperatorId = user.getSwitchUser().getId();
		Long companyId = user.getSwitchUser().getCompanyId();
		List<QueryOperatorsDto> operators = operatorService.queryOperators(companyId, switchOperatorId, type);
		if (operators != null) {
			queryOperatorResponses = JoinfBeanUtils.copyToNewListBean(QueryOperatorResponse.class, operators);
			// 将切换人放在第一位
			for (int i = 0; i < queryOperatorResponses.size(); i++) {
				if (switchOperatorId.equals(queryOperatorResponses.get(i).getOperatorId())) {
					queryOperatorResponses.add(0, queryOperatorResponses.remove(i));
					break;
				}
			}
		}
		entity.setCode(ResponseCodeEnum.SUCCESS.getStatus());
		entity.setSuccess(true);
		entity.setData(queryOperatorResponses);
		return entity;
	}

	@ApiOperation(value = "查询企业下所有业务员信息",notes = "下拉框查询")
	@GetMapping("/operators")
	@ResponseBody
	public BaseResponseEntity<List<QueryOperatorResponse>> queryAllOperators(HttpServletRequest request){
		BaseResponseEntity<List<QueryOperatorResponse>> entity = new BaseResponseEntity<>(true);
		SessionUser user = getSessionUser(request);

		List<QueryOperatorsDto> operators = operatorService.queryAllOperators(user.getUser().getCompanyId());

		List<QueryOperatorResponse> queryOperatorResponses = JoinfBeanUtils.copyToNewListBean(QueryOperatorResponse.class, operators);

		entity.setCode(ResponseCodeEnum.SUCCESS.getStatus());
		entity.setSuccess(true);
		entity.setData(queryOperatorResponses);
		return entity;
	}

	/**
	 * 获取当前登录用户信息
	 * @param request
	 * @return
	 */
	@ApiOperation(value="获取登陆用户信息", notes="获取登陆用户信息")
	@GetMapping("/operator/login")
	public BaseResponseEntity<SessionUser> getUserInfo(HttpServletRequest request){
		return BaseEntityBuilder.success(this.getSessionUser(request));
	}

	/**
	 * 获取业务员所有权限代码
	 * @param request
	 * @return
	 */
	@GetMapping("/operator/resource")
	@ApiOperation(value = "获取业务员所有权限代码",notes = "获取业务员所有权限代码")
	public BaseResponseEntity<List<Integer>> getAllResource(HttpServletRequest request){
		BaseResponseEntity<List<Integer>> entity = new BaseResponseEntity<>();
		SessionUser user = getSessionUser(request);

		if(user !=null){
			entity.setData(user.getResources());
		}
		entity.setSuccess(true);
		return entity;
	}

	@ApiOperation(value="切换用户", notes="切换用户")
	@PostMapping("/operator/switch")
	@ApiImplicitParam(name = "req", value = "切换用户参数", required = true, dataType = "SwitchOperatorRequest")
	public BaseResponseEntity<List<Integer>> switchOperator(HttpServletRequest request,@RequestBody SwitchOperatorRequest req){
		SessionUser user = getSessionUser(request);
		//切换了业务员
		if (req != null && req.getCid() != null && user.getSwitchUser().getId().longValue() != req.getCid().longValue()) {
			//业务员信息
			Operator operator = operatorService.selectByPrimaryKey(req.getCid());

			if(operator.getCompanyId().longValue() == user.getCompanyId().longValue()){
				//业务员信息(包括用户中心的信息)
				UserInfoDto userInfoDto = operatorService.selectUserInfoDtoByOperator(operator);
				//可管理当前切换用户权限
				List<Integer> resourceCodeList = relRoleResService.queryManagedResourcesCode(user.getUser().getId(), operator.getId());
				//切换业务员
				changeSessionUser(request, user, userInfoDto, resourceCodeList);
			}else{
				deleteSessionUser(request);
				//用户已经重新登陆了
				throw  new NoLoginException();
			}
		}
		return BaseEntityBuilder.success(user.getResources());
	}




}
