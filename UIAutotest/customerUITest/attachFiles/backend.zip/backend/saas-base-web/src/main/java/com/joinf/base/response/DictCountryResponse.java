package com.joinf.base.response;

import io.swagger.annotations.ApiModelProperty;

public class DictCountryResponse {
	
	@ApiModelProperty(value ="id")
    private Long id;

    @ApiModelProperty(value ="中文名称")
    private String name;

    @ApiModelProperty(value ="英文名称")
    private String ename;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

}
