package com.joinf.base.dto;

/**
 * @author lyj 日志 2019年5月10日下午4:20:59
 */
public class DataAcquisitionInputDto {

	/**
	 * 输入值ID
	 */
	private String inputId;
	/**
	 * 输入值
	 */
	private String inputValue;
	/**
	 * 输入类型 1 输入框 ，2 下拉框
	 */
	private String inputType;
	/**
	 * 输入项名称
	 */
	private String inputName;

	public DataAcquisitionInputDto() {
	}

	public DataAcquisitionInputDto(String inputId, String inputValue, String inputType, String inputName) {
		super();
		this.inputId = inputId;
		this.inputValue = inputValue;
		this.inputType = inputType;
		this.inputName = inputName;
	}

	public String getInputId() {
		return inputId;
	}

	public void setInputId(String inputId) {
		this.inputId = inputId;
	}

	public String getInputValue() {
		return inputValue;
	}

	public void setInputValue(String inputValue) {
		this.inputValue = inputValue;
	}

	public String getInputType() {
		return inputType;
	}

	public void setInputType(String inputType) {
		this.inputType = inputType;
	}

	public String getInputName() {
		return inputName;
	}

	public void setInputName(String inputName) {
		this.inputName = inputName;
	}

	
}
