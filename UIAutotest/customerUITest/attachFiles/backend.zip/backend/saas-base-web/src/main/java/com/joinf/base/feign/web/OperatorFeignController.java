package com.joinf.base.feign.web;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.joinf.JoinfClientUtils;
import com.joinf.base.request.SettingTypeRequest;
import com.joinf.config.SaasClientConfig;
import com.joinf.dto.OperatorLoginInfo;
import com.joinf.entity.OtherContacts;
import com.joinf.entity.generator.*;
import com.joinf.interfaces.*;
import com.joinf.utils.dto.user.*;
import com.joinf.utils.util.JoinfBeanUtils;
import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * @author zlx
 * @description: 业务员操作服务
 * @date 2019年6月26日 上午10:18:26
 * @revisionHistory
 */
@Slf4j
@Api(tags = "业务员服务", description = "OperatorFeignController")
@RequestMapping("/feign")
@RestController
public class OperatorFeignController {
	@Resource
	private OperatorService operatorService;
	@Resource
	private DepartmentService departmentService;
	@Resource
	private RelRoleResService relRoleResService;

	@Resource
	private StringRedisTemplate stringRedisTemplate;

	@Resource
	private AssignmentService assignmentService;

	@Resource
	private OtherContactsService otherContactsService;

	@Resource
	private CompanySettingService companySettingService;

	@Resource
	private CompanyService companyService;

	@ApiOperation(value = "查询业务员信息(登陆时完善用户信息)", notes = "查询业务员信息")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "head", value = "头像", paramType = "query"),
		@ApiImplicitParam(name = "centerUserId", value = "业务员中心ID", paramType = "path", required = true)
	})
	@GetMapping("/operator/login/{centerUserId}")
	public UserLoginDto queryUserLoginByCenterUserId(HttpServletRequest request, @PathVariable(value = "centerUserId") Long centerUserId, @RequestParam(value = "head", defaultValue = "") String head) {
		log.info("入参为：centerUserId={}", centerUserId);

		UserLoginDto userLoginDto = null;

		Operator operator = operatorService.selectByCenterUserId(centerUserId);

		if (operator != null) {
			userLoginDto = new UserLoginDto();
			userLoginDto.setId(operator.getId());
			userLoginDto.setCompanyId(operator.getCompanyId());
			userLoginDto.setDepartment(operator.getDepartment());
			userLoginDto.setRoleId(operator.getRoleId());
			userLoginDto.setSysVersion(operator.getSysVersion());
			if (StringUtils.isNotEmpty(head) && !head.startsWith("http")) {
				userLoginDto.setHead(JoinfClientUtils.getUrl(SaasClientConfig.saasClientConfig, head));
			}
			//权限代码
			userLoginDto.setResources(relRoleResService.queryOperatorResourcesCode(operator));
		}

		return userLoginDto;
	}

	@ApiOperation(value = "查询所有业务员信息", notes = "查询所有业务员信息")
	@PostMapping("/operators/all")
	@ResponseBody
	public List<UserInfoDto> queryUserSimpleInfo(HttpServletRequest request, @RequestBody QueryOperatorDto dto) {
		return operatorService.selectUserSimpleInfoByIds(dto);
	}


	/**
	 * 根据Operatorid 查询name和账号(只要业务员存在就会有值，不受管理权限约束)
	 *
	 * @param request
	 * @return
	 */
	@ApiOperation(value = "查询name和账号", notes = "查询name和账号")
	@PostMapping("/operators/name")
	public String queryOperatorNameAndAccount(@RequestBody com.joinf.base.dto.QueryOperatorRequest request) {
		String name = "--";

		if (request.getQueryOperatorId() == null || request.getQueryOperatorId() == 0) {
			return name;
		}

		List<UserInfoDto> users = getOperatorAssignment(request.getCompanyId(), request.getOperatorId());
		boolean exsit = false;
		for (UserInfoDto user : users) {
			if (user.getId().toString().equals(request.getQueryOperatorId().toString())) {
				name = user.getChineseName() + "(" + user.getUserName() + ")";
				exsit = true;
				break;
			}
		}
		//去用户中心查询
		if (!exsit) {
			OperatorLoginInfo info = operatorService.getOperatorLoginName(request.getQueryOperatorId());
			name = info.getChineseName() + "(" + info.getLoginName() + ")";
		}
		return name;
	}

	@ApiOperation(value = "查询当前用户可管理的人员", notes = "查询当前用户可管理的人员")
	@PostMapping("/operators/assigment")
	public List<UserInfoDto> queryOperatorAssignment(@RequestBody com.joinf.base.dto.QueryOperatorRequest request) {
		return getOperatorAssignment(request.getCompanyId(), request.getOperatorId(), request.getType());
	}

	/**
	 * 获取当前用户可管理人员
	 *
	 * @param companyId
	 * @param operatorId
	 * @param type       [1]包含自己
	 * @return
	 */
	public List<UserInfoDto> getOperatorAssignment(Long companyId, Long operatorId, int type) {
		List<UserInfoDto> users = new ArrayList<UserInfoDto>();
		String key = String.format(AssignmentService.OPERATOR_ASSIGNMENT_USERS, companyId, operatorId);
		if (stringRedisTemplate.hasKey(key)) {
			String value = stringRedisTemplate.opsForValue().get(key);
			JSONArray array = JSONArray.parseArray(value);
			UserInfoDto info;
			for (int i = 0; i < array.size(); i++) {
				JSONObject ob = array.getJSONObject(i);
				info = JSONObject.toJavaObject(ob, UserInfoDto.class);
				if (type == 1 || info.getId().longValue() != operatorId.longValue()) {
					users.add(info);
				}
			}
		} else {//切换用户的时候可能不存在--重新获取
			List<UserInfoDto> data = assignmentService.selectAssignmentUserList(companyId, operatorId);
			stringRedisTemplate.opsForValue().set(key, JSONArray.toJSONString(data), 120, TimeUnit.HOURS);
			for (UserInfoDto user : data) {
				if (type == 1 || user.getId().longValue() != operatorId.longValue()) {
					users.add(user);
				}
			}
		}
		return users;
	}

	/**
	 * 获取当前用户可管理人员
	 *
	 * @param companyId
	 * @param operatorId
	 * @return
	 */
	public List<UserInfoDto> getOperatorAssignment(Long companyId, Long operatorId) {
		return getOperatorAssignment(companyId, operatorId, 1);
	}

	@ApiModelProperty(value = "校验是否可管理指定业务员的数据(查询或编辑)", notes = "校验是否可管理指定业务员的数据(查询或编辑)")
	@PostMapping("/user/validate")
	public boolean validateMangerPermission(@RequestBody ValidateManagerRequest request) {
		// 默认没有权限
		Long managerId = request.getManagerId();
		Long staffId = request.getStaffId();
		Long resourceId = request.getResourceId();
		boolean checkHas = false;
		if (managerId != null && staffId != null && !managerId.equals(staffId)) {
			// 判断当前客户所属的业务员 对于当前操作员是否是只读权限
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("operatorId", managerId);
			map.put("subordinateIdArray", Arrays.asList(staffId));
			// 设置资源是否只读
			List<Assignment> assignmentList = assignmentService.selectByManagerIdStaffId(map);
			if (null != assignmentList && assignmentList.size() > 0) {
				Assignment assignment = assignmentList.get(0);
				String resAu = assignment.getResourceAuthority();
				if (resourceId != null && StringUtils.isNotEmpty(resAu)) {
					JSONArray arr = JSONArray.parseArray(resAu);
					for (int i = 0; i < arr.size(); i++) {
						JSONObject jsonRes = arr.getJSONObject(i);
						// 如果资源ID和权限中的资源ID相等，则有权限
						if (resourceId.equals(jsonRes.getLong("resource_id")) && jsonRes.getBooleanValue("checked")) {
							checkHas = true;
						}
					}
				}
				// 兼容老数据，如果为空或null 则 有全部权限
				else {
					checkHas = true;
				}
			}
		} else {
			checkHas = true;
		}
		return checkHas;
	}

	@ApiOperation(value = "查询部门信息", notes = "查询所有业务员信息")
	@ApiImplicitParam(name = "companyId", value = "公司ID", paramType = "path", required = true)
	@GetMapping("/department/{companyId}")
	public List<Department> queryDepartment(HttpServletRequest request,@PathVariable(value = "companyId") Long companyId){
		return departmentService.selectByCompanyId(companyId);
	}

	@ApiOperation(value = "通过名称获取业务员id", notes = "通过名称获取业务员id")
	@PostMapping("/operators/operatorIds")
	public List<Long> getOperatorIdListByLoginName(@RequestBody QueryGetOperatorIdByName query){
		List<Long> operatorIdList = new ArrayList<>();
		List<String> loginNameList = null;
		if (StringUtils.isNotBlank(query.getLoginNameStr())) {
			loginNameList = Arrays.asList(query.getLoginNameStr().split(","));
		}else{
			return operatorIdList;
		}
		String key = String.format(AssignmentService.OPERATOR_ASSIGNMENT_USERS, query.getCompanyId(),query.getOperatorId());
		if(stringRedisTemplate.hasKey(key)){
			String value = stringRedisTemplate.opsForValue().get(key);
			JSONArray array = JSONArray.parseArray(value);
			UserInfoDto info;
			for(int i=0;i<array.size();i++){
				JSONObject ob = array.getJSONObject(i);
				info = JSONObject.toJavaObject(ob, UserInfoDto.class);
				if (loginNameList.contains(info.getUserName())) {
					operatorIdList.add(info.getId());
				}
			}
		}
		return operatorIdList;
	}

	@ApiModelProperty(value = "通过邮件获取其他联系人", notes = "通过邮件获取其他联系人")
	@PostMapping("/operators/otherContacts")
	public OtherContacts selectOtherContactsByEmail(@RequestBody QueryOtherContactsRequest request){
		return otherContactsService.selectOtherContactsByEmail(request.getCompanyId(), request.getMailbox());
	}


	@ApiModelProperty(value = "获取其他联系人", notes = "通过邮件获取其他联系人")
	@GetMapping("/operators/otherContacts/{companyId}")
	public List<OtherContacts> selectListByParam(@PathVariable(value = "companyId") Long companyId){
		Map<String, Object> map = new HashMap<>();
		map.put("companyId",companyId);
		return otherContactsService.selectListByParam(map);
	}


	@ApiModelProperty(value = "查询企业信息", notes = "查询企业信息")
	@GetMapping("/company/{companyId}")
	public CompanyDTO queryCompanyInfo(@PathVariable(value = "companyId") Long companyId){

		Company company = companyService.selectByPrimaryKey(companyId);

		CompanyDTO companyDTO = JoinfBeanUtils.copyToNewBean(CompanyDTO.class,company);

		return companyDTO;

	}


	@ApiModelProperty(value = "查询企业信息", notes = "查询企业信息")
	@PostMapping("/company/companySetting")
	public List<CompanySetting> selectCompanySettingListByParam(@RequestBody SettingTypeRequest request){

		Map<String, Object> map = new HashMap<>();
		map.put("companyId",request.getCompanyId());
		map.put("operatorId",request.getOperatorId());
		map.put("settingType", request.getSettingType());

		List<CompanySetting> companySettingList = companySettingService.selectCompanySettingListByParam(map);

		return companySettingList;

	}

	@ApiModelProperty(value = "查询部门(包括子部门)下的业务员", notes = "查询部门下的业务员")
	@PostMapping("/company/department")
	public List<Operator> queryOperatorByDepartmentIds(@RequestBody QueryOperatorDto query){
		return operatorService.queryOperatorByDepartmentIds(query);
	}
}
