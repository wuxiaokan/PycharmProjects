package com.joinf.base.config;

import com.joinf.SpringApplicationContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.List;

/**
 * @description: Swagger2api配置类
 * @author zlx
 * @date 2019年6月24日 下午4:44:31
 * @revisionHistory
 */
@Configuration
@EnableSwagger2
@PropertySource("classpath:swagger.properties")
@Profile({"alidev","dev","test","alicloud"})
public class Swagger2 extends WebMvcConfigurerAdapter {

    @Value("${gateway.url}")
    private String apiDocHost;

	@Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/api/doc/**").addResourceLocations("classpath:/swagger/dist/");
        super.addResourceHandlers(registry);
    }
	
    @Bean
    public Docket createRestApi() {
    	Docket docket = new Docket(DocumentationType.SWAGGER_2)
    			.groupName("1")  
                .apiInfo(apiInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.joinf.base.web"))
                .paths(PathSelectors.any())
                .build();

        return setDocketHost(docket);
    }
    
    @Bean
    public Docket createOpenApi() {
    	Docket docket =  new Docket(DocumentationType.SWAGGER_2)
        		.groupName("2")  
                .apiInfo(openApiInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.joinf.base.feign.web"))
                .paths(PathSelectors.any())
                .build();

        return setDocketHost(docket);
    }
    
    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("富通天下-saas-email 页面交互API接口文档")
                .description("https://xxxx/swagger-ui.html")
                .version("1.0")
                .build();
    }
    
    private ApiInfo openApiInfo() {
        return new ApiInfoBuilder()
                .title("富通天下-saas-email 服务内调API接口文档")
                .description("https://xxxx/swagger-ui.html")
                .version("1.0")
                .build();
    }

    /**
     * 设置接口的Host
     * @author zlx
     * @date 2019/8/27 9:00
     * @param docket
     * @return springfox.documentation.spring.web.plugins.Docket
     */
    private Docket setDocketHost(Docket docket){
        List<String> profilesActives = SpringApplicationContext.getProfilesActive();

        //本地环境没有使用Nginx代理
        if (profilesActives != null && !profilesActives.contains("alidev") && !profilesActives.contains("dev")) {
            if (apiDocHost.contains("://")) {
                docket.host(apiDocHost.substring(apiDocHost.indexOf("://") + 3, apiDocHost.length()));
            }else{
                docket.host(apiDocHost);
            }
        }
        return docket;
    }
    
}



