package com.joinf;

import com.joinf.base.filter.RequestWrapperFilter;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.ContentNegotiationConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import javax.servlet.Filter;
import java.util.ArrayList;
import java.util.List;

/**
 * @description: 基本微服务启动类
 * @author zlx
 * @date 2019年6月25日 下午4:36:51
 * @revisionHistory
 */
@EnableDiscoveryClient
@SpringBootApplication
public class BaseWebApplication extends WebMvcConfigurerAdapter {

	/**
	 * 程序入口
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			SpringApplication.run(new Object[]{BaseWebApplication.class,ApplicationRunner.class}, args);
		}catch (Exception e){
			e.printStackTrace();
		}
	}

	/**
	 * 注册拦截器
	 * @return
	 */
	@Bean
	public FilterRegistrationBean filterRegistrationBean() {
	   FilterRegistrationBean registrationBean = new FilterRegistrationBean();
	   registrationBean.setFilter(requestWrapperFilter());
	   List<String> urlPatterns = new ArrayList<String>();
	   urlPatterns.add("/*");
	   registrationBean.setUrlPatterns(urlPatterns);
	   return registrationBean;
	}

	/**
	 * 重复获取数据拦截器
	 * @return
	 */
	@Bean
	public Filter requestWrapperFilter(){
		return new RequestWrapperFilter();
	}


	/**
	 * {关闭后缀匹配（当请get 请求，如果参数中包含  xx.xx 时，会爆406 错误，进行了后缀匹配，造成返回给前端数据格式不是JSON格式）}
	 * <p>This implementation is empty.
	 *
	 * @param configurer
	 */
	@Override
	public void configureContentNegotiation(ContentNegotiationConfigurer configurer) {
		configurer.favorPathExtension(false);
	}
}
