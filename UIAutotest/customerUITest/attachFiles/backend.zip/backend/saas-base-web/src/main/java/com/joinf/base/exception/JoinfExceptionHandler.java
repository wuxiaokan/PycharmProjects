package com.joinf.base.exception;

import com.joinf.utils.base.BaseEntityBuilder;
import com.joinf.utils.base.BaseResponseEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;


/**
 * Description: 全局异常处理
 *
 * @author lyj
 * @date 2017年12月14日 下午3:12:16
 */
@Slf4j
@ControllerAdvice
public class JoinfExceptionHandler {
	
	@Value("${gateway.auth.url}")
	private String gatewayUrl;

	/**
	 * 没有登入错误
	 * @param req
	 * @param e
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@ExceptionHandler(value= NoLoginException.class)
	public BaseResponseEntity<String> noLoginException(HttpServletRequest req, Exception e) throws Exception {
		
		log.error("", e);
		//通知前端，走授权流程
		return BaseEntityBuilder.fail(401, "Unauthorized", gatewayUrl);
	}

	/**
	 * 统一异常处理
	 * @param e
	 * @return
	 */
	@ResponseBody
	@ExceptionHandler(value= Exception.class)
	public BaseResponseEntity<?> exception(Exception e){
		log.error("",e);
		
		BaseResponseEntity<?> response = new BaseResponseEntity<>();
		response.setSuccess(false);
		response.setErrMsg(e.getMessage());

		return response;
	}
	
	
}
