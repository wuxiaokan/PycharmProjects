package com.joinf.base.web;

import com.joinf.base.request.EmailTagDtoRequest;
import com.joinf.base.request.EmailTagRequest;
import com.joinf.dto.TagPersonalListParamDto;
import com.joinf.dto.TagPersonalParamDto;
import com.joinf.entity.generator.Tag;
import com.joinf.exception.CommonException;
import com.joinf.utils.base.BaseEntityBuilder;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.dto.dict.AddPersonalTagListRequest;
import com.joinf.utils.dto.dict.AddPersonalTagRequest;
import com.joinf.utils.dto.dict.TagListRequest;
import com.joinf.utils.dto.session.SessionUser;
import com.joinf.utils.dto.tag.EmailTagEntity;
import com.joinf.utils.dto.tag.TagResult;
import com.joinf.utils.util.BeanUtils;
import com.joinf.utils.util.JoinfBeanUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author CyNick
 * @Description: 公共标签服务
 * @date 2019 2019-07-16  10:00
 */
@Slf4j
@Api(tags = "标签服务", description = "TagController")
@RestController
public class TagController extends BaseController {

    /**
     * 获取标签列表
     * @param req 业务类型
     * @return
     */
    @ApiOperation(value="获取对应业务的标签列表", notes="查询标签列表")
    @GetMapping(value = "tags")
    @ResponseBody
    public BaseResponseEntity<List<TagResult>> getTagList(HttpServletRequest request,EmailTagDtoRequest req){
        log.info("入参为：type="+req.getType());
        BaseResponseEntity<List<TagResult>> response = new BaseResponseEntity<>(true);
        SessionUser user = getSessionUser(request);
        if (req.getOperatorId() == null){
            req.setOperatorId(user.getSwitchUser().getId());
        }
        response.setData(tagService.getTagList(req.getType(), user.getSwitchUser().getCompanyId(), req.getOperatorId()));
        return response;
    }


    /**
     * 获取标签列表
     * @param req 业务类型
     * @return
     */
    @ApiOperation(value="获取对应业务数据绑定的标签列表", notes="获取对应业务数据绑定的标签列表")
    @GetMapping(value = "type/tags")
    @ResponseBody
    public BaseResponseEntity<List<EmailTagEntity>> getTagListByTypeId(HttpServletRequest request, TagListRequest req){
        log.info("入参为：type="+req.getType());
        BaseResponseEntity<List<EmailTagEntity>> response = new BaseResponseEntity<>(true);
        Map<String,Object> map = new HashMap<>();
        map.put("type",req.getType());
        map.put("typeId",req.getTypeId());
        List<Tag> tagList = tagService.selectTagListByTypeId(map);
        List<EmailTagEntity> emailTagEntities = BeanUtils.copyToNewListBean(EmailTagEntity.class,tagList);
        response.setData(emailTagEntities);
        return response;
    }

    @ApiOperation(value = "保存标签", notes = "保存标签")
    @ApiImplicitParam(name = "req", value = "保存标签", required = true, dataType = "EmailTagRequest")
    @PostMapping("tag")
    @ResponseBody
    public BaseResponseEntity<?> emailTagSaveData(HttpServletRequest request,@RequestBody EmailTagRequest req) {
        SessionUser user = getSessionUser(request);

        Tag tagDto = BeanUtils.copyToNewBean(Tag.class, req);
        if (req.getOperatorId() == null){
            tagDto.setOperatorId(user.getUser().getId());
        }
        tagDto.setCompanyId(user.getUser().getCompanyId());
        tagDto.setCreateId(user.getUser().getId());
        tagDto.setUpdateId(user.getUser().getId());

        int succ = 0;
        try {
            succ = tagService.addOrUpdateTag(tagDto);
        } catch (CommonException e){
            return BaseEntityBuilder.fail(localeMessage.getMessage(e.getMessage()));
        }catch (Exception e) {
            e.printStackTrace();
            log.error("保存标签失败！");
            return BaseEntityBuilder.fail(localeMessage.getMessage("system.tag.save.error"));
        }

        if (succ != 1) {
            log.error("保存标签失败！");
            return BaseEntityBuilder.fail(localeMessage.getMessage("system.tag.save.error"));
        }
        return BaseEntityBuilder.success();
    }


    @ApiOperation(value = "修改标签", notes = "修改邮件标签")
    @PutMapping("tag")
    @ResponseBody
    public BaseResponseEntity<?> emailTagEditData(HttpServletRequest request,@RequestBody EmailTagRequest req) {
        SessionUser user = getSessionUser(request);

        Tag tagDto = BeanUtils.copyToNewBean(Tag.class, req);
        if (req.getOperatorId() == null){
            tagDto.setOperatorId(user.getUser().getId());
        }
        tagDto.setCompanyId(user.getUser().getCompanyId());
        tagDto.setUpdateId(user.getUser().getId());
        int succ = 0;
        try {
            succ = tagService.addOrUpdateTag(tagDto);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("修改标签失败！");
            return BaseEntityBuilder.fail(e.getMessage());
        }
        if (succ != 1) {
            log.error("修改标签失败！");
            return BaseEntityBuilder.fail(localeMessage.getMessage("system.tag.edit.error"));
        }
        return BaseEntityBuilder.success();
    }


    @ApiOperation(value = "删除标签", notes = "删除标签")
    @ApiImplicitParam(name = "tagId", value = "删除标签ID", paramType = "path", dataType = "Long",required = true)
    @DeleteMapping("tag/{tagId}")
    @ResponseBody
    public BaseResponseEntity<?> emailTagDelete(HttpServletRequest request, @PathVariable(value = "tagId") Long tagId){

        boolean succ = tagService.delete(tagId);
        if (!succ) {
            log.error("删除标签失败！");
            return BaseEntityBuilder.fail(localeMessage.getMessage("system.tag.delete.error"));
        }
        return BaseEntityBuilder.success();
    }



    /**
     * 加标签
     * @param req
     * @return
     */
    @ApiOperation(value="给业务勾选标签", notes="给业务勾选标签")
    @PostMapping("/type/personal")
    @ResponseBody
    public BaseResponseEntity<?> createPersonalTagBatch(HttpServletRequest request, @RequestBody AddPersonalTagRequest req) throws Exception{
        BaseResponseEntity<Boolean> response = new BaseResponseEntity<>(true);
        SessionUser user = getSessionUser(request);
        Long companyId = user.getCompanyId();
        Long operatorId = user.getSwitchOperatorId();
        TagPersonalParamDto dto = JoinfBeanUtils.copyToNewBean(TagPersonalParamDto.class,req);
        dto.setIdList(req.getIdList());
        dto.setCompanyId(companyId);
        dto.setOperatorId(operatorId);

        try {
            //加标签
            tagService.addTagBatch(dto);
        } catch (CommonException e){
            return BaseEntityBuilder.fail(localeMessage.getMessage(e.getMessage(),new String[]{String.valueOf(e.getMaxCount())}));

        }catch (Exception e) {
            e.printStackTrace();
        }
        return BaseEntityBuilder.success();
    }


    /**
     * 加标签
     * @param req
     * @return
     */
    @ApiOperation(value="批量给业务勾选标签", notes="批量给业务勾选标签")
    @PostMapping("/type/personal/batch")
    @ResponseBody
    public BaseResponseEntity<?> addPersonalTagBatch(HttpServletRequest request, @RequestBody AddPersonalTagListRequest req){
        BaseResponseEntity<Boolean> response = new BaseResponseEntity<>(true);
        SessionUser user = getSessionUser(request);
        Long companyId = user.getCompanyId();
        Long operatorId = user.getSwitchOperatorId();
        TagPersonalListParamDto dto = JoinfBeanUtils.copyToNewBean(TagPersonalListParamDto.class,req);
        dto.setIdList(req.getIdList());
        dto.setTypeId(req.getTypeId());
        dto.setCompanyId(companyId);
        dto.setOperatorId(operatorId);
        try {
            //加标签
            tagService.addTagPersonaBatch(dto);
        } catch (CommonException e){
            return BaseEntityBuilder.fail(localeMessage.getMessage(e.getMessage(),new String[]{String.valueOf(e.getMaxCount())}));

        }catch (Exception e) {
            e.printStackTrace();
        }
        return BaseEntityBuilder.success();
    }

}
