package com.joinf.base.web;

import com.alibaba.fastjson.JSON;
import com.joinf.interfaces.*;
import com.joinf.utils.LocaleMessage.LocaleMessage;
import com.joinf.utils.dto.session.SessionUser;
import com.joinf.utils.dto.session.SessionUserInfo;
import com.joinf.utils.dto.user.UserInfoDto;
import com.joinf.utils.util.JoinfBeanUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @author zlx
 * @Description: 控制层基类，提供获取登陆业务员等公共方法
 * @date 2019年6月22日 下午4:01:33
 */
@Slf4j
@RestController
public class BaseController {

	@Resource
	protected LocaleMessage localeMessage;

	@Resource
	protected StringRedisTemplate stringRedisTemplate;
	@Resource
	protected RelRoleResService relRoleResService;
	@Resource
	protected OperatorService operatorService;
	@Resource
	protected DictCountryService dictCountryService;
	@Resource
	protected DictCustTypeService dictCustTypeService;
	@Resource
	protected DictFlowstepService dictFlowstepService;
	@Resource
	protected DictCustGradeService dictCustGradeService;
	@Resource
	protected BasicDataValueService basicDataValueService;
	@Resource
	protected TagService tagService;
	@Resource
	protected UserGroupMemberService userGroupMemberService;
	@Resource
	protected UserGroupService userGroupService;
	@Resource
	protected DictProvinceService dictProvinceService;
	@Resource
	protected DictUnitService dictUnitService;
	@Resource
    protected CorporationService corporationService;
	@Resource
	protected AssignmentService assignmentService;
	@Resource
	protected DepartmentService departmentService;
	@Resource
	protected RoleService roleService;

	/**
	 * 获取登陆用户信息
	 * @return
	 */
	protected SessionUser getSessionUser(HttpServletRequest request) {
		SessionUser sessionUser = null;

		String joinfJsessionid = request.getHeader("joinf-jsessionid");

		log.info("joinfJsessionid:{}", joinfJsessionid);

		String sessionUserJson = stringRedisTemplate.opsForValue().get(joinfJsessionid);
		if (StringUtils.isNotBlank(sessionUserJson)) {
			sessionUser = JSON.parseObject(sessionUserJson, SessionUser.class);
		}

		return sessionUser;
	}

	/**
	 * 切换业务员
	 * @author zlx
	 * @date 2019/7/15 19:13
	 * @param request
	 * @param user
	 * @param userInfoDto
	 * @param resourceCodeList
	 * @return void
	 */
	protected void changeSessionUser(HttpServletRequest request, SessionUser user, UserInfoDto userInfoDto, List<Integer> resourceCodeList) {
		String joinfJsessionid = request.getHeader("joinf-jsessionid");

		log.info("joinfJsessionid:{}", joinfJsessionid);

		SessionUserInfo sessionUserInfo = JoinfBeanUtils.copyToNewBean(SessionUserInfo.class, userInfoDto);
		//切换业务员信息
		user.setSwitchUser(sessionUserInfo);
		//切换业务员权限
		user.setSwitchResources(resourceCodeList);

		stringRedisTemplate.opsForValue().set(joinfJsessionid, JSON.toJSONString(user),stringRedisTemplate.getExpire(joinfJsessionid), TimeUnit.SECONDS);

	}

	/**
	 * 注销用户信息
	 * @return
	 */
	protected void deleteSessionUser(HttpServletRequest request) {
		String joinfJsessionid = request.getHeader("joinf-jsessionid");

		log.info("joinfJsessionid:{}", joinfJsessionid);

		stringRedisTemplate.delete(joinfJsessionid);

	}


}
