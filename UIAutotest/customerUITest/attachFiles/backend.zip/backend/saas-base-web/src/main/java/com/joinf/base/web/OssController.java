package com.joinf.base.web;

import com.joinf.ClientConfig;
import com.joinf.JoinfClientUtils;
import com.joinf.base.request.GetOSSPolicyRequest;
import com.joinf.base.request.GetOssKeyRequest;
import com.joinf.base.response.OssPolicyResponse;
import com.joinf.config.SaasClientConfig;
import com.joinf.exception.CommonException;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.dto.session.SessionUser;
import com.joinf.utils.enums.UploadDataTypeEnum;
import com.joinf.utils.util.FileUtil;
import com.joinf.utils.util.JoinfBeanUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * @author zlx
 * @Description:  文件上传服务
 * @date 2019年6月24日 上午11:31:06
 */
@Slf4j
@Api(tags = "文件直传服务oss", description = "OssController")
@RestController
public class OssController extends BaseController {

	@Value("${file.oss.upload.callback}")
	private String fileUploadCallback;
	
	/**
	 * 获取oss签名--直传
	 * @param req
	 * @return
	 * @throws Exception 
	 */
	@ApiOperation(value="获取oss签名", notes="获取oss签名")
	@GetMapping("/oss/policy")
	public BaseResponseEntity<OssPolicyResponse> getOssPolicy(HttpServletRequest request, GetOSSPolicyRequest req) throws Exception {
		BaseResponseEntity<OssPolicyResponse> entity = new BaseResponseEntity<>();

		UploadDataTypeEnum name = UploadDataTypeEnum.getByType(req.getType());
		if(name == null){
			throw  new CommonException("类型不存在");
		}

		SessionUser user = getSessionUser(request);
		
		Long companyId = user.getUser().getCompanyId();
		
		String key = FileUtil.getFileKey(companyId.toString(), String.valueOf(req.getType()), null);
		ClientConfig config = JoinfBeanUtils.copyToNewBean(ClientConfig.class, req.getBucketType()==0?SaasClientConfig.saasClientConfig:SaasClientConfig.bigClientConfig);

		//自定义参数
		Map<String, Object> callvackVarMap = new HashMap<>();
		callvackVarMap.put("x:buckettype", req.getBucketType());

		com.alibaba.fastjson.JSONObject result = JoinfClientUtils.getPolicy(config, 1000*60*15, key, fileUploadCallback, callvackVarMap);
		OssPolicyResponse response = new OssPolicyResponse();
		response.setAccessid(result.getString("accessid"));
		response.setPolicy(result.getString("policy"));
		response.setSignature(result.getString("signature"));
		response.setDir(result.getString("dir"));
		response.setHost(result.getString("host"));
		response.setExpire(result.getString("expire"));
		response.setCallbackVar(fileUploadCallback);
		response.setCallbackSig(result.getString("callback"));
		entity.setSuccess(true);
		entity.setData(response);
		return entity;
	}
	
	/**
	 * oss回调请求--直传
	 */
	@ApiOperation(value="oss直传回调", notes="oss直传回调")
	@PostMapping("oss/callback")
	public void ossCallback(HttpServletRequest request, HttpServletResponse response) throws Exception{

		JSONObject result = new JSONObject();
		
		String ossCallbackBody = getPostBody(request.getInputStream(), Integer.parseInt(request.getHeader("content-length")));
        log.info("OSS Callback Body: {}", ossCallbackBody);

        if (ossCallbackBody != null) {
            JSONObject json = JSONObject.fromObject(ossCallbackBody);

            String key = json.getString("object");
			int buckettype = json.containsKey("buckettype")?json.getInt("buckettype"):0;

    		result.put("url", JoinfClientUtils.getUrl(buckettype==0?SaasClientConfig.saasClientConfig:SaasClientConfig.bigClientConfig,key));
    		result.put("size", json.get("size"));
    		result.put("success", true);
            
    		String results = result.toString();
    		
    		log.info("OSS Result Body: {}", results);

            String callbackFunName = request.getParameter("callback");
            response.addHeader("Content-Length", String.valueOf(results.length()));
            if (callbackFunName == null || "".equalsIgnoreCase(callbackFunName))
			{
				response.getWriter().println(results);
			}
            else{
                response.getWriter().println(callbackFunName + "( " + results + " )");
			}
        }
        response.setStatus(HttpServletResponse.SC_OK);
        response.flushBuffer();
	}
	
	
	/**
	 * 获取上传文件key
	 * @return
	 */
	@GetMapping("/oss/key")
	@ApiOperation(value="获取文件key值", notes="获取文件key值")
	public BaseResponseEntity<String> getOssKey(HttpServletRequest request, GetOssKeyRequest req){
		BaseResponseEntity<String> entity = new BaseResponseEntity<>();
		
		SessionUser user = getSessionUser(request);
		
		if(user != null){
			UploadDataTypeEnum name = UploadDataTypeEnum.getByType(req.getType());
			if(name == null){
				entity.setSuccess(false);
				entity.setErrMsg("没有找到文件类型");
			}else{
				String key = FileUtil.getFileKey(user.getUser().getCompanyId().toString(), name.name(), null)+"/"+req.getFileName();
				entity.setData(key);
				entity.setSuccess(true);
			}
		}
		return entity;
	}

	/**
	 * 获取PostBody数据
	 *
	 * @param is
	 * @param contentLen
	 * @return
	 */
	private String getPostBody(InputStream is, int contentLen) {
		if (contentLen > 0) {
			int readLen = 0;
			int readLengthThisTime = 0;
			byte[] message = new byte[contentLen];
			try {
				while (readLen != contentLen) {
					readLengthThisTime = is.read(message, readLen, contentLen - readLen);
					if (readLengthThisTime == -1) {// Should not happen.
						break;
					}
					readLen += readLengthThisTime;
				}
				return new String(message, "utf-8");
			} catch (IOException e) {
			} finally {
				if (is != null) {
					try {
						is.close();
					} catch (IOException e) {
					}
				}
			}
		}
		return "";
	}

}
