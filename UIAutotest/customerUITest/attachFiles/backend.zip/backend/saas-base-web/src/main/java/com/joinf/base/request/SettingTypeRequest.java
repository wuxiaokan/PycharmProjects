package com.joinf.base.request;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * @author CyNick
 * @Description:
 * @date 2019-08-12 14:12
 */
public class SettingTypeRequest {


    @ApiModelProperty(value ="企业ID")
    private Long companyId;
    @ApiModelProperty(value ="业务员ID")
    private Long operatorId;

    @ApiModelProperty(value ="企业个性设置类型")
    private Integer settingType;

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public Long getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(Long operatorId) {
        this.operatorId = operatorId;
    }

    public Integer getSettingType() {
        return settingType;
    }

    public void setSettingType(Integer settingType) {
        this.settingType = settingType;
    }
}
