package com.joinf.base.response;

import java.util.List;

/**
 * 
 * @description: 用户组
 * @author CyNick
 * @date 2019年7月9日 下午2:34:46
 * @revisionHistory
 */
public class UserGroupResponse {

	/**
	 * 主键
	 */
	private Long id;

	/**
	 * 名称
	 */
	private String name;

	/**
	 * 联系人
	 */
	private List<UserGroupMemberResponse> userGroupMemberResponseList;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<UserGroupMemberResponse> getUserGroupMemberResponseList() {
		return userGroupMemberResponseList;
	}

	public void setUserGroupMemberResponseList(List<UserGroupMemberResponse> userGroupMemberResponseList) {
		this.userGroupMemberResponseList = userGroupMemberResponseList;
	}
}
