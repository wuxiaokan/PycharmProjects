package com.joinf.base.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author yzq
 * @Description: 部门信息
 * @date 2019年8月5日
 */
@Getter
@Setter
@ToString
public class DepartmentResponse {
    @ApiModelProperty(value ="部门标识")
    private Long id;

    @ApiModelProperty(value ="部门名称")
    private String name;
}
