package com.joinf.base.request;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * @author CyNick
 * @Description: 查询标签
 * @date 2019-07-17 19:29
 */
public class EmailTagDtoRequest implements Serializable {

    private static final long serialVersionUID = 1L;


    @ApiModelProperty(value ="业务员ID")
    private Long operatorId;

    @ApiModelProperty(value ="业务类型(0:商机;1:客户;2:邮件;)")
    private Integer type;

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Long getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(Long operatorId) {
        this.operatorId = operatorId;
    }
}
