package com.joinf.base.dto;

import java.util.List;

import com.alibaba.fastjson.JSONObject;

/**
 * @author lyj 日志 2019年5月10日下午4:20:59
 */
public class DataAcquisitionDto {

	private Long companyId;

	private Long operatorId;

	/**
	 * 操作名称
	 */
	private String actionName;
	/**
	 * 操作类型 1 按钮，2 鼠标悬浮
	 */
	private String actionType;
	/**
	 * 操作时间
	 */
	private String actionTime;
	/**
	 * 动作触发源
	 */
	private String actionUrl;
	/**
	 * IP
	 */
	private String ip;
	/**
	 * 浏览器信息
	 */
	private String browserVersion;
	/**
	 * 参数列表
	 */
	private String acquisitionInputJson;

	private String message;

	private Object extraMessage;
	
	private String module;

	public DataAcquisitionDto() {
	}

	public DataAcquisitionDto(String module,Long companyId, Long operatorId, String actionName, String actionType,
			String actionTime, String actionUrl, String ip, String browserVersion,
			List<DataAcquisitionInputDto> inputlist, String message) {
		super();
		this.module = module;
		this.companyId = companyId;
		this.operatorId = operatorId;
		this.actionName = actionName;
		this.actionType = actionType;
		this.actionTime = actionTime;
		this.actionUrl = actionUrl;
		this.ip = ip;
		this.browserVersion = browserVersion;
		this.acquisitionInputJson = JSONObject.toJSONString(inputlist);
		this.message = message;
	}

	public DataAcquisitionDto(String message) {
		this.message = message;
	}

	public Object getExtraMessage() {
		return extraMessage;
	}

	public void setExtraMessage(Object extraMessage) {
		this.extraMessage = extraMessage;
	}

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public Long getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(Long operatorId) {
		this.operatorId = operatorId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getActionTime() {
		return actionTime;
	}

	public void setActionTime(String actionTime) {
		this.actionTime = actionTime;
	}

	public String getActionUrl() {
		return actionUrl;
	}

	public void setActionUrl(String actionUrl) {
		this.actionUrl = actionUrl;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getBrowserVersion() {
		return browserVersion;
	}

	public void setBrowserVersion(String browserVersion) {
		this.browserVersion = browserVersion;
	}

	public String getAcquisitionInputJson() {
		return acquisitionInputJson;
	}

	public void setAcquisitionInputJson(String acquisitionInputJson) {
		this.acquisitionInputJson = acquisitionInputJson;
	}
	
	

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	@Override
	public String toString() {
		return JSONObject.toJSONString(this);
	}
}
