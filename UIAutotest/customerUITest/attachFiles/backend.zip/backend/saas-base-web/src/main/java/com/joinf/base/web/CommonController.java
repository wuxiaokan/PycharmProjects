package com.joinf.base.web;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.joinf.base.dto.DictRequest;
import com.joinf.base.response.*;
import com.joinf.base.trans.TransApi;
import com.joinf.dto.*;
import com.joinf.entity.generator.*;
import com.joinf.interfaces.AssignmentService;
import com.joinf.utils.base.BaseEntityBuilder;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.dto.session.SessionUser;
import com.joinf.utils.dto.user.DepartmentTreeResponse;
import com.joinf.utils.dto.user.OperatorAssignmentDto;
import com.joinf.utils.dto.user.UserInfoDto;
import com.joinf.utils.util.BeanUtils;
import com.joinf.utils.util.JoinfBeanUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @author zlx
 * @Description: 公共基本服务
 * @date 2019年6月24日 上午11:31:06
 */
@Slf4j
@Api(tags = "公共基本服务", description = "CommonController")
@RestController
public class CommonController extends BaseController {

	public final static String COMPANYOPERATORS = "app-company-all-operators";

	@ApiOperation(value = "切换国际化语言", notes = "切换国际化语言")
	@ApiImplicitParam(name = "lang", value = "语言", paramType = "query", required = true)
	@GetMapping("/common/switchLang")
	public BaseResponseEntity<String> queryEmailDetail(HttpServletRequest request,
													   @RequestParam(value = "lang") String lang) {
		log.info("入参为：lang={}", lang);

		return BaseEntityBuilder.success(localeMessage.getMessage("welcome"));
	}


	@ApiOperation(value = "查询角色集合", notes = "查询角色集合")
	@GetMapping("/roles")
	public BaseResponseEntity<List<RoleResponse>> getRuleList(HttpServletRequest request) {
		BaseResponseEntity<List<DictTypeResponse>> entity = new BaseResponseEntity<>();
		SessionUser user = getSessionUser(request);

		List<Role> roleList =  roleService.selectByCompanyId(user.getCompanyId());
		List<RoleResponse> roleResponseList = BeanUtils.copyToNewListBean(RoleResponse.class,roleList);
		return BaseEntityBuilder.success(roleResponseList);
	}

	@ApiOperation(value = "查詢基础数据字典", notes = "查詢基础数据字典")
	@GetMapping("/dict/dataBaseValue")
	public BaseResponseEntity<List<DictTypeResponse>> getDataBaseValue(HttpServletRequest request, DictRequest req) {
		BaseResponseEntity<List<DictTypeResponse>> entity = new BaseResponseEntity<>();
		SessionUser user = getSessionUser(request);
		DictDto dictDto = new DictDto();
		dictDto.setCompanyId(user.getSwitchUser().getCompanyId());
		dictDto.setBasicDataId(req.getBasicDataId());
		dictDto.setKey(req.getKey());
		dictDto.setFlag(1);
		List<DictTypeResponse> response = getBaseDataValue(dictDto);
		entity.setData(response);
		entity.setSuccess(true);
		return entity;
	}

	@ApiOperation(value = "查詢基础数据字典（全部）", notes = "查詢基础数据字典（全部）")
	@GetMapping("/dict/dataBaseValueAll")
	public BaseResponseEntity<DictTypeListResponse> getDataBaseValueAll(HttpServletRequest request) {
		// 基础数据ID: [1] 客户类型,[2] 客户分类,[3]国家/地区,[4] 开户银行,[5] 客户来源,[6] "
		// + "业务类型,[7] 主营产品,[8] 跟进阶段,[9] 统计单位,[10] 币种,[11] 付款条件,[12] "
		// + "价格条款,[14] 提醒时间,[15] 客户等级,[16] 性别,[17] 联系人状态,[18] 运输方式,"
		// + "[19] 佣金方法,[20] 运费计算方式,[22] 计算类型,[23] 计算方式,[24] 日期方式,[26] 职务,"
		// + "[27] 计量单位,[28] 港口,[29] 省份,[34] 尾款付款方式,[36] 颜色,[37] 网店币种,[38]
		// 网店单位,"
		// + "[42] 跟进方式,[44] 包装方式,[46] 丢单原因

		BaseResponseEntity<DictTypeListResponse> entity = new BaseResponseEntity<>();
		SessionUser user = getSessionUser(request);
		DictDto dictDto = new DictDto();
		dictDto.setFlag(1);
		dictDto.setCompanyId(user.getSwitchUser().getCompanyId());
		// @ApiModelProperty(value = "主营产品")
		dictDto.setBasicDataId(7L);
		List<DictTypeResponse> mainProductResponse = getBaseDataValue(dictDto);
		// @ApiModelProperty(value = "跟进阶段")
		dictDto.setBasicDataId(8L);
		List<DictTypeResponse> folloStepResponse = getBaseDataValue(dictDto);
		// @ApiModelProperty(value = "客户类型")
		dictDto.setBasicDataId(1L);
		List<DictTypeResponse> custTypeResponse = getBaseDataValue(dictDto);
		// @ApiModelProperty(value = "客户等级")
		dictDto.setBasicDataId(15L);
		List<DictTypeResponse> custGradeResponse = getBaseDataValue(dictDto);
		// @ApiModelProperty(value = "客户来源")
		dictDto.setBasicDataId(5L);
		List<DictTypeResponse> custSourceResponse = getBaseDataValue(dictDto);
		// @ApiModelProperty(value = "客户标签")
//		dictDto.setBasicDataId(7L);
//		List<DictTypeResponse> custTagResponse = getBaseDataValue(dictDto);
		// @ApiModelProperty(value = "洲")
		List<DictTypeResponse> continentResponse = new ArrayList<DictTypeResponse>();
		List<DictCountry> dictList = dictCountryService.selectCountryDistrict();
		for(DictCountry cou : dictList){
			DictTypeResponse re = new DictTypeResponse();
			re.setCname(cou.getDistrict());
			continentResponse.add(re);
		}
		// @ApiModelProperty(value = "国家地区")
		dictDto.setBasicDataId(3L);
		List<DictTypeResponse> countryResponse = getBaseDataValue(dictDto);
		// @ApiModelProperty(value = "业务类型")
		dictDto.setBasicDataId(6L);
		List<DictTypeResponse> businessResponse = getBaseDataValue(dictDto);
		DictTypeListResponse res = new DictTypeListResponse();
		res.setMainProductResponse(mainProductResponse);
		res.setFolloStepResponse(folloStepResponse);
		res.setCustTypeResponse(custTypeResponse);
		res.setCustGradeResponse(custGradeResponse);
		res.setCustSourceResponse(custSourceResponse);
		res.setCountryResponse(countryResponse);
		res.setBusinessResponse(businessResponse);
		res.setContinentResponse(continentResponse);
		entity.setData(res);
		entity.setSuccess(true);
		return entity;
	}

	private List<DictTypeResponse> getBaseDataValue(DictDto dictDto) {

		List<BasicDataValue> list = this.basicDataValueService.selectBaseDataValue(dictDto);
		log.info(JSON.toJSONString(list));
		List<DictTypeResponse> response = new ArrayList<DictTypeResponse>();
		for (BasicDataValue bd : list) {
			DictTypeResponse dr = new DictTypeResponse();
			dr.setId(bd.getId());
			dr.setCname(bd.getChineseName());
			dr.setEname(bd.getEnglishName());
			response.add(dr);
		}
		return response;
	}

	/**
	 *
	 * 内部联系人用户组
	 * @author CyNick
	 * @date 2019年7月9日 上午11:12:08
	 * @param request
	 * @return
	 */
	@GetMapping("/inner/group")
	@ApiOperation(value="内部联系人用户组", notes="内部联系人用户组")
	public BaseResponseEntity<List<UserGroupDTO>> innerGroup(HttpServletRequest request){

		SessionUser user = getSessionUser(request);
		UserGroupRequestDto dto = new UserGroupRequestDto();
		dto.setCompanyId(user.getSwitchUser().getCompanyId());
		List<UserGroupDTO> list = userGroupService.selectUserGroupList(dto);
		return BaseEntityBuilder.success(list);
	}


	/**
	 *
	 * 内部联系人
	 * @author CyNick
	 * @date 2019年7月9日 上午11:12:08
	 * @param request
	 * @param groupId
	 * @return
	 */
	@ApiImplicitParam(name = "groupId", value = "分组Id", paramType = "path", required = false)
	@GetMapping("/inners")
	@ApiOperation(value="通过分组ID获取内部联系人", notes="通过分组ID获取内部联系人(不传groupI的情况下，只查询业务员)")
	public BaseResponseEntity<List<UserGroupMemberResponse>> inners(HttpServletRequest request,Long groupId){

		SessionUser user = getSessionUser(request);

		QueryUserGroupMemberDto reqDto = new QueryUserGroupMemberDto();
		reqDto.setCompanyId(user.getSwitchUser().getCompanyId());
		reqDto.setGroupId(groupId);
		//重新组装用户列表
		List<UserGroupMemberDTO> list = userGroupMemberService.getUserGroupMemberList(reqDto);
		//去除list 中的重复数据
		list = list.stream().collect(
				Collectors.collectingAndThen(Collectors.toCollection(
						() -> new TreeSet<>(Comparator.comparing(o -> o.getMemberId()))), ArrayList::new));

		List<UserGroupMemberResponse> res = BeanUtils.copyToNewListBean(UserGroupMemberResponse.class, list);

		return BaseEntityBuilder.success(list, res);
	}


	/**
	 * 公司列表
	 * @author CyNick
	 * @date 2019-07-13  14:11
	 * @param
	 * @return
	 */
	@GetMapping("/company/corporations")
	@ApiOperation(value="获取公司列表", notes="获取公司列表")
	public BaseResponseEntity<List<CorporationResponse>> inners(HttpServletRequest request){
		SessionUser user = getSessionUser(request);
		List<Corporation> corporationList = corporationService.selectByCompanyId(user.getUser().getCompanyId());

		List<CorporationResponse> responseList = BeanUtils.copyToNewListBean(CorporationResponse.class,corporationList);
		return BaseEntityBuilder.success(responseList);
	}

	/**
	 *
	 * 内部联系人
	 * @author CyNick
	 * @date 2019年7月9日 上午11:12:08
	 * @param request
	 * @param corporationId
	 * @return
	 */
	@ApiImplicitParam(name = "corporationId", value = "公司ID", paramType = "path", required = true)
	@GetMapping("/corporation/inners/{corporationId}")
	@ApiOperation(value="通过公司ID获取内部联系人", notes="通过公司ID获取内部联系人")
	public BaseResponseEntity<List<UserGroupMemberResponse>> getCorporationsInner(HttpServletRequest request, @PathVariable(value = "corporationId") Long corporationId){

		SessionUser user = getSessionUser(request);
		//重新组装用户列表
		List<UserGroupMemberDTO> list = userGroupMemberService.getInnerUserListByCorporationId(user.getUser().getCompanyId(),corporationId);

		List<UserGroupMemberResponse> res = BeanUtils.copyToNewListBean(UserGroupMemberResponse.class, list);

		return BaseEntityBuilder.success(list, res);
	}

	@GetMapping("/operator/tree")
	@ApiOperation(value = "获取业务员选择树结构",notes = "获取业务员选择树结构")
	public BaseResponseEntity<List<DepartmentTreeResponse>> getOperatorChoiceTree(HttpServletRequest request){

		SessionUser user = getSessionUser(request);

		List<OperatorAssignmentDto> operatorAssignmentDtoList = addCompanyOperatorsToSession(request);

		List<DepartmentTreeResponse> dto = operatorService.getOperatorChoiceTree(user,operatorAssignmentDtoList);

		return BaseEntityBuilder.success(dto);
	}


	/**
	 * 封装业务员参数
	 *
	 * @param request
	 * @return
	 */
	private List<OperatorAssignmentDto> addCompanyOperatorsToSession(HttpServletRequest request){
		List<OperatorAssignmentDto> dataList = new ArrayList<>();
		SessionUser user = getSessionUser(request);
		List<UserInfoDto> userInfoDtoList = getOperatorAssignment(user.getCompanyId(),user.getSwitchOperatorId(),1);
		for (UserInfoDto userInfo : userInfoDtoList) {
			OperatorAssignmentDto o = JoinfBeanUtils.copyToNewBean(OperatorAssignmentDto.class, userInfo);
			o.setId(userInfo.getId());
			o.setDepartment(userInfo.getDepartment());
			if (userInfo.getParentId() == null || userInfo.getParentId().equals(userInfo.getCenterUserId())) {
				o.setIsAdmin(1);
			} else {
				o.setIsAdmin(0);
			}
			dataList.add(o);
		}
		return dataList;
	}

	private List<UserInfoDto> getOperatorAssignment(Long companyId,Long operatorId,int type){
		List<UserInfoDto> users = new ArrayList<UserInfoDto>();
		String key = String.format(AssignmentService.OPERATOR_ASSIGNMENT_USERS, companyId,operatorId);
		if(stringRedisTemplate.hasKey(key)){
			String value = stringRedisTemplate.opsForValue().get(key);
			JSONArray array = JSONArray.parseArray(value);
			UserInfoDto info;
			for(int i=0;i<array.size();i++){
				JSONObject ob = array.getJSONObject(i);
				info = JSONObject.toJavaObject(ob, UserInfoDto.class);
				if (type == 1 || info.getId().longValue() != operatorId.longValue()) {
					users.add(info);
				}
			}
		}else{//切换用户的时候可能不存在--重新获取
			List<UserInfoDto> datas = assignmentService.selectAssignmentUserList(companyId, operatorId);
			stringRedisTemplate.opsForValue().set(key, JSONArray.toJSONString(datas), 120, TimeUnit.HOURS);
			for(UserInfoDto user :datas){
				if (type == 1 || user.getId().longValue() != operatorId.longValue()) {
					users.add(user);
				}
			}
		}
		return users;
	}

	@GetMapping("/company/department")
	@ApiOperation(value="获取部门列表", notes="获取部门列表")
	public BaseResponseEntity<List<DepartmentResponse>> getDepartment(HttpServletRequest request){
		SessionUser user = getSessionUser(request);

		//企业下所有部门，并重新赋值
		List<Department> departmentList = departmentService.selectByCompanyId(user.getCompanyId());

		List<DepartmentResponse> responseList = BeanUtils.copyToNewListBean(DepartmentResponse.class,departmentList);

		return BaseEntityBuilder.success(responseList);
	}


	@ApiOperation(value = "文件翻译")
	@ApiImplicitParam(name = "type", value = "0:后端properties文件 1:前端预约包脚本文件", paramType = "query", required = true)
	@PostMapping(value = "/file/trans")
	@ResponseBody
	public void uploadAttachment(HttpServletResponse response, MultipartFile file, int type) throws IOException {
		log.info("type:{}", type);

		response.setCharacterEncoding("utf-8");
		PrintWriter writer = response.getWriter();

		//所有的原信息
		List<String> orgStr = new ArrayList<>();
		//待翻译的文本
		StringBuffer waitTransText = new StringBuffer();

		TransApi api = new TransApi("20190816000326976", "MbC9uVYj25iLlVaMIrN7");

		InputStreamReader inputReader = new InputStreamReader(file.getInputStream());
		BufferedReader bf = new BufferedReader(inputReader);
		// 按行读取字符串
		List<String> stringList = new ArrayList<>();
		String str;
		while ((str = bf.readLine()) != null) {
			stringList.add(str);

			//前端脚本文件
			if(type == 1){
				if(str.indexOf("'") != -1){
					String test = str.substring(str.indexOf("'")+1, str.lastIndexOf("'"));
					String tag = str.substring(str.indexOf("\"") + 1, str.lastIndexOf(":"));
					log.info("test:{},tag:{}",test,tag);
					//使用-;-分隔
					if (waitTransText.length() > 0){
						waitTransText.append("\r\n");
					}
					waitTransText.append(test);
					orgStr.add(tag);
				}

			}
			//后端properties文件
			else{
				String[] pr = str.split("=");
				if(pr.length > 1){
					//使用-;-分隔
					if (waitTransText.length() > 0){
						waitTransText.append("\r\n");
					}
					waitTransText.append(pr[1]);
					orgStr.add(pr[0]);
				}
			}
		}

		String transStr = api.getTransResult(waitTransText.toString(), "zh", "en");
//		log.info("str:{}", waitTransText.toString());
//		log.info("transStr:{}", transStr);


		Map<String,String> orMap = transPc(orgStr,transStr);
		String orSb = null;

		StringBuffer ssb = new StringBuffer();
		if (type == 1){


			for (String s : stringList){
				if(s.indexOf("'") != -1){
					String test = s.substring(s.indexOf("'")+1, s.lastIndexOf("'"));
					String tag = s.substring(s.indexOf("\"") + 1, s.lastIndexOf(":"));


					String retest = orMap.get(tag);

					s = s.replace(test,retest);
				}

				if (ssb.length()>0){
					ssb.append("\r\n");
				}
				ssb.append(s);
			}
			orSb = ssb.toString();
		}else{
			for (String s : stringList){
				String[] pr = s.split("=");
				if(pr.length > 1){
					//使用-;-分隔
					if (waitTransText.length() > 0){
						waitTransText.append("\r\n");
					}

					String test = pr[1];
					String tag = pr[0];

					String retest = orMap.get(tag);

					s = s.replace(test,retest);
					log.info("{}",s);

				}
				if (ssb.length()>0){
					ssb.append("\r\n");
				}
				ssb.append(s);
			}
			orSb = ssb.toString();
		}

		writer.write(orSb);

		bf.close();
		inputReader.close();
	}


	private Map<String,String> transPc(List<String> orgStr ,String transStr){
		JSONObject jsonObject = JSON.parseObject(transStr);

		JSONArray array = jsonObject.getJSONArray("trans_result");

		StringBuffer orSb = new StringBuffer();
		//翻译后的文件
		String[] dst = new String[array.size()];
		int i = 0;
		for (Object obj : array){
			JSONObject dstJson = JSON.parseObject(String.valueOf(obj));

			dst[i] = dstJson.get("dst").toString();
			i++;

		}

		Map<String,String> map = new HashMap<>();

		int j = 0;
		for (String or : orgStr){

			map.put(or,dst[j]);

			if (orSb.length() > 0){
				orSb.append("\r\n");
			}
			orSb.append(or);
			orSb.append("=");
			orSb.append(dst[j]);
//			log.info("翻译后的：{}",orSb.toString());
			j++;
		}

		return  map;
	}
}
