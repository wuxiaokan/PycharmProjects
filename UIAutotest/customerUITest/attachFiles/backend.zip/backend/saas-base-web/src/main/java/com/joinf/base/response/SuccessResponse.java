package com.joinf.base.response;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 是否成功返回对象
 * @date 2018年4月11日 上午9:59:40
 */
public class SuccessResponse {
	
	@ApiModelProperty(value="是否成功",required=true)
	private boolean success = true;
	
	@ApiModelProperty(value="错误信息",required=true)
	private String error;
	
	public SuccessResponse(){}
	
	public SuccessResponse(boolean success){
		this.success = success;
	}
	public SuccessResponse(boolean success,String error){
		this.success = success;
		this.error = error;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
}
