package com.joinf.base.config.datasource;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.alibaba.druid.pool.DruidDataSource;
import com.dangdang.ddframe.rdb.sharding.api.MasterSlaveDataSourceFactory;
import com.dangdang.ddframe.rdb.sharding.api.ShardingDataSourceFactory;
import com.dangdang.ddframe.rdb.sharding.api.rule.DataSourceRule;
import com.dangdang.ddframe.rdb.sharding.api.rule.ShardingRule;

/**
 * @author zlx
 * @Description: 分表数据源配置
 * @date 2018年1月5日 下午2:52:50
 */
@Configuration
@EnableConfigurationProperties
public class DataSourceConfig {
	@Autowired
	private DatasourceMasterProperties masterProperties;
	@Autowired
	private DatasourceSlave0Properties slave0Properties;
	@Autowired
	private DatasourceSlave1Properties slave1Properties;
	
	private final Map<String, DataSource> dataSourceMap = new HashMap<>();
	
	@Bean(name = "dataSource")
    public DataSource testDataSource() {
		
        // 主从库配置
        DataSource dataSource = MasterSlaveDataSourceFactory.createDataSource("dataSource",
        		createMasterDataSource(), //主库
        		createSlave0DataSource(), //从库0
        		createSlave1DataSource() //从库1
        		);
        
        dataSourceMap.put("db_master", dataSource);
        
        DataSourceRule dataSourceRule = new DataSourceRule(dataSourceMap);
    	
    	ShardingRule shardingRule = ShardingRule.builder()
    			.dataSourceRule(dataSourceRule)
    	        .build();
    	        
        return ShardingDataSourceFactory.createDataSource(shardingRule);
    }
	
	/**
	 * 创建主数据源
	 * @return
	 */
	private DruidDataSource createMasterDataSource(){
		DruidDataSource dataSource = new DruidDataSource();
		dataSource.setUrl(masterProperties.getUrl());
		dataSource.setUsername(masterProperties.getUsername());
		dataSource.setPassword(masterProperties.getPassword());
		
		dataSource.setDriverClassName(masterProperties.getCommon().getDriverClassName());
		dataSource.setInitialSize(masterProperties.getCommon().getInitialSize());
		dataSource.setMinIdle(masterProperties.getCommon().getMinIdle());
		dataSource.setMaxActive(masterProperties.getCommon().getMaxActive());
		dataSource.setMaxWait(masterProperties.getCommon().getMaxWait());
		dataSource.setTimeBetweenEvictionRunsMillis(masterProperties.getCommon().getTimeBetweenEvictionRunsMillis());
		dataSource.setMinEvictableIdleTimeMillis(masterProperties.getCommon().getMinEvictableIdleTimeMillis());
		dataSource.setValidationQuery(masterProperties.getCommon().getValidationQuery());
		dataSource.setTestWhileIdle(masterProperties.getCommon().getTestWhileIdle());
		dataSource.setTestOnBorrow(masterProperties.getCommon().getTestOnBorrow());
		dataSource.setTestOnReturn(masterProperties.getCommon().getTestOnReturn());
		dataSource.setPoolPreparedStatements(masterProperties.getCommon().getPoolPreparedStatements());
		dataSource.setMaxPoolPreparedStatementPerConnectionSize(masterProperties.getCommon().getMaxPoolPreparedStatementPerConnectionSize());
		try {
			dataSource.setFilters(masterProperties.getCommon().getFilters());
		} catch (SQLException e) {}
		dataSource.setConnectionProperties(masterProperties.getCommon().getConnectionProperties());
		return dataSource;
	}
	
	/**
	 * 创建从数据源1
	 * @return
	 */
	private DruidDataSource createSlave0DataSource(){
		DruidDataSource dataSource = new DruidDataSource();
		dataSource.setUrl(slave0Properties.getUrl());
		dataSource.setUsername(slave0Properties.getUsername());
		dataSource.setPassword(slave0Properties.getPassword());
		
		dataSource.setDriverClassName(slave0Properties.getCommon().getDriverClassName());
		dataSource.setInitialSize(slave0Properties.getCommon().getInitialSize());
		dataSource.setMinIdle(slave0Properties.getCommon().getMinIdle());
		dataSource.setMaxActive(slave0Properties.getCommon().getMaxActive());
		dataSource.setMaxWait(slave0Properties.getCommon().getMaxWait());
		dataSource.setTimeBetweenEvictionRunsMillis(slave0Properties.getCommon().getTimeBetweenEvictionRunsMillis());
		dataSource.setMinEvictableIdleTimeMillis(slave0Properties.getCommon().getMinEvictableIdleTimeMillis());
		dataSource.setValidationQuery(slave0Properties.getCommon().getValidationQuery());
		dataSource.setTestWhileIdle(slave0Properties.getCommon().getTestWhileIdle());
		dataSource.setTestOnBorrow(slave0Properties.getCommon().getTestOnBorrow());
		dataSource.setTestOnReturn(slave0Properties.getCommon().getTestOnReturn());
		dataSource.setPoolPreparedStatements(slave0Properties.getCommon().getPoolPreparedStatements());
		dataSource.setMaxPoolPreparedStatementPerConnectionSize(slave0Properties.getCommon().getMaxPoolPreparedStatementPerConnectionSize());
		try {
			dataSource.setFilters(slave0Properties.getCommon().getFilters());
		} catch (SQLException e) {}
		dataSource.setConnectionProperties(slave0Properties.getCommon().getConnectionProperties());
		return dataSource;
	}
	
	/**
	 * 创建从数据源2
	 * @return
	 */
	private DruidDataSource createSlave1DataSource(){
		DruidDataSource dataSource = new DruidDataSource();
		dataSource.setUrl(slave1Properties.getUrl());
		dataSource.setUsername(slave1Properties.getUsername());
		dataSource.setPassword(slave1Properties.getPassword());
		
		dataSource.setDriverClassName(slave1Properties.getCommon().getDriverClassName());
		dataSource.setInitialSize(slave1Properties.getCommon().getInitialSize());
		dataSource.setMinIdle(slave1Properties.getCommon().getMinIdle());
		dataSource.setMaxActive(slave1Properties.getCommon().getMaxActive());
		dataSource.setMaxWait(slave1Properties.getCommon().getMaxWait());
		dataSource.setTimeBetweenEvictionRunsMillis(slave1Properties.getCommon().getTimeBetweenEvictionRunsMillis());
		dataSource.setMinEvictableIdleTimeMillis(slave1Properties.getCommon().getMinEvictableIdleTimeMillis());
		dataSource.setValidationQuery(slave1Properties.getCommon().getValidationQuery());
		dataSource.setTestWhileIdle(slave1Properties.getCommon().getTestWhileIdle());
		dataSource.setTestOnBorrow(slave1Properties.getCommon().getTestOnBorrow());
		dataSource.setTestOnReturn(slave1Properties.getCommon().getTestOnReturn());
		dataSource.setPoolPreparedStatements(slave1Properties.getCommon().getPoolPreparedStatements());
		dataSource.setMaxPoolPreparedStatementPerConnectionSize(slave1Properties.getCommon().getMaxPoolPreparedStatementPerConnectionSize());
		try {
			dataSource.setFilters(slave1Properties.getCommon().getFilters());
		} catch (SQLException e) {}
		dataSource.setConnectionProperties(slave1Properties.getCommon().getConnectionProperties());
		return dataSource;
	}

}