package com.joinf.base.response;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 扩展类
 *
 * @author lyj
 * @date 2017年12月8日 上午10:06:53
 */
public class DictTypeResponse {

	@ApiModelProperty(value = "id")
	private Long id;

	@ApiModelProperty(value = "中文名称")
	private String cname;

	@ApiModelProperty(value = "英文名称")
	private String ename;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

}
