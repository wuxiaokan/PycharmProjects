package com.joinf.base.feign.web;

import com.joinf.base.web.BaseController;
import com.joinf.dto.DictDto;
import com.joinf.dto.IdAndNameDto;
import com.joinf.entity.DictCustTypeEx;
import com.joinf.entity.generator.BasicDataValue;
import com.joinf.entity.generator.DictCountry;
import com.joinf.entity.generator.DictCustGrade;
import com.joinf.entity.generator.DictFlowstep;
import com.joinf.entity.generator.DictUnit;
import com.joinf.utils.util.StringUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * 字典服务
 *
 * @author yzq
 * @date 2019-06-27
 */
@Slf4j
@Api(tags="字典服务", description = "DictFeignController")
@RequestMapping("/feign")
@RestController
public class DictFeignController extends BaseController {


	@ApiOperation(value = "查询国家字典", notes = "查询国家字典")
	@ApiImplicitParam(name = "ids[]", value = "主键ids", paramType = "path", required = true)
	@GetMapping("/dict/countries/{ids}")
	public List<DictCountry> queryDictCountryByIds(@PathVariable(value = "ids") String ids){
		log.info("入参为：ids={}", ids);
		return dictCountryService.selectByIds(StringUtil.stringToList(ids));
	}

	@ApiOperation(value = "查询客户类型字典", notes = "查询客户类型字典")
	@ApiImplicitParam(name = "companyId", value = "企业id", paramType = "path", required = true)
	@GetMapping("/dict/customerTypes/{companyId}")
	public List<DictCustTypeEx> queryCustomerTypeByCompanyId(@PathVariable(value = "companyId")Long companyId){
		log.info("入参为：ids={}", companyId);
		DictDto dictDto = new DictDto();
		dictDto.setCompanyId(companyId);
		return this.dictCustTypeService.selectByCompanyId(dictDto);
	}
	
	
	@ApiOperation(value = "通过洲，查询国家地区", notes = "通过洲，查询国家地区")
	@ApiImplicitParam(name = "district", value = "洲", paramType = "path", required = true)
	@GetMapping("/dict/countriesBydistrict/{district}")
	public List<DictCountry> selectCountryByDistrict(@PathVariable(value = "district")String district){
		log.info("入参为：洲={}", district);
		return this.dictCountryService.selectCountryByDistrict(district);
	}
	
	
	@ApiOperation(value = "客户来源,查询有客户的类型信息", notes = "查询有客户的类型信息")
	@PostMapping("/dict/getBasicHasCustomerDict")
	@ResponseBody
	public List<BasicDataValue> getBasicHasCustomerDict(HttpServletRequest request, @RequestBody DictDto dto){
		return this.basicDataValueService.selectHasCustomerDict(dto);
	}
	
	@ApiOperation(value = "客户等级,查询有客户的类型信息", notes = "查询有客户的类型信息")
	@PostMapping("/dict/getCustGradeHasCustomerDict")
	@ResponseBody
	public List<DictCustGrade> getCustGradeHasCustomerDict(HttpServletRequest request, @RequestBody DictDto dto){
		return this.dictCustGradeService.selectHasCustomerDict(dto);
	}
	
	@ApiOperation(value = "客户国家地区,查询有客户的类型信息", notes = "查询有客户的类型信息")
	@PostMapping("/dict/getCountryHasCustomerDict")
	@ResponseBody
	public List<DictCountry> getCountryHasCustomerDict(HttpServletRequest request, @RequestBody DictDto dto){
		return this.dictCountryService.selectHasCustomerDict(dto);
	}
	
	@ApiOperation(value = "客户跟进阶段,查询有客户的类型信息", notes = "查询有客户的类型信息")
	@PostMapping("/dict/getFollowStepHasCustomerDict")
	@ResponseBody
	public List<DictFlowstep> getFollowStepHasCustomerDict(HttpServletRequest request, @RequestBody DictDto dto){
		return this.dictFlowstepService.selectHasCustomerDict(dto);
	}

	@ApiOperation(value = "客户跟进阶段有效列表", notes = "客户跟进阶段有效列表")
	@GetMapping("/dict/getFollowStepCustomerDicts/{companyId}")
	public List<DictFlowstep> getFollowStepCustomerDicts(HttpServletRequest request,@PathVariable("companyId")Long companyId) {
		DictDto dictDto = new DictDto();
		dictDto.setCompanyId(companyId);
		dictDto.setFlag(1);
		return this.dictFlowstepService.selectByCompanyId(dictDto);
	}
	
	@ApiOperation(value = "客户类型,查询有客户的类型信息", notes = "查询有客户的类型信息")
	@PostMapping("/dict/getCusTypeHasCustomerDict")
	@ResponseBody
	public List<DictCustTypeEx> getCusTypeHasCustomerDict(HttpServletRequest request, @RequestBody DictDto dto){
		return this.dictCustTypeService.selectHasCustomerDict(dto);
	}
	
	@ApiOperation(value = "供应商 国家地区,查询有客户的类型信息", notes = "查询有供应商的类型信息")
	@PostMapping("/dict/getSupplierCountryHasCustomerDict")
	@ResponseBody
	public List<IdAndNameDto> getSupplierCountryHasCustomerDict(HttpServletRequest request, @RequestBody DictDto dto){
		return this.dictCountryService.selectHasSupplierDictCountry(dto);
	}
	
	@ApiOperation(value = "供应商 省份,查询有客户的类型信息", notes = "查询有供应商的类型信息")
	@PostMapping("/dict/getSupplierProvinceHasCustomerDict")
	@ResponseBody
	public List<IdAndNameDto> getSupplierProvinceHasCustomerDict(HttpServletRequest request, @RequestBody DictDto dto){
		return this.dictProvinceService.selectHasSupplierDictProvince(dto);
	}
	
	@ApiOperation(value = "供应商 主营产品,查询有客户的类型信息", notes = "查询有供应商的类型信息")
	@PostMapping("/dict/getSupplierMainProductHasCustomerDict")
	@ResponseBody
	public List<IdAndNameDto> getSupplierMainProductHasCustomerDict(HttpServletRequest request, @RequestBody DictDto dto){
		return this.basicDataValueService.selectHasSupplierDictMainProduct(dto.getCompanyId(), dto.getMainProductArray());
	}
	
	@ApiOperation(value = "供应商类型,查询有客户的类型信息", notes = "查询有供应商的类型信息")
	@PostMapping("/dict/getSupplierTypeHasCustomerDict")
	@ResponseBody
	public List<IdAndNameDto> getSupplierTypeHasCustomerDict(HttpServletRequest request, @RequestBody DictDto dto){
		return this.basicDataValueService.selectHasSupplierDictType(dto.getCompanyId(), dto.getOperatorId());
	}

	@ApiOperation(value = "查询单位字典", notes = "查询单位字典")
	@ApiImplicitParam(name = "ids[]", value = "主键ids", paramType = "path", required = true)
	@GetMapping("/dict/units/{ids}")
	public List<DictUnit> queryDictUnitByIds(@PathVariable(value = "ids") String ids){
		log.info("入参为：ids={}", ids);
		return dictUnitService.selectByIds(StringUtil.stringToList(ids));
	}

	@ApiOperation(value = "查询业务类型字典数据", notes = "查询业务类型字典数据")
	@PostMapping("/dict/getBusinessTypeListByParam")
	public List<IdAndNameDto> getBusinessTypeListByParam(HttpServletRequest request, @RequestBody DictDto dto){
		dto.setBasicDataId(6L);
		return this.basicDataValueService.selectBasicDataValueListByParam(dto);
	}
}
