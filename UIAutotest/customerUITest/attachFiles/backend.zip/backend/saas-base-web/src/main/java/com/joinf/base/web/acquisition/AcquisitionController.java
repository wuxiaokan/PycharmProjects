package com.joinf.base.web.acquisition;

import com.joinf.base.dto.DataAcquisitionDto;
import com.joinf.base.dto.DataAcquisitionInputDto;
import com.joinf.base.request.AcquisitionRequest;
import com.joinf.utils.base.BaseEntityBuilder;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.util.BeanUtils;
import com.joinf.utils.util.CheckingUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * 
 * @description: 数据埋点采集
 * @author CyNick
 * @date 2019年7月2日 下午7:15:39
 * @revisionHistoryhttps://api01.aliyun.venuscn.com
 */

@Slf4j
@Api(tags = "数据埋点采集", description = "AcquisitionController")
@RestController
public class AcquisitionController {

	/**
	 * 
	 * @description: 数据埋点采集
	 * @author CyNick
	 * @date 2019年7月2日 下午7:17:23
	 * @param @param
	 *            json
	 * @param @return
	 * @param @throws
	 *            ParseException
	 */
	@ApiOperation(value = "数据埋点采集", notes = "数据埋点采集")
	@PutMapping("acquistion/acquisitionSave")
	@ResponseBody
	public BaseResponseEntity<?> acquisitionSave(HttpServletRequest request, @RequestBody List<AcquisitionRequest> req) {

			try {

				String ip = CheckingUtil.getIpAddress(request);
				String browserVersion = CheckingUtil.getUserAgent(request);

				for (AcquisitionRequest acquisitionRequest : req) {
					Long companyId = acquisitionRequest.getCompanyId();
					Long operatorId = acquisitionRequest.getOperatorId();
					String actionName = acquisitionRequest.getActionName();
					String actionType = acquisitionRequest.getActionType();
					String actionTime = acquisitionRequest.getActionTime();
					String actionUrl = acquisitionRequest.getActionUrl();
					String message = acquisitionRequest.getMessage();
					List<DataAcquisitionInputDto> inputlist = BeanUtils.copyToNewListBean(DataAcquisitionInputDto.class,acquisitionRequest.getInputDataList());
					log.info("{}", new DataAcquisitionDto("tmsLog",companyId, operatorId, actionName, actionType, actionTime,
							actionUrl, ip, browserVersion, inputlist, message));
				}
			} catch (Exception e) {
						log.error("msgDetailListJson exception", e);
			}
		return BaseEntityBuilder.success();

	}

}
