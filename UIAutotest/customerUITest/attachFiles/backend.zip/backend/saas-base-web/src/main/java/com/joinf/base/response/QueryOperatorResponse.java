package com.joinf.base.response;

import java.io.Serializable;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.joinf.utils.util.LongJsonDeserializer;
import com.joinf.utils.util.LongJsonSerializer;

import io.swagger.annotations.ApiModelProperty;

/**
 * 业务员下拉返回值
 *
 * @author yzq
 * @date 2019-04-18
 */
public class QueryOperatorResponse implements Serializable {

    private static final long serialVersionUID = -100002979933957374L;

    @JsonSerialize(using = LongJsonSerializer.class)
    @JsonDeserialize(using = LongJsonDeserializer.class)
    @ApiModelProperty(value = "业务员id")
    private Long operatorId;
    
    @ApiModelProperty(value = "用户名")
    private String loginName;

    @ApiModelProperty(value = "业务员中文名")
    private String operatorName;
    
    @ApiModelProperty(value = "部门名称  示例：  xxxx公司 -> 部门A -> 部门B")
    private String departmentName;
    
    
    public QueryOperatorResponse() {
		super();
	}

	public QueryOperatorResponse(Long operatorId, String operatorName, String loginName, String departmentName) {
        this.operatorId = operatorId;
        this.operatorName = operatorName;
        this.loginName = loginName;
        this.departmentName = departmentName;
    }

    public Long getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(Long operatorId) {
        this.operatorId = operatorId;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
    
    

}
