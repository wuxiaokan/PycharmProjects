package com.joinf.request.business;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @author zlx
 * @Description: 线索建档保存
 * @date 2019年4月25日 下午2:16:04
 */
public class SaveClueFilingRequest implements Serializable {

    private static final long serialVersionUID = 197540694897823242L;
    
    @ApiModelProperty(value = "所有选中的线索ID")
    private Long[] clueIds;
    
    @ApiModelProperty(value = "当前处理的线索ID")
    private Long clueId;
    
    @ApiModelProperty(value = "分配业务员ID")
    private Long allocationUserId;
    
    @ApiModelProperty(value = "客户信息")
    private SaveClueFilingCustomerRequest customer;
    
    @ApiModelProperty(value = "商机信息")
    private SaveClueFilingBusinessRequest business;


    public Long[] getClueIds() {
		return clueIds;
	}

	public void setClueIds(Long[] clueIds) {
		this.clueIds = clueIds;
	}

	public Long getClueId() {
		return clueId;
	}

	public void setClueId(Long clueId) {
		this.clueId = clueId;
	}
	
	
	public Long getAllocationUserId() {
		return allocationUserId;
	}

	public void setAllocationUserId(Long allocationUserId) {
		this.allocationUserId = allocationUserId;
	}

	public SaveClueFilingCustomerRequest getCustomer() {
		return customer;
	}

	public void setCustomer(SaveClueFilingCustomerRequest customer) {
		this.customer = customer;
	}

	public SaveClueFilingBusinessRequest getBusiness() {
		return business;
	}

	public void setBusiness(SaveClueFilingBusinessRequest business) {
		this.business = business;
	}

	@Override
	public String toString() {
		return "SaveClueFilingRequest [clueId=" + clueId + ", allocationUserId=" + allocationUserId + ", customer="
				+ customer + ", business=" + business + "]";
	}
	
}
