package com.joinf.request.business;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.List;

/**
 * 更新线索状态请求参数
 *
 * @author yzq
 * @date 2019-04-20
 */
public class QueryUpdateClueStatusRequest implements Serializable {

    private static final long serialVersionUID = 197540694897823242L;

    @ApiModelProperty(value = "线索标记List",required=true)
    private List<Long> id;

    @ApiModelProperty(value = "0:设置忽略;1:取消忽略",required=true)
    private Integer type;

    public List<Long> getId() {
        return id;
    }

    public void setId(List<Long> id) {
        this.id = id;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "QueryUpdateClueStatusRequest{" +
                "id=" + id +
                ", type=" + type +
                '}';
    }
}
