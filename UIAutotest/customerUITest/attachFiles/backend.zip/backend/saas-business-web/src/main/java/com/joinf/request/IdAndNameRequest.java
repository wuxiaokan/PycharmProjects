package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @author zlx
 * @Description: ID和名称，用于下拉选中传参
 * @date 2019年4月25日 下午4:17:03
 */
public class IdAndNameRequest {
	
	@ApiModelProperty(value="id")
	private Long id;
	
	@ApiModelProperty(value="名称")
	private String name;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "IdAndNameRequest [id=" + id + ", name=" + name + "]";
	}
	

}
