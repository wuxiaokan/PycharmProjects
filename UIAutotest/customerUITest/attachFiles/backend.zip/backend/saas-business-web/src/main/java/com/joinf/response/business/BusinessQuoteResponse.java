package com.joinf.response.business;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * 商机详情-报价返回参数
 *
 * @author yzq
 * @date 2019-05-06
 */
public class BusinessQuoteResponse implements Serializable {

    private static final long serialVersionUID = -2605791959612961659L;

    @ApiModelProperty(value = "报价id")
    private Long id;

    @ApiModelProperty(value = "报价单号")
    private String code;

    @ApiModelProperty(value = "客户名称")
    private String customerName;

    @ApiModelProperty(value = "合同总额:币种+金额")
    private String totalAmount;

    @ApiModelProperty(value = "联系人")
    private String contactName;

    @ApiModelProperty(value = "报价日期")
    private String quoteDate;

    @ApiModelProperty(value = "状态")
    private String status;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getQuoteDate() {
        return quoteDate;
    }

    public void setQuoteDate(String quoteDate) {
        this.quoteDate = quoteDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
