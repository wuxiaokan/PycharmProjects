package com.joinf.request.message;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @ClassName: InsertMessageRequest
 * @Description: 点击保存点击记录
 * @author CyNick
 * @date 2019年6月26日
 *
 */
public class InsertMessageRequest {

	@ApiModelProperty(value = " 消息类型[0]全局消息  [6]个人消息", required = true)
	private Integer module;

	@ApiModelProperty(value = "发送类型 0 [0系统通知、1活动通知] 6 [0个人消息]", required = true)
	private Integer type;

	@ApiModelProperty(value = "消息id", required = true)
	private Long relId;

	public Integer getModule() {
		return module;
	}

	public void setModule(Integer module) {
		this.module = module;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Long getRelId() {
		return relId;
	}

	public void setRelId(Long relId) {
		this.relId = relId;
	}

}
