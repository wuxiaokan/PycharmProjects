package com.joinf.request.business;

import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 获取线索详情的参数
 *
 * @author yzq
 * @date 2019-04-16
 */
public class QueryBusinessClueDetailRequest implements Serializable {

    private static final long serialVersionUID = 1809254677940595616L;

    @ApiModelProperty(value = "线索id", required = true)
    @NotNull
    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


}
