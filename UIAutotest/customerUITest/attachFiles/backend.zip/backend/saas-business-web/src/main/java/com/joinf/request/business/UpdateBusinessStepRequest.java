package com.joinf.request.business;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * 更新商机阶段
 *
 * @author yzq
 * @date 2019-04-26
 */
public class UpdateBusinessStepRequest implements Serializable {

    private static final long serialVersionUID = 2562093965222850315L;

    @ApiModelProperty(value = "商机id",required = true)
    private Long id;

    @ApiModelProperty(value = "是否一并修改客户跟进阶段",required = true)
    private Boolean modifyCustomerFlowStep;

    @ApiModelProperty(value = "跟进阶段",required = true)
    private Long flowStep;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Boolean getModifyCustomerFlowStep() {
        return modifyCustomerFlowStep;
    }

    public void setModifyCustomerFlowStep(Boolean modifyCustomerFlowStep) {
        this.modifyCustomerFlowStep = modifyCustomerFlowStep;
    }

    public Long getFlowStep() {
        return flowStep;
    }

    public void setFlowStep(Long flowStep) {
        this.flowStep = flowStep;
    }

    @Override
    public String toString() {
        return "UpdateBusinessStepRequest{" +
                "id=" + id +
                ", modifyCustomerFlowStep=" + modifyCustomerFlowStep +
                ", flowStep=" + flowStep +
                '}';
    }
}
