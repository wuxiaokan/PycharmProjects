package com.joinf.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.Page;
import com.joinf.constant.Constants;
import com.joinf.constant.ReportConstants;
import com.joinf.constant.ResponseCodeEnum;
import com.joinf.constants.BusinessConstants;
import com.joinf.dto.BusinessClueDetailDto;
import com.joinf.dto.BusinessClueDto;
import com.joinf.dto.BusinessClueFilingDto;
import com.joinf.dto.ExistsDataDto;
import com.joinf.dto.GenerateCodeDto;
import com.joinf.dto.IdAndNameDto;
import com.joinf.dto.QueryBusinessClueDto;
import com.joinf.dto.QueryCustomerDataDto;
import com.joinf.dto.QueryOperatorsDto;
import com.joinf.dto.businesses.SaveClueFilingBusinessDto;
import com.joinf.dto.businesses.SaveClueFilingCustomerDto;
import com.joinf.dto.businesses.SaveClueFilingDto;
import com.joinf.dto.businesses.SaveClueFilingResultDto;
import com.joinf.entity.generator.BusinessClue;
import com.joinf.enums.AreadyExsitEnum;
import com.joinf.exception.AreadyExsitException;
import com.joinf.exception.CommonException;
import com.joinf.interfaces.CommonManager;
import com.joinf.interfaces.CustomizeParameterValueService;
import com.joinf.interfaces.DataPermissionValidateManager;
import com.joinf.interfaces.business.BusinessClueManager;
import com.joinf.request.business.QueryBusinessClueListRequest;
import com.joinf.request.business.QueryUpdateClueStatusRequest;
import com.joinf.request.business.SaveClueFilingRequest;
import com.joinf.request.business.SaveCustomerContactRequest;
import com.joinf.response.business.BusinessClueSourceResponse;
import com.joinf.response.business.QueryBusinessClueDetailResponse;
import com.joinf.response.business.QueryBusinessClueListResponse;
import com.joinf.response.business.QueryClueFilingInitResponse;
import com.joinf.response.business.QueryClueFilingResponse;
import com.joinf.response.business.QueryOperatorResponse;
import com.joinf.response.business.SaveClueFilingResponse;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.annotations.Permission;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.dto.session.SessionUser;
import com.joinf.utils.util.JoinfBeanUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

/**
 * 商机线索
 *
 * @author yzq
 * @date 2019-04-12
 */
@Slf4j
@Api(tags = "商机线索服务", description = "BusinessClueController")
@RestController
@RequestMapping("/business/clues")
public class BusinessClueController extends BaseController{

    @Autowired
	private CommonManager commonmanager;
    
    @Autowired
    private BusinessClueManager businessClueManager;
    @Autowired
    private DataPermissionValidateManager dataPermissionValidateManager;
    @Autowired
    private CustomizeParameterValueService customizeParameterValueService;

    /**
     * 查询线索列表
     *
     * @param request
     * @param req    查询参数
     * @return
     */
    @ApiOperation(value = "查询线索列表", notes = "查询线索列表")
    @GetMapping(value = "/")
    @ResponseBody
    @Permission(require = "business.list.clue_preview")
    public BaseResponseEntity<List<QueryBusinessClueListResponse>> geClues(HttpServletRequest request, QueryBusinessClueListRequest req) {
        log.info("入参为："+req.toString());
        BaseResponseEntity<List<QueryBusinessClueListResponse>> response = new BaseResponseEntity<>(true);
        SessionUser user = getSessionUser(request);
        QueryBusinessClueDto queryDto = JoinfBeanUtils.copyToNewBean(QueryBusinessClueDto.class, req);
        queryDto.setCompanyId(user.getCompanyId());
        List<BusinessClueDto> clueList = businessClueManager.queryBusinessClueListByCondition(queryDto);
        if (req.isPaging()) {
            response.setTotalPage(((Page<BusinessClueDto>) clueList).getPages());
            response.setTotalRecords(((Page<BusinessClueDto>) clueList).getTotal());
        }
        List<QueryBusinessClueListResponse> resultList = JoinfBeanUtils.copyToNewListBean(QueryBusinessClueListResponse.class, clueList);
        response.setSuccess(true);
        response.setCode(ResponseCodeEnum.SUCCESS.getStatus());
        response.setData(resultList);
        return response;
    }

    /**
     * 获取线索详情
     * @param request
     * @param clueId
     * @return
     */
    @ApiOperation(value = "查询线索详情", notes = "查询线索详情")
    @ApiImplicitParam(name = "id", value="线索ID", paramType="path", required=true) 
    @GetMapping(value = "/{id}")
    @ResponseBody
    @Permission(require = "business.list.clue_preview")
    public BaseResponseEntity<QueryBusinessClueDetailResponse> getClue(HttpServletRequest request,@PathVariable(value = "id",required=true) Long clueId) {
        log.info("入参为clueId=："+clueId);
        BaseResponseEntity<QueryBusinessClueDetailResponse> response = new BaseResponseEntity<>(true);
        SessionUser user = getSessionUser(request);

        BusinessClueDetailDto businessClueDetailDto = businessClueManager.queryBusinessClueDetail(user.getCompanyId(), user.getSwitchOperatorId(), clueId);
        QueryBusinessClueDetailResponse result = JoinfBeanUtils.copyToNewBean(QueryBusinessClueDetailResponse.class, businessClueDetailDto);
        if(null!=businessClueDetailDto){
            List<BusinessClueSourceResponse> sourceResponses = JoinfBeanUtils.copyToNewListBean(BusinessClueSourceResponse.class, businessClueDetailDto.getClueSourceResponseList());
            result.setClueSourceResponseList(sourceResponses);
        }
        response.setCode(ResponseCodeEnum.SUCCESS.getStatus());
        response.setData(result);
        return response;
    }

    /**
     * 更新状态
     *
     * @param request
     * @param req
     * @return
     */
    @ApiOperation(value = "更新线索的状态", notes = "更新线索的状态")
    @PutMapping("/")
    @ResponseBody
    @Permission(require = "business.list.clue_edit")
    public BaseResponseEntity<Integer> updateClueStatus(HttpServletRequest request, @RequestBody QueryUpdateClueStatusRequest req){
        log.info("入参为："+req.toString());
        BaseResponseEntity<Integer> response = new BaseResponseEntity<>(true);
        SessionUser user = getSessionUser(request);

        Long companyId = user.getCompanyId();
        List<Long> ids = req.getId();
        Integer type = req.getType();

        //已处理的不能设置状态
        List<BusinessClue> businessClueList = businessClueManager.selectBusinessClueByIds(ids,companyId);
        for (BusinessClue businessClue : businessClueList) {
            if(businessClue.getClueStatus().equals(BusinessConstants.CLUE_STATUS_HANDLE_ALREADY)){
                throw new CommonException("已处理的不能改变状态！");
            }
        }

        int clueStatus = -1;
        //0:设置忽略;1:取消忽略 (线索状态,0：待处理；1：已处理；2：已忽略)
        if(type==0){
            clueStatus = BusinessConstants.CLUE_STATUS_IGNORE;
        }else if(type==1){
            clueStatus = BusinessConstants.CLUE_STATUS_HANDLE_WAIT;
        }else {
            throw new CommonException("请检查type参数！");
        }

        response.setData(businessClueManager.updateClueStatusByIds(ids,clueStatus,companyId));
        response.setSuccess(true);
        return response;
    }
    
    /**
     * 查询线索存档初始数据
     * @param type
     * @return
     */
    @ApiOperation(value = "查询线索存档初始数据")
    @ApiImplicitParams({
    	@ApiImplicitParam(name = "type", value="建档类型 0:客户   1:商机", paramType="path", required=true),
    	@ApiImplicitParam(name = "clueIds", value="选中的线索id,多个逗号隔开", paramType="query", required=true)
    })
    @GetMapping(value = "/filing/{type}")
    @ResponseBody
    @Permission(require = "business.list.clue_allocation")
    public BaseResponseEntity<QueryClueFilingInitResponse> clueFilingInit(HttpServletRequest request, @PathVariable(value = "type",required=true) int type,
    		@RequestParam(value = "clueIds", required=true) Long[] clueIds) {
        log.info("入参为type=："+type);
        
        SessionUser user = getSessionUser(request);
        
        BaseResponseEntity<QueryClueFilingInitResponse> entity = new BaseResponseEntity<>(true);
       
        QueryClueFilingInitResponse result = new QueryClueFilingInitResponse();
        
        //业务员信息
        List<QueryOperatorResponse> queryOperatorResponses = null;
		List<QueryOperatorsDto> operators = this.commonmanager.queryOperators(user.getCompanyId(), user.getSwitchOperatorId());
		if (operators != null) {
			queryOperatorResponses = JoinfBeanUtils.copyToNewListBean(QueryOperatorResponse.class, operators);
			result.setOperators(queryOperatorResponses);
		}
        
        Long parameterId = (type == 0 ? 1L : 8L);
        
        GenerateCodeDto generateCodeDto = new GenerateCodeDto();
		generateCodeDto.setCompanyId(user.getCompanyId());
		generateCodeDto.setParameterId(parameterId);
		result.setCustomizeCodePrefix(this.commonmanager.generateCode(generateCodeDto));
		
		QueryCustomerDataDto dto = new QueryCustomerDataDto();
		dto.setCompanyId(user.getCompanyId());
		dto.setParameterId(parameterId);
		dto.setType(11);
		result.setCustomizeCodeDicts(this.commonmanager.getCustomerCustomizeCodeData(dto));
		
		//自定义编码是否限制手动输入
		Byte force = customizeParameterValueService.getCustomizeParameterForceById(user.getCompanyId(), parameterId);
		result.setCodeForce(force!=null && force > 0);
		
		//查询新建商机/客户需要的基础资料
		result.setDictMap(this.businessClueManager.queryDictMap(user.getCompanyId(), user.getSwitchOperatorId(), type));
		//没有自定义编码
		if (StringUtils.isBlank(result.getCustomizeCodePrefix()) && CollectionUtils.isEmpty(result.getCustomizeCodeDicts())) {
			result.setHasCustomizeCode(false);
		}
		//是否有设置自定义编码的权限
		result.setHasSetCodePermission(SessionUtils.hasOperatorResources(request, ReportConstants.RESOURCE_ADVANCED_SETTING));
		
        entity.setCode(ResponseCodeEnum.SUCCESS.getStatus());
        entity.setData(result);
        return entity;
    }
    
    @ApiOperation(value = "线索直接添加为客户联系人")
    @PostMapping(value = "/contact")
    @ResponseBody
    @Permission(require = "business.list.clue_allocation")
    public BaseResponseEntity<SaveClueFilingResponse> saveCustomerContact(HttpServletRequest request,@RequestBody SaveCustomerContactRequest req) throws CommonException {
        log.info("入参为：{}", req);
        
        SessionUser user = getSessionUser(request);
        
        BaseResponseEntity<SaveClueFilingResponse> entity = new BaseResponseEntity<>(true);
        
        SaveClueFilingDto saveClueFilingDto = new SaveClueFilingDto();
        saveClueFilingDto.setUser(convertToLoginUserDto(user));
        saveClueFilingDto.setClueId(req.getClueId());
        saveClueFilingDto.setAllocationUserId(req.getAllocationUserId());
        saveClueFilingDto.setCustomerId(req.getCustomerId());
        
        SaveClueFilingResultDto saveClueFilingResultDto = null;
		try {
			saveClueFilingResultDto =  this.businessClueManager.saveCustomerContact(saveClueFilingDto);
		} catch (AreadyExsitException e) {
			log.info(e.toString(), e);
			//重新封装错误信息给前端
			saveClueFilingResultDto = getSaveClueFilingFailInfo(request, user, e);
		}
       
        entity.setData(JoinfBeanUtils.copyToNewBean(SaveClueFilingResponse.class, saveClueFilingResultDto));
        entity.setCode(ResponseCodeEnum.SUCCESS.getStatus());
        return entity;
    }
    
   
    @ApiOperation(value = "线索建档客户/商机")
    @PostMapping(value = "/filing")
    @ResponseBody
    @Permission(require = "business.list.clue_allocation")
    public BaseResponseEntity<SaveClueFilingResponse> saveClueFiling(HttpServletRequest request,@RequestBody SaveClueFilingRequest req) throws CommonException {
        log.info("入参为：{}", req);
        
        SessionUser user = getSessionUser(request);
        
        BaseResponseEntity<SaveClueFilingResponse> entity = new BaseResponseEntity<>(true);
       
        SaveClueFilingCustomerDto customer = null;
        if (req.getCustomer() != null) {
        	customer = JoinfBeanUtils.copyToNewBean(SaveClueFilingCustomerDto.class, req.getCustomer());
        	customer.setCustomizeCodeDicts(req.getCustomer().getCustomizeCodeDicts());
        	customer.setBusinessTypeInfo(JoinfBeanUtils.copyToNewBean(IdAndNameDto.class, req.getCustomer().getBusinessTypeInfo()));
        	customer.setFlowStepInfo(JoinfBeanUtils.copyToNewBean(IdAndNameDto.class, req.getCustomer().getFlowStepInfo()));
        	customer.setGradeInfo(JoinfBeanUtils.copyToNewBean(IdAndNameDto.class, req.getCustomer().getGradeInfo()));
        	customer.setSourceInfo(JoinfBeanUtils.copyToNewBean(IdAndNameDto.class, req.getCustomer().getSourceInfo()));
        	customer.setTypeInfo(JoinfBeanUtils.copyToNewBean(IdAndNameDto.class, req.getCustomer().getTypeInfo()));
		}
        
        SaveClueFilingBusinessDto business = null;
        if (req.getBusiness() != null) {
        	business = JoinfBeanUtils.copyToNewBean(SaveClueFilingBusinessDto.class, req.getBusiness());
        	business.setCustomizeCodeDicts(req.getBusiness().getCustomizeCodeDicts());
        	business.setFlowStepInfo(JoinfBeanUtils.copyToNewBean(IdAndNameDto.class, req.getBusiness().getFlowStepInfo()));
		}
        
        SaveClueFilingDto saveClueFilingDto = new SaveClueFilingDto();
        saveClueFilingDto.setUser(convertToLoginUserDto(user));
        saveClueFilingDto.setClueId(req.getClueId());
        saveClueFilingDto.setCustomer(customer);
        saveClueFilingDto.setBusiness(business);
        saveClueFilingDto.setAllocationUserId(req.getAllocationUserId());
        
        SaveClueFilingResultDto saveClueFilingResultDto = null;
		try {
			saveClueFilingResultDto =  this.businessClueManager.saveClueFiling(saveClueFilingDto);
		} catch (AreadyExsitException e) {
			log.info(e.toString(), e);
			
			//邮箱冲突，直接移出线索池，saveClueFiling方法中事务需要回滚，修改状态放在controller中调用
			if (e.getCode() != null && e.getCode() == AreadyExsitEnum.EMAIL.value()) {
				//删除线索
				this.businessClueManager.deleteBusinessClueById(saveClueFilingDto.getClueId(), user.getCompanyId());
			}
			
			//重新封装错误信息给前端
			saveClueFilingResultDto = getSaveClueFilingFailInfo(request, user, e);
		}
		
		SaveClueFilingResponse saveClueFilingResponse = JoinfBeanUtils.copyToNewBean(SaveClueFilingResponse.class, saveClueFilingResultDto);
		saveClueFilingResponse.setShowAddCustomerContact(saveClueFilingResultDto.isShowAddCustomerContact());
		saveClueFilingResponse.setShowEditUserCustomerNum(saveClueFilingResultDto.isShowEditUserCustomerNum());
		saveClueFilingResponse.setHasCustomerPermission(saveClueFilingResultDto.isHasCustomerPermission());
       
        entity.setData(saveClueFilingResponse);
        entity.setCode(ResponseCodeEnum.SUCCESS.getStatus());
        return entity;
    }
    
    
    
    /**
	 * 获取建档客户/商机失败的提示信息
	 * @param failCode
	 * @param existsDataDto
	 * @return
	 */
	private SaveClueFilingResultDto getSaveClueFilingFailInfo(HttpServletRequest request, SessionUser user, AreadyExsitException e){
		SaveClueFilingResultDto failResult = new SaveClueFilingResultDto();
		
		Integer failCode = e.getCode();
		ExistsDataDto existsDataDto = e.getExistsDataDto();
		String errorMsg = e.getMessage();
		
		if (failCode == null) {
			failResult.setMsg(errorMsg);
			return failResult;
		}
		
		//处理失败
		int type = 2;
		//错误提示
		String conflictMsg = "";
		
		if (failCode == AreadyExsitEnum.CUSTOMER_TYPE.value()) {
			conflictMsg = "已达到可建档客户数量上限";
			
			if (existsDataDto != null) {
				//冲突明细
				failResult.setConflictMsgDetail(StringUtils.join("达到“", existsDataDto.getName(),"”类型用户的建档上限，业务员：", existsDataDto.getOperatorName()));
			}
			//是否显示设置业务员客户数量上限
			failResult.setShowEditUserCustomerNum(SessionUtils.hasOperatorResources(request, ReportConstants.RESOURCE_USER_SETTING));
			//不需要显示添加为联系人按钮
			failResult.setShowAddCustomerContact(false);
		}else{
			if (failCode == AreadyExsitEnum.EMAIL.value()) {
				//邮箱冲突，直接表示为已处理
				type = 1;
				failResult.setMsg("已处理，已移出线索池");
				conflictMsg = "邮箱地址重复";
			}
			else if (failCode == AreadyExsitEnum.NAME.value()) {
				conflictMsg = "客户名称重复";
			}
			else if (failCode == AreadyExsitEnum.WEB_SITE.value()) {
				conflictMsg = "网址重复";
			}
			else if (failCode == AreadyExsitEnum.CODE.value()) {
				conflictMsg = "客户编码重复";
			}
			
			if (existsDataDto != null) {
				//是否有查看客户的权限
				boolean hasCustomerPermission = dataPermissionValidateManager.validateDataPermission(user.getOperatorId(), existsDataDto.getOperatorId(), existsDataDto.getOperatorIds(), existsDataDto.getOpen(), Constants.RESOURCE_CUSTOMER_ID);

				if (hasCustomerPermission) {
					//冲突的客户ID
					failResult.setCustomerId(existsDataDto.getDataId());
					//冲突的客户名称
					failResult.setCustomerName(existsDataDto.getName());
				}
				
				//有客户权限  或者  设置显示冲突信息
				if (hasCustomerPermission || (existsDataDto.getRuleValue() != null && existsDataDto.getRuleValue().intValue() == 1))
				{
					if (existsDataDto.getOperatorId() == null || existsDataDto.getOperatorId().longValue() == 0L) {
						failResult.setConflictMsgDetail("该客户已存在于公海中");
					}else{
						//冲突客户所属业务员
						failResult.setConflictMsgDetail(StringUtils.join("冲突客户所属业务员：", existsDataDto.getOperatorName()));
					}
				}else {
					failResult.setConflictMsgDetail("客户已被他人建档且未设置为对您共享");
				}
				
				failResult.setHasCustomerPermission(hasCustomerPermission);
			}
		}
		
		failResult.setType(type);
		failResult.setConflictMsg(conflictMsg);
		return failResult;
	}

    @ApiOperation(value = "线索处理信息")
    @GetMapping(value = "/filing/log/{clueId}")
    @ResponseBody
    @Permission(require = "business.list.clue_preview")
    public BaseResponseEntity<QueryClueFilingResponse> getClueFiling(HttpServletRequest request, @PathVariable(value = "clueId") Long clueId){
        log.info("入参为clueId=："+clueId);
        BaseResponseEntity<QueryClueFilingResponse> response = new BaseResponseEntity<>(true);
        SessionUser user = getSessionUser(request);

        BusinessClueFilingDto businessClueFilingDto = businessClueManager.queryBusinessClueFiling(user.getCompanyId(), user.getSwitchOperatorId(), clueId);

        QueryClueFilingResponse result = JoinfBeanUtils.copyToNewBean(QueryClueFilingResponse.class, businessClueFilingDto);
        response.setCode(ResponseCodeEnum.SUCCESS.getStatus());
        response.setData(result);
        response.setSuccess(true);
        return response;
    }

}
