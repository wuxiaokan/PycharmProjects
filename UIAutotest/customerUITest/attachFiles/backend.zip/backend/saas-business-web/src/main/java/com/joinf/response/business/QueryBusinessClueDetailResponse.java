package com.joinf.response.business;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.List;

/**
 * 获取线索详情
 *
 * @author yzq
 * @date 2019-04-16
 */
public class QueryBusinessClueDetailResponse implements Serializable {

    private static final long serialVersionUID = -7241969974466503757L;

    @ApiModelProperty(value="线索id")
    private Long id;

    @ApiModelProperty(value="线索名称")
    private String name;

    @ApiModelProperty(value="企业信息")
    private String enterpriseInformation;

    @ApiModelProperty(value="线索等级(0:待定;1:一星;...5:五星)")
    private Integer clueGrade;

    @ApiModelProperty(value="线索来源")
    private List<BusinessClueSourceResponse> clueSourceResponseList;

    @ApiModelProperty(value="线索状态(0:待处理;1:已处理;2:已忽略)")
    private Integer clueStatus;



    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEnterpriseInformation() {
        return enterpriseInformation;
    }

    public void setEnterpriseInformation(String enterpriseInformation) {
        this.enterpriseInformation = enterpriseInformation;
    }

    public Integer getClueGrade() {
        return clueGrade;
    }

    public void setClueGrade(Integer clueGrade) {
        this.clueGrade = clueGrade;
    }

    public Integer getClueStatus() {
        return clueStatus;
    }

    public void setClueStatus(Integer clueStatus) {
        this.clueStatus = clueStatus;
    }


    public List<BusinessClueSourceResponse> getClueSourceResponseList() {
        return clueSourceResponseList;
    }

    public void setClueSourceResponseList(List<BusinessClueSourceResponse> clueSourceResponseList) {
        this.clueSourceResponseList = clueSourceResponseList;
    }

}
