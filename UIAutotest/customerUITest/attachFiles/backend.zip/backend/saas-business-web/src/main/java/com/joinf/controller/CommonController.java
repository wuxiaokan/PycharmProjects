package com.joinf.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.Page;
import com.joinf.constant.ResponseCodeEnum;
import com.joinf.constants.Constants;
import com.joinf.constants.Customize;
import com.joinf.dto.*;
import com.joinf.dto.supplier.QueryCustomerObjectDto;
import com.joinf.dto.supplier.QuerySupplierDto;
import com.joinf.entity.generator.*;
import com.joinf.exception.BusinessException;
import com.joinf.interceptor.system.PermissionInterceptor;
import com.joinf.interfaces.*;
import com.joinf.interfaces.customer.CustomerContactManager;
import com.joinf.interfaces.customer.CustomerFollowUpManager;
import com.joinf.interfaces.customer.CustomerManager;
import com.joinf.interfaces.supplier.SupplierManager;
import com.joinf.mapper.CustomizeForceinputExMapper;
import com.joinf.mapper.DictCountryExMapper;
import com.joinf.request.*;
import com.joinf.request.customer.UpdateCustomerFollowUpFlagRequest;
import com.joinf.response.*;
import com.joinf.response.supplier.QuerySupplierResponse;
import com.joinf.service.redis.RedisService;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.annotations.Permission;
import com.joinf.utils.base.BaseEntityBuilder;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.dto.session.SessionUser;
import com.joinf.utils.dto.user.QueryOperatorDto;
import com.joinf.utils.dto.user.UserInfoDto;
import com.joinf.utils.util.JoinfBeanUtils;
import com.rabbitmq.http.client.domain.UserInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * Description: 基础服务
 *
 * @author lyj
 * @date 2017年12月13日 下午1:46:38
 */
@Slf4j
@RestController
@RequestMapping("/common")
@Api(tags="基础服务", description = "CommonController")
public class CommonController extends BaseController{
	
	@Autowired
	private CommonManager manager;
	
	@Autowired
	private DictCountryExMapper dictCountryExMapper;
	
	@Autowired
	private CustomizeForceinputExMapper customizeForceinputExMapper;
	
	@Autowired
	private UserCenterService userCenterService;

	@Autowired
	private CustomerContactManager contactManager;

	@Autowired
	private CustomerManager customerManager;

	@Autowired
    private OperatorService operatorService;
	
    @Autowired
    private CustomerFollowUpManager customerFollowUpManager;

    @Autowired
	private SupplierManager supplierManager;

    @Resource
	private RedisService redisService;
	
	/**
	 * 查询字段字典
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询字段字典列表", notes="查询字段字典列表")
	@GetMapping("/dicts")
	public BaseResponseEntity<JSONArray> queryColumnDictList(HttpServletRequest request, DictRequest req){
		BaseResponseEntity<JSONArray> entity= new BaseResponseEntity<JSONArray>();
		SessionUser user = getSessionUser(request);
		CustomizeDictDto dto = new CustomizeDictDto();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getSwitchOperatorId());
		dto.setAddBigDict(true);
		dto.setAddDict(true);
		dto.setKey(req.getKey());
		CustomizeDictResponse resonse = manager.getDictCollection(dto);
		entity.setData(resonse.getDicts());
		entity.setTotalPage(resonse.getPages());
		entity.setTotalRecords(resonse.getTotalRecord());
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="查询表必填项", notes="查询表必填项")
	@GetMapping("/forceinput")
	public BaseResponseEntity<List<String>> getcolumnForceinput(HttpServletRequest request, GetcolumnForceinputRequest req){
		SessionUser user = getSessionUser(request);
		BaseResponseEntity<List<String>> entity = new BaseResponseEntity<>();
		entity.setSuccess(true);
		QueryCustomizeForceinputParam param = new QueryCustomizeForceinputParam();
		param.setColumnCondition(req.getModuleId()+",");
		param.setCompanyId(user.getCompanyId());
		Customize cus = Customize.getByLogTableName(req.getTableName());
		param.setTableName(cus == null?null:cus.getTableName());
		CustomizeForceinput forceinput = customizeForceinputExMapper.findbyTableAndColumnIds(param);
		if(forceinput!= null)
			entity.setData(Arrays.asList(forceinput.getColumnForcename().split(",")));
		return entity;
	}
	
	@ApiOperation(value="查询国家基础信息", notes="查询国家基础信息")
	@GetMapping("/country")
	public BaseResponseEntity<DictCountryResponse> getDBCountryIdByName(
			@ApiParam(required = true, name = "name", value= "国家名称") @RequestParam(value = "name",required=true) String name){
		BaseResponseEntity<DictCountryResponse> entity = new BaseResponseEntity<>();
		DictCountry country = dictCountryExMapper.getDBCountryIdByName(name);
		if(country !=null){
			DictCountryResponse response = new DictCountryResponse();
			JoinfBeanUtils.copyProperties(response, country);
			entity.setData(response);
		}
		entity.setSuccess(true);
		return entity;
	}
	
	/**
	 * 查询自定义code选择值
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询自定义code选择值", notes="查询自定义code选择值")
	@ApiImplicitParam(name = "parameterId", value="1：客户编码，2：产品编码，3：报价单号，4：合同编号5：销售合同号6：供应商编码，7产品条码  8:商机编号", paramType="path", required=true) 
	@GetMapping("/customize/codes/{parameterId}")
	public BaseResponseEntity<List<CustomizeCodeResponse>> getCustomizeCodeData(HttpServletRequest request, @PathVariable(value = "parameterId",required=true) Long parameterId){
		
		BaseResponseEntity<List<CustomizeCodeResponse>> entity= new BaseResponseEntity<>();
		SessionUser user = getSessionUser(request);
		QueryCustomerDataDto dto = new QueryCustomerDataDto();
		dto.setCompanyId(user.getCompanyId());
		dto.setParameterId(parameterId);
		dto.setType(11);
		entity.setSuccess(true);
		entity.setData(manager.getCustomerCustomizeCodeData(dto));
		return entity;
	}
	
	/**
	 * 生成自定义code
	 * @param req
	 * @return
	 */
	@ApiOperation(value="生成自定义code", notes="生成自定义code")
	@PostMapping("/customize/codes")
	@ResponseBody
	public BaseResponseEntity<String> generateCode(HttpServletRequest request,@RequestBody GenerateCodeRequest req){
		BaseResponseEntity<String> entity= new BaseResponseEntity<>();
		SessionUser user = getSessionUser(request);
		GenerateCodeDto dto = new GenerateCodeDto();
		dto.setCompanyId(user.getCompanyId());
		dto.setList(req.getList());
		dto.setParameterId(req.getParameterId());
		entity.setSuccess(true);
		entity.setData(manager.generateCode(dto));
		return entity;
	}
	
	/**
	 * 校验是否存在
	 * @param req
	 * @return
	 */
	@ApiOperation(value="校验数据是否存在", notes="校验数据是否存在")
	@GetMapping("/data/exsit")
	public BaseResponseEntity<?> checkDataExsit(HttpServletRequest request, CheckDataExistRequest req){
		BaseResponseEntity<?> entity= new BaseResponseEntity<>();
		SessionUser user = getSessionUser(request);
		QuerySizeByObjectName param = new QuerySizeByObjectName();
		param.setTableName(req.getSystemTableName());
		param.setId(req.getId());
		param.setObjectName(req.getColumnName());
		param.setValue(req.getValue());
		param.setCompanyId(user.getCompanyId());
		boolean success = manager.selectCountByObjectName(param) > 0;
		entity.setSuccess(!success);
		entity.setErrMsg(success?"存在":"不存在");
		return entity;
	} 
	
	@ApiOperation(value="校验是否是主账号", notes="校验是否是主账号")
	@GetMapping("/user/primary")
	public BaseResponseEntity<?> checkPrimaryAccount(HttpServletRequest request
			,@ApiParam(required = true, name = "loginName", value= "用户名")@RequestParam(value = "loginName") String loginName){
		BaseResponseEntity<?> entity= new BaseResponseEntity<>();
		boolean success = manager.checkIsPrimaryAccount(loginName);
		entity.setSuccess(success);
		entity.setErrMsg(success?"是":"否");
		return entity;
	}
	
	
	@ApiOperation(value="校验数据量是否超过限制", notes="校验数量是否超过限制")
	@PostMapping("/data/limit")
	public BaseResponseEntity<?> checkLimit(HttpServletRequest request
			,@RequestBody CheckNumLimitRequest req){
		BaseResponseEntity<?> entity= new BaseResponseEntity<>();
		CheckNumLimitDto dto = new CheckNumLimitDto();
		JoinfBeanUtils.copyProperties(dto, req);
		SessionUser user = getSessionUser(request);
		dto.setOperatorId(user.getOperatorId());
		dto.setCompanyId(user.getCompanyId());
		boolean success = manager.checkNumLimit(dto);
		entity.setSuccess(success);
		entity.setErrMsg(success?"是":"否");
		return entity;
	}
	
	@ApiOperation(value="校验企业容量是否超过限制", notes="校验企业容量是否超过限制")
	@PostMapping("/volume/limit")
	public BaseResponseEntity<?> checkVolumeLimit(HttpServletRequest request){
		BaseResponseEntity<?> entity= new BaseResponseEntity<>();
		CompanyDTO user = SessionUtils.getCenterCompanyInfo(request);
		UserCenterResponse<?> httpResponse = userCenterService.volumeValidate(user.getCompanyId());
		entity.setSuccess(!httpResponse.isSuccess());
		entity.setErrMsg(!httpResponse.isSuccess()?"是":"否");
		return entity;
	}

	@ApiOperation(value="查询客户联系人列表", notes="查询客户联系人列表")
	@GetMapping("/customer/contacts")
	public BaseResponseEntity<QuerySupplierResponse> querySupplierContactList(HttpServletRequest request, QueryCustomerConcactRequest req){

		SessionUser user = getSessionUser(request);
		QueryCustomerObjectDto queryDto = new QueryCustomerObjectDto();
		JoinfBeanUtils.copyProperties(queryDto, req);
		queryDto.setCompanyId(user.getCompanyId());
		List<CustomerContact> responseList = contactManager.queryCustomerContactList(queryDto);

		QuerySupplierDto dto = new QuerySupplierDto();
		dto.setOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setRoleId(user.getRoleId());
		dto.setResourceId(Customize.CustomerContactList.getResourceId());
		dto.setTableName(Customize.CustomerContactList.getTableName());
		dto.setModule(Customize.CustomerContactList.getModule());

		BaseResponseEntity<QuerySupplierResponse> entity = new BaseResponseEntity<>();
		if(req.isPaging()){
			entity.setTotalPage(((Page<CustomerContact>) responseList).getPages());
			entity.setTotalRecords(((Page<CustomerContact>) responseList).getTotal());
			responseList = ((Page<CustomerContact>) responseList).getResult();
		}

		//显示哪些字段
		List<String> showFields = new ArrayList<String>();
		showFields.add("name");//名称
		showFields.add("email");//邮箱
		showFields.add("flag");//状态
		dto.setOperatorId(user.getOperatorId());
		entity.setData(contactManager.getContactList(dto, responseList, showFields));
		entity.setSuccess(true);
		return entity;
	}

	@ApiOperation(value = "查询客户名称列表", notes = "查询客户名称列表")
	@GetMapping(value = "/customers/name")
	@ResponseBody
	public BaseResponseEntity<List<CustomerNameResponse>> getCustomerName(HttpServletRequest request, QueryCustomerNameRequest req) {
		BaseResponseEntity<List<CustomerNameResponse>> response = new BaseResponseEntity<>(true);
		SessionUser user = getSessionUser(request);

		/*这是查询切换人管理权限下的所有业务员
		List<UserInfo> list = redisService.getOperatorAssignment(user.getCompanyId(), user.getSwitchOperatorId(),1);
		for(UserInfo userInfo : list){
			operatorIdList.add(userInfo.getId());
		}*/

		//查询自己的客户+共享给自己的客户,先用list,为了以后做扩展用
		List<Long> operatorIdList = new ArrayList<>();
		operatorIdList.add(user.getSwitchOperatorId());
		QueryCustomerNameDto queryDto = JoinfBeanUtils.copyToNewBean(QueryCustomerNameDto.class, req);
		queryDto.setCompanyId(user.getCompanyId());
		queryDto.setOperatorIdList(operatorIdList);
		queryDto.setOperatorId(user.getSwitchOperatorId());
		List<Customer> customerList = customerManager.queryCustomerByOperator(queryDto);

		if (req.isPaging()) {
			response.setTotalPage(((Page<Customer>) customerList).getPages());
			response.setTotalRecords(((Page<Customer>) customerList).getTotal());
		}

		List<CustomerNameResponse> resultList = JoinfBeanUtils.copyToNewListBean(CustomerNameResponse.class, customerList);
		response.setSuccess(true);
		response.setCode(ResponseCodeEnum.SUCCESS.getStatus());
		response.setData(resultList);
		return response;
	}

    /**
     * 获取公司所有用户信息
     * @param request
     * @return
     */
    @ApiOperation(value="获取公司所有用户信息", notes="获取公司所有用户信息")
    @GetMapping("/allUserInfo")
    public BaseResponseEntity<List<OperatorAssignmentResponse>> getCompanyOperators(HttpServletRequest request){
        BaseResponseEntity<List<OperatorAssignmentResponse>> entity = new BaseResponseEntity<>();
        entity.setData(JoinfBeanUtils.copyToNewListBean(OperatorAssignmentResponse.class, addCompanyOperatorsToSession(request)));
        entity.setSuccess(true);
        return entity;
    }

    @GetMapping("/departments")
    @ApiOperation(value = "获取分享展示业务员列表",notes = "获取分享展示业务员列表")
    public BaseResponseEntity<List<ShareDepartmentListDto>> getShareDepartmentList(HttpServletRequest request, QueryShareDepartmentRequest req){
		log.info("入参为："+req.toString());
    	BaseResponseEntity<List<ShareDepartmentListDto>> entity = new BaseResponseEntity<>();
    	SessionUser user = getSessionUser(request);
    	List<OperatorAssignmentDto> operatorAssignmentDtoList = addCompanyOperatorsToSession(request);
    	QueryShareDepartmentDto dto = new QueryShareDepartmentDto();
    	dto.setId(req.getId());
    	dto.setBusType(req.getBusType());
    	dto.setCompanyId(user.getCompanyId());
    	dto.setOperatorId(user.getSwitchOperatorId());
    	dto.setOperatorAssignmentDtoList(operatorAssignmentDtoList);
    	
    	List<ShareDepartmentListDto> shareDepartmentListDto = manager.getShareDepartmentList(dto);
    	
    	entity.setData(shareDepartmentListDto);
    	entity.setSuccess(true);
    	return entity;
    }

	/**
	 * 封装业务员参数
	 *
	 * @param request
	 * @return
	 */
	private List<OperatorAssignmentDto> addCompanyOperatorsToSession(HttpServletRequest request){
		List<OperatorAssignmentDto> dataList = new ArrayList<>();
		SessionUser user = getSessionUser(request);
		List<UserInfoDto> list = getOperatorAssignment(user.getCompanyId(),user.getSwitchOperatorId(),1);
		for (UserInfoDto userInfo : list) {
			OperatorAssignmentDto o = JoinfBeanUtils.copyToNewBean(OperatorAssignmentDto.class, userInfo);
			o.setId(userInfo.getId());
			o.setDepartment(userInfo.getDepartment());
			if(userInfo.getParentId()==null || userInfo.getParentId().equals(userInfo.getCenterUserId())){
				o.setIsAdmin(1);
			}else {
				o.setIsAdmin(0);
			}
			dataList.add(o);
		}
		return dataList;
	}

    @ApiOperation(value="修改选中客户跟进状态", notes="修改客户跟进状态")
    @PutMapping("updateCustomerFollowUpFlag")
    @Permission(require="follow.list.execute")
    public BaseResponseEntity<?> updateSelectCustomerFollowUpFlag(HttpServletRequest request,@RequestBody UpdateCustomerFollowUpFlagRequest req){
		log.info("入参为"+req.toString());
		BaseResponseEntity<Integer> entity = new BaseResponseEntity<>();
        SessionUser user = getSessionUser(request);

        entity.setData(customerFollowUpManager.updateSelectCustomerFollowUpFlag(req,user.getSwitchOperatorId()));
        entity.setSuccess(true);
		entity.setCode(ResponseCodeEnum.SUCCESS.getStatus());
        return entity;
    }

    @ApiOperation(value="删除选中客户跟进", notes="删除选中客户跟进")
    @PutMapping("deleteCustomerFollowUp")
    @Permission(require="follow.list.delete")
    public BaseResponseEntity<?> deleteSelectCustomerFollowUp(HttpServletRequest request,@RequestBody UpdateCustomerFollowUpFlagRequest req){
		log.info("入参为"+req.toString());
        SessionUser user = getSessionUser(request);
        BaseResponseEntity<?> entity = new BaseResponseEntity<>();

        customerFollowUpManager.updateSelectCustomerFollowUpFlag(req,user.getSwitchOperatorId());
        entity.setSuccess(true);
		entity.setCode(ResponseCodeEnum.SUCCESS.getStatus());
        return entity;
    }

	@ApiOperation(value = "查询供应商名称列表", notes = "查询供应商名称列表")
	@GetMapping(value = "/suppliers/name")
	@ResponseBody
	public BaseResponseEntity<List<SupplierNameResponse>> getCustomerName(HttpServletRequest request, QuerySupplierNameRequest req) {
		BaseResponseEntity<List<SupplierNameResponse>> response = new BaseResponseEntity<>(true);
		SessionUser user = getSessionUser(request);

		//查询自己的客户+共享给自己的客户,先用list,为了以后做扩展用
		List<Long> operatorIdList = new ArrayList<>();
		operatorIdList.add(user.getSwitchOperatorId());
		QuerySupplierNameDto queryDto = JoinfBeanUtils.copyToNewBean(QuerySupplierNameDto.class, req);
		queryDto.setCompanyId(user.getCompanyId());
		queryDto.setOperatorIdList(operatorIdList);
		queryDto.setOperatorId(user.getSwitchOperatorId());
		List<Supplier> supplierList = supplierManager.querySupplierByOperator(queryDto);

		if (req.isPaging()) {
			response.setTotalPage(((Page<Supplier>) supplierList).getPages());
			response.setTotalRecords(((Page<Supplier>) supplierList).getTotal());
		}

		List<SupplierNameResponse> resultList = JoinfBeanUtils.copyToNewListBean(SupplierNameResponse.class, supplierList);
		response.setSuccess(true);
		response.setCode(ResponseCodeEnum.SUCCESS.getStatus());
		response.setData(resultList);
		return response;
	}

	/**
	 * 获取公司业务员信息
	 *
	 * @param companyId
	 * @param operatorId
	 * @param type 0:不包括自己 1:包括自己
	 * @return
	 */
	private List<UserInfoDto> getOperatorAssignment(Long companyId,Long operatorId,int type){
		List<UserInfoDto> users = new ArrayList<>();
		String key = String.format(AssignmentService.OPERATOR_ASSIGNMENT_USERS, companyId,operatorId);
		if(stringRedisTemplate.hasKey(key)){
			String value = stringRedisTemplate.opsForValue().get(key);
			JSONArray array = JSONArray.parseArray(value);
			UserInfoDto info;
			for(int i=0;i<array.size();i++){
				JSONObject ob = array.getJSONObject(i);
				info = JSONObject.toJavaObject(ob, UserInfoDto.class);
				if (type == 1 || info.getId().longValue() != operatorId.longValue()) {
					users.add(info);
				}
			}
		}else{//切换用户的时候可能不存在--重新获取
			List<UserInfoDto> datas = assignmentService.selectAssignmentUserList(companyId, operatorId);
			stringRedisTemplate.opsForValue().set(key, JSONArray.toJSONString(datas), 120, TimeUnit.HOURS);
			for(UserInfoDto user :datas){
				if (type == 1 || user.getId().longValue() != operatorId.longValue()) {
					users.add(user);
				}
			}
		}
		return users;
	}

	@ApiOperation(value = "检查客户查看权限", notes = "检查客户查看权限")
	@ApiImplicitParam(name = "customerId", value = "客户ID", paramType = "path", required = true)
	@GetMapping(value = "/customer/power/{customerId}")
	public BaseResponseEntity<Boolean> checkViewCustomerPower(HttpServletRequest request, @PathVariable(value = "customerId") Long id){

		SessionUser user = getSessionUser(request);
		Long switchOperatorId = user.getSwitchOperatorId();
		Long companyId = user.getCompanyId();
		//获取该切换人下可管理的业务员集合

		//获取该切换人下可管理的业务员集合
		List<UserInfoDto> list = redisService.getOperatorAssignment(companyId, switchOperatorId, 1);
		List<Long> operatorIds = list.stream().filter(userInfo -> userInfo != null && userInfo.getId() != null).map(UserInfoDto::getId).collect(Collectors.toList());

		//通过operatorIds+客户id+companyId 查询客户 + 用switchOperatorId+companyId 查询共享的客户
		QueryCustomerNameDto queryDto = new QueryCustomerNameDto();
		queryDto.setCompanyId(companyId);
		queryDto.setOperatorIdList(operatorIds);
		queryDto.setOperatorId(switchOperatorId);
		queryDto.setCustomerId(id);
		//该业务员有查看权限的客户
		List<Customer> customerList = customerManager.queryCustomerByOperatorAndCid(queryDto);
		if(CollectionUtils.isEmpty((customerList))) {
			throw new BusinessException("无客户查看权限！");
		}else {
			//只会查到一条数据
			if(customerList.get(0).getFlag() == 0){
				throw new BusinessException("客户已删除！");
			}else if(customerList.get(0).getFlag() == -1){
				//查看该业务员是否有查看客户回收箱的权限
				if(!dataPermissionValidateManager.validateMangerPermission(user.getOperatorId(), user.getSwitchOperatorId(), Constants.RESOURCE_CUSTOMER_RECOVERY)){
					throw new BusinessException("无客户查看权限！");
				}
			}
		}
		return BaseEntityBuilder.success(true);
	}
}
