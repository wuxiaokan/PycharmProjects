package com.joinf.controller;

import com.github.pagehelper.Page;
import com.joinf.constant.ResponseCodeEnum;
import com.joinf.constants.Customize;
import com.joinf.dto.BusinessEmailDto;
import com.joinf.dto.BusinessFollowUpDto;
import com.joinf.dto.BusinessOrderDto;
import com.joinf.dto.BusinessProductDto;
import com.joinf.dto.BusinessQuoteDto;
import com.joinf.dto.DeleteBusinessDto;
import com.joinf.dto.InsertOrUpdateDto;
import com.joinf.dto.LogGroupInfoDto;
import com.joinf.dto.QueryBusinessDetailTableDto;
import com.joinf.dto.QueryBusinessDto;
import com.joinf.dto.QueryBusinessEmailDto;
import com.joinf.dto.QueryBusinessInfoDto;
import com.joinf.dto.SaveBusinessEmailRelDto;
import com.joinf.dto.supplier.SupplierDetailDto;
import com.joinf.entity.BusinessEntity;
import com.joinf.entity.BusinessInfoEntity;
import com.joinf.entity.BusinessShareRelEntity;
import com.joinf.entity.PropertiesEntity;
import com.joinf.entity.generator.Business;
import com.joinf.exception.AreadyExsitException;
import com.joinf.exception.CommonException;
import com.joinf.interfaces.business.BusinessManager;
import com.joinf.request.InsertOrUpdateRequest;
import com.joinf.request.business.BusinessEmailRelRequest;
import com.joinf.request.business.BusinessShareRequest;
import com.joinf.request.business.DeleteBusinessRequest;
import com.joinf.request.business.GetBusinessLogRequest;
import com.joinf.request.business.QueryBusinessDetailTableRequest;
import com.joinf.request.business.QueryBusinessEmailRelRequest;
import com.joinf.request.business.QueryBusinessListRequest;
import com.joinf.request.business.UpdateBusinessStepRequest;
import com.joinf.response.EditDetailResponse;
import com.joinf.response.business.*;
import com.joinf.response.supplier.QuerySupplierResponse;
import com.joinf.service.redis.RedisService;
import com.joinf.utils.BaseEntityUtils;
import com.joinf.utils.annotations.Permission;
import com.joinf.utils.base.BaseEntityBuilder;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.dto.log.LogInfoDto;
import com.joinf.utils.dto.session.SessionUser;
import com.joinf.utils.dto.user.UserInfoDto;
import com.joinf.utils.enums.EsSearchUrlEnum;
import com.joinf.utils.util.BeanUtils;
import com.joinf.utils.util.EsSearchUtil;
import com.joinf.utils.util.JoinfBeanUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 商机
 *
 * @author yzq
 * @date 2019-04-12
 */
@Slf4j
@Api(tags = "商机服务", description = "BusinessController")
@RestController
public class BusinessController extends BaseController{

    @Autowired
    private RedisService redisService;

    @Autowired
    private BusinessManager businessManager;

    @Autowired
	private PropertiesEntity propertiesEntity;

    /**
     * 查询商机列表
     *
     * @param req
     * @return
     */
    @ApiOperation(value = "查询商机列表", notes = "查询商机列表")
    @GetMapping("/businesses")
    @ResponseBody
    @Permission(require = "business.list.preview")
    public BaseResponseEntity<QuerySupplierResponse> getBusinessList(HttpServletRequest request, QueryBusinessListRequest req) {
        log.info("入参为：" + req.toString());
        BaseResponseEntity<QuerySupplierResponse> response = new BaseResponseEntity<>(true);
        SessionUser user = getSessionUser(request);

        QueryBusinessDto queryBusinessDto = JoinfBeanUtils.copyToNewBean(QueryBusinessDto.class, req);

        queryBusinessDto.setCompanyId(user.getCompanyId());
        queryBusinessDto.setOperatorId(user.getOperatorId());
        queryBusinessDto.setSwitchOperatorId(user.getSwitchOperatorId());

        List<Long> operatorIdList = new ArrayList<>();
        //查询业务员为空，获取自己和下属的operatorId集合，查询对应的商机
        if(null == req.getOperatorId()){
            List<UserInfoDto> list = redisService.getOperatorAssignment(user.getCompanyId(), user.getSwitchOperatorId(), 1);
            operatorIdList = list.stream().filter(userInfo -> userInfo != null && userInfo.getId() != null).map(UserInfoDto::getId).collect(Collectors.toList());
        }else {//有业务员，只查询该业务员对应的商机
            operatorIdList.add(req.getOperatorId());
        }
        queryBusinessDto.setOperatorIdList(operatorIdList);

        List<BusinessEntity> businessEntities = businessManager.queryBusinessList(queryBusinessDto);

        queryBusinessDto.setRoleId(user.getRoleId());
        queryBusinessDto.setResourceId(Customize.BusinessList.getResourceId());
        queryBusinessDto.setTableName(Customize.BusinessList.getTableName());
        queryBusinessDto.setModule(Customize.BusinessList.getModule());
        List<BusinessEntity> queryEntities;
        if (req.isPaging()) {
            queryEntities = ((Page<BusinessEntity>) businessEntities).getResult();
            response.setTotalPage(((Page<BusinessEntity>) businessEntities).getPages());
            response.setTotalRecords(((Page<BusinessEntity>) businessEntities).getTotal());
        } else {
            queryEntities = businessEntities;
        }
        response.setData(businessManager.getBusinessListArray(queryBusinessDto, queryEntities));
        response.setCode(ResponseCodeEnum.SUCCESS.getStatus());
        response.setSuccess(true);
        return response;
    }

    @ApiOperation(value = "商机新增", notes = "商机新增")
    @PostMapping("/businesses")
    @Permission(require = "business.list.new")
    public BaseResponseEntity<Business> createBusiness(HttpServletRequest request, @RequestBody InsertOrUpdateRequest req) throws AreadyExsitException {
        log.info("入参为：" + req.toString());
        BaseResponseEntity<Business> entity = new BaseResponseEntity<>();
        InsertOrUpdateDto dto = new InsertOrUpdateDto();
        dto.setValues(req.getModels());
        dto.setOldValue(req.getOldValue());
        SessionUser user = getSessionUser(request);
        dto.setOperatorId(user.getOperatorId());
        dto.setOperatorName(user.getUser().getChineseName());
        dto.setSwitchOperatorId(user.getSwitchOperatorId());
        dto.setCompanyId(user.getCompanyId());
        dto.setTableName(Customize.BusinessEdit.getTableName());
        dto.setRoleId(user.getRoleId());
        dto.setModifyCustomerFlowStep(req.getModifyCustomerFlowStep());
        dto.setAttachmentIdList(req.getAttachmentIdList());
        dto.setClueId(req.getClueId());

        entity.setData((Business) businessManager.insertOrUpdateBusiness(dto).getReturnValue());
        entity.setSuccess(true);
        return entity;
    }

    @ApiOperation(value = "商机修改", notes = "商机修改")
    @PutMapping("/businesses")
    @Permission(require = "business.list.edit")
    @ResponseBody
    public BaseResponseEntity<Business> modifyBusiness(HttpServletRequest request, @RequestBody InsertOrUpdateRequest req) throws AreadyExsitException {
        log.info("入参为：" + req.toString());
        BaseResponseEntity<Business> entity = new BaseResponseEntity<>();
        SessionUser user = getSessionUser(request);
        Long businessId = req.getId();

        InsertOrUpdateDto dto = new InsertOrUpdateDto();
        dto.setValues(req.getModels());
        dto.setOldValue(req.getOldValue());
        dto.setOperatorId(user.getOperatorId());
        dto.setOperatorName(user.getUser().getChineseName());
        dto.setSwitchOperatorId(user.getSwitchOperatorId());
        dto.setCompanyId(user.getCompanyId());
        dto.setId(businessId);
        dto.setTableName(Customize.BusinessEdit.getTableName());
        dto.setRoleId(user.getRoleId());
        dto.setModifyCustomerFlowStep(req.getModifyCustomerFlowStep());
        dto.setAttachmentIdList(req.getAttachmentIdList());
        entity.setData((Business) businessManager.insertOrUpdateBusiness(dto).getReturnValue());
        entity.setSuccess(true);
        return entity;
    }

    @ApiOperation(value = "查询商机明细", notes = "查询商机明细")
    @ApiImplicitParams({@ApiImplicitParam(name = "id", value = "商机ID(新建的时候入0)", paramType = "path", required = true),
                        @ApiImplicitParam(name = "type", value = "新建:0  编辑:1  查看:2", paramType = "path", required = true)})
    @GetMapping("/businesses/{id}/{type}")
    @Permission(require = "business.list.preview")
    public BaseResponseEntity<List<EditDetailResponse>> getBusinessDetail(HttpServletRequest request, @PathVariable(value = "id") Long id, @PathVariable(value = "type") Integer type){
        log.info("入参为：id="+id+",type="+type);
        if (type.intValue() == 0 || type.intValue() == 1 || type.intValue() == 2) {
            SupplierDetailDto dto = new SupplierDetailDto();
            dto.setId(id);
            SessionUser user = getSessionUser(request);
            dto.setOperatorId(user.getOperatorId());
            dto.setOperatorName(user.getUser().getChineseName() + "(" + user.getUser().getUserName() + ")");
            dto.setSwitchOperatorId(user.getSwitchOperatorId());
            dto.setCompanyId(user.getCompanyId());
            dto.setRoleId(user.getRoleId());

            dto.setResourceId(Customize.BusinessEdit.getResourceId());
            dto.setTableName(Customize.BusinessEdit.getTableName());
            dto.setModule(Customize.BusinessEdit.getModule());
            List<EditDetailResponse> details = businessManager.getBusinessEditArray(dto, type);
            return BaseEntityUtils.successOne(details);
        } else {
            throw new CommonException("参数类型错误！");
        }
    }

    @ApiOperation(value = "商机跟进阶段修改", notes = "商机阶段修改")
    @PutMapping("/businesses/step")
    @Permission(require = "business.list.edit")
    public BaseResponseEntity<Boolean> modifyBusinessStep(HttpServletRequest request, @RequestBody UpdateBusinessStepRequest req){
        log.info("入参为：" + req.toString());
        BaseResponseEntity<Boolean> entity = new BaseResponseEntity<>();
        SessionUser user = getSessionUser(request);

        Long id = req.getId();
        Long flowStep = req.getFlowStep();
        boolean modifyCustomerFlowStep = req.getModifyCustomerFlowStep();
        entity.setSuccess(businessManager.modifyBusinessStep(id,modifyCustomerFlowStep,flowStep,convertToLoginUserDto(user)));
        return entity;
    }

    @ApiOperation(value = "商机删除校验",notes = "商机删除校验")
    @GetMapping("/businesses/check")
    @Permission(require = "business.list.delete")
    public BaseResponseEntity<String> deleteCheckBusiness(HttpServletRequest request, DeleteBusinessRequest req){
        log.info("入参为："+req.toString());
        BaseResponseEntity<String> entity = new BaseResponseEntity<>();

        SessionUser user = getSessionUser(request);

        DeleteBusinessDto dto = new DeleteBusinessDto();
        dto.setCompanyId(user.getCompanyId());
        dto.setIds(req.getIds());
        dto.setOperatorId(user.getSwitchOperatorId());

        entity.setData(businessManager.deleteCheckBusiness(dto));
        entity.setSuccess(true);
        return entity;
    }

    @ApiOperation(value = "商机删除",notes = "商机删除")
    @DeleteMapping("/businesses")
    @Permission(require = "business.list.delete")
    public BaseResponseEntity<Boolean> deleteBusiness(HttpServletRequest request, DeleteBusinessRequest req){
        log.info("入参为："+req.toString());
        BaseResponseEntity<Boolean> entity = new BaseResponseEntity<>();

        SessionUser user = getSessionUser(request);

        DeleteBusinessDto dto = new DeleteBusinessDto();
        dto.setCompanyId(user.getCompanyId());
        dto.setIds(req.getIds());
        dto.setOperatorId(user.getSwitchOperatorId());

        entity.setSuccess(businessManager.deleteBusiness(convertToLoginUserDto(user), dto));
        entity.setSuccess(true);
        return entity;
    }


	@ApiOperation(value="查询商机日志", notes="查询商机日志")
    @GetMapping("/businesses/logs")
    @Permission(require = "business.list.preview")
    public BaseResponseEntity<List<LogInfoDto>> getBusinessLogs(HttpServletRequest request, GetBusinessLogRequest req){
        log.info("入参为："+req.toString());
        BaseResponseEntity<List<LogInfoDto>> entity = new BaseResponseEntity<>();
        SessionUser user = getSessionUser(request);
        
        Map<String, Object> searchMap = new HashMap<>();
        searchMap.put("companyId", user.getCompanyId());

        //自己或下属，查询所有操作日志;上级共享的客户,只查询当前业务员的操作日志。
        List<UserInfoDto> list = redisService.getOperatorAssignment(user.getCompanyId(), user.getSwitchOperatorId(),1);
        List<Long> operatorIds = list.stream().filter(userInfo -> userInfo != null && userInfo.getId() != null).map(UserInfoDto::getId).collect(Collectors.toList());

        //Long operatorId = user.getSwitchOperatorId();
        if(req.getBusinessId() != null){
            searchMap.put("businessId", req.getBusinessId());
            //operatorId = getSearchBusinessLogOperatorId(user.getCompanyId(),req.getBusinessId(),user.getSwitchOperatorId(),operatorIds);
            Business business = businessManager.selectByPrimaryKey(req.getBusinessId());
            //暂时不按客户id查, 存在bug #59190
            //searchMap.put("cid",business.getCustomerId());
            searchMap.put("shareBusinessIds", business.getOperatorIds());

        }

        //邮件不能完全关联到业务员，先去掉
        //searchMap.put("operatorId", operatorId);

        if (StringUtils.isNotBlank(req.getBusType())) {
            searchMap.put("tableName", req.getBusType());
        } else {
            List<String> modules = getOperatorModules(user);
            searchMap.put("tableName", StringUtils.join(modules, ","));
            if(modules.size() == 0){
                entity.setSuccess(true);
                entity.setTotalRecords(0L);
                return entity;
            }
        }

        Integer year = null != req.getYear() ? Integer.parseInt(req.getYear()) : 0;
        Integer month = null != req.getMonth() ? Integer.parseInt(req.getMonth()) : 0;

        getDateStr(year,month,searchMap);
        searchMap.put("pageStart", (req.getPageStart()-1)*req.getPageSize());
        searchMap.put("pageSize", req.getPageSize());
        searchMap.put("flowStep",req.getFlowStep());
        searchMap.put("from", "app");

        
        BaseResponseEntity<List<LogInfoDto>> result = EsSearchUtil.searchDataList(EsSearchUrlEnum.LOG_SEARCH.getUrl(propertiesEntity.getEsUrl()), searchMap, LogInfoDto.class);
        
        businessManager.convertBusinessLogData(result.getData(), convertToLoginUserDto(user));
        entity.setTotalPage((int)result.getTotalPage(req.getPageSize()));
        entity.setTotalRecords(result.getTotalRecords());
        entity.setData(result.getData());
        entity.setSuccess(result.isSuccess());
        return entity;
    }

	
//    private Long getSearchBusinessLogOperatorId(Long companyId,Long businessId,Long operatorId,List<Long> operatorIdList){
//
//        //自己或下属的商机，查询所有操作日志。 上级共享的客户，只查询当前业务员的操作日志。
//        Long searchOperatorId = null;
//
//        //查询商机明细
//        Business business = this.businessManager.selectByPrimaryKey(businessId);
//
//        if(business==null || business.getCompanyId() == null) {
//            throw new CommonException("商机ID不存在！");
//        }
//
//        if(business.getCompanyId().longValue() != companyId.longValue()) {
//            throw new CommonException("无效的商机ID");
//        }
//
//        if(business.getFlag().intValue()!=1){
//            throw new CommonException("商机已删除！");
//        }
//
//        //自己或下属的客户
//        if (business.getOperatorId().longValue() == operatorId || operatorIdList.contains(business.getOperatorId().longValue())) {
//            searchOperatorId = operatorId;
//        }
//        //其他情况就是共享给我的商机
//        else{
//            //获取该商机共享的业务员集合
//            List<BusinessShareRel> businessShareRelList = businessService.selectBusinessShareByBidAndCid(business.getId(),business.getCompanyId());
//            if (!CollectionUtils.isEmpty(businessShareRelList)) {
//                for (BusinessShareRel businessShareRel : businessShareRelList) {
//                    if(operatorId.equals(businessShareRel.getShareId())){
//                        searchOperatorId = operatorId;
//                        break;
//                    }
//                }
//            }
//            //searchOperatorId为空表示没有此商机的查询条件
//            if (searchOperatorId == null) {
//                throw new CommonException("没有商机的查询权限！");
//            }
//        }
//
//        return searchOperatorId;
//    }

    /**
     * 查询商机对应业务数目
     * @param request
     * @param req
     * @return
     */
	@ApiOperation(value="统计商机日志", notes="统计商机日志")
    @GetMapping(value = "/businesses/logs/num")
    @Permission(require = "business.list.preview")
    @ResponseBody
    public BaseResponseEntity<List<LogGroupInfoDto>> getBusinessLogNum(HttpServletRequest request, GetBusinessLogRequest req) {
        log.info("入参为："+req.toString());
        BaseResponseEntity<List<LogGroupInfoDto>> entity = new BaseResponseEntity<>();
        SessionUser user = getSessionUser(request);

        Map<String, Object> searchMap = new HashMap<>();
        searchMap.put("companyId", user.getCompanyId());

        //自己或下属，查询所有操作日志;上级共享的客户,只查询当前业务员的操作日志。
        List<UserInfoDto> list = redisService.getOperatorAssignment(user.getCompanyId(), user.getSwitchOperatorId(),1);
        List<Long> operatorIds = list.stream().filter(userInfo -> userInfo != null && userInfo.getId() != null).map(UserInfoDto::getId).collect(Collectors.toList());

        //Long operatorId = user.getSwitchOperatorId();
        if(req.getBusinessId() != null){
            searchMap.put("businessId", req.getBusinessId());
            //operatorId = getSearchBusinessLogOperatorId(user.getCompanyId(),req.getBusinessId(),user.getSwitchOperatorId(),operatorIds);
            Business business = businessManager.selectByPrimaryKey(req.getBusinessId());
            //暂时不按客户id查, 存在bug #59190
            //searchMap.put("cid",business.getCustomerId());
            searchMap.put("shareBusinessIds", business.getOperatorIds());

        }
        //searchMap.put("operatorId", operatorId);

        if(StringUtils.isNotBlank(req.getBusType()))
            searchMap.put("tableName", req.getBusType());
        else {
            List<String> modules = getOperatorModules(user);
            searchMap.put("tableName", StringUtils.join(modules, ","));
            if(modules.size() == 0){
                entity.setSuccess(true);
                entity.setTotalRecords(0L);
                return entity;
            }
        }

        Integer year = null != req.getYear() ? Integer.parseInt(req.getYear()) : 0;
        Integer month = null != req.getMonth() ? Integer.parseInt(req.getMonth()) : 0;
        getDateStr(year,month,searchMap);
        searchMap.put("flowStep",req.getFlowStep());
        searchMap.put("from", "app");

        BaseResponseEntity<List<LogGroupInfoDto>> result = EsSearchUtil.searchDataList(EsSearchUrlEnum.LOG_GROUP_SEARCH.getUrl(propertiesEntity.getEsUrl()), searchMap, LogGroupInfoDto.class);
        
        entity.setData(result.getData());
        entity.setSuccess(result.isSuccess());
        entity.setCode(ResponseCodeEnum.SUCCESS.getStatus());
        return entity;
    }

    @ApiOperation(value="共享商机", notes="共享商机")
    @PutMapping("/businesses/share")
    @ResponseBody
    @Permission(require = "business.list.share")
    public BaseResponseEntity<Boolean> shareBusiness(HttpServletRequest request, @RequestBody BusinessShareRequest req) {
        log.info("入参为："+req.toString());
        BaseResponseEntity<Boolean> entity = new BaseResponseEntity<>();
        SessionUser user = getSessionUser(request);

        Long companyId = user.getCompanyId();
        Long id = req.getId();
        List<BusinessShareRelEntity> shareList = req.getShareList();

        entity.setData(businessManager.updateBusinessOperatorIds(id, shareList,companyId));
        entity.setSuccess(true);
        entity.setCode(ResponseCodeEnum.SUCCESS.getStatus());
        return entity;
    }

    @ApiOperation(value="商机详情-订单", notes="商机详情-订单")
    @GetMapping("/businesses/orders")
    @Permission(require = "business.list.preview")
    public BaseResponseEntity<List<BusinessOrderResponse>> getBusinessOrderTab(HttpServletRequest request, QueryBusinessDetailTableRequest req){
        log.info("入参为："+req.toString());
        BaseResponseEntity<List<BusinessOrderResponse>> entity = new BaseResponseEntity<>();
        SessionUser user = getSessionUser(request);

        QueryBusinessDetailTableDto dto = JoinfBeanUtils.copyToNewBean(QueryBusinessDetailTableDto.class,req);
        dto.setCompanyId(user.getCompanyId());

        List<BusinessOrderDto> dtoList = businessManager.selectBusinessOrders(dto);

        if (req.isPaging()) {
            entity.setTotalPage(((Page<BusinessOrderDto>) dtoList).getPages());
            entity.setTotalRecords(((Page<BusinessOrderDto>) dtoList).getTotal());
        }

        List<BusinessOrderResponse> response = JoinfBeanUtils.copyToNewListBean(BusinessOrderResponse.class, dtoList);


        entity.setData(response);
        entity.setSuccess(true);
        return entity;
    }

    @ApiOperation(value="商机详情-报价", notes="商机详情-报价")
    @GetMapping("/businesses/quotes")
    @Permission(require = "business.list.preview")
    public BaseResponseEntity<List<BusinessQuoteResponse>> getBusinessQuoteTab(HttpServletRequest request, QueryBusinessDetailTableRequest req){
        log.info("入参为："+req.toString());
        BaseResponseEntity<List<BusinessQuoteResponse>> entity = new BaseResponseEntity<>();
        SessionUser user = getSessionUser(request);

        QueryBusinessDetailTableDto dto = JoinfBeanUtils.copyToNewBean(QueryBusinessDetailTableDto.class,req);
        dto.setCompanyId(user.getCompanyId());

        List<BusinessQuoteDto> dtoList = businessManager.selectBusinessQuotes(dto);

        if (req.isPaging()) {
            entity.setTotalPage(((Page<BusinessQuoteDto>) dtoList).getPages());
            entity.setTotalRecords(((Page<BusinessQuoteDto>) dtoList).getTotal());
        }

        List<BusinessQuoteResponse> response = JoinfBeanUtils.copyToNewListBean(BusinessQuoteResponse.class, dtoList);

        entity.setData(response);
        entity.setSuccess(true);
        return entity;
    }

    @ApiOperation(value="商机详情-跟进", notes="商机详情-跟进")
    @GetMapping("/businesses/followUps")
    @Permission(require = "business.list.preview")
    public BaseResponseEntity<List<BusinessFollowUpResponse>> getBusinessFollowUpTab(HttpServletRequest request, QueryBusinessDetailTableRequest req){
        log.info("入参为："+req.toString());
        BaseResponseEntity<List<BusinessFollowUpResponse>> entity = new BaseResponseEntity<>();
        SessionUser user = getSessionUser(request);

        QueryBusinessDetailTableDto dto = JoinfBeanUtils.copyToNewBean(QueryBusinessDetailTableDto.class,req);
        dto.setCompanyId(user.getCompanyId());

        List<BusinessFollowUpDto> dtoList = businessManager.selectBusinessFollowUps(dto, convertToLoginUserDto(user));

        if (req.isPaging()) {
            entity.setTotalPage(((Page<BusinessFollowUpDto>) dtoList).getPages());
            entity.setTotalRecords(((Page<BusinessFollowUpDto>) dtoList).getTotal());
        }

        List<BusinessFollowUpResponse> response = JoinfBeanUtils.copyToNewListBean(BusinessFollowUpResponse.class, dtoList);

        entity.setData(response);
        entity.setSuccess(true);
        return entity;
    }

    @ApiOperation(value="商机详情-邮件", notes="商机详情-邮件")
    @GetMapping("/businesses/emails")
    @Permission(require = "business.list.preview")
    public BaseResponseEntity<List<BusinessEmailResponse>> getBusinessEmailTab(HttpServletRequest request, QueryBusinessDetailTableRequest req){
        log.info("入参为："+req.toString());
        BaseResponseEntity<List<BusinessEmailResponse>> entity = new BaseResponseEntity<>();
        SessionUser user = getSessionUser(request);

        QueryBusinessDetailTableDto dto = JoinfBeanUtils.copyToNewBean(QueryBusinessDetailTableDto.class,req);
        dto.setCompanyId(user.getCompanyId());

        List<BusinessEmailDto> dtoList = businessManager.selectBusinessEmailRecord(dto);

        if (req.isPaging()) {
            entity.setTotalPage(((Page<BusinessEmailDto>) dtoList).getPages());
            entity.setTotalRecords(((Page<BusinessEmailDto>) dtoList).getTotal());
        }

        List<BusinessEmailResponse> response = JoinfBeanUtils.copyToNewListBean(BusinessEmailResponse.class, dtoList);

        entity.setData(response);
        entity.setSuccess(true);
        return entity;
    }

    @ApiOperation(value="商机详情-可关联邮件", notes="商机详情-可关联邮件")
    @GetMapping("/businesses/emailRel")
    @Permission(require = "business.list.preview")
    public BaseResponseEntity<List<BusinessEmailResponse>> getBusinessEmailRel(HttpServletRequest request, QueryBusinessEmailRelRequest req){
        log.info("入参为："+req.toString());
        BaseResponseEntity<List<BusinessEmailResponse>> entity = new BaseResponseEntity<>();
        SessionUser user = getSessionUser(request);

        QueryBusinessEmailDto dto = JoinfBeanUtils.copyToNewBean(QueryBusinessEmailDto.class,req);
        dto.setCompanyId(user.getCompanyId());

        List<BusinessEmailDto> dtoList = businessManager.selectBusinessEmailRel(dto);

        if (req.isPaging()) {
            entity.setTotalPage(((Page<BusinessEmailDto>) dtoList).getPages());
            entity.setTotalRecords(((Page<BusinessEmailDto>) dtoList).getTotal());
        }

        List<BusinessEmailResponse> response = JoinfBeanUtils.copyToNewListBean(BusinessEmailResponse.class, dtoList);

        entity.setData(response);
        entity.setSuccess(true);
        return entity;
    }

    @ApiOperation(value="商机详情-邮件-关联邮件保存", notes="商机详情-邮件-关联邮件保存")
    @PutMapping("/businesses/emails")
    @Permission(require = "business.list.edit")
    public BaseResponseEntity<Boolean> saveBusinessEmailRel(HttpServletRequest request, @RequestBody BusinessEmailRelRequest req){
        log.info("入参为："+req.toString());
        BaseResponseEntity<Boolean> entity = new BaseResponseEntity<>();
        SessionUser user = getSessionUser(request);

        SaveBusinessEmailRelDto saveBusinessEmailRelDto = JoinfBeanUtils.copyToNewBean(SaveBusinessEmailRelDto.class, req);
        saveBusinessEmailRelDto.setCompanyId(user.getCompanyId());
        saveBusinessEmailRelDto.setOperatorId(user.getSwitchOperatorId());
        saveBusinessEmailRelDto.setEmailIds(req.getEmailIds());

        entity.setData(businessManager.saveBusinessEmailRel(saveBusinessEmailRelDto));
        entity.setSuccess(true);
        entity.setCode(ResponseCodeEnum.SUCCESS.getStatus());
        return entity;
    }

    @ApiOperation(value = "商机详情-邮件-取消关联", notes = "商机详情-邮件-取消关联")
    @DeleteMapping("/businesses/emails")
    @Permission(require = "business.list.edit")
    public BaseResponseEntity<Boolean> cancelBusinessEmailRel(HttpServletRequest request, BusinessEmailRelRequest req){
        log.info("入参为："+req.toString());
        BaseResponseEntity<Boolean> entity = new BaseResponseEntity<>();
        SessionUser user = getSessionUser(request);

        SaveBusinessEmailRelDto saveBusinessEmailRelDto = JoinfBeanUtils.copyToNewBean(SaveBusinessEmailRelDto.class, req);
        saveBusinessEmailRelDto.setOperatorId(user.getSwitchOperatorId());
        saveBusinessEmailRelDto.setCompanyId(user.getCompanyId());
        saveBusinessEmailRelDto.setEmailIds(req.getEmailIds());

        entity.setData(businessManager.cancelBusinessEmailRel(saveBusinessEmailRelDto));
        entity.setSuccess(true);
        entity.setCode(ResponseCodeEnum.SUCCESS.getStatus());

        return entity;
    }

    @ApiOperation(value="商机详情-产品", notes="商机详情-产品")
    @GetMapping("/businesses/products")
    @Permission(require = "business.list.preview")
    public BaseResponseEntity<List<BusinessProductResponse>> getBusinessProductTab(HttpServletRequest request, QueryBusinessDetailTableRequest req){
        log.info("入参为："+req.toString());
        BaseResponseEntity<List<BusinessProductResponse>> entity = new BaseResponseEntity<>();
        SessionUser user = getSessionUser(request);

        QueryBusinessDetailTableDto dto = JoinfBeanUtils.copyToNewBean(QueryBusinessDetailTableDto.class,req);
        dto.setCompanyId(user.getCompanyId());

        List<BusinessProductDto> dtoList = businessManager.selectBusinessProducts(dto);

        if (req.isPaging()) {
            entity.setTotalPage(((Page<BusinessProductDto>) dtoList).getPages());
            entity.setTotalRecords(((Page<BusinessProductDto>) dtoList).getTotal());
        }

        List<BusinessProductResponse> response = JoinfBeanUtils.copyToNewListBean(BusinessProductResponse.class, dtoList);

        entity.setData(response);
        entity.setSuccess(true);
        return entity;
    }

    @ApiOperation(value = "商机列表-总目标金额", notes = "商机列表-总目标金额")
    @GetMapping("businesses/sumTargetPayment")
    @Permission(require = "business.list.preview")
    public BaseResponseEntity<String> getSumTargetPayment(HttpServletRequest request, QueryBusinessListRequest req){
        log.info("入参为："+req.toString());
        BaseResponseEntity<String> entity = new BaseResponseEntity<>();
        SessionUser user = getSessionUser(request);

        QueryBusinessDto queryBusinessDto = JoinfBeanUtils.copyToNewBean(QueryBusinessDto.class, req);
        queryBusinessDto.setCompanyId(user.getCompanyId());
        queryBusinessDto.setOperatorId(user.getOperatorId());
        queryBusinessDto.setSwitchOperatorId(user.getSwitchOperatorId());

        List<Long> operatorIdList = new ArrayList<>();
        //查询业务员为空，获取自己和下属的operatorId集合，查询对应的商机
        if(null == req.getOperatorId()){
            List<UserInfoDto> list = redisService.getOperatorAssignment(user.getCompanyId(), user.getSwitchOperatorId(), 1);
            for (UserInfoDto userInfo : list) {
                if(userInfo != null && userInfo.getId() != null){
                    operatorIdList.add(userInfo.getId());
                }
            }
        }else {//有业务员，只查询该业务员对应的商机
            operatorIdList.add(req.getOperatorId());
        }
        queryBusinessDto.setOperatorIdList(operatorIdList);

        queryBusinessDto.setRoleId(user.getRoleId());
        queryBusinessDto.setResourceId(Customize.BusinessList.getResourceId());
        queryBusinessDto.setTableName(Customize.BusinessList.getTableName());
        queryBusinessDto.setModule(Customize.BusinessList.getModule());
        //总金额不需要分页、排序
        queryBusinessDto.setPaging(false);
        queryBusinessDto.setSortColumn(null);
        queryBusinessDto.setSortType(null);

        List<BusinessEntity> businessEntities = businessManager.queryBusinessList(queryBusinessDto);
        entity.setData(businessManager.getSumTargetPayment(businessEntities, queryBusinessDto));
        entity.setSuccess(true);
        entity.setCode(ResponseCodeEnum.SUCCESS.getStatus());
        return entity;
    }

    @ApiOperation(value = "检查商机是否可编辑啊-只针对只读", notes = "检查商机是否可编辑")
    @GetMapping(value = "businesses/isEdit/{id}")
    public BaseResponseEntity<Boolean> checkIsView(HttpServletRequest request, @PathVariable(value = "id") Long id ){
        BaseResponseEntity<Boolean> entity = new BaseResponseEntity<>();
        SessionUser user = getSessionUser(request);

        entity.setData(businessManager.selectBusinessIsEdit(id, convertToLoginUserDto(user)));
        entity.setSuccess(true);
        entity.setCode(ResponseCodeEnum.SUCCESS.getStatus());
        return entity;
    }

    @ApiOperation(value = "关联关系商机详情", notes = "关联关系商机详情")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value="商机ID", paramType="query", required=true) ,
            @ApiImplicitParam(name = "emailId", value="邮件ID", paramType="query", required=true)})
    @GetMapping(value = "businesses/get")
    public BaseResponseEntity<EmailRelBusinessResponse> getBusinessInfoById(HttpServletRequest request,
                                                                            @RequestParam(value = "id",required = true) Long id,
                                                                            @RequestParam(value = "emailId", required = true) Long emailId) {
        SessionUser user = getSessionUser(request);
        QueryBusinessInfoDto dto = new QueryBusinessInfoDto();
        dto.setCompanyId(user.getCompanyId());
        dto.setOperatorId(user.getSwitchOperatorId());
        dto.setLoginOperatorId(user.getOperatorId());
        dto.setId(id);
        dto.setEmailId(emailId);
        BusinessInfoEntity entity = businessManager.getBuisnessInfoById(dto);
        EmailRelBusinessResponse response = JoinfBeanUtils.copyToNewBean(EmailRelBusinessResponse.class, entity);
        return BaseEntityBuilder.success(response);
    }


    @ApiOperation(value = "通过客户id 查询商机", notes = "通过客户id 查询商机")
    @ApiImplicitParam(name = "customerId", value="客户ID", paramType="path", required=true)
    @GetMapping(value = "businesses/{customerId}")
    public BaseResponseEntity<List<BusinessCustomerResponse>> getBusinessByCustomerId(HttpServletRequest request, @PathVariable(value = "customerId") Long customerId ){
        BaseResponseEntity<List<BusinessCustomerResponse>> entity = new BaseResponseEntity<>();
        SessionUser user = getSessionUser(request);
        DeleteBusinessDto dto = new DeleteBusinessDto();
        dto.setCompanyId(user.getCompanyId());
        dto.setCustomerId(customerId);
        List<Business> businessList = businessManager.selectBusinessByIdsAndCidAndOid(dto);
        List<BusinessCustomerResponse> responseList = BeanUtils.copyToNewListBean(BusinessCustomerResponse.class,businessList);
        entity.setData(responseList);
        entity.setSuccess(true);
        entity.setCode(ResponseCodeEnum.SUCCESS.getStatus());
        return entity;
    }

}
