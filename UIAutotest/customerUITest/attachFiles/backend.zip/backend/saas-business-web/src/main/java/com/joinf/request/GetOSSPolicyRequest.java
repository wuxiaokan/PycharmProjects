package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 获取签名请求
 * @date 2018年4月12日 上午10:23:59
 */
public class GetOSSPolicyRequest {

	@ApiModelProperty(value="1:其他,2:业务员头像,3:业务员中英文文签章,4:公司中英文logo,5:公司印章,11:身份信息验证附件,22:反馈附件  23:商机附件",required=true)
	private Integer type;

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}
}
