package com.joinf.request.business;

import java.io.Serializable;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 新增商机附件参数
 * @date 2019年5月6日 下午7:03:16
 */
public class SaveBusinessAttachmentRequest implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value ="商机附件集合")
	private List<BusinessAttachmentRequest> list;

	public List<BusinessAttachmentRequest> getList() {
		return list;
	}

	public void setList(List<BusinessAttachmentRequest> list) {
		this.list = list;
	}
	
	
    
}
