package com.joinf.request.business;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

import com.joinf.utils.base.BasePage;

/**
 * @author zlx
 * @Description: 商机列表查询参数
 * @date 2019年4月11日 上午10:35:25
 */
public class QueryBusinessListRequest extends BasePage implements Serializable {

	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value ="跟进阶段")
	private Long flowStep;

	@ApiModelProperty(value ="执行状态")
	private Integer status;

	@ApiModelProperty(value ="业务员ID")
	private Long operatorId;

	@ApiModelProperty(value ="业务员姓名")
	private String operatorName;

	@ApiModelProperty(value ="排序字段")
	private String sortColumn;

	@ApiModelProperty(value ="排序类别")
	private String sortType;

	public Long getFlowStep() {
		return flowStep;
	}

	public void setFlowStep(Long flowStep) {
		this.flowStep = flowStep;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Long getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(Long operatorId) {
		this.operatorId = operatorId;
	}

	public String getOperatorName() {
		return operatorName;
	}

	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}

	public String getSortColumn() {
		return sortColumn;
	}

	public void setSortColumn(String sortColumn) {
		this.sortColumn = sortColumn;
	}

	public String getSortType() {
		return sortType;
	}

	public void setSortType(String sortType) {
		this.sortType = sortType;
	}

	@Override
	public String toString() {
		return "QueryBusinessListRequest [flowStep=" + flowStep + ", status=" + status + ", operatorId=" + operatorId
				+ ", operatorName=" + operatorName + ", sortColumn=" + sortColumn + ", sortType=" + sortType + ", num="
				+ num + ", size=" + size + ", paging=" + paging + "]";
	}
	
	
}
