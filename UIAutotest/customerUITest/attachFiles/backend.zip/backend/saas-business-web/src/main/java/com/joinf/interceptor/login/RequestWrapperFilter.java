package com.joinf.interceptor.login;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Description: 增加request中json多次读取过滤器
 *
 * @author lyj
 * @date 2017年12月15日 下午8:43:14
 */
public class RequestWrapperFilter implements Filter {
	public void init(FilterConfig config) throws ServletException {
		// nothing goes here
	}

	/**
	 * 实现方法
	 */
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws java.io.IOException, ServletException {

		HttpServletResponse res = (HttpServletResponse) response;
		
		String method = ((HttpServletRequest) request).getMethod();

		if (method.equals("OPTIONS")) {
			res.setStatus(HttpServletResponse.SC_OK);
		} else {
			HttpServletRequest httpServletRequest = (HttpServletRequest) request;
			MultiReadHttpServletRequestWrapper requestWrapper = new MultiReadHttpServletRequestWrapper(
					httpServletRequest);
			chain.doFilter(requestWrapper, response);
		}

	}

	/**
	 * 实现方法
	 */
	public void destroy() {
	}
}
