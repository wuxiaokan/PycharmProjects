package com.joinf.request.business;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.List;

/**
 * 商机删除请求参数
 *
 * @author yzq
 * @date 2019-04-30
 */
public class DeleteBusinessRequest implements Serializable {

    private static final long serialVersionUID = -8018689481666242453L;

    @ApiModelProperty(value = "商机id列表",required = true)
    private List<Long> ids;

    public List<Long> getIds() {
        return ids;
    }

    public void setIds(List<Long> ids) {
        this.ids = ids;
    }

    @Override
    public String toString() {
        return "DeleteBusinessRequest{" +
                "ids=" + ids +
                '}';
    }
}
