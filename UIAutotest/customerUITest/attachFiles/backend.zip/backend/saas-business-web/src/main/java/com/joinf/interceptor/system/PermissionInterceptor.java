package com.joinf.interceptor.system;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.joinf.exception.NoLoginException;
import com.joinf.exception.NoPermissionException;
import com.joinf.singleton.ResourceSingleton;
import com.joinf.utils.LocaleMessage.LocaleMessage;
import com.joinf.utils.annotations.Permission;
import com.joinf.utils.dto.session.SessionUser;
import com.joinf.utils.dto.session.SessionUserInfo;
import org.apache.commons.lang.StringUtils;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @description: 权限拦截器
 * @author zlx
 * @date 2019年6月26日 下午7:38:26
 * @revisionHistory
 */
public class PermissionInterceptor implements HandlerInterceptor{

	@Resource
	private StringRedisTemplate stringRedisTemplate;
	@Resource
	private LocaleMessage localeMessage;
	
	/**
	 * 实现方法
	 */
	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		if(handler instanceof HandlerMethod){
			HandlerMethod method = (HandlerMethod) handler;

			SessionUser sessionUser = null;

			String joinfJsessionid = request.getHeader("joinf-jsessionid");
			String sessionUserJson = stringRedisTemplate.opsForValue().get(joinfJsessionid);
			if (StringUtils.isNotBlank(sessionUserJson)) {
				sessionUser = JSON.parseObject(sessionUserJson, SessionUser.class);
				if (sessionUser != null) {
					SessionUserInfo user = sessionUser.getUser();
					if (user == null) {
						throw new NoLoginException();
					}
				}
			}
			if (sessionUser == null) {
				throw new NoLoginException();
			}

			//需要校验权限
			if(method.hasMethodAnnotation(Permission.class)){
				Permission permission = method.getMethodAnnotation(Permission.class);
				String permissionCode = request.getParameter("permissionCode");
				if(StringUtils.isBlank(permissionCode))
				{
					permissionCode = permission.require();
				}
				
				validatePermission(sessionUser, permissionCode);
			}
		}
		return true;
	}

	/**
	 * 实现方法
	 */
	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub
		
	}

	/**
	 * 实现方法
	 */
	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	/**
	 * 判断是否有权限
	 * @param user
	 * @param permission 当前方法需要拥有的权限
	 * @return
	 */
	private void validatePermission(SessionUser user, String permission){
		
		List<String> requires = Arrays.asList(permission.split(","));
		
		for (String req : requires) {
			//权限代码
			List<String> codes = convertCode(req);
			
			//没有权限的代码
			List<String> notCodes = new ArrayList<>(codes);
			//业务员没有权限
			if (user.getResources() != null) {
				for (String code : codes) {
					for (Integer r : user.getResources()) {
						if (r != null && StringUtils.equals(r.toString(), code)) {
							notCodes.remove(code);
							break;
						}
					}
				}
			}
			
			//业务员拥有的权限代码
			if (notCodes.size() > 0) {
				//TODO 后续需要要根据权限代码查询权限名称(还要支持多语言)
				throw new NoPermissionException(localeMessage.getMessage("system.not.permission"));
			}
		}
	}

	/**
	 * 读取权限代码
	 * @param code
	 * @return
	 */
	private static List<String> convertCode(String code){
		JSONObject object = new JSONObject();
		String[] codeSplit = code.split("\\.");
		for(int i=0;i<codeSplit.length;i++){
			if(i==0)
			{
				object = ResourceSingleton.getResource().getJSONObject(codeSplit[0]);
			}
			else{
				if(object!=null){
					object = object.getJSONObject(codeSplit[i]);
				}
			}
		}
		if(object!=null)
		{
			return Arrays.asList(object.getString("code").split(","));
		}
		return new ArrayList<String>();
	}
}
