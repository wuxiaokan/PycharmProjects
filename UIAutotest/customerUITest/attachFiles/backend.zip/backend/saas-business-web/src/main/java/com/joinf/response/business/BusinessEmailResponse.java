package com.joinf.response.business;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * 商机详情页-table页邮件
 *
 * @author yzq
 * @date 2019-05-10
 */
public class BusinessEmailResponse implements Serializable {

    private static final long serialVersionUID = -4248380878752683983L;

    @JsonSerialize(using= ToStringSerializer.class)
    @ApiModelProperty(value = "邮箱id")
    private Long id;

    @ApiModelProperty(value = "邮箱地址")
    private String email;

    @ApiModelProperty(value = "邮箱主题")
    private String subject;

    @ApiModelProperty(value = "操作")
    private String lastOperater;

    @ApiModelProperty(value = "状态")
    private String status;

    @ApiModelProperty(value = "时间")
    private String createTime;

    @ApiModelProperty("联系人id")
    private Long contactId;

    @ApiModelProperty("联系人名称")
    private String contactName;

    @ApiModelProperty("客户id")
    private Long customerId;

    @ApiModelProperty("客户名称")
    private String customerName;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getLastOperater() {
        return lastOperater;
    }

    public void setLastOperater(String lastOperater) {
        this.lastOperater = lastOperater;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getContactId() {
        return contactId;
    }

    public void setContactId(Long contactId) {
        this.contactId = contactId;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
}
