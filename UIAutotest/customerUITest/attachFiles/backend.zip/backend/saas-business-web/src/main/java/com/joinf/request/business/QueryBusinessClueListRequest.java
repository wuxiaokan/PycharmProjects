package com.joinf.request.business;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

import com.joinf.utils.base.BasePage;

/**
 * 线索列表查询参数
 *
 * @author yzq
 * @date 2019-04-11
 */
public class QueryBusinessClueListRequest extends BasePage implements Serializable {

    private static final long serialVersionUID = -1236419995178884913L;

    @ApiModelProperty(value ="排序字段")
    private String sortColumn;

    @ApiModelProperty(value ="排序类别")
    private String sortType;

    @ApiModelProperty(value = "线索等级(0:待定;1:一星;2:二星;3:三星;4:四星;5:五星)")
    private Integer clueGrade;

    @ApiModelProperty(value = "线索来源(0:询盘信息;1:注册会员;2:访问咨询;3:商业数据;4:营销邮件)")
    private Integer clueType;

    @ApiModelProperty(value = "线索状态(0:待处理;1:已处理;2:已忽略)")
    private Integer clueStatus;

    public String getSortColumn() {
        return sortColumn;
    }

    public void setSortColumn(String sortColumn) {
        this.sortColumn = sortColumn;
    }

    public String getSortType() {
        return sortType;
    }

    public void setSortType(String sortType) {
        this.sortType = sortType;
    }

    public Integer getClueGrade() {
        return clueGrade;
    }

    public void setClueGrade(Integer clueGrade) {
        this.clueGrade = clueGrade;
    }

    public Integer getClueType() {
        return clueType;
    }

    public void setClueType(Integer clueType) {
        this.clueType = clueType;
    }

    public Integer getClueStatus() {
        return clueStatus;
    }

    public void setClueStatus(Integer clueStatus) {
        this.clueStatus = clueStatus;
    }

    @Override
    public String toString() {
        return "QueryBusinessClueListRequest{" +
                "sortColumn='" + sortColumn + '\'' +
                ", sortType='" + sortType + '\'' +
                ", clueGrade=" + clueGrade +
                ", clueType=" + clueType +
                ", clueStatus=" + clueStatus +
                ", num=" + num +
                ", size=" + size +
                ", paging=" + paging +
                '}';
    }
}
