package com.joinf.request.business;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @author zlx
 * @Description: 线索建档保存
 * @date 2019年4月25日 下午2:16:04
 */
public class SaveCustomerContactRequest implements Serializable {

    private static final long serialVersionUID = 197540694897823242L;
    
    @ApiModelProperty(value = "当前处理的线索ID")
    private Long clueId;
    
    @ApiModelProperty(value = "分配业务员ID")
    private Long allocationUserId;
    
    @ApiModelProperty(value = "客户ID")
    private Long customerId;


	public Long getClueId() {
		return clueId;
	}

	public void setClueId(Long clueId) {
		this.clueId = clueId;
	}

	public Long getAllocationUserId() {
		return allocationUserId;
	}

	public void setAllocationUserId(Long allocationUserId) {
		this.allocationUserId = allocationUserId;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	@Override
	public String toString() {
		return "SaveCustomerContactRequest [clueId=" + clueId + ", allocationUserId=" + allocationUserId
				+ ", customerId=" + customerId + "]";
	}
   
    
	
}
