package com.joinf.response.business;

import java.io.Serializable;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import com.joinf.JoinfClientUtils;
import com.joinf.config.SaasClientConfig;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 查询商机附件列表返回参数
 * @date 2019年5月6日 下午8:24:42
 */
public class QueryBusinessAttachmentResponse implements Serializable{
    @ApiModelProperty(value ="附件标识")
    private Long id;

    @ApiModelProperty(value ="附件名称")
    private String name;

    @ApiModelProperty(value ="附件code")
    private String code;
    
    @ApiModelProperty(value ="图片预览url")
    private String viewUrl;
    
    @ApiModelProperty(value ="原url")
    private String url;

    @ApiModelProperty(value ="附件大小")
    private Long size;

    @ApiModelProperty(value ="附件类型")
    private String type;
    
    @ApiModelProperty(value ="创建时间")
    private Date createTime;

    @ApiModelProperty(value = "创建人中文名")
	private String createName;

    private static final long serialVersionUID = 1L;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Long getSize() {
		return size;
	}

	public void setSize(Long size) {
		this.size = size;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getViewUrl() {
		if (StringUtils.isNotBlank(code)) {
			String reg = ".+(.JPEG|.jpeg|.JPG|.jpg)$";
			Pattern pattern = Pattern.compile(reg);
			Matcher matcher = pattern.matcher(code);
			if(matcher.find()){
				return JoinfClientUtils.getLfitUrl(SaasClientConfig.saasClientConfig,code, 150, 150);
			}else {
				return JoinfClientUtils.getUrl(SaasClientConfig.saasClientConfig,code);
			}
		}
		return null;
	}

	public String getUrl() {
		if (StringUtils.isNotBlank(code)) {
			return JoinfClientUtils.getUrl(SaasClientConfig.saasClientConfig,code, 0);
		}
		return null;
	}

	public String getCreateName() {
		return createName;
	}

	public void setCreateName(String createName) {
		this.createName = createName;
	}

}
