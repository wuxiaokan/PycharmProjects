package com.joinf.response;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * 供应商名称
 *
 * @author yzq
 * @date 2019-06-19
 */
public class SupplierNameResponse implements Serializable {

    private static final long serialVersionUID = 4011029078808398544L;
    @ApiModelProperty(value = "客户id")
    private Long id;
    @ApiModelProperty(value = "客户姓名")
    private String name;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
