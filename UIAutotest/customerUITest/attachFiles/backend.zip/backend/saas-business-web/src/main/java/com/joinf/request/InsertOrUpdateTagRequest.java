package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * 新增/更新标签请求参数
 *
 * @author yzq
 * @date 2019-04-25
 */
public class InsertOrUpdateTagRequest implements Serializable {

    private static final long serialVersionUID = -2186824218810066352L;

    @ApiModelProperty(value="标签ID")
    private Long id;

    @ApiModelProperty(value="标签内容")
    private String content;

    @ApiModelProperty(value="颜色")
    private String color;

    @ApiModelProperty(value="业务类型  0:商机  1:客户",required=true)
    private Integer type;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "InsertOrUpdateTagRequest{" +
                "id=" + id +
                ", content='" + content + '\'' +
                ", color='" + color + '\'' +
                ", type=" + type +
                '}';
    }
}
