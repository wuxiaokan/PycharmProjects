package com.joinf.config;

import com.joinf.SpringApplicationContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.List;

/**
 * Description: Swagger2api配置类
 *
 * @author lyj
 * @date 2017年12月4日 下午5:02:17
 */
@Configuration
@EnableSwagger2
@PropertySource("classpath:swagger.properties")
@Profile({"alidev","dev","test","alicloud"})
public class Swagger2 extends WebMvcConfigurerAdapter {

    @Value("${gateway.url}")
    private String apiDocHost;

	@Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/api/doc/**").addResourceLocations("classpath:/swagger/dist/");
        super.addResourceHandlers(registry);
    }

    @Bean
    public Docket createRestApi() {
    	Docket docket = new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(apiInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.joinf.controller"))
                .paths(PathSelectors.any())
                .build();

        return setDocketHost(docket);
    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("富通天下-SAAS API接口文档")
                .description("https://tradecn.joinf.com/api/doc/index.html")
                .termsOfServiceUrl("http://ceshi.joinf.com")
                .version("1.0")
                .build();
    }

    /**
     * 设置接口的Host
     * @author zlx
     * @date 2019/8/27 9:00
     * @param docket
     * @return springfox.documentation.spring.web.plugins.Docket
     */
    private Docket setDocketHost(Docket docket){
        List<String> profilesActives = SpringApplicationContext.getProfilesActive();

        //本地环境没有使用Nginx代理
        if (profilesActives != null && !profilesActives.contains("alidev") && !profilesActives.contains("dev")) {
            if (apiDocHost.contains("://")) {
                docket.host(apiDocHost.substring(apiDocHost.indexOf("://") + 3, apiDocHost.length()));
            }else{
                docket.host(apiDocHost);
            }
        }
        return docket;
    }


}
