package com.joinf.controller;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.joinf.jms.MessageProducer;
import com.joinf.properties.TopicProperties;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(tags="测试服务", description = "TestController")
@RestController
public class TestController {
//	@Autowired
//	private SiteProducerClient siteProducerClient;
	
	@Autowired
    private MessageProducer messageProducer;
	
	@Resource
	private TopicProperties topicProperties;
	
	@ApiOperation(value = "测试接口", notes = "")
	@RequestMapping(value = "/test", method = RequestMethod.GET)
	@ResponseBody
	public String test() {
		//营销站询盘	--0
		//TOPIC_SITE_INQUIRY
		//{"companyId":企业id,"email":邮箱,"companyName":企业名称,"pushClient":推送的客户端,"siteName":站点名称,"mustPushOp":推送的业务员ID号,'msgType':消息型类(1=询盘，2=访问，没什么用了),'content':询盘内容,'date':2018-10-11 22:00:00}
		//
		//营销站访问	--2
		//TOPIC_SITE_VISIT
		//{"companyId":企业id,"email":邮箱,"companyName":企业名称,"pushClient":推送的客户端,"siteName":站点名称,"mustPushOp":推送的业务员ID号,'msgType':消息型类(1=询盘，2=访问，没什么用了),'accessUrl':访问URL,'date':2018-10-11 22:00:00)}
		//
		//营销站会员注册--1
		//TOPIC_SITE_REGISTER
		//{"companyId":企业id,"email":注册邮箱,"companyName":企业名称,"id":会员ID号,"url":注册URL,'date':2018-10-11 22:00:00}
//		this.siteProducerClient.sendMsg(0, "{\"companyName\":\"\",\"companyId\":\"37938\",\"email\":\"mqtest001@123.com\",\"pushClient\":\"2,1\",\"siteName\":\"\\u8425\\u9500\\u7ad9123\",\"mustPushOp\":\"128670\",\"msgType\":2,\"date\":\"2019-05-20 14:26:28\",\"content\":\"Message Content Message Content Message Content Message Content Message Content Message Content\"} ");
//
//		this.siteProducerClient.sendMsg(1, "{\"companyId\":1453,\"email\":\"s<hahac@qq.com>\",\"companyName\":\"访问_TEST\",\"id\":0,\"url\":\"https://ceshi.joinf.com\",\"residenceTime\":10}");
//		
//		this.siteProducerClient.sendMsg(2, "{\"companyId\":1452,\"email\":\"hahac@qq.com\",\"companyName\":\"会员注册_TEST\",\"id\":0,\"url\":\"https://ceshi.joinf.com\"}");
		
		messageProducer.sendMsg(topicProperties.getRegisterTopic(), null, "哇哈哈！");
		
		return "ok";
	}

}
