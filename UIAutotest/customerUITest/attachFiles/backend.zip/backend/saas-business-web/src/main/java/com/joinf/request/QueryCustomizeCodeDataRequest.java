package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 查询自定义code
 *
 * @author lyj
 * @date 2017年12月26日 下午2:45:25
 */
public class QueryCustomizeCodeDataRequest {
	
	@ApiModelProperty(value="1：客户编码，2：产品编码，3：报价单号，4：合同编号5：销售合同号6：供应商编码，7产品条码  8:商机编号",required=true)
	private Long parameterId;

	public Long getParameterId() {
		return parameterId;
	}

	public void setParameterId(Long parameterId) {
		this.parameterId = parameterId;
	}

}
