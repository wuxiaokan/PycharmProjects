package com.joinf.response.business;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * 商机跟进返回参数
 *
 * @author yzq
 * @date 2019-05-06
 */
public class BusinessFollowUpResponse implements Serializable {

    private static final long serialVersionUID = -4781695084583326871L;

    @ApiModelProperty(value="操作员")
    private String operatorName;

    @ApiModelProperty(value="跟进时间")
    private String createTime;

    @ApiModelProperty(value="联系内容")
    private String contactContent;

    public String getOperatorName() {
        return operatorName;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getContactContent() {
        return contactContent;
    }

    public void setContactContent(String contactContent) {
        this.contactContent = contactContent;
    }
}
