package com.joinf.request.business;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 新增商机附件参数
 * @date 2019年5月6日 下午7:02:34
 */
public class BusinessAttachmentRequest implements Serializable{
	
	private static final long serialVersionUID = 1L;
	 
    @ApiModelProperty(value ="附件名称")
    private String fileName;

    @ApiModelProperty(value ="附件大小(字节)")
    private Long fileSize;

    @ApiModelProperty(value ="文件key")
    private String fileCode;

    @ApiModelProperty(value ="附件类型")
    private String fileSuffix;

    public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Long getFileSize() {
		return fileSize;
	}

	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}

	public String getFileCode() {
		return fileCode;
	}

	public void setFileCode(String fileCode) {
		this.fileCode = fileCode;
	}

	public String getFileSuffix() {
		return fileSuffix;
	}

	public void setFileSuffix(String fileSuffix) {
		this.fileSuffix = fileSuffix;
	}
    
    
}
