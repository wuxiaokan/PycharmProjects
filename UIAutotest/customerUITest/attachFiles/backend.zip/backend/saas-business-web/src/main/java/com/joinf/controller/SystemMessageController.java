package com.joinf.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.joinf.dto.message.MessageDto;
import com.joinf.dto.message.MessageManageDto;
import com.joinf.interfaces.message.MessageManager;
import com.joinf.request.message.InsertMessageRequest;
import com.joinf.response.message.MessageManageResponse;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.dto.session.SessionUser;
import com.joinf.utils.util.JoinfBeanUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @ClassName: SystemMessageController
 * @Description: 系统通知控制中心
 * @author CyNick
 * @date 2019年6月26日
 *
 */
@Slf4j
@Api(tags = "系统消息通知服务", description = "SystemMessageController")
@RestController
public class SystemMessageController extends BaseController {

	@Autowired
	private MessageManager messageManager;

	@ApiOperation(value = "全局消息和个人消息推送", notes = "全局消息和个人消息推送,不需要参数")
	@GetMapping("/messageManageList")
	public BaseResponseEntity<List<MessageManageResponse>> messageManageList(HttpServletRequest request) {
		BaseResponseEntity<List<MessageManageResponse>> entity = new BaseResponseEntity<>();
		SessionUser user = getSessionUser(request);
		List<MessageManageDto> list = messageManager
				.selectNotExpiredMessageManageByCenterCompanyId(user.getUser().getCenterCompanyId(),0);
		
		List<MessageManageResponse> resList = JoinfBeanUtils.copyToNewListBean(MessageManageResponse.class, list);
		
		entity.setData(resList);
		entity.setSuccess(true);
		return entity;
	}
	
	
	
	@ApiOperation(value = "全局消息点击记录", notes = "全局消息发送后如果点击则向t_message中插入一条对应的记录")
	@ApiImplicitParam(name = "req", value = "全局消息点击记录", required = true, dataType = "InsertMessageRequest")
	@PostMapping("/messageManageRecord")
	public BaseResponseEntity<?> messageManageRecord(HttpServletRequest request,@RequestBody InsertMessageRequest req) {
		BaseResponseEntity<?> entity = new BaseResponseEntity<>();
		SessionUser user = getSessionUser(request);
		
		MessageDto dto = JoinfBeanUtils.copyToNewBean(MessageDto.class, req);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getOperatorId());
		dto.setRead(true);//标注为已读
		try {
			int i = 0;
			i = messageManager.messageManageRecord(dto);
			if(i == 1){
				entity.setSuccess(true);
			}else{
				entity.setSuccess(false);
			}
		} catch (Exception e) {
			log.error("全局消息点击记录异常：{}",e.getMessage());
			entity.setSuccess(false);
			entity.setErrMsg("全局消息点击记录异常!");
		}
		return entity;
	}
}
