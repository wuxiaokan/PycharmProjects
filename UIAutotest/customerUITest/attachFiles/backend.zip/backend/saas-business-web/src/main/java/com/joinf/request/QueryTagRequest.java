package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * 标签
 *
 * @author yzq
 * @date 2019-04-19
 */
public class QueryTagRequest {

    @ApiModelProperty(value="类型id")
    private Long typeId;

    @ApiModelProperty(value="类型(0:商机;1:客户;2:;)",required=true)
    private Integer type;

    public Long getTypeId() {
        return typeId;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public void setTypeId(Long typeId) {
        this.typeId = typeId;
    }


}
