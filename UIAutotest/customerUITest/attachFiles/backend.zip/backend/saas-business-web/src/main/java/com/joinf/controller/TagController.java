package com.joinf.controller;

import com.joinf.constant.ResponseCodeEnum;
import com.joinf.constants.BusinessConstants;
import com.joinf.utils.dto.dict.TagPersonalRequestDto;
import com.joinf.entity.generator.Tag;
import com.joinf.exception.CommonException;
import com.joinf.interfaces.TagManager;
import com.joinf.utils.dto.dict.AddPersonalTagRequest;
import com.joinf.request.InsertOrUpdateTagRequest;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.dto.session.SessionUser;
import com.joinf.utils.dto.tag.TagResult;
import com.joinf.utils.util.JoinfBeanUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;


/**
 * 标签
 *
 * @author yzq
 * @date 2019-04-19
 */
@Slf4j
@Api(tags = "公共标签服务", description = "TagController")
@RestController
@RequestMapping("/tags")
public class TagController extends BaseController{

    @Autowired
    private TagManager tagManager;

    /**
     * 新增标签
     * @param req
     * @return
     */
    @ApiOperation(value="新增标签", notes="新增标签")
    @PostMapping("/")
    @ResponseBody
    public BaseResponseEntity<Boolean> createTag(HttpServletRequest request, @RequestBody InsertOrUpdateTagRequest req) throws Exception{
        log.info("入参为："+req.toString());
        BaseResponseEntity<Boolean> response = new BaseResponseEntity<>(true);
        SessionUser user = getSessionUser(request);
        Long companyId = user.getCompanyId();
        Long operatorId = user.getSwitchOperatorId();
        Integer type = req.getType();
        Tag tagDto = JoinfBeanUtils.copyToNewBean(Tag.class, req);
        //新增时最多只能有20个标签
        if(tagDto.getId() == null || tagDto.getId()==0) {
            //校验当前业务员对应的业务标签条数是否超过20条
            int count = tagManager.selectTagCountByParam(companyId,operatorId,type);
            int total = BusinessConstants.TAG_NEW_CRE_NUM_MAX;
            if (count >= total) {
                throw new CommonException("最多新建"+total+"个标签！");
            }
        }
        tagDto.setCompanyId(companyId);
        tagDto.setOperatorId(operatorId);
        tagDto.setUpdateId(operatorId);
        tagManager.addOrUpdateTag(tagDto);
        response.setData(true);
        return response;
    }

    /**
     * 修改标签
     * @param request
     * @param req
     * @return
     * @throws Exception
     */
    @ApiOperation(value = "修改标签", notes = "修改标签")
    @PutMapping("/")
    @ResponseBody
    public BaseResponseEntity<Boolean> modifyTag(HttpServletRequest request, @RequestBody InsertOrUpdateTagRequest req) throws Exception{
        log.info("入参为："+req.toString());
        BaseResponseEntity<Boolean> response = new BaseResponseEntity<>(true);
        SessionUser user = getSessionUser(request);
        Long companyId = user.getCompanyId();
        Long operatorId = user.getSwitchOperatorId();
        Tag tagDto = JoinfBeanUtils.copyToNewBean(Tag.class, req);
        tagDto.setCompanyId(companyId);
        tagDto.setOperatorId(operatorId);
        tagDto.setUpdateId(operatorId);
        tagManager.addOrUpdateTag(tagDto);
        response.setData(true);
        return response;
    }

    /**
     * 删除标签
     * @param id
     * @return
     */
    @ApiOperation(value="删除标签", notes="删除标签")
    @ApiImplicitParam(name = "id", value = "业务模块数据id", paramType = "path", dataType = "Long", required = true)
    @DeleteMapping(value = "/{id}")
    @ResponseBody
    public BaseResponseEntity<Boolean> deleteTag(@PathVariable(value = "id",required = true) Long id){
        log.info("入参为：id="+id);
        BaseResponseEntity<Boolean> response = new BaseResponseEntity<>(true);
        Boolean isDelete = tagManager.delete(id);
        response.setData(isDelete);
        response.setCode(ResponseCodeEnum.SUCCESS.getStatus());
        return response;
    }
    
    /**
     * 获取标签列表
     * @param type 业务类型
     * @return
     */
    @ApiOperation(value="获取对应业务的标签列表", notes="查询标签列表")
    @ApiImplicitParam(name = "type", value = "业务模块类型   0:商机  1:客户", paramType = "path", dataType = "Long", required = true)
    @GetMapping(value = "/{type}")
    @ResponseBody
    public BaseResponseEntity<List<TagResult>> getTagList(HttpServletRequest request,
                                                          @PathVariable(value = "type") int type){
        log.info("入参为：type="+type);
        BaseResponseEntity<List<TagResult>> response = new BaseResponseEntity<>(true);
        SessionUser user = getSessionUser(request);
        long companyId = user.getCompanyId();
        long switchOperatorId = user.getSwitchOperatorId();
        response.setData(tagManager.getTagList(type,companyId,switchOperatorId));
        return response;
    }

    /**
     * 加标签
     * @param req
     * @return
     */
    @ApiOperation(value="给业务勾选标签", notes="给业务勾选标签")
    @PostMapping("/type/personal")
    @ResponseBody
    public BaseResponseEntity<Boolean> createPersonalTagBatch(HttpServletRequest request, @RequestBody AddPersonalTagRequest req) throws Exception{
        log.info("入参为："+req.toString());
        BaseResponseEntity<Boolean> response = new BaseResponseEntity<>(true);
        SessionUser user = getSessionUser(request);
        Long companyId = user.getCompanyId();
        Long operatorId = user.getSwitchOperatorId();
        TagPersonalRequestDto dto =JoinfBeanUtils.copyToNewBean(TagPersonalRequestDto.class,req);
        dto.setIdList(req.getIdList());
        dto.setCompanyId(companyId);
        dto.setOperatorId(operatorId);
        //加标签
        tagManager.addTagBatch(dto);
        response.setCode(ResponseCodeEnum.SUCCESS.getStatus());
        response.setSuccess(true);
        return response;
    }


    /**
     * 获取标签
     * @param request
     * @param typeId
     * @param type
     * @return
     */
    @ApiOperation(value="获取业务勾选标签", notes="获取标签")
    @ApiImplicitParams({
	    @ApiImplicitParam(name = "type", value = "业务模块类型   0:商机  1:客户", paramType = "path", dataType = "Long", required = true),
	    @ApiImplicitParam(name = "typeId", value = "业务模块数据id", paramType = "path", dataType = "Long", required = true)
    })
    @GetMapping(value="/{type}/personal/{typeId}")
    @ResponseBody
    public BaseResponseEntity<List<Tag>> getTagPersonalList(HttpServletRequest request,
                                                            @PathVariable(value = "typeId") Long typeId,
                                                            @PathVariable(value = "type") int type){
        log.info("入参为：typeId"+type+";type="+type);
        BaseResponseEntity<List<Tag>> response = new BaseResponseEntity<>(true);
        SessionUser user = getSessionUser(request);
        Long companyId = user.getCompanyId();
        Long operatorId = user.getSwitchOperatorId();
        TagPersonalRequestDto dto = new TagPersonalRequestDto();
        dto.setCompanyId(companyId);
        dto.setOperatorId(operatorId);
        dto.setType(type);
        dto.setTypeId(typeId);
        response.setData(tagManager.selectTagPersonalByParam(dto));
        response.setSuccess(true);
        response.setCode(ResponseCodeEnum.SUCCESS.getStatus());
        return response;
    }
}
