package com.joinf.response.business;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.joinf.helper.LongJsonDeserializer;
import com.joinf.helper.LongJsonSerializer;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Date;

/**
 * 查询线索列表返回参数
 *
 * @author yzq
 * @date 2019-04-11
 */
public class QueryBusinessClueListResponse implements Serializable {

    private static final long serialVersionUID = 4586069369042088966L;

    @JsonSerialize(using = LongJsonSerializer.class)
    @JsonDeserialize(using = LongJsonDeserializer.class)
    @ApiModelProperty(value = "标示")
    private Long id;

    @ApiModelProperty(value = "线索名称")
    private String name;

    @ApiModelProperty(value = "名称")
    private String clueName;

    @ApiModelProperty(value = "邮箱")
    private String clueEmail;

    @ApiModelProperty(value = "企业信息")
    private String enterpriseInformation;

    @ApiModelProperty(value = "线索等级(0:待定;1:一星;2:二星;3:三星;4:四星;5:五星)")
    private Integer clueGrade;

    @ApiModelProperty(value = "线索来源(0:询盘信息;1:注册会员;2:访问咨询;3:商业数据;4:营销邮件)")
    private Integer clueType;

    @ApiModelProperty(value = "线索状态(0:待处理;1:已处理;2:已忽略;3:已移出)")
    private Integer clueStatus;

    @ApiModelProperty(value = "更新日期")
    private Date updateTime;

    @ApiModelProperty(value = "推送日期")
    private Date createTime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getClueName() {
        return clueName;
    }

    public void setClueName(String clueName) {
        this.clueName = clueName;
    }

    public String getClueEmail() {
        return clueEmail;
    }

    public void setClueEmail(String clueEmail) {
        this.clueEmail = clueEmail;
    }

    public String getEnterpriseInformation() {
        return enterpriseInformation;
    }

    public void setEnterpriseInformation(String enterpriseInformation) {
        this.enterpriseInformation = enterpriseInformation;
    }

    public Integer getClueGrade() {
        return clueGrade;
    }

    public void setClueGrade(Integer clueGrade) {
        this.clueGrade = clueGrade;
    }

    public Integer getClueType() {
        return clueType;
    }

    public void setClueType(Integer clueType) {
        this.clueType = clueType;
    }

    public Integer getClueStatus() {
        return clueStatus;
    }

    public void setClueStatus(Integer clueStatus) {
        this.clueStatus = clueStatus;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
