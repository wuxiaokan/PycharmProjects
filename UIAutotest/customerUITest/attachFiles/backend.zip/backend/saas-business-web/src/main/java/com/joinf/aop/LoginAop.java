//package com.joinf.aop;
//
//import java.util.List;
//import java.util.concurrent.TimeUnit;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpSession;
//
//import org.aspectj.lang.annotation.Aspect;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.redis.core.StringRedisTemplate;
//import org.springframework.stereotype.Component;
//
//import com.alibaba.fastjson.JSONArray;
//import com.alibaba.fastjson.JSONObject;
//import com.joinf.cas.client.aop.LoginAbstractAop;
//import com.joinf.cas.client.bean.SessionUser;
//import com.joinf.cas.client.utils.SessionUtils;
//import com.joinf.constant.login.LoginContant;
//import com.joinf.dto.CompanyDTO;
//import com.joinf.dto.OperatorDTO;
//import com.joinf.entity.UserInfo;
//import com.joinf.entity.generator.Company;
//import com.joinf.entity.generator.Operator;
//import com.joinf.entity.generator.RelResource;
//import com.joinf.exception.LoginFailException;
//import com.joinf.interfaces.AssignmentService;
//import com.joinf.interfaces.CompanyService;
//import com.joinf.interfaces.OperatorService;
//import com.joinf.interfaces.RelRoleResService;
//import com.joinf.utils.JoinfBeanUtils;
//
//@Aspect
//@Component
//public class LoginAop extends LoginAbstractAop{
//	
//	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());
//
//	@Autowired
//	private CompanyService companyService;
//	@Autowired
//	private OperatorService operatorService;
//	@Autowired
//	private AssignmentService assignmentService;
//	@Autowired
//	private RelRoleResService relRoleResService;
//	@Autowired
//	private StringRedisTemplate stringRedisTemplate;
//	
//	
//	@Override
//	protected void preLogin(HttpServletRequest request) {
//		logger.info("登陆前处理逻辑...");
//	}
//
//	@Override
//	protected void afterLogin(HttpServletRequest request) {
//		if (SessionUtils.isLogin(request)) {
//			logger.info("登陆成功后处理逻辑...");
//			
//			//cas-client授权成功的用户信息转成   pc-weg兼容的信息
//			SessionUser sessionUser = SessionUtils.getCurrentUserInfo(request);
//			if(sessionUser == null || sessionUser.getCompany() == null || sessionUser.getUser() == null){
//    			throw new LoginFailException("账号无效");
//    		}
//			
//			HttpSession session = request.getSession();
//			
//			CompanyDTO companyDTO = JoinfBeanUtils.copyToNewBean(CompanyDTO.class, sessionUser.getCompany());
//			companyDTO.setCompanyId(sessionUser.getCompany().getId());
//			
//    		OperatorDTO operatorDTO = JoinfBeanUtils.copyToNewBean(OperatorDTO.class, sessionUser.getUser());
//    		operatorDTO.setUserId(sessionUser.getUser().getId());
//    		
//    		
//    		//查询企业信息
//			Company company = companyService.selectByCenterCompanyId(companyDTO.getCompanyId());
//			Operator operator = operatorService.selectByCenterUserId(operatorDTO.getUserId());
//			if(company !=null){
//				company.setCompanyType(companyDTO.getCompanyType()!=null?companyDTO.getCompanyLevel().byteValue():null);
//				company.setCompanyLevel(companyDTO.getCompanyLevel());
//				company.setOrderStatus(companyDTO.getOrderStatus()!=null?companyDTO.getOrderStatus().byteValue():null);
//				session.setAttribute(LoginContant.COMPANY_INFO, JSONObject.toJSONString(company));
//			}
//			
//			if(operator!=null){
//				session.setAttribute(LoginContant.OPERATOR_INFO,JSONObject.toJSONString(operator));
//			}
//			
//			session.setAttribute(LoginContant.CENTER_COMPANY_INFO, JSONObject.toJSONString(companyDTO));
//    		session.setAttribute(LoginContant.CENTER_OPERATOR_INFO, JSONObject.toJSONString(operatorDTO));
//    		
//    		//当前用户可管理人员
//    		List<UserInfo> assignmentUsers = assignmentService.selectAssignmentUserList(company.getId(), operator.getId());
//    		
//    		String key = String.format(AssignmentService.OPERATOR_ASSIGNMENT_USERS, company.getId(),operator.getId());
//    		stringRedisTemplate.opsForValue().set(key, JSONArray.toJSONString(assignmentUsers),120,TimeUnit.MINUTES);
//    		
//    		//当前用户权限
//    		List<RelResource> resources = relRoleResService.queryOperatorResources(operator);
//    		session.setAttribute(LoginContant.OPERATOR_RESOURCES, JSONArray.toJSONString(resources));
//    		
//		}
//	}
//
//	@Override
//	protected void preLogout(HttpServletRequest request) {
//		logger.info("登出前处理逻辑...");
//	}
//
//	@Override
//	protected void afterLogout(HttpServletRequest request) {
//		if (!SessionUtils.isLogin(request)) {
//			logger.info("登出成功后处理逻辑...");
//		}
//	}
//	
//
//}
