package com.joinf.request.business;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * 获取商机日志的请求参数
 *
 * @author yzq
 * @date 2019-04-28
 */
public class GetBusinessLogRequest implements Serializable {

    private static final long serialVersionUID = 457090508844006322L;

    @ApiModelProperty(value="商机id--如果为空则查询所有商机日志")
    private Long businessId;

    @ApiModelProperty(value="业务类别(空表示全部)：business-商机,follow-跟进,email-邮件,order-订单,quote-报价")
    private String busType;

    @ApiModelProperty(value="跟进阶段")
    private String flowStep;

    @ApiModelProperty(value="年份")
    private String year;

    @ApiModelProperty(value="月份")
    private String month;

    @ApiModelProperty(value="第几页",required=true)
    private Integer pageStart;

    @ApiModelProperty(value="分页大小",required=true)
    private Integer pageSize;

    public Long getBusinessId() {
        return businessId;
    }

    public void setBusinessId(Long businessId) {
        this.businessId = businessId;
    }

    public String getBusType() {
        return busType;
    }

    public void setBusType(String busType) {
        this.busType = busType;
    }

    public String getFlowStep() {
        return flowStep;
    }

    public void setFlowStep(String flowStep) {
        this.flowStep = flowStep;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public Integer getPageStart() {
        return pageStart;
    }

    public void setPageStart(Integer pageStart) {
        this.pageStart = pageStart;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    @Override
    public String toString() {
        return "GetBusinessLogRequest{" +
                "businessId=" + businessId +
                ", busType='" + busType + '\'' +
                ", flowStep='" + flowStep + '\'' +
                ", year='" + year + '\'' +
                ", month='" + month + '\'' +
                ", pageStart=" + pageStart +
                ", pageSize=" + pageSize +
                '}';
    }
}
