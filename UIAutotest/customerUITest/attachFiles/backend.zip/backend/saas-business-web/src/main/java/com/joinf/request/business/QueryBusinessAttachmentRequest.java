package com.joinf.request.business;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 查询商机附件参数
 * @date 2019年5月6日 下午8:11:54
 */
public class QueryBusinessAttachmentRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value ="商机ID")
	private Long businessId;

	public Long getBusinessId() {
		return businessId;
	}

	public void setBusinessId(Long businessId) {
		this.businessId = businessId;
	}

	@Override
	public String toString() {
		return "QueryBusinessListRequest [businessId=" + businessId + "]";
	}
	
}
