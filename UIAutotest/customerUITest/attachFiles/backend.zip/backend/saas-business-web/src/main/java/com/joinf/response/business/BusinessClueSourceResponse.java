package com.joinf.response.business;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Date;

/**
 * 线索来源参数
 *
 * @author yzq
 * @date 2019-04-16
 */
public class BusinessClueSourceResponse implements Serializable {

    private static final long serialVersionUID = 319361654541721254L;

    @ApiModelProperty(value="来源地址")
    private String url;

    @ApiModelProperty(value = "线索内容（询盘的时候使用）")
    private String content;

    @ApiModelProperty(value="创建日期")
    private Date createTime;

    @ApiModelProperty(value="自定义字段1(网址个数/打开次数/访问次数)")
    private Integer selfCustom1;

    @ApiModelProperty(value="自定义字段2(邮箱个数/停留时间/点击次数)")
    private Integer selfCustom2;

    @ApiModelProperty(value="自定义字段3(...)")
    private Integer selfCustom3;

    @ApiModelProperty(value="操作员名称")
    private String operatorName;

    @ApiModelProperty(value="线索类型(0:询盘信息;1:注册会员;2:访问咨询;3:商业数据;4:营销邮件)")
    private Integer type;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getSelfCustom1() {
        return selfCustom1;
    }

    public void setSelfCustom1(Integer selfCustom1) {
        this.selfCustom1 = selfCustom1;
    }

    public Integer getSelfCustom2() {
        return selfCustom2;
    }

    public void setSelfCustom2(Integer selfCustom2) {
        this.selfCustom2 = selfCustom2;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public Integer getSelfCustom3() {
        return selfCustom3;
    }

    public void setSelfCustom3(Integer selfCustom3) {
        this.selfCustom3 = selfCustom3;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
