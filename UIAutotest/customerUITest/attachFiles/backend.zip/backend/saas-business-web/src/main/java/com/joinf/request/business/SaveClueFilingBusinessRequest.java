package com.joinf.request.business;

import java.io.Serializable;
import java.util.List;

import com.joinf.dto.DictCodeDto;
import com.joinf.request.IdAndNameRequest;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @author zlx
 * @Description: 线索建档保存-商机信息
 * @date 2019年4月25日 下午2:16:04
 */
public class SaveClueFilingBusinessRequest implements Serializable {

    private static final long serialVersionUID = 197540694897823242L;
    
    @ApiModelProperty(value="商机编码 字典集合")
	private List<DictCodeDto> customizeCodeDicts;
    
    @ApiModelProperty(value ="跟进阶段")
    private IdAndNameRequest flowStepInfo;
    
    @ApiModelProperty(value ="商机名称  自定义部分")
    private String name;
    
    @ApiModelProperty(value ="开始日期   毫秒时间戳")
    private Long startTime;

	public List<DictCodeDto> getCustomizeCodeDicts() {
		return customizeCodeDicts;
	}

	public void setCustomizeCodeDicts(List<DictCodeDto> customizeCodeDicts) {
		this.customizeCodeDicts = customizeCodeDicts;
	}

	public IdAndNameRequest getFlowStepInfo() {
		return flowStepInfo;
	}

	public void setFlowStepInfo(IdAndNameRequest flowStepInfo) {
		this.flowStepInfo = flowStepInfo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getStartTime() {
		return startTime;
	}

	public void setStartTime(Long startTime) {
		this.startTime = startTime;
	}

	@Override
	public String toString() {
		return "SaveClueFilingBusinessRequest [customizeCodeDicts=" + customizeCodeDicts + ", flowStepInfo="
				+ flowStepInfo + ", name=" + name + ", startTime=" + startTime + "]";
	}

	
	
}
