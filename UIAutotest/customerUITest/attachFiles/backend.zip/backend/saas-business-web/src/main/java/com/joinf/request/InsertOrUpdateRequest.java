package com.joinf.request;

import com.joinf.response.EditDetailResponse;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * Description: 新增或修改参数
 *
 * @author lyj
 * @date 2017年12月11日 下午7:23:49
 */
public class InsertOrUpdateRequest {

	@ApiModelProperty(value="主键id",required=true)
	private Long id;
	
	@ApiModelProperty(value="参数集合",required=true)
	private List<InsertOrUpdateModel> models;

	@ApiModelProperty(value="原始数据",required=true)
	private List<EditDetailResponse> oldValue;
	
	@ApiModelProperty(value="是否一并修改客户跟进阶段",required=true)
	private Boolean modifyCustomerFlowStep;

	@ApiModelProperty(value = "线索id,保存线索处理日志用")
	private Long clueId;
	
	@ApiModelProperty(value = "附件id集合")
	private List<Long> attachmentIdList;

	public Boolean getModifyCustomerFlowStep() {
		return modifyCustomerFlowStep;
	}

	public void setModifyCustomerFlowStep(Boolean modifyCustomerFlowStep) {
		this.modifyCustomerFlowStep = modifyCustomerFlowStep;
	}

	public Long getClueId() {
		return clueId;
	}

	public void setClueId(Long clueId) {
		this.clueId = clueId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<InsertOrUpdateModel> getModels() {
		return models;
	}

	public void setModels(List<InsertOrUpdateModel> models) {
		this.models = models;
	}

	public List<EditDetailResponse> getOldValue() {
		return oldValue;
	}

	public void setOldValue(List<EditDetailResponse> oldValue) {
		this.oldValue = oldValue;
	}
	
	public List<Long> getAttachmentIdList() {
		return attachmentIdList;
	}

	public void setAttachmentIdList(List<Long> attachmentIdList) {
		this.attachmentIdList = attachmentIdList;
	}

	@Override
	public String toString() {
		return "InsertOrUpdateRequest [id=" + id + ", models=" + models + ", oldValue=" + oldValue
				+ ", modifyCustomerFlowStep=" + modifyCustomerFlowStep + ", attachmentIdList=" + attachmentIdList + "]";
	}
}
