package com.joinf.request.business;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

import com.joinf.utils.base.BasePage;

/**
 * Demo class
 *
 * @author yzq
 * @date 2019-05-17
 */
public class QueryBusinessEmailRelRequest extends BasePage implements Serializable {

    private static final long serialVersionUID = 7415985805203341370L;

    @ApiModelProperty(value = "商机id",required = true)
    private Long businessId;

    @ApiModelProperty(value = "客户id")
    private Long customerId;

    @ApiModelProperty(value = "联系人id")
    private Long contactId;

    @ApiModelProperty(value = "主题")
    private String subject;

    @ApiModelProperty(value = "类型,(0:收件  1:发件)",required = true)
    private Integer type;

    public Long getBusinessId() {
        return businessId;
    }

    public void setBusinessId(Long businessId) {
        this.businessId = businessId;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public Long getContactId() {
        return contactId;
    }

    public void setContactId(Long contactId) {
        this.contactId = contactId;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "QueryBusinessEmailRelRequest{" +
                "businessId=" + businessId +
                ", customerId=" + customerId +
                ", contactId=" + contactId +
                ", subject='" + subject + '\'' +
                ", type=" + type +
                ", num=" + num +
                ", size=" + size +
                ", paging=" + paging +
                '}';
    }
}
