package com.joinf.jms;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.aliyun.mq.http.MQClient;
import com.aliyun.mq.http.MQConsumer;
import com.aliyun.mq.http.common.AckMessageException;
import com.aliyun.mq.http.model.Message;
import com.joinf.dto.BusinessClueJmsDto;
import com.joinf.interfaces.business.BusinessClueManager;
import com.joinf.properties.TopicProperties;
import com.joinf.thread.PoolThread;

import lombok.extern.slf4j.Slf4j;


/**
 * @author zlx
 * @Description: 消费自建站的消息
 * @date 2019年5月5日 下午5:31:53
 */
@Slf4j
@ConditionalOnProperty(prefix="spring.joinf",name = "jms", havingValue = "rocketMq")
@Component
public class RocketMqConsumer implements CommandLineRunner{
	
	// 设置HTTP接入域名
	@Value("${ons.http.endpoint}")
	private String httpEndpoint;
	// AccessKey 阿里云身份验证，在阿里云服务器管理控制台创建
	@Value("${ons.access.key}")
	private String accessKey;
	// SecretKey 阿里云身份验证，在阿里云服务器管理控制台创建
	@Value("${ons.secret.key}")
	private String secretKey;
	// 实例 ID
	@Value("${ons.instance.id}")
	private String instanceId;
	
	@Resource
	private TopicProperties topicProperties;
	
	@Autowired
	private BusinessClueManager businessClueManager;
	
	@Override
	public void run(String... args) throws Exception {
		MQClient mqClient = new MQClient(httpEndpoint, accessKey, secretKey);

		PoolThread.mThreadPool.execute(new Runnable() {
            @Override
            public void run() {
            	//询盘topic消费
            	final MQConsumer inquiryConsumer = mqClient.getConsumer(instanceId, topicProperties.getInquiryTopic(), topicProperties.getTopicGroupId(), null);
                consumerMessage(inquiryConsumer);
            }
        });
        
		PoolThread.mThreadPool.execute(new Runnable() {
            @Override
            public void run() {
            	//访问topic消费
                final MQConsumer visitConsumer = mqClient.getConsumer(instanceId, topicProperties.getVisitTopic(), topicProperties.getTopicGroupId(), null);
                consumerMessage(visitConsumer);
            }
        });
        

		PoolThread.mThreadPool.execute(new Runnable() {
            @Override
            public void run() {
            	  //注册会员topic消费
                final MQConsumer registerConsumer = mqClient.getConsumer(instanceId, topicProperties.getRegisterTopic(), topicProperties.getTopicGroupId(), null);
                consumerMessage(registerConsumer);
            }
        });
	}
	
	/**
	 * 消费消息
	 * @param consumer
	 */
	private void consumerMessage(MQConsumer consumer){
		// 在当前线程循环消费消息，建议是多开个几个线程并发消费消息
        do {
            List<com.aliyun.mq.http.model.Message> messages = null;

            try {
                // 长轮询消费消息
                // 长轮询表示如果topic没有消息则请求会在服务端挂住3s，3s内如果有消息可以消费则立即返回
                messages = consumer.consumeMessage(
                        3,// 一次最多消费3条(最多可设置为16条)
                        30// 长轮询时间3秒（最多可设置为30秒）
                );
            } catch (Throwable e) {
            	log.error("", e);
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e1) {
                	log.error("", e1);
                }
            }
            // 没有消息
            if (messages == null || messages.isEmpty()) {
                continue;
            }

            List<String> handles = new ArrayList<String>();
            
            // 处理业务逻辑
            for (Message message : messages) {
            	try {
            		String msgBody = new String(message.getMessageBodyString());

    				log.info("topic:{}, msg:{} ", consumer.getTopicName(), msgBody);

    				BusinessClueJmsDto dto = JSON.parseObject(msgBody, BusinessClueJmsDto.class);

    				//设置线索类型(0:询盘信息;1:注册会员;2:访问咨询;3:商业数据;4:营销邮件)
    				int type = 0;
    				if (topicProperties.getRegisterTopic().equals(consumer.getTopicName())) {
    					type = 1;
    				}else if(topicProperties.getVisitTopic().equals(consumer.getTopicName())){
    					type = 2;
    				}
    				dto.setMsgType(String.valueOf(type));

    				businessClueManager.processingBusinessClue(dto);
    				
    				//需要确定消费成功
					handles.add(message.getReceiptHandle());
					
				} catch (Exception e) {
					log.error("消息处理业务异常", e);
				} 
            }

            // Message.nextConsumeTime前若不确认消息消费成功，则消息会重复消费
            // 消息句柄有时间戳，同一条消息每次消费拿到的都不一样
            {
            	if (handles != null && handles.size() > 0) {
            		try {
            			consumer.ackMessage(handles);
            		} catch (Throwable e) {
            			// 某些消息的句柄可能超时了会导致确认不成功
            			if (e instanceof AckMessageException) {
            				AckMessageException errors = (AckMessageException) e;
            				log.info("Ack message fail, requestId is:" + errors.getRequestId() + ", fail handles:");
            				if (errors.getErrorMessages() != null) {
            					for (String errorHandle :errors.getErrorMessages().keySet()) {
            						log.info("Handle:" + errorHandle + ", ErrorCode:" + errors.getErrorMessages().get(errorHandle).getErrorCode()
            								+ ", ErrorMsg:" + errors.getErrorMessages().get(errorHandle).getErrorMessage());
            					}
            				}
            				continue;
            			}
            			log.error("", e);
            		}
				}
            }
        } while (true);
	}

	
}