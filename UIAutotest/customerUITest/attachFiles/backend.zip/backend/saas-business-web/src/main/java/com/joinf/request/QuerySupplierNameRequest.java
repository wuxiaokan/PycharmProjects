package com.joinf.request;

import com.joinf.utils.base.BasePage;

import io.swagger.annotations.ApiModelProperty;

/**
 * 供应商名称查询参数
 *
 * @author yzq
 * @date 2019-06-19
 */
public class QuerySupplierNameRequest extends BasePage {

    private static final long serialVersionUID = -6781014602994380542L;
    @ApiModelProperty(value = "关键字搜索")
    private String key;

    @ApiModelProperty(value = "供应商id;有供应商id的时候，将该供应商放在第一位")
    private Long supplierId;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Long getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(Long supplierId) {
        this.supplierId = supplierId;
    }
}
