package com.joinf.properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * @description: 主题或队列名称
 * @author zlx
 * @date 2019年6月28日 下午2:20:26
 * @revisionHistory
 */
@Configuration
public class TopicProperties {
	
	@Value("${topic.site.group.id:}")
	private String topicGroupId;
	
	//自建站询盘
	@Value("${topic.site.inquiry}")
	private String inquiryTopic;
	//自建站访问
	@Value("${topic.site.visit}")
	private String visitTopic;
	//自建站会员注册
	@Value("${topic.site.register}")
	private String registerTopic;
	
	public String getTopicGroupId() {
		return topicGroupId;
	}
	public void setTopicGroupId(String topicGroupId) {
		this.topicGroupId = topicGroupId;
	}
	public String getInquiryTopic() {
		return inquiryTopic;
	}
	public void setInquiryTopic(String inquiryTopic) {
		this.inquiryTopic = inquiryTopic;
	}
	public String getVisitTopic() {
		return visitTopic;
	}
	public void setVisitTopic(String visitTopic) {
		this.visitTopic = visitTopic;
	}
	public String getRegisterTopic() {
		return registerTopic;
	}
	public void setRegisterTopic(String registerTopic) {
		this.registerTopic = registerTopic;
	}
	

}