package com.joinf.response.business;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * 商机列表
 *
 * @Author cxi
 * @Date 2019-07-30 19:55
 **/
@Getter
@Setter
public class EmailRelBusinessResponse {

    @ApiModelProperty(value ="ID")
    private Long id;

    @ApiModelProperty(value ="客户ID")
    private Long customerId;

    @ApiModelProperty(value ="客户名称")
    private String customerName;

    @ApiModelProperty(value ="商机名称")
    private String name;

    @ApiModelProperty(value ="商机编码")
    private String code;

    @ApiModelProperty(value ="联系人ID")
    private Long contactId;

    @ApiModelProperty(value ="联系人邮箱")
    private String contactEmail;

    @ApiModelProperty(value ="联系人")
    private String contactName;

    @ApiModelProperty(value ="执行状态(0:跟进;1:赢单;2:丢单)")
    private Integer status;

    @ApiModelProperty(value ="目标赢单金额")
    private BigDecimal targetPayment;

    @ApiModelProperty(value ="预计成功率（百分比）")
    private BigDecimal successRate;

    @ApiModelProperty(value ="需求描述")
    private String description;

    @ApiModelProperty(value ="是否关联：0-未关联， 1-关联")
    private Integer associate;

    @ApiModelProperty(value ="关联关系ID")
    private Long relId;

    @ApiModelProperty(value = "业务员名称")
    private String operatorName;

    @ApiModelProperty(value = "货币单元名称")
    private String priceUnitName;

    @ApiModelProperty(value ="开始日期")
    private String startDateStr;

    @ApiModelProperty(value ="结单日期")
    private String endDateStr;

    @ApiModelProperty(value ="创建日期")
    private String createTimeStr;

    @ApiModelProperty(value ="预计签单日期")
    private String signDateStr;

    @ApiModelProperty(value ="跟进阶段")
    private String flowStepStr;

}
