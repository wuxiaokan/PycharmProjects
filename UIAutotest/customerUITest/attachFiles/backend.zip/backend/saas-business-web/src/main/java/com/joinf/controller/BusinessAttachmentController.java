package com.joinf.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.joinf.constant.ResponseCodeEnum;
import com.joinf.dto.AttachmentBaseDto;
import com.joinf.dto.SaveAttachmentBaseDto;
import com.joinf.entity.BusinessAttachmentEntity;
import com.joinf.interfaces.business.BusinessManager;
import com.joinf.request.business.QueryBusinessAttachmentRequest;
import com.joinf.request.business.SaveBusinessAttachmentRequest;
import com.joinf.response.business.QueryBusinessAttachmentResponse;
import com.joinf.utils.annotations.Permission;
import com.joinf.utils.annotations.ResubmitData;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.dto.session.SessionUser;
import com.joinf.utils.util.JoinfBeanUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;


/**
 * @author zlx
 * @Description: 商机附件
 * @date 2019年5月6日 下午8:51:14
 */
@Slf4j
@Api(tags = "商机附件服务", description = "BusinessAttachmentController")
@RestController
public class BusinessAttachmentController extends BaseController{

    @Autowired
    private BusinessManager businessManager;

    /**
     * 查询商机附件列表
     * @param req
     * @return
     */
    @ApiOperation(value = "查询商机附件列表", notes = "查询商机附件列表")
    @GetMapping("/business/attachment")
    @Permission(require = "business.list.preview")
    @ResponseBody
    public BaseResponseEntity<List<QueryBusinessAttachmentResponse>> queryBusinessAttachment(HttpServletRequest request, QueryBusinessAttachmentRequest req) {
        log.info("入参为：" + req.toString());
        BaseResponseEntity<List<QueryBusinessAttachmentResponse>> response = new BaseResponseEntity<>(true);
        SessionUser user = getSessionUser(request);
       
        List<BusinessAttachmentEntity> attachmentList =  businessManager.queryBusinessAttachment(user.getCompanyId(), user.getSwitchOperatorId(), req.getBusinessId());
        
        if (attachmentList != null && attachmentList.size() > 0) {
			response.setData(JoinfBeanUtils.copyToNewListBean(QueryBusinessAttachmentResponse.class, attachmentList));
		}
        response.setCode(ResponseCodeEnum.SUCCESS.getStatus());
        response.setSuccess(true);
        return response;
    }
    
    
    /**
	 * 保存商机附件
	 * @param request
	 * @param req
	 * @return
	 */
	@ApiOperation(value="保存商机附件", notes="保存商机附件,返回附件id")
	@PostMapping(value = "/business/attachment")
	@Permission(require = "business.list.new")
	@ResubmitData
	@ResponseBody
	public BaseResponseEntity<List<String>> saveBusinessAttachment(HttpServletRequest request, @RequestBody SaveBusinessAttachmentRequest req) {
		
		BaseResponseEntity<List<String>> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = getSessionUser(request);
		
		SaveAttachmentBaseDto saveDto = JoinfBeanUtils.copyToNewBean(SaveAttachmentBaseDto.class, req);
		saveDto.setList(JoinfBeanUtils.copyToNewListBean(AttachmentBaseDto.class, req.getList()));
		saveDto.setCompanyId(user.getCompanyId());
		saveDto.setOperatorId(user.getSwitchOperatorId());
		saveDto.setCreateId(user.getSwitchOperatorId());
		saveDto.setUpdateId(user.getSwitchOperatorId());
		
		entity.setData(businessManager.saveBusinessAttachment(saveDto));
		
		return entity;
	}



}
