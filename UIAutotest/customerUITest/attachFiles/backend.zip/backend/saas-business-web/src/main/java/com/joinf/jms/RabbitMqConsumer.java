package com.joinf.jms;

import javax.annotation.Resource;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.joinf.dto.BusinessClueJmsDto;
import com.joinf.interfaces.business.BusinessClueManager;

import lombok.extern.slf4j.Slf4j;

/**
 * @description: 监听rabbitmq消息
 * @author zlx
 * @date 2019年6月28日 上午11:26:55
 * @revisionHistory
 */
@Slf4j
@ConditionalOnProperty(prefix="spring.joinf",name = "jms", havingValue = "rabbitMq")
@Component
public class RabbitMqConsumer {
  
	@Resource
	private BusinessClueManager businessClueManager;
	
	
	/**
	 * @description: 自建站询盘消息
	 * @author zlx
	 * @date 2019年6月28日 下午3:38:45
	 * @param msg
	 */
    @RabbitListener(queues = "${topic.site.inquiry}")
    public void processInquiryMessage(String msgBody) {
        try {
        	log.info("Receiving Message: -----[{}]----- \n.", msgBody);
            
            BusinessClueJmsDto dto = JSON.parseObject(msgBody, BusinessClueJmsDto.class);
    		//设置线索类型(0:询盘信息;1:注册会员;2:访问咨询;3:商业数据;4:营销邮件)
    		dto.setMsgType("0");
    		businessClueManager.processingBusinessClue(dto);
		} catch (Exception e) {
			//必须包异常，避免死循环
			log.error("", e);
		}
    }
    
    /**
	 * @description: 自建注册消息
	 * @author zlx
	 * @date 2019年6月28日 下午3:38:45
	 * @param msg
	 */
    @RabbitListener(queues = "${topic.site.register}")
    public void processRegisterMessage(String msg) {
    	try {
    		log.info("Receiving Message: -----[{}]----- \n.", msg);
            
            BusinessClueJmsDto dto = JSON.parseObject(msg, BusinessClueJmsDto.class);
    		//设置线索类型(0:询盘信息;1:注册会员;2:访问咨询;3:商业数据;4:营销邮件)
    		dto.setMsgType("1");
    		businessClueManager.processingBusinessClue(dto);
		} catch (Exception e) {
			//必须包异常，避免死循环
			log.error("", e);
		}
    }
    
    /**
	 * @description: 自建访问消息
	 * @author zlx
	 * @date 2019年6月28日 下午3:38:45
	 * @param msg
	 */
    @RabbitListener(queues = "${topic.site.visit}")
    public void processVisitMessage(String msg) {
    	try {
    		log.info("Receiving Message: -----[{}]----- \n.", msg);
            
            BusinessClueJmsDto dto = JSON.parseObject(msg, BusinessClueJmsDto.class);
    		//设置线索类型(0:询盘信息;1:注册会员;2:访问咨询;3:商业数据;4:营销邮件)
    		dto.setMsgType("2");
    		businessClueManager.processingBusinessClue(dto);
		} catch (Exception e) {
			//必须包异常，避免死循环
			log.error("", e);
		}
    }
    
    
    
    
}