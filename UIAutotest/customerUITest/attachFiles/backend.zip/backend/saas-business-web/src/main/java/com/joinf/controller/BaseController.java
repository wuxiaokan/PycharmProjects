package com.joinf.controller;

import com.alibaba.fastjson.JSON;
import com.joinf.constant.Constants;
import com.joinf.dto.LoginUserDto;
import com.joinf.interfaces.AssignmentService;
import com.joinf.interfaces.DataPermissionValidateManager;
import com.joinf.utils.LocaleMessage.LocaleMessage;
import com.joinf.utils.dto.session.SessionUser;
import com.joinf.utils.util.DateUtil;
import com.joinf.utils.util.JoinfBeanUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.StringRedisTemplate;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 基础公用controlle
 *
 * @author yzq
 * @date 2019-04-28
 */
@Slf4j
public class BaseController {

	@Resource
	protected LocaleMessage localeMessage;
	
	@Resource
	protected StringRedisTemplate stringRedisTemplate;
	
    @Resource
    protected DataPermissionValidateManager dataPermissionValidateManager;

    @Resource
    protected AssignmentService assignmentService;

    /**
	 * 获取登陆用户信息
	 * @return
	 */
	protected SessionUser getSessionUser(HttpServletRequest request) {
		SessionUser sessionUser = null;
		
		String joinfJsessionid = request.getHeader("joinf-jsessionid");
		
		log.info("joinfJsessionid:{}", joinfJsessionid);
		
		String sessionUserJson = stringRedisTemplate.opsForValue().get(joinfJsessionid);
		if (StringUtils.isNotBlank(sessionUserJson)) {
			sessionUser = JSON.parseObject(sessionUserJson, SessionUser.class);
		}
		
		return sessionUser;
	}
	
	/**
	 * @description: 登陆用户信息转换为LoginUserDto
	 * @author zlx
	 * @date 2019年6月26日 下午8:22:05
	 * @param TODO
	 */
	protected LoginUserDto convertToLoginUserDto(SessionUser sessionUser) {
		LoginUserDto loginUserDto = JoinfBeanUtils.copyToNewBean(LoginUserDto.class, sessionUser.getUser());
		
		loginUserDto.setSwitchOperatorId(sessionUser.getSwitchOperatorId());
		
		return loginUserDto;
	}
	
    public List<String> getOperatorModules(SessionUser user) {
        List<String> modules = new ArrayList<>();
        //权限判断    app 的行事日程中包含 客户、邮件、跟进、订单、报价、edm、客户合并、商机等日志，需要判断后传不同的参数上去
        if (this.checkHas(user.getOperatorId(), user.getSwitchOperatorId(), Constants.RESOURCE_CUSTOMER_ID)) {
            modules.add("customer");
            modules.add("transfer");
        }
        if (this.checkHas(user.getOperatorId(), user.getSwitchOperatorId(), Constants.RESOURCE_PRODUCT_ID)) {
            modules.add("product");
        }
        if (this.checkHas(user.getOperatorId(), user.getSwitchOperatorId(), Constants.RESOURCE_QUOTE_ID)) {
            modules.add("quote");
        }
        if (this.checkHas(user.getOperatorId(), user.getSwitchOperatorId(), Constants.RESOURCE_ORDER_ID)) {
            modules.add("order");
        }
        if (this.checkHas(user.getOperatorId(), user.getSwitchOperatorId(), Constants.RESOURCE_CUSTOMER_FOLLOW_ID)) {
            modules.add("follow");
        }
        if (this.checkHas(user.getOperatorId(), user.getSwitchOperatorId(), Constants.RESOURCE_EMAIL_ID)) {
            modules.add("email");
            modules.add("email_send");
            modules.add("email_receive");
            modules.add("edmEmail");
        }
        if (this.checkHas(user.getOperatorId(), user.getSwitchOperatorId(), Constants.RESOURCE_SUPPLIER_ID)) {
            modules.add("supplier");
        }
        if (this.checkHas(user.getOperatorId(), user.getSwitchOperatorId(), Constants.RESOURCE_BUSINESS_ID)) {
            modules.add("business");
        }
        return modules;
    }

    /**
     * 校验当前业务员是否有模块权限
     *
     * @param id
     *            登陆人ID
     * @param operatorId
     *            资源所属操作员ID
     * @param resourceId
     *            资源ID
     * @return
     * @throws Exception
     */
    protected boolean checkHas(Long id, Long operatorId, Long resourceId) {
        return dataPermissionValidateManager.validateMangerPermission(id, operatorId, resourceId);
    }

    /**
     * 拼接查询日志时间参数
     * @param year
     * @param month
     * @param map
     */
    protected void getDateStr(Integer year, Integer month,Map<String ,Object> map){
        String monthStr = "01";
        String endMonthStr = "01";
        String endYearStr = "2017";
        if(0 == year){
            year = 2017;
            endYearStr = String.valueOf(Integer.parseInt(DateUtil.formatThread(new Date()).substring(0,4))+1);

        }else {
            if(month == 12){
                monthStr = month+"";
                endYearStr = (year+1)+"";
                endMonthStr = "01";
            }else if (month > 0 && month < 10){
                monthStr = "0"+month;
                endYearStr = year+"";
                endMonthStr = (month+1)<10?("0"+(month+1)):(month+1)+"";
            }else if(month==0){
                endYearStr = (year+1)+"";
            }else{
                monthStr = month+"";
                endMonthStr = (month+1)+"";
                endYearStr = year+"";
            }
        }



        map.put("beginDate", year+"-"+monthStr+"-01 00:00:00");
        map.put("endDate", endYearStr+"-"+endMonthStr+"-01 00:00:00");
    }
}
