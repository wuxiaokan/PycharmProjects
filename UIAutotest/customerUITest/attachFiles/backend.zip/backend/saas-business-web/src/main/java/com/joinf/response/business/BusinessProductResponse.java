package com.joinf.response.business;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * 商机详情-产品请求参数
 *
 * @author yzq
 * @date 2019-05-13
 */
public class BusinessProductResponse implements Serializable {
    private static final long serialVersionUID = 2563080270310148537L;

    @ApiModelProperty(value = "产品id")
    private Long productId;

    @ApiModelProperty(value = "产品代码")
    private String code;

    @ApiModelProperty(value = "英文名称")
    private String englishName;

    @ApiModelProperty(value = "中文名称")
    private String chineseName;

    @ApiModelProperty(value = "数量")
    private String count;

    @ApiModelProperty(value = "金额")
    private String usdSum;

    @ApiModelProperty(value = "商品图片")
    private String pictureUrl;

    @ApiModelProperty(value = "商品图片缩略图")
    private String pictureViewUrl;

    @ApiModelProperty(value = "产品来源:[0]没有产品;[1]产品;[2]网店")
    private String productFrom;

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getEnglishName() {
        return englishName;
    }

    public void setEnglishName(String englishName) {
        this.englishName = englishName;
    }

    public String getChineseName() {
        return chineseName;
    }

    public void setChineseName(String chineseName) {
        this.chineseName = chineseName;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getUsdSum() {
        return usdSum;
    }

    public void setUsdSum(String usdSum) {
        this.usdSum = usdSum;
    }

    public String getPictureUrl() {
        return pictureUrl;
    }

    public void setPictureUrl(String pictureUrl) {
        this.pictureUrl = pictureUrl;
    }

    public String getPictureViewUrl() {
        return pictureViewUrl;
    }

    public void setPictureViewUrl(String pictureViewUrl) {
        this.pictureViewUrl = pictureViewUrl;
    }

    public String getProductFrom() {
        return productFrom;
    }

    public void setProductFrom(String productFrom) {
        this.productFrom = productFrom;
    }
}

