package com.joinf.request;

import com.joinf.utils.dto.tag.TagDto;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * 标签
 *
 * @author yzq
 * @date 2019-04-19
 */
public class OperateTagRequest {

    @ApiModelProperty(value="标签ID")
    private Long id;

    @ApiModelProperty(value="标签内容")
    private String content;

    @ApiModelProperty(value="颜色")
    private String color;

    @ApiModelProperty(value="标志")
    private Integer flag;

    @ApiModelProperty(value="业务类型ID",required=true)
    private String typeId;

    @ApiModelProperty(value="业务类型  0:商机  1:客户",required=true)
    private Integer type;

    @ApiModelProperty(value="标签列表")
    private List<TagDto> tagList;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }

    public String getTypeId() {
        return typeId;
    }

    public void setTypeId(String typeId) {
        this.typeId = typeId;
    }

    public List<TagDto> getTagList() {
        return tagList;
    }

    public void setTagList(List<TagDto> tagList) {
        this.tagList = tagList;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "OperateTagRequest{" +
                "id=" + id +
                ", content='" + content + '\'' +
                ", color='" + color + '\'' +
                ", flag=" + flag +
                ", typeId='" + typeId + '\'' +
                ", type=" + type +
                ", tagList=" + tagList +
                '}';
    }
}
