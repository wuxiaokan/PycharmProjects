package com.joinf;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.embedded.ConfigurableEmbeddedServletContainer;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.context.annotation.Bean;

import com.joinf.interceptor.login.RequestWrapperFilter;

@EnableDiscoveryClient
@EnableFeignClients
@SpringBootApplication
public class BusinessWebApplication {
	
	/**
	 * 程序入口
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(new Object[]{BusinessWebApplication.class,ApplicationRunner.class}, args);
	}
	
	/**
	 * 会话时间
	 * @return
	 */
	@Bean
	public EmbeddedServletContainerCustomizer containerCustomizer() {
		return new EmbeddedServletContainerCustomizer() {
			@Override
			public void customize(ConfigurableEmbeddedServletContainer container) {
				container.setSessionTimeout(-1);// 单位为S
			}
		};
	}
	
	/**
	 * 注册拦截器
	 * @return
	 */
	@Bean
	public FilterRegistrationBean filterRegistrationBean() {
	   FilterRegistrationBean registrationBean = new FilterRegistrationBean();
	   registrationBean.setFilter(requestWrapperFilter());
	   List<String> urlPatterns = new ArrayList<String>();
	   urlPatterns.add("/*");
	   registrationBean.setUrlPatterns(urlPatterns);
	   return registrationBean;
	}
	
	/**
	 * 重复获取数据拦截器
	 * @return
	 */
	@Bean
	public Filter requestWrapperFilter(){
		return new RequestWrapperFilter();
	}
	

}
