package com.joinf.request;

import com.joinf.utils.base.BasePage;

import io.swagger.annotations.ApiModelProperty;

/**
 * 客户名称请求参数
 *
 * @author yzq
 * @date 2019-04-25
 */
public class QueryCustomerNameRequest extends BasePage {

    private static final long serialVersionUID = 7034939712695469350L;

    @ApiModelProperty(value = "关键字搜索")
    private String key;

    @ApiModelProperty(value = "客户id;有客户id的时候将该客户放在第一位")
    private Long customerId;

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
