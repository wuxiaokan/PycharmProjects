package com.joinf.request.business;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

import com.joinf.utils.base.BasePage;

/**
 * 查看商机详情页-table页请求参数
 *
 * @author yzq
 * @date 2019-05-10
 */
public class QueryBusinessDetailTableRequest extends BasePage implements Serializable {

    private static final long serialVersionUID = 7406618880454510626L;

    @ApiModelProperty(value = "商机id",required = true)
    private Long businessId;

    @ApiModelProperty(value = "邮件:0收件;1发件 || 产品:0订单;1报价;2自定义; || 文件:0附件;1邮件附件;2云盘文件")
    private Integer type;

    public Long getBusinessId() {
        return businessId;
    }

    public void setBusinessId(Long businessId) {
        this.businessId = businessId;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "QueryBusinessDetailTableRequest{" +
                "businessId=" + businessId +
                ", type=" + type +
                ", num=" + num +
                ", size=" + size +
                ", paging=" + paging +
                '}';
    }
}
