package com.joinf.request.business;

import com.joinf.entity.BusinessShareRelEntity;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.List;

/**
 * 商机-共享请求参数
 *
 * @author yzq
 * @date 2019-05-07
 */
public class BusinessShareRequest implements Serializable {

    private static final long serialVersionUID = 8178672036827240531L;

    @ApiModelProperty(value = "商机id")
    private Long id;

    @ApiModelProperty(value = "业务员id集合")
    private List<BusinessShareRelEntity> shareList;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<BusinessShareRelEntity> getShareList() {
        return shareList;
    }

    public void setShareList(List<BusinessShareRelEntity> shareList) {
        this.shareList = shareList;
    }

    @Override
    public String toString() {
        return "BusinessShareRequest{" +
                "id=" + id +
                ", shareList=" + shareList.toString() +
                '}';
    }
}
