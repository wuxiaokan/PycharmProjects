package com.joinf.interceptor.system;

import java.io.BufferedReader;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONObject;
import com.joinf.entity.SessionUser;
import com.joinf.exception.ResubmitException;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.annotations.ResubmitData;

/**
 * @author zlx
 * @Description: 重复提交数据限制
 * @date 2018年2月23日 上午10:38:26
 */
public class ResubmitDataInterceptor implements HandlerInterceptor {

	/**
	 * 实现方法
	 */
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		
		String requestMethod = request.getMethod();
		if (requestMethod != null && requestMethod.toUpperCase().equals("OPTIONS")) {
			//探测请求直接过
			return true;
		}
		
		if (handler instanceof HandlerMethod) {
			HandlerMethod handlerMethod = (HandlerMethod) handler;
			Method method = handlerMethod.getMethod();
			ResubmitData annotation = method.getAnnotation(ResubmitData.class);

			if (annotation != null) {
				if (repeatDataValidator(request)) // 判断是否重复提交
					throw new ResubmitException("重复提交数据");
				else
					return true;
			}
			return true;
		}
		return true;
	}

	/**
	 * 实现方法
	 */
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub
	}

	/**
	 * 实现方法
	 */
	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub
	}

	/**
	 * 验证同一个用户，相同的url和参数是否重复提交 ,相同返回true
	 * 
	 * @param request
	 * @return
	 */
	public boolean repeatDataValidator(HttpServletRequest request) {
		String params = null;
		
		if (request.getParameterMap() != null && request.getParameterMap().size() > 0) {
			//读取application/x-www-form-urlencoded形式的参数
			params = JSONObject.toJSONString(request.getParameterMap());
		}else{
			//读取其他形式参数
			BufferedReader br = null;
			try {
				br = request.getReader();
				StringBuffer paramSb = new StringBuffer();
				
				String contentLine = br.readLine();
				paramSb.append(contentLine);
				
				while (contentLine != null) {
					contentLine = br.readLine();
					if (StringUtils.isNotBlank(contentLine)) {
						paramSb.append(contentLine);
					}
				}
				params = paramSb.toString();
			} catch (Exception e) {} finally {
				if(br != null)
					try {
						br.close();
					} catch (IOException e) {}
			}
		}
		
		String url = request.getRequestURI();

		SessionUser user = SessionUtils.getCurrentUserInfo(request);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("url", url);
		map.put("param", params);
		if (user != null)
		{
			map.put("oid", user.getUser().getId().toString()); // 用户id
		}

		String nowUrlParams = JSONObject.toJSONString(map); //url和参数
		
		//上次提交的参数
		String preUrlParams = (String) request.getSession().getAttribute("repeatData");
		if (preUrlParams == null) // 如果上一个数据为null,表示还未请求
		{
			request.getSession().setAttribute("repeatData", nowUrlParams);
			return false;
		} 
		// 否则，已经请求过
		else 
		{
			JSONObject preParamJson = JSONObject.parseObject(preUrlParams);
			long preTime = 0;
			if (preParamJson.containsKey("time")) {
				preTime = preParamJson.getLong("time");
			}
			long currTime = System.currentTimeMillis();
			
			preParamJson.remove("time");
			// 如果上次url+参数和本次url+参数相同，并且在2秒之内，则表示重复提交数据
			if (preParamJson.toJSONString().equals(nowUrlParams) && currTime-preTime <= 2000)
			{
				return true;
			} 
			// 如果上次url+参数和本次url+参数不同，则不是重复提交
			else 
			{
				//判断指定时间内提交为重复提交
				map.put("time",System.currentTimeMillis());
				nowUrlParams = JSONObject.toJSONString(map); //url和参数
				
				request.getSession().setAttribute("repeatData", nowUrlParams);
				return false;
			}

		}
	}

}
