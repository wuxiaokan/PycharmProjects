package com.joinf.response.business;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * t_business
 */
public class BusinessCustomerResponse implements Serializable {
    @ApiModelProperty(value ="ID")
    private Long id;

    @ApiModelProperty(value ="线索id")
    private Long clueId;

    @ApiModelProperty(value ="客户ID")
    private Long customerId;

    @ApiModelProperty(value ="商机名称")
    private String name;

    @ApiModelProperty(value ="商机编码")
    private String code;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getClueId() {
        return clueId;
    }

    public void setClueId(Long clueId) {
        this.clueId = clueId;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}