package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

import com.joinf.dto.DictCodeDto;


public class GenerateCodeRequest {

	@ApiModelProperty(value="1：客户编码，2：产品编码，3：报价单号，4：合同编号5：销售合同号6：供应商编码，7产品条码  8:商机编号",required=true)
	private Long parameterId;
	
	@ApiModelProperty(value="字典集合",required=true)
	private List<DictCodeDto> list = null;
	
	public List<DictCodeDto> getList() {
		return list;
	}

	public void setList(List<DictCodeDto> list) {
		this.list = list;
	}

	public Long getParameterId() {
		return parameterId;
	}

	public void setParameterId(Long parameterId) {
		this.parameterId = parameterId;
	}
	
	
	public String getParameterCode(){
		
		if(parameterId==null) return "";
		
		if(parameterId.intValue()==1){
			return "CUSTOMER_CODE";
		}else if(parameterId.intValue()==2){
			return "PRODUCT_CODE";
		}else if(parameterId.intValue()==3){
			return "QUOTE_CODE";
		}else if(parameterId.intValue()==4){
			return "CONTRACT_CODE";
		}else if(parameterId.intValue()==7){
			return "PRODUCT_BAR_CODE";
		}
		//商机编码
		else if(parameterId.intValue()==8){
			return "BUSINESS_CODE";
		}
		
		return "";
	}

}
