package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * 分享-展示部门人员列表请求参数
 *
 * @author yzq
 * @date 2019-05-08
 */
public class QueryShareDepartmentRequest implements Serializable {

    private static final long serialVersionUID = 643600912488626041L;

    @ApiModelProperty(value = "0:商机;1:客户",required = true)
    private Integer busType;

    @ApiModelProperty(value = "对应商机/客户/其他的主键id",required = true)
    private Long id;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public Integer getBusType() {
        return busType;
    }

    public void setBusType(Integer busType) {
        this.busType = busType;
    }

    @Override
    public String toString() {
        return "QueryShareDepartmentRequest{" +
                "busType=" + busType +
                ", id=" + id +
                '}';
    }
}
