package com.joinf.response.business;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * 商机详情-订单返回参数
 *
 * @author yzq
 * @date 2019-05-06
 */
public class BusinessOrderResponse implements Serializable {

    private static final long serialVersionUID = -6129047838908996995L;

    @ApiModelProperty(value = "订单id")
    private Long id;

    @ApiModelProperty(value="销售合同编号")
    private String saleContractNo;

    @ApiModelProperty(value="客户名称")
    private String customerName;

    @ApiModelProperty(value="合同总额")
    private String contractAmount;

    @ApiModelProperty(value="联系人")
    private String contactName;

    @ApiModelProperty(value="签约日期")
    private String signDate;

    @ApiModelProperty(value="状态:1/草拟;2/待审批;3/修改;4/完成;6/待审批;7/终止;/8生效")
    private String status;

    public String getSaleContractNo() {
        return saleContractNo;
    }

    public void setSaleContractNo(String saleContractNo) {
        this.saleContractNo = saleContractNo;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getContractAmount() {
        return contractAmount;
    }

    public void setContractAmount(String contractAmount) {
        this.contractAmount = contractAmount;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getSignDate() {
        return signDate;
    }

    public void setSignDate(String signDate) {
        this.signDate = signDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
