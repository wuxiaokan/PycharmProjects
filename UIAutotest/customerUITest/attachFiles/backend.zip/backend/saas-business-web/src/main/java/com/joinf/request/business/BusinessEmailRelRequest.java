package com.joinf.request.business;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.List;

/**
 * 保存商机关联邮件参数
 *
 * @author yzq
 * @date 2019-05-15
 */
public class BusinessEmailRelRequest implements Serializable {
    private static final long serialVersionUID = -5587797121785754008L;

    @ApiModelProperty(value = "商机id")
    private Long businessId;

    /**
     * 关联的邮件id集合
     */
    private List<Long> emailIds;

    public Long getBusinessId() {
        return businessId;
    }

    public void setBusinessId(Long businessId) {
        this.businessId = businessId;
    }

    public List<Long> getEmailIds() {
        return emailIds;
    }

    public void setEmailIds(List<Long> emailIds) {
        this.emailIds = emailIds;
    }

    @Override
    public String toString() {
        return "BusinessEmailRelRequest{" +
                "businessId=" + businessId +
                ", emailIds=" + emailIds +
                '}';
    }
}
