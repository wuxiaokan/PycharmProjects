package com.joinf.request;

import com.joinf.utils.base.BasePage;

import io.swagger.annotations.ApiModelProperty;

/**
 * 查询客户联系人请求参数
 *
 * @author yzq
 * @date 2019-04-25
 */
public class QueryCustomerConcactRequest extends BasePage{

    private static final long serialVersionUID = 4863273331389720786L;

    @ApiModelProperty(value="客户id",required=true)
    private Long customerId;

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }
}
