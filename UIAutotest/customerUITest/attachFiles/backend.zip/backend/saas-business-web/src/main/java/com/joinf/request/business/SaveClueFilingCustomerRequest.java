package com.joinf.request.business;

import java.io.Serializable;
import java.util.List;

import com.joinf.dto.DictCodeDto;
import com.joinf.request.IdAndNameRequest;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @author zlx
 * @Description: 线索建档保存-客户信息
 * @date 2019年4月25日 下午2:16:04
 */
public class SaveClueFilingCustomerRequest implements Serializable {

    private static final long serialVersionUID = 197540694897823242L;
    
    @ApiModelProperty(value="商机编码 字典集合")
   	private List<DictCodeDto> customizeCodeDicts;

    @ApiModelProperty(value ="客户类型")
    private IdAndNameRequest typeInfo;

    @ApiModelProperty(value ="客户来源")
    private IdAndNameRequest sourceInfo;

    @ApiModelProperty(value ="跟进阶段")
    private IdAndNameRequest flowStepInfo;
    
    @ApiModelProperty(value ="客户等级")
    private IdAndNameRequest gradeInfo;
    
    @ApiModelProperty(value ="业务类型")
    private IdAndNameRequest businessTypeInfo;
    
    @ApiModelProperty(value ="客户代码")
    private String code;

    @ApiModelProperty(value ="客户名称")
    private String name;
    
    @ApiModelProperty(value ="企业网址")
    private String webSite;
    
    @ApiModelProperty(value ="联系人姓名")
    private String contactName;
    
    @ApiModelProperty(value ="联系人邮箱")
    private String contactEmail;

	public List<DictCodeDto> getCustomizeCodeDicts() {
		return customizeCodeDicts;
	}

	public void setCustomizeCodeDicts(List<DictCodeDto> customizeCodeDicts) {
		this.customizeCodeDicts = customizeCodeDicts;
	}

	public IdAndNameRequest getTypeInfo() {
		return typeInfo;
	}

	public void setTypeInfo(IdAndNameRequest typeInfo) {
		this.typeInfo = typeInfo;
	}

	public IdAndNameRequest getSourceInfo() {
		return sourceInfo;
	}

	public void setSourceInfo(IdAndNameRequest sourceInfo) {
		this.sourceInfo = sourceInfo;
	}

	public IdAndNameRequest getFlowStepInfo() {
		return flowStepInfo;
	}

	public void setFlowStepInfo(IdAndNameRequest flowStepInfo) {
		this.flowStepInfo = flowStepInfo;
	}

	public IdAndNameRequest getGradeInfo() {
		return gradeInfo;
	}

	public void setGradeInfo(IdAndNameRequest gradeInfo) {
		this.gradeInfo = gradeInfo;
	}

	public IdAndNameRequest getBusinessTypeInfo() {
		return businessTypeInfo;
	}

	public void setBusinessTypeInfo(IdAndNameRequest businessTypeInfo) {
		this.businessTypeInfo = businessTypeInfo;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getWebSite() {
		return webSite;
	}

	public void setWebSite(String webSite) {
		this.webSite = webSite;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	@Override
	public String toString() {
		return "SaveClueFilingCustomerRequest [customizeCodeDicts=" + customizeCodeDicts + ", typeInfo=" + typeInfo
				+ ", sourceInfo=" + sourceInfo + ", flowStepInfo=" + flowStepInfo + ", gradeInfo=" + gradeInfo
				+ ", businessTypeInfo=" + businessTypeInfo + ", code=" + code + ", name=" + name + ", webSite="
				+ webSite + ", contactName=" + contactName + ", contactEmail=" + contactEmail + "]";
	}

	
	
	
	
	
}
