package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;

/**
 * Description: 创建名片扫描订单
 *
 * @author lyj
 * @date 2017年12月27日 下午2:11:04
 */
public class CreateUserCardScanOrderRequest {
	
	@ApiModelProperty(value="价格",required=true)
	private BigDecimal price;
	
	@ApiModelProperty(value="数量",required=true)
	private Integer amount;

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public Integer getAmount() {
		return amount;
	}

	public void setAmount(Integer amount) {
		this.amount = amount;
	}

}
