package com.joinf.controller;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.alibaba.fastjson.JSON;
import com.joinf.JoinfClientUtils;
import com.joinf.annotations.NeedLogin;
import com.joinf.config.SaasClientConfig;
import com.joinf.dto.CustomerFollowUpAttachmentDto;
import com.joinf.dto.DictDto;
import com.joinf.dto.QueryCustomerFollowCycle;
import com.joinf.dto.SaveCustomerFollowUpAttachmentDto;
import com.joinf.dto.customer.AddCustomerFollowUpDto;
import com.joinf.entity.SessionUser;
import com.joinf.entity.generator.BasicDataValue;
import com.joinf.entity.generator.CustomerContact;
import com.joinf.entity.generator.CustomerFollowCycle;
import com.joinf.entity.generator.CustomerFollowUpAttachment;
import com.joinf.entity.generator.SupplierContact;
import com.joinf.interfaces.CustomerContactService;
import com.joinf.interfaces.FollowCycleService;
import com.joinf.interfaces.SupplierContactService;
import com.joinf.interfaces.customer.CustomerFollowUpManager;
import com.joinf.request.IdRequest;
import com.joinf.request.customer.AddCustomerFollowUpRequest;
import com.joinf.request.customer.FollowRequest;
import com.joinf.request.customer.SaveFollowUpAttachmentRequest;
import com.joinf.request.customer.UpdateCustomerFollowUpFlagRequest;
import com.joinf.request.customer.UpdateCustomerFollowUpRequest;
import com.joinf.response.CustomerFollowUpVo;
import com.joinf.service.BasicDataValueServiceImpl;
import com.joinf.service.customer.CustomerFollowUpAttachmentManagerImpl;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.annotations.Permission;
import com.joinf.utils.annotations.ResubmitData;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.util.DateFormtContants;
import com.joinf.utils.util.JoinfBeanUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;


/**
 * Description: 客户跟进服务
 *
 * @author lyj
 * @date 2018年1月5日 下午4:53:16
 */
@RestController
@RequestMapping("customerFollowUp")
@Api(tags="客户跟进服务")
public class CustomerFollowUpController {
	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());
	@Autowired
	private CustomerFollowUpManager manager;
	@Autowired
    protected BasicDataValueServiceImpl basicDataValueService;
	
	@Autowired
	private FollowCycleService followCycleService;
	
	@Autowired
	private CustomerContactService customerContactService;
	
	@Autowired
	private SupplierContactService supplierContactService;
	
	@Autowired
	protected CustomerFollowUpAttachmentManagerImpl customerFollowUpAttachmentManagerImpl;
	
//	@ApiOperation(value="查询跟进信息", notes="查询跟进信息")
//	@ApiImplicitParam(name = "req", value = "查询跟进信息请求对象", required = true, dataType = "QueryCustomerFollowUpRequest")
//	@PostMapping("queryCustomerFollowUp")
//	public BaseResponseEntity<List<CustomerFollowUpVo>> queryCustomerFollowUp(HttpServletRequest request,@RequestBody QueryCustomerFollowUpRequest req){
//		BaseResponseEntity<List<CustomerFollowUpVo>> entity = new BaseResponseEntity<>();
//		QueryDateCustomerFollowUpListParam param = new QueryDateCustomerFollowUpListParam();
//		param.setCompanyId(1l);
//		param.setDate(req.getDate());
//		param.setOperatorId(1l);
//		entity.setData(service.getDateCustomerFollowUp(param));
//		entity.setSuccess(true);
//		return entity;
//	}
	
	@ApiOperation(value="查询跟进列表", notes="查询跟进信息列表")
	@ApiImplicitParam(name = "req", value = "查询跟进信息列表请求对象", required = true, dataType = "FollowRequest")
	@PostMapping("getCustomerFollowUpList")
	@Permission(require="follow.list.preview")
	public BaseResponseEntity<List<CustomerFollowUpVo>> getCustomerFollowUpList(HttpServletRequest request,@RequestBody FollowRequest req){
		BaseResponseEntity<List<CustomerFollowUpVo>> entity = new BaseResponseEntity<>();
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		boolean cloudSearch = false;
		if (req.isCloudSearch()) {//云搜索
			cloudSearch = req.isCloudSearch();
		}
		if(cloudSearch){
			//云搜索
			BaseResponseEntity<List<CustomerFollowUpVo>> searchCustomerFollow = manager.searchCustomerFollow(user.getCompanyId(), user.getOperatorId(), user.getSwitchOperatorId(),req);
			//需要获取跟进的颜色，帆姐说暂时不改es结果，先从数据库中获取
			SimpleDateFormat hms = new SimpleDateFormat(DateFormtContants.FORMAT_YYYY_MM_DD_HH_MM);
			List<CustomerFollowUpVo> data = searchCustomerFollow.getData();
			//批量查询所有联系人信息
			List<Long> contactIdList = data.stream().filter(a -> a.getContactId() != null && a.getContactId().longValue() != 0L).map(c -> c.getContactId()).collect(Collectors.toList());
			//客户联系人信息
			Map<Long, String> contactMap = new HashMap<Long, String>();
			//供应商联系人信息
			Map<Long, String> supplierMap = new HashMap<Long, String>();
			
			if(contactIdList.size() >0){
				List<CustomerContact> contactList = customerContactService.selectCustomerContactsByIds(user.getCompanyId(), contactIdList);
				contactList.forEach(contact ->{
					contactMap.put(contact.getId(), contact.getName());
				});
				
				List<SupplierContact> supplierList = supplierContactService.selectSupplierContactsByIds(user.getCompanyId(), contactIdList);
				supplierList.forEach(contact ->{
					supplierMap.put(contact.getId(), contact.getName());
				});
			}
			
			data.forEach(d ->{
				if(d.getCreateTime() != null){
					d.setCreateTimeStr(hms.format(d.getCreateTime()));
					//客户联系人名称
					if(contactMap.containsKey(d.getContactId())){
						d.setContactName(contactMap.get(d.getContactId()));
					}
					
					//供应商联系人名称
					if(supplierMap.containsKey(d.getContactId())){
						d.setContactName(supplierMap.get(d.getContactId()));
					}
					//查询附件列表
					List<CustomerFollowUpAttachment> followUpAttaList = customerFollowUpAttachmentManagerImpl.selectFollowUpAttachmentListByFollowId(d.getId());
					if(!CollectionUtils.isEmpty(followUpAttaList)){
						//从oss 获取附件的绝对路径
						for(CustomerFollowUpAttachment followUpAtta : followUpAttaList){
							followUpAtta.setUrl(JoinfClientUtils.getUrl(SaasClientConfig.saasClientConfig,followUpAtta.getUrl()));
						}
						
						d.setFollowUpAtta(followUpAttaList.size() > 0 ? 1 : 0);
						d.setFollowUpAttaList(followUpAttaList);
					}
				}
			});
			entity.setData(data);
			entity.setTotalPage((int)searchCustomerFollow.getTotalPage(req.getSize()));
			entity.setTotalRecords(searchCustomerFollow.getTotalRecords());
			entity.setSuccess(true);
		}else{
			List<CustomerFollowUpVo> data = manager.selectByCompanyIdAndCustomerIds(user.getCompanyId(), user.getOperatorId(), user.getSwitchOperatorId(),req);
			int total = manager.selectCountByCompanyIdAndCustomerIds(user.getCompanyId(), user.getOperatorId(), user.getSwitchOperatorId(),req);
			entity.setData(data);
			entity.setTotalPage((int)(total%req.getSize() == 0 ? total/req.getSize() : total/req.getSize() + 1));
			entity.setTotalRecords(Long.valueOf(total));
			entity.setSuccess(true);
		}
		return entity;
	}
	
	
	@ApiOperation(value="查询跟进详情", notes="查询跟进信息详情")
	@ApiImplicitParam(name = "req", value = "查询跟进信息详情请求对象", required = true, dataType = "IdRequest")
	@PostMapping("getCustomerFollowUpDetail")
	@Permission(require="follow.list.preview")
	public BaseResponseEntity<CustomerFollowUpVo> getCustomerFollowUpDetail(HttpServletRequest request,@RequestBody IdRequest req){
		BaseResponseEntity<CustomerFollowUpVo> entity = new BaseResponseEntity<>();
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		entity.setData(manager.getCustomerFollowUpDetail(user.getCompanyId(), user.getOperatorId(), user.getSwitchOperatorId(), req.getId(),req.getFlowModel()));
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="新增客户跟进", notes="新增客户跟进")
	@ApiImplicitParam(name = "req", value = "新增客户跟进请求对象", required = true, dataType = "AddCustomerFollowUpRequest")
	@PostMapping("addCustomerFollowUp")
	@NeedLogin
	@Permission(require="follow.list.new")
	public BaseResponseEntity<Long> addCustomerFollowUp(HttpServletRequest request,@RequestBody AddCustomerFollowUpRequest req){
		BaseResponseEntity<Long> entity = new BaseResponseEntity<>();
		AddCustomerFollowUpDto dto = new AddCustomerFollowUpDto();
		JoinfBeanUtils.copyProperties(dto, req);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		entity.setData(manager.addCustomerFollowUp(dto));
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="修改客户跟进", notes="修改客户跟进")
	@ApiImplicitParam(name = "req", value = "修改客户跟进请求对象", required = true, dataType = "UpdateCustomerFollowUpRequest")
	@PostMapping("updateCustomerFollowUp")
	@NeedLogin
	@Permission(require="follow.list.edit")
	public BaseResponseEntity<Long> updateCustomerFollowUp(HttpServletRequest request,@RequestBody UpdateCustomerFollowUpRequest req){
		BaseResponseEntity<Long> entity = new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		manager.updateCustomerFollowUp(req,user.getSwitchOperatorId());
		entity.setData(req.getId());
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="修改客户跟进状态", notes="修改客户跟进状态")
	@ApiImplicitParam(name = "req", value = "修改客户跟进请求对象", required = true, dataType = "UpdateCustomerFollowUpFlagRequest")
	@PostMapping("updateCustomerFollowUpFlag")
	@Permission(require="follow.list.execute")
	public BaseResponseEntity<List<Long>> updateCustomerFollowUpFlag(HttpServletRequest request,@RequestBody UpdateCustomerFollowUpFlagRequest req){
		BaseResponseEntity<List<Long>> entity = new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		List<Long> updateIds = manager.updateCustomerFollowUpFlag(req,user.getSwitchOperatorId());
		entity.setData(updateIds);
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="修改选中客户跟进状态", notes="修改客户跟进状态")
	@ApiImplicitParam(name = "req", value = "修改客户跟进请求对象", required = true, dataType = "UpdateCustomerFollowUpFlagRequest")
	@PostMapping("updateSelectCustomerFollowUpFlag")
	@Permission(require="follow.list.execute")
	public BaseResponseEntity<?> updateSelectCustomerFollowUpFlag(HttpServletRequest request,@RequestBody UpdateCustomerFollowUpFlagRequest req){
		BaseResponseEntity<?> entity = new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		manager.updateSelectCustomerFollowUpFlag(req,user.getSwitchOperatorId());
		entity.setSuccess(true);
		return entity;
	}
	
	
	@ApiOperation(value="删除客户跟进", notes="删除客户跟进")
	@ApiImplicitParam(name = "req", value = "删除客户跟进请求对象", required = true, dataType = "IdRequest")
	@PostMapping("delteCustomerFollowUp")
	@Permission(require="follow.list.delete")
	public BaseResponseEntity<?> updateCustomerFollowUpFlag(HttpServletRequest request,@RequestBody IdRequest req){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		BaseResponseEntity<?> entity = new BaseResponseEntity<>();
		UpdateCustomerFollowUpFlagRequest dto = new UpdateCustomerFollowUpFlagRequest();
		dto.setFlag(-1);
		dto.setFollowUpId(req.getId());
		dto.setUpdateBatch(0);
		manager.updateCustomerFollowUpFlag(dto,user.getSwitchOperatorId());
		entity.setSuccess(true);
		return entity;
	}
	
	
	@ApiOperation(value="删除选中客户跟进", notes="删除客户跟进")
	@ApiImplicitParam(name = "req", value = "删除客户跟进请求对象", required = true, dataType = "IdRequest")
	@PostMapping("delteSelectCustomerFollowUp")
	@Permission(require="follow.list.delete")
	public BaseResponseEntity<?> delteSelectCustomerFollowUp(HttpServletRequest request,@RequestBody IdRequest req){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		BaseResponseEntity<?> entity = new BaseResponseEntity<>();
		UpdateCustomerFollowUpFlagRequest dto = new UpdateCustomerFollowUpFlagRequest();
		dto.setFlag(-1);
		dto.setFollowUpIds(req.getIds());
		dto.setUpdateBatch(0);
		manager.updateSelectCustomerFollowUpFlag(dto,user.getSwitchOperatorId());
		entity.setSuccess(true);
		return entity;
	}
	
	
	/**
	 * 保存跟进附件
	 * @param request
	 * @param req
	 * @return
	 */
	@ApiOperation(value="保存跟进附件", notes="保存跟进附件,返回附件id")
	@ApiImplicitParam(name = "req", value = "保存跟进附件请求对象", required = true, dataType = "SaveFollowUpAttachmentRequest")
	@PostMapping(value = "/saveFollowUpAttachment")
	@ResponseBody
	@NeedLogin
	@ResubmitData
	public BaseResponseEntity<List<String>> saveFollowUpAttachment(HttpServletRequest request, @RequestBody SaveFollowUpAttachmentRequest req) {
		
		BaseResponseEntity<List<String>> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		SaveCustomerFollowUpAttachmentDto saveDto = JoinfBeanUtils.copyToNewBean(SaveCustomerFollowUpAttachmentDto.class, req);
		saveDto.setList(JoinfBeanUtils.copyToNewListBean(CustomerFollowUpAttachmentDto.class, req.getList()));
		saveDto.setCompanyId(user.getCompanyId());
		saveDto.setOperatorId(user.getSwitchOperatorId());
		saveDto.setCreateId(user.getSwitchOperatorId());
		saveDto.setUpdateId(user.getSwitchOperatorId());
		logger.info("保存附件对象===================================={}",JSON.toJSON(saveDto));
		
		entity.setData(manager.saveFollowUpAttachment(saveDto));
		
		return entity;
	}
	
	
	/**
	 * 通过跟进ID 查询跟进附件
	 * @param request
	 * @param req
	 * @return
	 */
	@ApiOperation(value="通过跟进ID查询跟进附件", notes="通过跟进ID 查询跟进附件,返回附件集合")
	@ApiImplicitParam(name = "req", value = "通过跟进ID查询跟进附件", required = true, dataType = "GettFollowUpAttachmentListByFollowId")
	@PostMapping(value = "/gettFollowUpAttachmentListByFollowId")
	@ResponseBody
	@NeedLogin
	public BaseResponseEntity<List<CustomerFollowUpAttachment>> gettFollowUpAttachmentListByFollowId(HttpServletRequest request,@RequestBody IdRequest req) {
		
		BaseResponseEntity<List<CustomerFollowUpAttachment>> entity = new BaseResponseEntity<>();
		
		entity.setData(manager.selectFollowUpAttachmentListByFollowId(req.getId()));
		entity.setSuccess(true);
		return entity;
	}
	
	
	
	/**
	 * 获取跟进方式
	 * @param request
	 * @param req
	 * @return
	 */
	@ApiOperation(value="获取跟进方式", notes="获取跟进方式")
	@ApiImplicitParam(name = "req", value = "通过跟进ID查询跟进附件", required = true, dataType = "GetFollowMethod")
	@PostMapping(value = "/getFollowMethod")
	@ResponseBody
	@NeedLogin
	public BaseResponseEntity<List<BasicDataValue>> gettFollowMethod(HttpServletRequest request) {
		
		BaseResponseEntity<List<BasicDataValue>> entity = new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		DictDto dto = new DictDto();
		dto.setBasicDataId(42l);
		dto.setCompanyId(user.getCompanyId());
//		basicDataValueService.selectByCompanyId(dto);
		entity.setData(basicDataValueService.selectByCompanyId(dto));
		entity.setSuccess(true);
		return entity;
	}
	
	
	/**
	 * 查询周期列表
	 * 
	 * @param json
	 * @param session
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@PostMapping(value = "/getFollowCycle")
	@ResponseBody
	@ApiOperation(value="查询周期列表", notes="查询周期列表")
	@NeedLogin
	public BaseResponseEntity<List<CustomerFollowCycle>> getFollowCycle(HttpServletRequest request) {
		BaseResponseEntity<List<CustomerFollowCycle>> entity = new BaseResponseEntity<>();
		// 操作员
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		CustomerFollowCycle cy = new CustomerFollowCycle();
		cy.setCompanyId(user.getCompanyId());
		cy.setOperatorId(user.getSwitchOperatorId());
		
		List<CustomerFollowCycle> list = followCycleService.selectCustomerFollowCycleList(cy);
		entity.setData(list);
		entity.setSuccess(true);
		return entity;
	}
	
	/**
	 * 查询指定自定义周期详情
	 * 
	 * @param json
	 * @param session
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value="查询指定自定义周期详情", notes="查询指定自定义周期详情")
	@ApiImplicitParam(name = "req", value = "通过周期ID查询指定自定义周期详情", required = true, dataType = "IdRequest")
	@PostMapping(value = "/getFollowCycleDetail")
	@ResponseBody
	@NeedLogin
	public BaseResponseEntity<CustomerFollowCycle> getFollowCycleDetail(HttpServletRequest request,@RequestBody IdRequest req) {
		BaseResponseEntity<CustomerFollowCycle> entity = new BaseResponseEntity<>();
		// 操作员
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		CustomerFollowCycle detail = followCycleService.selectByPrimaryKey(req.getId(),user.getCompanyId(),user.getSwitchOperatorId());
		entity.setData(detail);
		entity.setSuccess(true);
		return entity;
	}
	
	/**
	 * 保存自定义周期
	 * 
	 * @param json
	 * @param session
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value="保存自定义周期", notes="保存自定义周期")
	@ApiImplicitParam(name = "req", value = "保存自定义周期", required = true, dataType = "QueryCustomerFollowCycle")
	@PostMapping(value = "/saveFollowCycle")
	@ResponseBody
	@NeedLogin
	public BaseResponseEntity<CustomerFollowCycle> saveFollowCycle(HttpServletRequest request,@RequestBody QueryCustomerFollowCycle req) {
		BaseResponseEntity<CustomerFollowCycle> entity = new BaseResponseEntity<>();
		// 操作员
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		if(req.getRepeatInterval() == null || req.getRepeatName() == null || req.getRepeatCycle() == null){
			entity.setSuccess(false);
			entity.setErrMsg("缺少必填参数");
			return entity;
		}
		req.setCompanyId(user.getCompanyId());
		req.setOperatorId(user.getSwitchOperatorId());
		req.setCreateId(user.getOperatorId());
		req.setUpdateId(user.getSwitchOperatorId());
		CustomerFollowCycle customerFollowCycle = followCycleService.insertCustomerFollowCycle(req);
		entity.setData(customerFollowCycle);
		entity.setSuccess(true);
		return entity;
	}
}
