package com.joinf.interceptor.system;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * Description: 系统拦截器配置
 *
 * @author lyj
 * @date 2017年12月19日 下午6:57:39
 */
@Configuration
public class SystemInterceptorConfigurer extends WebMvcConfigurerAdapter{
	
	/**
	 * 权限拦截器
	 * @return
	 */
	@Bean
	public PermissionInterceptor permissionInterceptor(){
		return new PermissionInterceptor();
	}
	
	/**
	 * 重复提交拦截器
	 */
	@Bean
	public ResubmitDataInterceptor resubmitDataInterceptor() {
		return new ResubmitDataInterceptor();
	}

	/**
	 * 容量限制拦截器
	 */
	@Bean
    public VolumeLimitInterceptor volumeLimitInterceptor() {
		return new VolumeLimitInterceptor();
	}
	
	/**
	 * 重复登录
	 */
	@Bean
	public RepeatLoginInterceptor repeatLoginInterceptor() {
		return new RepeatLoginInterceptor();
	}

	/**
	 * 配置拦截器
	 */
	@Override
    public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(repeatLoginInterceptor()).addPathPatterns("/**")
		.excludePathPatterns("/system/login").excludePathPatterns("/system/afterTwoCheck");
		registry.addInterceptor(permissionInterceptor()).addPathPatterns("/**").excludePathPatterns("/system/login");
		registry.addInterceptor(resubmitDataInterceptor()).addPathPatterns("/**");
		registry.addInterceptor(volumeLimitInterceptor()).addPathPatterns("/**");
	}
	
	
}
