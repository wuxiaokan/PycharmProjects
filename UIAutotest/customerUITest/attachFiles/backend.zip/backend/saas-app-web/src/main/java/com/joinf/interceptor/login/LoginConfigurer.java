package com.joinf.interceptor.login;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * Description: 登入拦截控制器
 *
 * @author lyj
 * @date 2017年12月15日 下午7:54:26
 */
@Configuration
public class LoginConfigurer extends WebMvcConfigurerAdapter {
	
	public final static String loginPath = "/system/login";
	public final static String initPath = "/system/init";
	public final static String afterInitPath = "/regist/afterInit";
	public final static String afterTwoCheck = "/system/afterTwoCheck";
	
	
	/**
	 * 校验用户名和密码
	 * @return
	 */
	@Bean
	public CheckUsernameAndPasswordInterceptor checkUsernameAndPasswordInterceptor(){
		return new CheckUsernameAndPasswordInterceptor();
	}
	
	/**
	 * 校验账号状态(校验权限接口已处理企业降权)
	 * @return
	 */
	@Bean
	public CheckAccountStatusInterceptor checkAccountStatus(){
		return new CheckAccountStatusInterceptor();
	}
	/**
	 * 处理企业过期时间
	 * @return
	 */
	@Bean
	public DealCompanyExpireInterceptor dealCompanyExpireInterceptor(){
		return new DealCompanyExpireInterceptor();
	}
	
	/**
	 * 初始化信息
	 * @return
	 */
	@Bean
	public InitSessionReourceInterceptor initSessionReourceInterceptor(){
		return new InitSessionReourceInterceptor();
	}
	
	/**
	 * 配置拦截器
	 */
	@Override
    public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(checkUsernameAndPasswordInterceptor()).addPathPatterns(loginPath);
		registry.addInterceptor(checkAccountStatus())
		.addPathPatterns(loginPath)
		.addPathPatterns(afterInitPath)
		.addPathPatterns(afterTwoCheck);
		registry.addInterceptor(dealCompanyExpireInterceptor())
		.addPathPatterns(afterInitPath)
		.addPathPatterns(loginPath)
		.addPathPatterns(afterTwoCheck);
		registry.addInterceptor(initSessionReourceInterceptor())
		.addPathPatterns(afterInitPath)
		.addPathPatterns(loginPath)
		.addPathPatterns(afterTwoCheck);
	}
}
