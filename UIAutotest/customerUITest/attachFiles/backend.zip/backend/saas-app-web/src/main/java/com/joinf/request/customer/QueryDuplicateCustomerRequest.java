package com.joinf.request.customer;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

import com.joinf.utils.base.BasePage;

/**
 * @author lyj
 * @Description: 客户跟进主键查询参数
 * @data 2017年12月4日 下午2:38:17
 */
public class QueryDuplicateCustomerRequest extends BasePage implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2596363725471279783L;
	
	@ApiModelProperty(value ="按客户名称")
	private String name;
	
	@ApiModelProperty(value ="按网站")
	private String webSite;
	
	@ApiModelProperty(value ="按联系人名称")
	private String contactName;
	
	@ApiModelProperty(value ="按联系方式")
	private String contactWay;
	
	@ApiModelProperty(value ="按联系地址")
	private String contactAddress;

	@ApiModelProperty(value ="排序字段")
	private String sortColumn;
	
	@ApiModelProperty(value ="是否公海")
	private boolean highSeas;
	
	public boolean isHighSeas() {
		return highSeas;
	}

	public void setHighSeas(boolean highSeas) {
		this.highSeas = highSeas;
	}
	public String getSortColumn() {
		return sortColumn;
	}

	public void setSortColumn(String sortColumn) {
		this.sortColumn = sortColumn;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getWebSite() {
		return webSite;
	}

	public void setWebSite(String webSite) {
		this.webSite = webSite;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getContactWay() {
		return contactWay;
	}

	public void setContactWay(String contactWay) {
		this.contactWay = contactWay;
	}

	public String getContactAddress() {
		return contactAddress;
	}

	public void setContactAddress(String contactAddress) {
		this.contactAddress = contactAddress;
	}

	
}
