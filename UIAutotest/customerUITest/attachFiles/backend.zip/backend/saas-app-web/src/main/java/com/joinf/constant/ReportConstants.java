package com.joinf.constant;

import java.util.HashMap;
import java.util.Map;

/**
 * @author qiuch
 * @date 2017年8月8日 下午8:54:50
 * @des 报表基本常量
 */
public class ReportConstants {
	
	/** 统计前xxx**/
	public final static Integer STAT_TOP_COUNT=10;
	
	/**rul 基本参数 {reportType}/{statDimension} **/
	public final static String REPORT_TYPE = "reportType";
	public final static String STAT_DISMENSION = "statDimension";
	
	/**报表类型**/
	public final static String MODEL_CUSTOMER = "customer";
	public final static String MODEL_EMAIL = "email";
	public final static String MODEL_ORDER = "order";
	public final static String MODEL_QUOTE = "quote";
	public final static String MODEL_PRODUCT = "product";
	public final static String MODEL_PK = "pk";
	/**维度名称**/
//	public final static String STAT_FOLLOW_UP = "follow_up";
	public final static String STAT_UNCONTACT = "uncontact";
//	public final static String STAT_TYPE = "type";
	public final static String STAT_OPERATOR = "operator";  //所属客户
	public final static String STAT_CREATE_OPERATOR = "create_operator"; //创建客户
//	public final static String STAT_SOURCE = "source";
//	public final static String STAT_GRADE = "grade";
//	public final static String STAT_REGION = "region";
//	public final static String STAT_PRODUCT = "main_product";
//	public final static String STAT_CUSTOMER_NAME = "customer_name";
//	public final static String STAT_PRODUCT_CODE = "product_code";
	
	
	/** 表后缀命名 **/
	/** customer **/
	public final static String CUSTOMER_FOLLOW_UP = "follow_up";
	public final static String CUSTOMER_UNCONTACT = "uncontact";
	public final static String CUSTOMER_TYPE = "type";
	public final static String CUSTOMER_OPERATOR = "operator";
	public final static String CUSTOMER_SOURCE = "source";
	public final static String CUSTOMER_GRADE = "grade";
	public final static String CUSTOMER_REGION = "region";
	public final static String CUSTOMER_PRODUCT = "main_product";

	/** email **/
	public final static String EMAIL_DAY = "day";
	public final static String EMAIL_TYPE = "type";
	public final static String EMAIL_OPERATOR = "operator";
	public final static String EMAIL_SOURCE = "source";
	public final static String EMAIL_REGION = "region";

	/** quote **/
	public final static String QUOTE_DAY = "day";
	public final static String QUOTE_OPERATOR = "operator";
	public final static String QUOTE_SOURCE = "source";
	public final static String QUOTE_REGION = "region";
	public final static String QUOTE_CUSTOMER_NAME = "customer_name";
	public final static String QUOTE_PRODUCT_CODE = "product_code";
	
	/** order **/
	public final static String ORDER_DAY = "day";
	public final static String ORDER_OPERATOR = "operator";
	public final static String ORDER_SOURCE = "source";
	public final static String ORDER_REGION = "region";
	public final static String ORDER_CUSTOMER_NAME = "customer_name";
	public final static String ORDER_PRODUCT_CODE = "product_code";
	
	/** product **/
	public final static String PRODUCT_GROUP = "group";
	public final static String PRODUCT_OPERATOR = "operator";
	public final static String PRODUCT_TOP_ORDER = "top_order"; 
	public final static String PRODUCT_TOP_QUOTE = "top_quote"; 
	
	
	/** 选择时间段常量 **/
	public final static String DTAE_TYPE = "dateType";  
	public final static String DTAE_VALUE = "dateValue";
	
	/** 起始时间 **/
	public final static String START_TIME = "startTime";  
	public final static String END_TIME = "endTime";  
	
	
	/** 年/月 **/
	public final static String DTAE_YEAR = "year";  
	public final static String DTAE_MONTH = "month"; 
	
	public final static String ORDER_TYPE = "orderType";  
	public final static String QUOTE_TYPE = "quoteType";
	
	
	/** 需要管理的资源权限 **/
	public final static Integer RESOURCE_EMAIL = 10000016;
	public final static Integer RESOURCE_CUSTOMER = 10000008;
	public final static Integer RESOURCE_PRODUCT = 10000011;
	public final static Integer RESOURCE_QUOTE = 10000018;
	public final static Integer RESOURCE_ORDER = 10000200;
	public final static Integer RESOURCE_FOLLOW = 10000010;
	public final static Integer RESOURCE_SUPPLIERS = 10000044;
	public final static Integer RESOURCE_CLOUDDISK = 10000250;
	public final static Integer RESOURCE_MESSAGE = 10000410;
	
	
	
	public final static Map<Integer,String> BOX_STATS_MAP = new HashMap<Integer,String>();
	
	static {
		BOX_STATS_MAP.put(1, "草稿");
		BOX_STATS_MAP.put(3, "草稿");
		BOX_STATS_MAP.put(2, "待批");
		BOX_STATS_MAP.put(6, "待批");
		BOX_STATS_MAP.put(4, "执行");
		BOX_STATS_MAP.put(8, "完成");
		BOX_STATS_MAP.put(7, "终止");
	}
 

}
