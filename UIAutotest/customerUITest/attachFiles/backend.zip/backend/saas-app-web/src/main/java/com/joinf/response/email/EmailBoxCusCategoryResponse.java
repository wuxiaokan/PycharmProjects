package com.joinf.response.email;

import io.swagger.annotations.ApiModelProperty;

/**
 * 客户箱分类
 * @author zlx
 * @Description: TODO
 * @date 2018年1月11日 上午11:28:38
 */
public class EmailBoxCusCategoryResponse {
	@ApiModelProperty(value = "分类id")
	private Long id;
	@ApiModelProperty(value = "分类名称")
	private String name;
	@ApiModelProperty(value = "分类类型")
	private int type;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	
	
}
