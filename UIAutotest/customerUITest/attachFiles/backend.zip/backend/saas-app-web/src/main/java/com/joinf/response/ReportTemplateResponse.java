package com.joinf.response;

import io.swagger.annotations.ApiModelProperty;

public class ReportTemplateResponse {

	@ApiModelProperty(value = "主键ID")
	private Long id;

	@ApiModelProperty(value = "企业ID,如果为空代表系统的")
	private Long companyId;

	@ApiModelProperty(value = "模板名称")
	private String name;

	@ApiModelProperty(value = "excel的存储路径")
	private String excelCode;

	@ApiModelProperty(value = "pdf的存储路径")
	private String pdfCode;

	@ApiModelProperty(value = "模板类型:[1]PI模板;[2]报价模板;[3]订单模板;")
	private Byte type;

	@ApiModelProperty(value = "html的存储路径")
	private String htmlCode;

	@ApiModelProperty(value = "文件原名称")
	private String fileName;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getExcelCode() {
		return excelCode;
	}

	public void setExcelCode(String excelCode) {
		this.excelCode = excelCode;
	}

	public String getPdfCode() {
		return pdfCode;
	}

	public void setPdfCode(String pdfCode) {
		this.pdfCode = pdfCode;
	}

	public Byte getType() {
		return type;
	}

	public void setType(Byte type) {
		this.type = type;
	}

	public String getHtmlCode() {
		return htmlCode;
	}

	public void setHtmlCode(String htmlCode) {
		this.htmlCode = htmlCode;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

}
