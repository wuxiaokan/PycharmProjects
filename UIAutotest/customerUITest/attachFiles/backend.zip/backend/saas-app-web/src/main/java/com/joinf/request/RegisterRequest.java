package com.joinf.request;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 注册参数
 *
 * @author lyj
 * @date 2017年12月21日 下午7:40:28
 */
public class RegisterRequest {
	
	@ApiModelProperty(value="公司名称",required=true)
	private String companyName;
	
	@Pattern(regexp = "^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{3,15}$",message="用户名格式不正确")
	@ApiModelProperty(value="用户名",required=true)
	private String userName;
	
	@Size(min=6,max=50,message="密码格式不正确")
	@ApiModelProperty(value="密码",required=true)
	private String password;
	
	@ApiModelProperty(value="邮箱",required=true)
	private String email;
	
	@ApiModelProperty(value="手机",required=true)
	private String mobile;
	
	@ApiModelProperty(value="类型(1=手机,2=邮箱)",required=true)
	private Integer checkType;
	
	@ApiModelProperty(value="随机码-校验使用",required=true)
	private String random;
	
	@ApiModelProperty(value="验证码",required=true)
	private String captcha;
	
	@ApiModelProperty(value ="省份")
    private String province;

    @ApiModelProperty(value ="城市")
    private String city;

    @ApiModelProperty(value ="县区")
    private String area;

    @ApiModelProperty(value ="地址")
    private String address;
    
    @ApiModelProperty(value = "联系人名称")
	private String contactName;
    
	@ApiModelProperty(value = "性别:1/男;0/女")
	private Integer sex;

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getRandom() {
		return random;
	}

	public void setRandom(String random) {
		this.random = random;
	}

	public String getCaptcha() {
		return captcha;
	}

	public void setCaptcha(String captcha) {
		this.captcha = captcha;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Integer getCheckType() {
		return checkType;
	}

	public void setCheckType(Integer checkType) {
		this.checkType = checkType;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public Integer getSex() {
		return sex;
	}

	public void setSex(Integer sex) {
		this.sex = sex;
	}

}
