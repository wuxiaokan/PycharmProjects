package com.joinf.request.product;

import java.io.Serializable;
import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 扫码条形码后返回参数
 * @author cuichuanlei
 * @created 2019年3月12日 下午5:57:50
 */
public class ScanRequest implements Serializable {
	
	private static final long serialVersionUID = 7934880812492717294L;
	
	@ApiModelProperty(value="条形码",required=true)
	private String data;

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}
	
}
