package com.joinf.request.supplier;

import com.joinf.utils.base.BasePage;

import io.swagger.annotations.ApiModelProperty;

public class QuerySupplierLogRequest extends BasePage{

	private static final long serialVersionUID = 1L;

	@ApiModelProperty("不传表示全部--表名(customer-客户,follow-跟进,email-邮件,order-订单,quote-报价,transfer-客户迁移)")
	private String tableName;

	@ApiModelProperty("供应商id")
	private Long sid;

	@ApiModelProperty("业务类别(空表示全部)：customer-客户,follow-跟进,email-邮件,order-订单,quote-报价,transfer-客户迁移")
	private String busType;

	@ApiModelProperty("开始日期(格式2017-12-01 00:00:00)")
	private String beginDate;
	
	@ApiModelProperty("截止日期(格式2017-12-31 23:59:59)")
	private String endDate;
	
	@ApiModelProperty("第几页(从0开始)")
	private Integer pageStart;
	
	@ApiModelProperty("分页大小")
	private Integer pageSize;
	
	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public Long getSid() {
		return sid;
	}

	public void setSid(Long sid) {
		this.sid = sid;
	}

	public String getBusType() {
		return busType;
	}

	public void setBusType(String busType) {
		this.busType = busType;
	}

	public String getBeginDate() {
		return beginDate;
	}

	public void setBeginDate(String beginDate) {
		this.beginDate = beginDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public Integer getPageStart() {
		return pageStart;
	}

	public void setPageStart(Integer pageStart) {
		this.pageStart = pageStart;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	
	
	
}
