package com.joinf.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.Page;
import com.joinf.dto.CloudDishFileDto;
import com.joinf.dto.QueryCloudDishParam;
import com.joinf.dto.QueryCloudFileParam;
import com.joinf.dto.cloudfile.DeleteCloudFileDto;
import com.joinf.dto.cloudfile.UploadCloudFileDto;
import com.joinf.entity.CloudDishCatalogueEx;
import com.joinf.entity.LimitConfig;
import com.joinf.entity.SessionUser;
import com.joinf.entity.generator.CloudDishCatalogue;
import com.joinf.entity.generator.Company;
import com.joinf.entity.generator.Operator;
import com.joinf.interfaces.CloudDishManager;
import com.joinf.request.IdArrayRequest;
import com.joinf.request.cloud.DeleteCloudFileRequest;
import com.joinf.request.cloud.UploadCloudFileRequest;
import com.joinf.request.cloud.ValidateClodDishRequest;
import com.joinf.request.clouddish.InsertOrUpdateCloudDishCatalogueRequest;
import com.joinf.request.clouddish.QueryColudDishFileRequest;
import com.joinf.request.clouddish.QueryColudDishFolderRequest;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.annotations.Permission;
import com.joinf.utils.annotations.VolumeLimit;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.util.JoinfBeanUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * Description: 云盘服务
 *
 * @author lyj
 * @date 2018年4月12日 下午3:43:11
 */
@RestController
@RequestMapping("cloud")
@Api(tags="云盘服务")
public class CloudDishController {
	
	@Autowired
	private LimitConfig limitConfig;
	
	@Autowired
	private CloudDishManager cloudDishManager;
	
	@ApiOperation(value="校验文件是否超出限制(True超过，false可以上传)", notes="校验文件是否超出限制(True超过，false可以上传)")
	@PostMapping("validateClodDish")
	@ApiImplicitParam(name = "req", value = "校验文件是否超出限制请求对象", required = true, dataType = "ValidateClodDishRequest")
	public BaseResponseEntity<Boolean> validateClodDish(HttpServletRequest request,@RequestBody ValidateClodDishRequest req){
		BaseResponseEntity<Boolean> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		QueryCloudFileParam param = new QueryCloudFileParam();
		JoinfBeanUtils.copyProperties(param, req);
		if(req.getType() == 1){//个人
			param.setOperatorId(user.getSwitchOperatorId());
		}
		param.setCompanyId(user.getCompanyId());
		param.setSize(1);
		param.setPaging(true);
		param.setNum(1);
		List<CloudDishFileDto> data = cloudDishManager.selectCloudDishFile(param);
		Long total = ((Page<CloudDishFileDto>) data).getTotal();
		entity.setData(total.intValue()>=limitConfig.getCloudDishAddFileAmount());
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="查询文件夹", notes="查询文件夹")
	@PostMapping("selectFolders")
	@ApiImplicitParam(name = "req", value = "查询文件夹请求对象", required = true, dataType = "QueryColudDishFolderRequest")
	@Permission(require="cloud.list.preview")
	public BaseResponseEntity<List<CloudDishCatalogueEx>> selectFolders(HttpServletRequest request,@RequestBody QueryColudDishFolderRequest req){
		BaseResponseEntity<List<CloudDishCatalogueEx>> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		QueryCloudDishParam param = new QueryCloudDishParam();
		JoinfBeanUtils.copyProperties(param, req);
		if(req.getType() == 1){//个人
			param.setOperatorId(user.getSwitchOperatorId());
		}
		param.setCompanyId(user.getCompanyId());
		List<CloudDishCatalogueEx> data = cloudDishManager.selectCloudDishFolder(param);
		if(req.isPaging()){
			data = ((Page<CloudDishCatalogueEx>) data).getResult();
			entity.setTotalPage(((Page<CloudDishCatalogueEx>) data).getPages());
			entity.setTotalRecords(((Page<CloudDishCatalogueEx>) data).getTotal());
		}
		entity.setData(data);
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="查询文件", notes="查询文件")
	@PostMapping("selectFolderFiles")
	@ApiImplicitParam(name = "req", value = "查询文件夹请求对象", required = true, dataType = "QueryColudDishFileRequest")
	@Permission(require="cloud.list.preview")
	public BaseResponseEntity<List<CloudDishFileDto>> selectFolderFiles(HttpServletRequest request,@RequestBody QueryColudDishFileRequest req){
		BaseResponseEntity<List<CloudDishFileDto>> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		QueryCloudFileParam param = new QueryCloudFileParam();
		JoinfBeanUtils.copyProperties(param, req);
		if(req.getType() == 1){//个人
			param.setOperatorId(user.getSwitchOperatorId());
		}
		param.setCompanyId(user.getCompanyId());
		List<CloudDishFileDto> data = cloudDishManager.selectCloudDishFile(param);
		if(req.isPaging()){
			data = ((Page<CloudDishFileDto>) data).getResult();
			entity.setTotalPage(((Page<CloudDishFileDto>) data).getPages());
			entity.setTotalRecords(((Page<CloudDishFileDto>) data).getTotal());
		}
		entity.setData(data);
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="文件上传回调", notes="文件上传回调")
	@PostMapping("uploadCloudFileCallback")
	@ApiImplicitParam(name = "req", value = "文件上传回调请求对象", required = true, dataType = "UploadCloudFileRequest")
	@Permission(require="cloud.file.upload")	
	@VolumeLimit
	public BaseResponseEntity<Long> uploadCloudFileCallback(HttpServletRequest request,@RequestBody UploadCloudFileRequest req){
		BaseResponseEntity<Long> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		UploadCloudFileDto param = new UploadCloudFileDto();
		JoinfBeanUtils.copyProperties(param, req);
		param.setOperatorId(user.getSwitchOperatorId());
		param.setCompanyId(user.getCompanyId());
		param.setOperateType("上传");
		param.setFromSys("tms");
		param.setLoginOperatorId(user.getOperatorId());
		entity.setData(cloudDishManager.uploadCloudFileCallback(param).getId());
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="修改文件夹", notes="修改文件夹")
	@PostMapping("insertOrUpdateCatalogue")
	@ApiImplicitParam(name = "req", value = "修改文件夹请求对象", required = true, dataType = "InsertOrUpdateCloudDishCatalogueRequest")
	@Permission(require="cloud.folder.edit")
	public BaseResponseEntity<CloudDishCatalogueEx> insertOrUpdateCatalogue(HttpServletRequest request,@RequestBody InsertOrUpdateCloudDishCatalogueRequest req){
		BaseResponseEntity<CloudDishCatalogueEx> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		CloudDishCatalogue catalogue = new CloudDishCatalogue();
		JoinfBeanUtils.copyProperties(catalogue, req);
		Date date = new Date();
		if(req.getId() == null){
			catalogue.setCompanyId(user.getCompanyId());
			catalogue.setCreateTime(date);
		}
		if(req.getType() == 1)
			catalogue.setOperatorId(user.getSwitchOperatorId());
		catalogue.setUpdateTime(date);
		catalogue.setUpdateId(user.getOperatorId());
		catalogue.setFlag(1);
		catalogue.setCreateId(user.getOperatorId());
		entity.setData(cloudDishManager.insertOrUpdateCloudDishCatalogue(catalogue));
		entity.setSuccess(true);
		return entity;
		
	}
	
	@ApiOperation(value="删除文件夹", notes="删除文件夹")
	@PostMapping("deleteCatalogue")
	@ApiImplicitParam(name = "req", value = "删除文件夹请求对象", required = true, dataType = "IdArrayRequest")
	@Permission(require="cloud.folder.delete")
	public BaseResponseEntity<?> deleteCatalogue(HttpServletRequest request,@RequestBody IdArrayRequest req){
		BaseResponseEntity<?> entity= new BaseResponseEntity<>();
		Company company = SessionUtils.getCompanyInfo(request);
		Operator operator = SessionUtils.getOperatorInfo(request);
		cloudDishManager.deleteCatalogue(req.getIdArray(), company.getId(), operator.getId());
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="删除文件", notes="删除文件")
	@PostMapping("deleteCloudFile")
	@ApiImplicitParam(name = "req", value = "删除文件请求对象", required = true, dataType = "DeleteCloudFileRequest")
	@Permission(require="cloud.file.delete")
	public BaseResponseEntity<?> deleteCloudFile(HttpServletRequest request,@RequestBody DeleteCloudFileRequest req){
		BaseResponseEntity<?> entity= new BaseResponseEntity<>();
		Company company = SessionUtils.getCompanyInfo(request);
		Operator operator = SessionUtils.getOperatorInfo(request);
		DeleteCloudFileDto dto = new DeleteCloudFileDto();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setCompanyId(company.getId());
		dto.setOperatorId(operator.getId());
		cloudDishManager.deleteCloudFile(dto);
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="校验同目录下是否存在同文件名的文件", notes="校验同目录下是否存在同文件名的文件")
	@PostMapping("checkCloudFileName")
	@ApiImplicitParam(name = "req", value = "校验同目录下是否存在同文件名的文件请求对象", required = true, dataType = "UploadCloudFileRequest")
	@Permission(require="cloud.file.upload")	
	@VolumeLimit
	public BaseResponseEntity<Long> checkCloudFileName(HttpServletRequest request,@RequestBody UploadCloudFileRequest req){
		BaseResponseEntity<Long> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		UploadCloudFileDto param = new UploadCloudFileDto();
		JoinfBeanUtils.copyProperties(param, req);
		param.setOperatorId(user.getSwitchOperatorId());
		param.setCompanyId(user.getCompanyId());
		param.setLoginOperatorId(user.getOperatorId());
		
		boolean flag = cloudDishManager.checkCloudFileName(param);
		
		if (!flag) {
			entity.setErrMsg("所选目录中含有重名文件，是否覆盖？");
		}
		entity.setSuccess(flag);
		return entity;
	}

}
