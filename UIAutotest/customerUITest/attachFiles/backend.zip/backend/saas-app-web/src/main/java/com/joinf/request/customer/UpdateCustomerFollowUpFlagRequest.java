package com.joinf.request.customer;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 修改客户跟进完成状态
 *
 * @author lyj
 * @date 2018年1月5日 下午4:59:08
 */
public class UpdateCustomerFollowUpFlagRequest {
	
	@ApiModelProperty(value="跟进id",required=true)
	private Long followUpId;
	
	@ApiModelProperty(value="跟进id集合")
	private String followUpIds;
	
	@ApiModelProperty(value="状态(0未完成，1完成,-1删除)",required=true)
	private Integer flag;
	
	@ApiModelProperty(value="是否批量更新（1是0否）",required=true)
	private Integer updateBatch=0;

	public Integer getUpdateBatch() {
		return updateBatch;
	}

	public void setUpdateBatch(Integer updateBatch) {
		this.updateBatch = updateBatch;
	}

	public Long getFollowUpId() {
		return followUpId;
	}

	public void setFollowUpId(Long followUpId) {
		this.followUpId = followUpId;
	}

	public Integer getFlag() {
		return flag;
	}

	public void setFlag(Integer flag) {
		this.flag = flag;
	}

	public String getFollowUpIds() {
		return followUpIds;
	}

	public void setFollowUpIds(String followUpIds) {
		this.followUpIds = followUpIds;
	}
	
	
}
