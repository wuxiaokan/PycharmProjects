package com.joinf.response;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 可管理业务员信息
 * @date 2018年3月7日 下午3:26:56
 */
public class OperatorAssignmentResponse {
	@ApiModelProperty(value="用户id")
	private Long id;
	@ApiModelProperty(value="用户名")
	private String userName;
	@ApiModelProperty(value="中文名")
	private String chineseName;
	@ApiModelProperty(value="英文姓名")
	private String englishName;
	
	@ApiModelProperty(value="部门")
	private String department;

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getChineseName() {
		return chineseName;
	}

	public void setChineseName(String chineseName) {
		this.chineseName = chineseName;
	}

	public String getEnglishName() {
		return englishName;
	}

	public void setEnglishName(String englishName) {
		this.englishName = englishName;
	}
	
	
	
	

}
