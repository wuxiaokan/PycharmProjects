package com.joinf.request.businessData;

import java.io.Serializable;
import java.util.List;

/**
 * 商业数据我的关注对应的组
 * @author cuichuanlei
 * @created 2019年1月29日
 */
public class BusinessFavoriteGroupReq implements Serializable{
	
	private static final long serialVersionUID = -3897895352755431767L;

	/**主键*/
	private Integer id;
	
	/**souceId*/
	private List<String> ids;
	
	/**组名*/
	private String groupName;
	
	/**用户ID*/
	private Integer userId;
	
	/**公司ID*/
	private Integer companyId;
	
	/**是否管理员*/
	private boolean admin;
	
	/**用户账号userId*/
	private Long accountId;
	
	/**组数据列表*/
	private List<BusinessFavoriteGroupDetailReq> groupDetailInfoList;
	
	private List<Integer> groupIds;
	/**登录的userId*/
	private int loginUserId;

	/**是否需要根据默认创建的组进行排序，为true系统默认创建组在最前面*/
	private Boolean sysflgSort;
	
	/** 当前页码 */
	private Integer pageNum;

	/** 当前页显示的数量 */
	private Integer pageSize;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public List<String> getIds() {
		return ids;
	}

	public void setIds(List<String> ids) {
		this.ids = ids;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public boolean isAdmin() {
		return admin;
	}

	public void setAdmin(boolean admin) {
		this.admin = admin;
	}

	public Long getAccountId() {
		return accountId;
	}

	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}

	public List<BusinessFavoriteGroupDetailReq> getGroupDetailInfoList() {
		return groupDetailInfoList;
	}

	public void setGroupDetailInfoList(List<BusinessFavoriteGroupDetailReq> groupDetailInfoList) {
		this.groupDetailInfoList = groupDetailInfoList;
	}

	public List<Integer> getGroupIds() {
		return groupIds;
	}

	public void setGroupIds(List<Integer> groupIds) {
		this.groupIds = groupIds;
	}

	public int getLoginUserId() {
		return loginUserId;
	}

	public void setLoginUserId(int loginUserId) {
		this.loginUserId = loginUserId;
	}

	public Boolean isSysflgSort() {
		return sysflgSort;
	}

	public void setSysflgSort(Boolean sysflgSort) {
		this.sysflgSort = sysflgSort;
	}

	public Integer getPageNum() {
		return pageNum;
	}

	public void setPageNum(Integer pageNum) {
		this.pageNum = pageNum;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

}
