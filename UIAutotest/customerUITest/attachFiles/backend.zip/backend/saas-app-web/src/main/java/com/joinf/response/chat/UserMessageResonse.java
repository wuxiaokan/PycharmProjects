package com.joinf.response.chat;

import com.alibaba.fastjson.annotation.JSONField;

import io.swagger.annotations.ApiModelProperty;

public class UserMessageResonse {
	
	@JSONField(name="messageid")
	@ApiModelProperty("会话id")
	private Integer messageId;
	
	@JSONField(name="threadid")
	@ApiModelProperty("聊天信息id")
	private Integer threadId;
	
	@JSONField(name="agentid")
	@ApiModelProperty("客服id（agantid为时并且ikind为一时说明是用户发送的信息）")
	private Integer agentId;
	
	@JSONField(name="ikind")
	@ApiModelProperty("信息类型（1为客户发送 2 为客服发送 其他的为系统发送消息）")
	private Integer iKind;
	
	@JSONField(name="dtmcreated")
	@ApiModelProperty("发送信息时间")
	private Long dtmCreated;
	
	@JSONField(name="tname")
	@ApiModelProperty("消息")
	private String tName;
	
	@JSONField(name="tmessage")
	@ApiModelProperty("用户名（客服跟客户都是用这个）")
	private String tMessage;

	public Integer getMessageId() {
		return messageId;
	}

	public void setMessageId(Integer messageId) {
		this.messageId = messageId;
	}

	public Integer getThreadId() {
		return threadId;
	}

	public void setThreadId(Integer threadId) {
		this.threadId = threadId;
	}

	public Integer getAgentId() {
		return agentId;
	}

	public void setAgentId(Integer agentId) {
		this.agentId = agentId;
	}

	public Integer getiKind() {
		return iKind;
	}

	public void setiKind(Integer iKind) {
		this.iKind = iKind;
	}

	public Long getDtmCreated() {
		return dtmCreated;
	}

	public void setDtmCreated(Long dtmCreated) {
		this.dtmCreated = dtmCreated;
	}

	public String gettName() {
		return tName;
	}

	public void settName(String tName) {
		this.tName = tName;
	}

	public String gettMessage() {
		return tMessage;
	}

	public void settMessage(String tMessage) {
		this.tMessage = tMessage;
	}

}
