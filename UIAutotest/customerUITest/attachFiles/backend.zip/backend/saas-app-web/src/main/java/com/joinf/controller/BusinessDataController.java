package com.joinf.controller;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.joinf.annotations.NeedLogin;
import com.joinf.constant.Constants;
import com.joinf.dto.CheckSuccessDto;
import com.joinf.dto.CompanyDTO;
import com.joinf.dto.businessData.BusinessData;
import com.joinf.dto.businessData.BusinessDataSnsDto;
import com.joinf.dto.businessData.BusinessFavoriteGroup;
import com.joinf.dto.businessData.CountryData;
import com.joinf.dto.businessData.EmailInfo;
import com.joinf.dto.businessData.IndustryData;
import com.joinf.dto.businessData.VerifyCustomerDto;
import com.joinf.entity.PropertiesEntity;
import com.joinf.entity.SessionUser;
import com.joinf.entity.generator.Customer;
import com.joinf.entity.generator.CustomerWithBLOBs;
import com.joinf.entity.generator.Operator;
import com.joinf.interfaces.CustomerService;
import com.joinf.interfaces.OperatorService;
import com.joinf.request.businessData.BusinessDataSearchReq;
import com.joinf.request.businessData.BusinessFavoriteGroupDetailReq;
import com.joinf.request.businessData.BusinessFavoriteGroupReq;
import com.joinf.request.businessData.CompanySearchReq;
import com.joinf.request.businessData.CountryRequest;
import com.joinf.request.businessData.TemporaryEdmGroupEmailReq;
import com.joinf.utils.AESUtils;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.util.HostDoneException;
import com.joinf.utils.util.HttpUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * Description: 商业数据服务
 * @author cuichuanlei
 * @created 2019年1月11日 下午3:33:01
 */
@RestController
@RequestMapping("businessData")
@Api(tags="商业数据服务")
public class BusinessDataController extends BaseController{
	
	@Autowired
	private PropertiesEntity propertiesEntity;
	
	//标签
	private final String companyNameTag = "<span style=\"color:rgb(255, 106, 0);\">";
	//标签结束
	private final String companyNameTagEx = "</span>";
	
	@Autowired
	protected OperatorService operatorService;
	
	@Autowired
	private CustomerService customerService; 
	
	/**
	 * 获取国家信息
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询国家", notes="查询国家")
	@ApiImplicitParam(name = "req", value = "查询国家字典请求对象", required = true, dataType = "CountryRequest")
	@PostMapping("searchCountry")
	public BaseResponseEntity<List<CountryData>> searchCountry(@RequestBody CountryRequest req) throws IOException{
		BaseResponseEntity<List<CountryData>> entity = new BaseResponseEntity<>(true);
		Map<String,String> params = new HashMap<>();
		if(req.getKeywords() != null && StringUtils.isNotBlank(req.getKeywords())){
			params.put("keyword", req.getKeywords());
		}
		String result = HttpUtils.postMapToJsonBody(propertiesEntity.getDataUrl()+"/dd/getBusinessCountry", params);
		JSONObject object = JSONObject.parseObject(result);
		if(object.containsKey("code") && "0".equals(object.getString("code"))){
			List<CountryData> datas = JSON.parseArray(object.getJSONArray("data").toJSONString(), CountryData.class);
			entity.setData(datas);
		}else{
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg("未知错误，请联系客服！");
		}
		return entity;	
	}
	
	/**
	 * 获取行业信息
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询行业", notes="查询行业")
	@ApiImplicitParam(name = "req", value = "查询行业字典请求对象", required = true, dataType = "CountryRequest")
	@PostMapping("searchIndustry")
	public BaseResponseEntity<List<IndustryData>> searchIndustry(@RequestBody CountryRequest req) throws IOException{
		BaseResponseEntity<List<IndustryData>> entity = new BaseResponseEntity<>(true);
		Map<String,String> params = new HashMap<>();
		if(req.getKeywords() != null && StringUtils.isNotBlank(req.getKeywords())){
			params.put("keyword", req.getKeywords());
		}
		String result = HttpUtils.postMapToJsonBody(propertiesEntity.getDataUrl()+"/bsApp/getIndustryThreeInfoByKeywords", params);
		JSONObject object = JSONObject.parseObject(result);
		if(object.containsKey("code") && "0".equals(object.getString("code"))){
			List<IndustryData> datas = JSON.parseArray(object.getJSONArray("data").toJSONString(), IndustryData.class);
			entity.setData(datas);
		}else{
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg("未知错误，请联系客服！");
		}
		return entity;	
	}
	
	
	/**
	 * 查询商业数据列表
	 * @param req
	 * @return
	 * @throws  
	 */
	@ApiOperation(value="查询商业数据列表", notes="查询商业数据列表")
	@ApiImplicitParam(name = "req", value = "查询字段字典请求对象", required = true, dataType = "BusinessDataSearchReq")
	@PostMapping("searchBusinessDataList")
	@NeedLogin
	public BaseResponseEntity<List<BusinessData>> searchBusinessDataList(HttpServletRequest request, @RequestBody BusinessDataSearchReq req) throws HostDoneException{
		BaseResponseEntity<List<BusinessData>> entity = new BaseResponseEntity<>(true);
		JSONObject paramObj = new JSONObject();
		
		CheckSuccessDto dto = SessionUtils.getCenterUserDto(request);
		CompanyDTO company = SessionUtils.getCenterCompanyInfo(request);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		if(dto == null || company == null){
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg("请先登录");
			return entity;
		}
		
		if(req.getEmailFlag() != null && req.getEmailFlag().intValue() != -1){
			paramObj.put("emailFlag", req.getEmailFlag());
		}
		if(req.getIndustries() != null && req.getIndustries().size() >0){
			paramObj.put("industries", JSONArray.toJSON(req.getIndustries()));
		}
		if(req.getCountries() != null && req.getCountries().size() >0){
			paramObj.put("countries", JSONArray.toJSON(req.getCountries()));
		}
		paramObj.put("userId", dto.getUserId());
		paramObj.put("companyId", dto.getCompanyId());
		paramObj.put("dataNotAstrict", company.getDataNotAstrict());
		
		if(req.getSearchType() != null){
			paramObj.put("searchType", req.getSearchType());
		}
		if(req.getUrlFlag() != null && req.getUrlFlag().intValue() != -1){
			paramObj.put("urlFlag", req.getUrlFlag());
		}
		if(req.getKeywords() != null && StringUtils.isNotBlank(req.getKeywords())){
			paramObj.put("keywords", req.getKeywords());
		}
		//全匹配
		paramObj.put("fullMatch", req.getFullMatch());
		
		Integer pageNum = 1;
		Integer pageSize = 20;
		
		if(req.getPageNum() != null && req.getPageNum().intValue() > 0){
			pageNum = req.getPageNum();
		}
		
		if(req.getPageSize() != null && req.getPageSize().intValue() > 0){
			pageSize = req.getPageSize();
		}
		
		paramObj.put("pageNum", pageNum);
		paramObj.put("pageSize", pageSize);
		
		String result = HttpUtils.httpPost(propertiesEntity.getDataUrl()+"/bsApp/search/selectBusinessDataList_v2", paramObj);
		JSONObject object = JSONObject.parseObject(result);
		if(object.containsKey("code") && "0".equals(object.getString("code"))){
			if(object.containsKey("data") && object.get("data") != null){
				
				JSONObject resultObject = object.getJSONObject("data");	
				Long total = 0L;
				if(resultObject.containsKey("max") && resultObject.get("max") != null){
					total = resultObject.getLong("max");
				}
				
				Long totalPage = 0l;
				
				if(total >0){
					totalPage = (total%pageSize==0)?(total/pageSize):(total/pageSize+1);
					List<BusinessData> datas = JSON.parseArray(resultObject.getJSONArray("businessDataEntities").toJSONString(), BusinessData.class);
					datas.forEach(bsData -> {
						//公司名取首字母
						String companyName = bsData.getCompanyName();
						if(companyName.contains(companyNameTag)){
							companyName = companyName.replace(companyNameTag, "").replace(companyNameTagEx, "").trim();
						}
						Customer customer = customerService.selectCustomerByName(user.getCompanyId(), companyName);
						if(customer != null){
							VerifyCustomerDto c = new VerifyCustomerDto();
							c.setExist(true);
							c.setCustomerId(customer.getId().intValue());
							if(!this.checkHas(user.getSwitchOperatorId(),customer.getOperatorId(), Constants.RESOURCE_CUSTOMER_ID)){
								c.setHasAuth(false);
							}else{
								c.setHasAuth(true);
							}
							bsData.setCustomer(c);
						}
						
						if(StringUtils.isNotBlank(companyName)){
							String companyNameEx = companyName.substring(0, 1);
							bsData.setCompanyNameEx(companyNameEx);
						}
						//竞争对手公司名取首字母
						List<BusinessData> competitorList = bsData.getCompetitorListEx();
						if(competitorList != null && competitorList.size() >0){
							competitorList.forEach(data ->{
								String dataEx = data.getCompanyName();
								if(dataEx.contains(companyNameTag)){
									dataEx = dataEx.replace(companyNameTag, "").replace(companyNameTagEx, "").trim();
								}
								if(StringUtils.isNotBlank(dataEx)){
									String cNameEx = dataEx.substring(0, 1);
									data.setCompanyNameEx(cNameEx);
								}
							});
						}
						
						//公共邮箱解密
						List<EmailInfo> publicEmailList = bsData.getPublicEmailList();
						if(publicEmailList != null && publicEmailList.size() >0){
							publicEmailList.forEach(data ->{
								String dataEx = data.getEmail();
								String emailEx = AESUtils.decryptStrs(dataEx);
								data.setEmail(emailEx);								
							});
						}
						
						//工作邮箱解密
						List<EmailInfo> personEmailList = bsData.getPersonEmailList();
						if(personEmailList != null && personEmailList.size() >0){
							personEmailList.forEach(data ->{
								String dataEx = data.getEmail();
								String emailEx = AESUtils.decryptStrs(dataEx);
								data.setEmail(emailEx);		
							});
						}
						
					});
					entity.setData(datas);
				}
				entity.setTotalRecords(total);
				entity.setTotalPage(totalPage.intValue());
			}
		}else{
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg(object.getString("msg"));
		}

		return entity;	
	}

	/**
	 * 查询公司详情信息
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询公司详情信息", notes="查询公司详情")
	@ApiImplicitParam(name = "req", value = "查询公司详情", required = true, dataType = "CompanySearchReq")
	@PostMapping("selectBusinessDataById")
	@NeedLogin
	public BaseResponseEntity<BusinessData> selectBusinessDataById(HttpServletRequest request, @RequestBody CompanySearchReq req) throws IOException{
		BaseResponseEntity<BusinessData> entity = new BaseResponseEntity<>(true);
		if (StringUtils.isBlank(req.getId())) {
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg("参数异常");
			return entity;
		}
		
		Map<String,String> params = new HashMap<>();
		CheckSuccessDto dto = SessionUtils.getCenterUserDto(request);
		CompanyDTO company = SessionUtils.getCenterCompanyInfo(request);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		if(dto == null || company == null){
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg("请先登录");
			return entity;
		}
		
		params.put("userId", dto.getUserId().toString());
		params.put("companyId", dto.getCompanyId().toString());
		params.put("id", req.getId());
		params.put("dataNotAstrict", company.getDataNotAstrict().toString());
		
		String result = HttpUtils.postMapToJsonBody(propertiesEntity.getDataUrl()+"/bsApp/decrypt/selectBusinessDataByIdv2", params);
		JSONObject object = JSONObject.parseObject(result);
		
		if(object.containsKey("code") && "0".equals(object.getString("code"))){
			if(object.containsKey("data") && object.get("data") != null){
				BusinessData data = JSON.parseObject(object.getJSONObject("data").toJSONString(), BusinessData.class);
				//公司名取首字母
				String companyName = data.getCompanyName();
				if(companyName.contains(companyNameTag)){
					companyName.replace(companyNameTag, "").replace(companyNameTagEx, "").trim();
				}
				
				VerifyCustomerDto c = data.getCustomer();
				if(c != null && c.getCustomerId() != null){
					CustomerWithBLOBs customer = customerService.queryByKey(c.getCustomerId().longValue());
					if(customer != null){
						VerifyCustomerDto vc = new VerifyCustomerDto();
						vc.setExist(true);
						vc.setCustomerId(customer.getId().intValue());
						if(!this.checkHas(user.getSwitchOperatorId(),customer.getOperatorId(), Constants.RESOURCE_CUSTOMER_ID)){
							vc.setHasAuth(false);
						}else{
							vc.setHasAuth(true);
						}
						data.setCustomer(vc);
					}
				}
				
				if(StringUtils.isNotBlank(companyName)){
					String companyNameEx = companyName.substring(0, 1);
					data.setCompanyNameEx(companyNameEx);
				}
				//竞争对手公司名生成首字母
				List<BusinessData> competitorList = data.getCompetitorListEx();
				if(competitorList != null && competitorList.size() > 0){
					competitorList.forEach(bsData ->{
						String dataEx = bsData.getCompanyName();
						if(dataEx.contains(companyNameTag)){
							dataEx = dataEx.replace(companyNameTag, "").replace(companyNameTagEx, "").trim();
						}
						if(StringUtils.isNotBlank(dataEx)){
							String cNameEx = dataEx.substring(0, 1);
							bsData.setCompanyNameEx(cNameEx);
						}
					});
				}
				
				//公共邮箱解密
				List<EmailInfo> publicEmailList = data.getPublicEmailList();
				if(publicEmailList != null && publicEmailList.size() >0){
					publicEmailList.forEach(bsData ->{
						String dataEx = bsData.getEmail();
						String emailEx = AESUtils.decryptStrs(dataEx);
						bsData.setEmail(emailEx);								
					});
				}
				
				//工作邮箱解密
				List<EmailInfo> personEmailList = data.getPersonEmailList();
				if(personEmailList != null && personEmailList.size() >0){
					personEmailList.forEach(bsData ->{
						String dataEx = bsData.getEmail();
						String emailEx = AESUtils.decryptStrs(dataEx);
						bsData.setEmail(emailEx);		
					});
				}
				entity.setData(data);
			}
		}else{
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg("商业数据额度不足，请及时充值");
		}
		
		return entity;	
	}
	
	/**
	 * 查询我的分组列表
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询我的分组列表", notes="查询我的分组列表")
	@PostMapping("selectGroupInfoByUserId")
	@NeedLogin
	public BaseResponseEntity<List<BusinessFavoriteGroup>> selectGroupInfoByUserId(HttpServletRequest request, @RequestBody BusinessFavoriteGroupReq req) throws HostDoneException{
		BaseResponseEntity<List<BusinessFavoriteGroup>> entity = new BaseResponseEntity<>(true);	
		JSONObject paramObj = new JSONObject();	
		
		CheckSuccessDto dto = SessionUtils.getCenterUserDto(request);
		
		if(dto == null){
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg("请先登录");
			return entity;
		}
		
		paramObj.put("userId", dto.getUserId());
		paramObj.put("companyId", dto.getCompanyId());
		
		if (StringUtils.isNotBlank(req.getGroupName())) {
			paramObj.put("groupName", req.getGroupName());
		}
		
		if (req.getGroupIds() != null && req.getGroupIds().size() > 0) {
			paramObj.put("groupIds", JSONArray.toJSON(req.getGroupIds()));
		}
		
		if (req.getPageNum() != null) {
			paramObj.put("pageNum", req.getPageNum());
		}
		
		if (req.getPageSize() != null) {
			paramObj.put("pageSize", req.getPageSize());
		}

		paramObj.put("sysflgSort", true);
		
		String url = "";
		if(req.getPageNum() == null || req.getPageSize() == null){
			url = propertiesEntity.getDataUrl()+"/bsApp/favorite/selectGroupInfoByUserId";
		}else{
			url = propertiesEntity.getDataUrl()+"/bsApp/favorite/selectGroupInfoByParams";
		}
		String result = HttpUtils.httpPost(url, paramObj);
		JSONObject object = JSONObject.parseObject(result);
		if(object.containsKey("code") && "0".equals(object.getString("code"))){
			if(object.containsKey("data") && object.get("data") != null){
				
				Long max = 0l;
				Integer pageCount = 0;
				
				if(object.containsKey("max") && object.get("max") != null){
					max = object.getLong("max");
				}
				
				if(object.containsKey("pageCount") && object.get("pageCount") != null){
					pageCount = object.getInteger("pageCount");
				}
				
				entity.setTotalRecords(max);
				entity.setTotalPage(pageCount);
				
				List<BusinessFavoriteGroup> datas = JSON.parseArray(object.getJSONArray("data").toJSONString(), BusinessFavoriteGroup.class);
				
				datas.forEach(group ->{
					long userId = group.getUserId();
					Operator op = operatorService.selectByCenterUserId(userId);
					if(op != null){
						group.setUserName(op.getZhName());
					}
				});
				entity.setData(datas);
			}	
		}else{
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg(object.getString("msg"));
		}
		
		return entity;	
	}
	
	/**
	 * 添加分组
	 * @param req
	 * @return
	 */
	@ApiOperation(value="添加分组", notes="添加分组")
	@ApiImplicitParam(name = "req", value = "添加分组请求对象", required = true, dataType = "BusinessFavoriteGroupReq")
	@PostMapping("addGroupInfo")
	@NeedLogin
	public BaseResponseEntity<Integer> addGroupInfo(HttpServletRequest request, @RequestBody BusinessFavoriteGroupReq req) throws IOException{
		BaseResponseEntity<Integer> entity= new BaseResponseEntity<>(true);
		Map<String,String> params = new HashMap<>();
		
		CheckSuccessDto dto = SessionUtils.getCenterUserDto(request);
		
		if(dto == null){
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg("请先登录");
			return entity;
		}
		
		params.put("userId", dto.getUserId().toString());
		params.put("companyId", dto.getCompanyId().toString());
		
		if (StringUtils.isBlank(req.getGroupName())) {
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg("参数异常");
			return entity;
		}
		params.put("groupName", req.getGroupName());
		
		String result = HttpUtils.postMapToJsonBody(propertiesEntity.getDataUrl()+"/bsApp/favorite/addGroupInfo", params);
		JSONObject object = JSONObject.parseObject(result);
		if(object.containsKey("code") && object.getIntValue("code") == 0){
			Integer groupId = object.getInteger("data");
			entity.setData(groupId);
		}else{
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg("添加分组失败");
		}
		return entity;	
	}
	
	
	/**
	 * 添加我的关注组数据
	 * @param req
	 * @return
	 */
	@ApiOperation(value="添加我的关注组数据", notes="添加我的关注组数据")
	@ApiImplicitParam(name = "req", value = "添加我的关注组请求对象", required = true, dataType = "BusinessFavoriteGroupReq")
	@PostMapping("addFavoriteGroupDetailInfo")
	@NeedLogin
	public BaseResponseEntity<Boolean> addFavoriteGroupDetailInfo(HttpServletRequest request, @RequestBody BusinessFavoriteGroupReq req) throws HostDoneException{
		BaseResponseEntity<Boolean> entity= new BaseResponseEntity<>(true);
		JSONObject paramObj = new JSONObject();	
		
		CheckSuccessDto dto = SessionUtils.getCenterUserDto(request);
		
		if(dto == null){
			entity.setCode(-3);
			entity.setData(false);
			entity.setSuccess(false);
			entity.setErrMsg("请先登录");
			return entity;
		}
		
		paramObj.put("userId", dto.getUserId());
		paramObj.put("companyId", dto.getCompanyId());
		
		if (req.getIds() == null || req.getIds().size() <= 0 || req.getId() == null) {
			entity.setCode(-3);
			entity.setData(false);
			entity.setSuccess(false);
			entity.setErrMsg("参数异常");
			return entity;
		}
		
		paramObj.put("ids", JSONArray.toJSON(req.getIds()));
		paramObj.put("id", req.getId());
		
		String result = HttpUtils.httpPost(propertiesEntity.getDataUrl()+"/bsApp/favorite/addFavoriteGroupDetailInfo", paramObj);
		JSONObject object = JSONObject.parseObject(result);
		if(object.containsKey("code") && object.getIntValue("code") == 0){
			entity.setData(true);
		}else{
			entity.setCode(-3);
			entity.setData(false);
			entity.setSuccess(false);
			entity.setErrMsg("添加我的关注组数据失败");
		}
		
		return entity;	
	}

	/**
	 * 删除组
	 * @param req
	 * @return
	 */
	@ApiOperation(value="删除组", notes="删除组")
	@ApiImplicitParam(name = "req", value = "删除组请求对象", required = true, dataType = "BusinessFavoriteGroupReq")
	@PostMapping("delGroupInfo")
	@NeedLogin
	public BaseResponseEntity<Boolean> delGroupInfo(HttpServletRequest request, @RequestBody BusinessFavoriteGroupReq req) throws IOException{
		BaseResponseEntity<Boolean> entity= new BaseResponseEntity<>(true);
		Map<String,String> params = new HashMap<>();
		
		CheckSuccessDto dto = SessionUtils.getCenterUserDto(request);
		
		if(dto == null){
			entity.setCode(-3);
			entity.setData(false);
			entity.setSuccess(false);
			entity.setErrMsg("请先登录");
			return entity;
		}
		
		params.put("userId", dto.getUserId().toString());
		params.put("companyId", dto.getCompanyId().toString());
		
		if (req.getId() == null) {
			entity.setCode(-3);
			entity.setData(false);
			entity.setSuccess(false);
			entity.setErrMsg("参数异常");
			return entity;
		}
		params.put("id", req.getId().toString());
		
		String result = HttpUtils.postMapToJsonBody(propertiesEntity.getDataUrl()+"/bsApp/favorite/delGroupInfo", params);
		JSONObject object = JSONObject.parseObject(result);
		if(object.containsKey("code") && object.getIntValue("code") == 0){
			entity.setData(true);
		}else{
			entity.setCode(-3);
			entity.setData(false);
			entity.setSuccess(false);
			entity.setErrMsg("删除组数据失败");
		}
		
		return entity;	
	}
	
	
	/**
	 * 取消关注
	 * @param req
	 * @return
	 */
	@ApiOperation(value="取消关注", notes="取消关注")
	@ApiImplicitParam(name = "req", value = "取消关注请求对象", required = true, dataType = "BusinessFavoriteGroupDetailReq")
	@PostMapping("deleteGroupDetailInfo")
	@NeedLogin
	public BaseResponseEntity<Boolean> deleteGroupDetailInfo(HttpServletRequest request, @RequestBody BusinessFavoriteGroupDetailReq req) throws IOException{
		BaseResponseEntity<Boolean> entity= new BaseResponseEntity<>(true);
		Map<String,String> params = new HashMap<>();
		
		CheckSuccessDto dto = SessionUtils.getCenterUserDto(request);
		
		if(dto == null){
			entity.setCode(-3);
			entity.setData(false);
			entity.setSuccess(false);
			entity.setErrMsg("请先登录");
			return entity;
		}
		
		params.put("userId", dto.getUserId().toString());
		params.put("companyId", dto.getCompanyId().toString());
		
		if (req.getGroupId() == null || req.getSourceId() == null) {
			entity.setCode(-3);
			entity.setData(false);
			entity.setSuccess(false);
			entity.setErrMsg("参数异常");
			return entity;
		}
		params.put("groupId", req.getGroupId().toString());
		params.put("sourceId", req.getSourceId().toString());
		
		if(req.getEmailCount() == null){
			params.put("emailCount", "0");
		}else{
			params.put("emailCount", req.getEmailCount().toString());
		}
		
		String result = HttpUtils.postMapToJsonBody(propertiesEntity.getDataUrl()+"/bsApp/favorite/deleteGroupDetailInfo", params);
		JSONObject object = JSONObject.parseObject(result);
		if(object.containsKey("code") && object.getIntValue("code") == 0){
			entity.setData(true);
		}else{
			entity.setCode(-3);
			entity.setData(false);
			entity.setSuccess(false);
			entity.setErrMsg("取消关注失败");
		}		
		return entity;	
	}
	
	/**
	 * 我的关注修改组名
	 * @param req
	 * @return
	 */
	@ApiOperation(value="修改组名", notes="修改组名")
	@ApiImplicitParam(name = "req", value = "修改组名请求对象", required = true, dataType = "BusinessFavoriteGroupReq")
	@PostMapping("updateGroupName")
	@NeedLogin
	public BaseResponseEntity<Boolean> updateGroupName(HttpServletRequest request, @RequestBody BusinessFavoriteGroupReq req) throws IOException{
		BaseResponseEntity<Boolean> entity= new BaseResponseEntity<>(true);
		Map<String,String> params = new HashMap<>();
		
		CheckSuccessDto dto = SessionUtils.getCenterUserDto(request);
		
		if(dto == null){
			entity.setCode(-3);
			entity.setData(false);
			entity.setSuccess(false);
			entity.setErrMsg("请先登录");
			return entity;
		}
		
		params.put("userId", dto.getUserId().toString());
		params.put("companyId", dto.getCompanyId().toString());
		
		if (StringUtils.isBlank(req.getGroupName()) || req.getId() == null) {
			entity.setCode(-3);
			entity.setData(false);
			entity.setSuccess(false);
			entity.setErrMsg("参数异常");
			return entity;
		}
		params.put("id", req.getId().toString());
		params.put("groupName", req.getGroupName());
		
		String result = HttpUtils.postMapToJsonBody(propertiesEntity.getDataUrl()+"/bsApp/favorite/updateGroupName", params);
		JSONObject object = JSONObject.parseObject(result);
		if(object.containsKey("code") && object.getIntValue("code") == 0){
			entity.setData(true);
		}else{
			entity.setCode(-3);
			entity.setData(false);
			entity.setSuccess(false);	
			entity.setErrMsg("修改组名失败");
		}	
		return entity;	
	}
		
		
	/**
	 * 根据组id查询组里的数据
	 * @param req
	 * @return
	 */
	@ApiOperation(value="根据组id查询组里的数据列表", notes="根据组id查询组里的数据列表")
	@ApiImplicitParam(name = "req", value = "根据组id查询组里的数据字典请求对象", required = true, dataType = "BusinessFavoriteGroupDetailReq")
	@PostMapping("selectBusinessDataListGroupId")
	@NeedLogin
	public BaseResponseEntity<List<BusinessData>> selectBusinessDataListGroupId(HttpServletRequest request, @RequestBody BusinessFavoriteGroupDetailReq req) throws IOException{
		BaseResponseEntity<List<BusinessData>> entity = new BaseResponseEntity<>(true);
		Map<String,String> params = new HashMap<>();
		CheckSuccessDto dto = SessionUtils.getCenterUserDto(request);  //用户中心信息
		CompanyDTO company = SessionUtils.getCenterCompanyInfo(request); //公司信息
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		if(dto == null || company == null){
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg("请先登录");
			return entity;
		}
		
		params.put("userId", dto.getUserId().toString());
		params.put("companyId", dto.getCompanyId().toString());
		params.put("dataNotAstrict", company.getDataNotAstrict().toString());
		
		Integer pageNum = 1;
		Integer pageSize = 20;
		
		if(req.getPageNum() != null && req.getPageNum().intValue() > 0){
			pageNum = req.getPageNum();
		}	
		if(req.getPageSize() != null && req.getPageSize().intValue() > 0){
			pageSize = req.getPageSize();
		}
		params.put("pageNum", pageNum.toString());
		params.put("pageSize", pageSize.toString());
		
		if (req.getGroupId() == null) {
			entity.setCode(-3);
			entity.setErrMsg("参数异常");
			return entity;
		}
		params.put("groupId", req.getGroupId().toString());
		
		String result = HttpUtils.postMapToJsonBody(propertiesEntity.getDataUrl()+"/bsApp/favorite/selectBusinessDataListGroupId", params);
		JSONObject object = JSONObject.parseObject(result);
		if(object.containsKey("code") && object.getIntValue("code") == 0){
			if(object.containsKey("data") && object.get("data") != null){
				
				Long max = 0l;
				Integer pageCount = 0;
				
				if(object.containsKey("max") && object.get("max") != null){
					max = object.getLong("max");
				}
				
				if(object.containsKey("pageCount") && object.get("pageCount") != null){
					pageCount = object.getInteger("pageCount");
				}
				
				entity.setTotalRecords(max);
				entity.setTotalPage(pageCount);
				
				List<BusinessData> datas = JSON.parseArray(object.getJSONArray("data").toJSONString(), BusinessData.class);
				datas.forEach(bsData ->{
					//公司名取首字母
					String companyName = bsData.getCompanyName();
					if(companyName.contains(companyNameTag)){
						companyName.replace(companyNameTag, "").replace(companyNameTagEx, "").trim();
					}
					
					Customer customer = customerService.selectCustomerByName(user.getCompanyId(), companyName);
					if(customer != null){
						VerifyCustomerDto c = new VerifyCustomerDto();
						c.setExist(true);
						c.setCustomerId(customer.getId().intValue());
						if(!this.checkHas(user.getSwitchOperatorId(),customer.getOperatorId(), Constants.RESOURCE_CUSTOMER_ID)){
							c.setHasAuth(false);
						}else{
							c.setHasAuth(true);
						}
						bsData.setCustomer(c);
					}
					
					if(StringUtils.isNotBlank(companyName)){
						String companyNameEx = companyName.substring(0, 1);
						bsData.setCompanyNameEx(companyNameEx);
					}
					//竞争对手公司名取首字母
					List<BusinessData> competitorList = bsData.getCompetitorListEx();
					if(competitorList != null && competitorList.size() > 0){
						competitorList.forEach(data ->{
							String dataEx = data.getCompanyName();
							if(dataEx.contains(companyNameTag)){
								dataEx = dataEx.replace(companyNameTag, "").replace(companyNameTagEx, "").trim();
							}
							if(StringUtils.isNotBlank(dataEx)){
								String cNameEx = dataEx.substring(0, 1);
								data.setCompanyNameEx(cNameEx);
							}
						});
					}
					
					//公共邮箱解密
					List<EmailInfo> publicEmailList = bsData.getPublicEmailList();
					if(publicEmailList != null && publicEmailList.size() >0){
						publicEmailList.forEach(data ->{
							String dataEx = data.getEmail();
							String emailEx = AESUtils.decryptStrs(dataEx);
							data.setEmail(emailEx);								
						});
					}
					
					//工作邮箱解密
					List<EmailInfo> personEmailList = bsData.getPersonEmailList();
					if(personEmailList != null && personEmailList.size() >0){
						personEmailList.forEach(data ->{
							String dataEx = data.getEmail();
							String emailEx = AESUtils.decryptStrs(dataEx);
							data.setEmail(emailEx);		
						});
					}
				});
				entity.setData(datas);
			}
		}else{
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg(object.getString("msg"));
		}
		
		return entity;	
	}
	
	/**
	 * 选择联系人发送邮件
	 * @param req
	 * @return
	 */
	@ApiOperation(value="选择联系人发送邮件", notes="选择联系人发送邮件")
	@ApiImplicitParam(name = "req", value = "选择联系人发送邮件请求对象", required = true, dataType = "TemporaryEdmGroupEmailReq")
	@PostMapping("postMailByDomain")
	@NeedLogin
	public BaseResponseEntity<String> postMailByDomain(HttpServletRequest request, @RequestBody TemporaryEdmGroupEmailReq req) throws HostDoneException{
		BaseResponseEntity<String> entity= new BaseResponseEntity<>(true);
		JSONObject paramObj = new JSONObject();
		
		if (req.getEmailList() == null || req.getEmailList().size() <= 0) {
			entity.setCode(-3);
			entity.setData("没有可发送的邮箱");
			entity.setSuccess(false);
			entity.setErrMsg("没有可发送的邮箱");
			return entity;
		}
		
		CheckSuccessDto dto = SessionUtils.getCenterUserDto(request);
		Operator operator = SessionUtils.getOperatorInfo(request);
		
		if(dto == null || operator == null){
			entity.setCode(-3);
			entity.setData("请先登录");
			entity.setSuccess(false);
			entity.setErrMsg("请先登录");
			return entity;
		}
		
		paramObj.put("userId", dto.getUserId());
		paramObj.put("companyId", dto.getCompanyId());
		paramObj.put("notCenterCompanyId", operator.getCompanyId());
		paramObj.put("operatorId", operator.getId());
		paramObj.put("emailList", JSONArray.toJSON(req.getEmailList()));
		
		if (StringUtils.isBlank(req.getCompanyName()) || StringUtils.isBlank(req.getSourceId()) ) {
			entity.setCode(-3);
			entity.setData("参数异常");
			entity.setSuccess(false);
			entity.setErrMsg("参数异常");
			return entity;
		}
		
		paramObj.put("companyName", req.getCompanyName());
		paramObj.put("sourceId", req.getSourceId());
		
		String result = HttpUtils.httpPost(propertiesEntity.getDataUrl()+"/bsApp/email/temporaryPostMail", paramObj);
		JSONObject object = JSONObject.parseObject(result);
		if(object.containsKey("code") && object.getIntValue("code") == 0){
			entity.setData("发送成功");
		}else{
			entity.setCode(-3);	
			entity.setData("发送失败");
			entity.setSuccess(false);
			entity.setErrMsg("发送失败");
		}
	
		return entity;	
	}

	/**
	 * 查询定制推荐列表
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询定制推荐列表", notes="查询定制推荐列表")
	@ApiImplicitParam(name = "req", value = "查询定制推荐字典请求对象", required = true, dataType = "BusinessDataSearchReq")
	@PostMapping("selectMyDataList")
	@NeedLogin
	public BaseResponseEntity<List<BusinessData>> selectMyDataList(HttpServletRequest request, @RequestBody BusinessDataSearchReq req) throws HostDoneException{
		BaseResponseEntity<List<BusinessData>> entity = new BaseResponseEntity<>(true);
		JSONObject paramObj = new JSONObject();
		
		CheckSuccessDto dto = SessionUtils.getCenterUserDto(request);
		CompanyDTO company = SessionUtils.getCenterCompanyInfo(request);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		if(dto == null || company == null){
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg("请先登录");
			return entity;
		}
		
		if(req.getEmailFlag() != null && req.getEmailFlag().intValue() != -1){
			paramObj.put("emailFlag", req.getEmailFlag());
		}
		if(req.getIndustries() != null && req.getIndustries().size() >0){
			paramObj.put("industries", JSONArray.toJSON(req.getIndustries()));
		}
		if(req.getCountries() != null && req.getCountries().size() >0){
			paramObj.put("countries", JSONArray.toJSON(req.getCountries()));
		}
		paramObj.put("userId", dto.getUserId());
		paramObj.put("companyId", dto.getCompanyId());
		paramObj.put("dataNotAstrict", company.getDataNotAstrict());
		
		if(req.getSearchType() != null){
			paramObj.put("searchType", req.getSearchType());
		}
		if(req.getUrlFlag() != null && req.getUrlFlag().intValue() != -1){
			paramObj.put("urlFlag", req.getUrlFlag());
		}
		if(req.getKeywords() != null && StringUtils.isNotBlank(req.getKeywords())){
			paramObj.put("keywords", req.getKeywords());
		}
		//非自动即手动
		paramObj.put("noAuto", false);
		//全匹配
		paramObj.put("fullMatch", req.getFullMatch());
		
		Integer pageNum = 1;
		Integer pageSize = 20;
		
		if(req.getPageNum() != null && req.getPageNum().intValue() > 0){
			pageNum = req.getPageNum();
		}
		
		if(req.getPageSize() != null && req.getPageSize().intValue() > 0){
			pageSize = req.getPageSize();
		}
		
		paramObj.put("pageNum", pageNum);
		paramObj.put("pageSize", pageSize);
		
		String result = HttpUtils.httpPost(propertiesEntity.getDataUrl()+"/bsApp/selectMyDataList", paramObj);
		JSONObject object = JSONObject.parseObject(result);
		if(object.containsKey("code") && "0".equals(object.getString("code"))){
			Long max = 0l;
			Integer pageCount = 0;
			
			if(object.containsKey("max") && object.get("max") != null){
				max = object.getLong("max");
			}
			
			if(object.containsKey("pageCount") && object.get("pageCount") != null){
				pageCount = object.getInteger("pageCount");
			}
			
			entity.setTotalRecords(max);
			entity.setTotalPage(pageCount);
			
			if(object.containsKey("data") && object.get("data") != null){
				List<BusinessData> datas = JSON.parseArray(object.getJSONArray("data").toJSONString(), BusinessData.class);
				datas.forEach(bsData ->{
					//公司名取首字母
					String companyName = bsData.getCompanyName();
					if(companyName.contains(companyNameTag)){
						companyName.replace(companyNameTag, "").replace(companyNameTagEx, "").trim();
					}
					
					Customer customer = customerService.selectCustomerByName(user.getCompanyId(), companyName);
					if(customer != null){
						VerifyCustomerDto c = new VerifyCustomerDto();
						c.setExist(true);
						c.setCustomerId(customer.getId().intValue());
						if(!this.checkHas(user.getSwitchOperatorId(),customer.getOperatorId(), Constants.RESOURCE_CUSTOMER_ID)){
							c.setHasAuth(false);
						}else{
							c.setHasAuth(true);
						}
						bsData.setCustomer(c);
					}
					
					if(StringUtils.isNotBlank(companyName)){
						String companyNameEx = companyName.substring(0, 1);
						bsData.setCompanyNameEx(companyNameEx);
					}
					//竞争对手公司名取首字母
					List<BusinessData> competitorList = bsData.getCompetitorListEx();
					if(competitorList != null && competitorList.size() > 0){
						competitorList.forEach(data ->{
							String dataEx = data.getCompanyName();
							if(dataEx.contains(companyNameTag)){
								dataEx = dataEx.replace(companyNameTag, "").replace(companyNameTagEx, "").trim();
							}
							if(StringUtils.isNotBlank(dataEx)){
								String cNameEx = dataEx.substring(0, 1);
								data.setCompanyNameEx(cNameEx);
							}
						});
					}
					
					//公共邮箱解密
					List<EmailInfo> publicEmailList = bsData.getPublicEmailList();
					if(publicEmailList != null && publicEmailList.size() >0){
						publicEmailList.forEach(data ->{
							String dataEx = data.getEmail();
							String emailEx = AESUtils.decryptStrs(dataEx);
							data.setEmail(emailEx);								
						});
					}
					
					//工作邮箱解密
					List<EmailInfo> personEmailList = bsData.getPersonEmailList();
					if(personEmailList != null && personEmailList.size() >0){
						personEmailList.forEach(data ->{
							String dataEx = data.getEmail();
							String emailEx = AESUtils.decryptStrs(dataEx);
							data.setEmail(emailEx);		
						});
					}
				});
				entity.setData(datas);
			}
		}else{
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg(object.getString("msg"));
		}
		return entity;	
	}
	
	
	/**
	 * 查询已解密公司列表
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询已解密公司列表", notes="查询已解密公司列表")
	@PostMapping("selectDecryptBusinessDataList")
	@NeedLogin
	public BaseResponseEntity<List<BusinessData>> selectDecryptBusinessDataList(HttpServletRequest request, @RequestBody CompanySearchReq req) throws HostDoneException{
		BaseResponseEntity<List<BusinessData>> entity = new BaseResponseEntity<>(true);
		JSONObject paramObj = new JSONObject();
		
		CheckSuccessDto dto = SessionUtils.getCenterUserDto(request);
		CompanyDTO company = SessionUtils.getCenterCompanyInfo(request);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		if(dto == null || company == null){
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg("请先登录");
			return entity;
		}
		
		if(req.getIndustries() != null && req.getIndustries().size() >0){
			paramObj.put("industries", JSONArray.toJSON(req.getIndustries()));
		}
		if(req.getCountries() != null && StringUtils.isNotBlank(req.getCountries())){
			paramObj.put("countries", req.getCountries());
		}
		paramObj.put("userId", dto.getUserId());
		paramObj.put("companyId", dto.getCompanyId());
		paramObj.put("dataNotAstrict", company.getDataNotAstrict());
		
		//根據公司名称搜索
		if(req.getCompanyName() != null && StringUtils.isNotBlank(req.getCompanyName())){
			paramObj.put("companyName", req.getCompanyName());
		}
		if(req.getKeywords() != null && StringUtils.isNotBlank(req.getKeywords())){
			paramObj.put("keywords", req.getKeywords());
		}

		Integer pageNum = 1;
		Integer pageSize = 20;
		
		if(req.getPageNum() != null && req.getPageNum().intValue() > 0){
			pageNum = req.getPageNum();
		}
		
		if(req.getPageSize() != null && req.getPageSize().intValue() > 0){
			pageSize = req.getPageSize();
		}
		
		paramObj.put("pageNum", pageNum);
		paramObj.put("pageSize", pageSize);
		
		String result = HttpUtils.httpPost(propertiesEntity.getDataUrl()+"/bsApp/decrypt/selectBusinessDataListByIds", paramObj);
		JSONObject object = JSONObject.parseObject(result);
		if(object.containsKey("code") && "0".equals(object.getString("code"))){
			
			Long max = 0l;
			Integer pageCount = 0;
			
			if(object.containsKey("max") && object.get("max") != null){
				max = object.getLong("max");
			}
			
			if(object.containsKey("pageCount") && object.get("pageCount") != null){
				pageCount = object.getInteger("pageCount");
			}
			
			entity.setTotalRecords(max);
			entity.setTotalPage(pageCount);
			
			if(object.containsKey("data") && object.get("data") != null){
				List<BusinessData> datas = JSON.parseArray(object.getJSONArray("data").toJSONString(), BusinessData.class);
				datas.forEach(bsData ->{
					//公司名取首字母
					String companyName = bsData.getCompanyName();
					if(companyName.contains(companyNameTag)){
						companyName.replace(companyNameTag, "").replace(companyNameTagEx, "").trim();
					}
					Customer customer = customerService.selectCustomerByName(user.getCompanyId(), companyName);
					if(customer != null){
						VerifyCustomerDto c = new VerifyCustomerDto();
						c.setExist(true);
						c.setCustomerId(customer.getId().intValue());
						if(!this.checkHas(user.getSwitchOperatorId(),customer.getOperatorId(), Constants.RESOURCE_CUSTOMER_ID)){
							c.setHasAuth(false);
						}else{
							c.setHasAuth(true);
						}
						bsData.setCustomer(c);
					}
					
					if(StringUtils.isNotBlank(companyName)){
						String companyNameEx = companyName.substring(0, 1);
						bsData.setCompanyNameEx(companyNameEx);
					}
					//竞争对手公司名取首字母
					List<BusinessData> competitorList = bsData.getCompetitorListEx();
					if(competitorList != null && competitorList.size() > 0){
						competitorList.forEach(data ->{
							String dataEx = data.getCompanyName();
							if(dataEx.contains(companyNameTag)){
								dataEx = dataEx.replace(companyNameTag, "").replace(companyNameTagEx, "").trim();
							}
							if(StringUtils.isNotBlank(dataEx)){
								String cNameEx = dataEx.substring(0, 1);
								data.setCompanyNameEx(cNameEx);
							}
						});
					}
					
					//公共邮箱解密
					List<EmailInfo> publicEmailList = bsData.getPublicEmailList();
					if(publicEmailList != null && publicEmailList.size() >0){
						publicEmailList.forEach(data ->{
							String dataEx = data.getEmail();
							String emailEx = AESUtils.decryptStrs(dataEx);
							data.setEmail(emailEx);								
						});
					}
					
					//工作邮箱解密
					List<EmailInfo> personEmailList = bsData.getPersonEmailList();
					if(personEmailList != null && personEmailList.size() >0){
						personEmailList.forEach(data ->{
							String dataEx = data.getEmail();
							String emailEx = AESUtils.decryptStrs(dataEx);
							data.setEmail(emailEx);		
						});
					}
				});
				entity.setData(datas);
			}
		}else{
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg(object.getString("msg"));
		}
		return entity;	
	}

	/**
	 * 查询社交账号列表
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询社交账号列表", notes="查询社交账号列表")
	@ApiImplicitParam(name = "req", value = "查询社交账号列表请求对象", required = true, dataType = "CompanySearchReq")
	@PostMapping("selectSnsByBvdId")
	@NeedLogin
	public BaseResponseEntity<List<BusinessDataSnsDto>> selectSnsByBvdId(HttpServletRequest request, @RequestBody CompanySearchReq req) throws HostDoneException{
		BaseResponseEntity<List<BusinessDataSnsDto>> entity = new BaseResponseEntity<>(true);
		JSONObject paramObj = new JSONObject();
		
		CheckSuccessDto dto = SessionUtils.getCenterUserDto(request);
		
		if(dto == null){
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg("请先登录");
			return entity;
		}
	
		if (StringUtils.isBlank(req.getId())) {
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg("参数异常");
			return entity;
		}
		
		if(req.getId() != null && StringUtils.isNotBlank(req.getId())){
			paramObj.put("id", req.getId());
		}
		if(req.getDuns() != null && StringUtils.isNotBlank(req.getDuns())){
			paramObj.put("duns", req.getDuns());
		}
		paramObj.put("userId", dto.getUserId());
		paramObj.put("companyId", dto.getCompanyId());
	
		String result = HttpUtils.httpPost(propertiesEntity.getDataUrl()+"/bsApp/search/selectSnsByBvdId", paramObj);
		JSONObject object = JSONObject.parseObject(result);
		if(object.containsKey("code") && "0".equals(object.getString("code"))){
			if(object.containsKey("data") && object.get("data") != null){
				List<BusinessDataSnsDto> datas = JSON.parseArray(object.getJSONArray("data").toJSONString(), BusinessDataSnsDto.class);
				entity.setData(datas);
			}	
		}else{
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg(object.getString("msg"));
		}
		return entity;	
	}
	

	/**
	 * 批量解密
	 * @param req
	 * @return
	 */
	@ApiOperation(value="批量解密", notes="批量解密")
	@ApiImplicitParam(name = "req", value = "批量解密请求对象", required = true, dataType = "CompanySearchReq")
	@PostMapping("decryptBusinessByIds")
	@NeedLogin
	public BaseResponseEntity<Boolean> decryptBusinessByIds(HttpServletRequest request, @RequestBody CompanySearchReq req) throws HostDoneException{
		BaseResponseEntity<Boolean> entity= new BaseResponseEntity<>(true);
		JSONObject paramObj = new JSONObject();
		
		CheckSuccessDto dto = SessionUtils.getCenterUserDto(request);
		CompanyDTO company = SessionUtils.getCenterCompanyInfo(request);
		
		if(dto == null || company == null){
			entity.setCode(-3);
			entity.setData(false);
			entity.setSuccess(false);
			entity.setErrMsg("请先登录");
			return entity;
		}
		
		paramObj.put("userId", dto.getUserId());
		paramObj.put("companyId", dto.getCompanyId());
		paramObj.put("dataNotAstrict", company.getDataNotAstrict());
		
		if (req.getIds() == null || req.getIds().size() == 0) {
			entity.setCode(-3);
			entity.setData(false);
			entity.setSuccess(false);
			entity.setErrMsg("参数异常");
			return entity;
		}
		paramObj.put("ids", JSONArray.toJSON(req.getIds()));
	
		String result = HttpUtils.httpPost(propertiesEntity.getDataUrl()+"/bsApp/decrypt/decryptBusinessByIds", paramObj);
		JSONObject object = JSONObject.parseObject(result);
		if(object.containsKey("code") && object.getIntValue("code") == 0){
			entity.setData(true);
		}else{
			entity.setCode(-3);
			entity.setData(false);
			entity.setSuccess(false);
			entity.setErrMsg("商业数据额度不足，请及时充值");
		}	
		return entity;	
	}
	
	
	/**
	 * 批量取消关注
	 * @param req
	 * @return
	 */
	@ApiOperation(value="批量取消关注", notes="批量取消关注")
	@ApiImplicitParam(name = "req", value = "批量取消关注请求对象", required = true, dataType = "BusinessFavoriteGroupDetailReq")
	@PostMapping("deleteGroupDetailInfoBySourceIds")
	@NeedLogin
	public BaseResponseEntity<Boolean> deleteGroupDetailInfoBySourceIds(HttpServletRequest request, @RequestBody BusinessFavoriteGroupDetailReq req) throws HostDoneException{
		BaseResponseEntity<Boolean> entity= new BaseResponseEntity<>(true);
		JSONObject paramObj = new JSONObject();
		
		CheckSuccessDto dto = SessionUtils.getCenterUserDto(request);
		CompanyDTO company = SessionUtils.getCenterCompanyInfo(request);
		
		if(dto == null || company == null){
			entity.setCode(-3);
			entity.setData(false);
			entity.setSuccess(false);
			entity.setErrMsg("请先登录");
			return entity;
		}
		
		paramObj.put("userId", dto.getUserId());
		paramObj.put("companyId", dto.getCompanyId());
		paramObj.put("dataNotAstrict", company.getDataNotAstrict());
		
		if (req.getGroupId() == null ||req.getSourceIds() == null || req.getSourceIds().size() == 0) {
			entity.setCode(-3);
			entity.setData(false);
			entity.setSuccess(false);
			entity.setErrMsg("参数异常");
			return entity;
		}
		paramObj.put("groupId", req.getGroupId());
		paramObj.put("sourceIds", JSONArray.toJSON(req.getSourceIds()));
		paramObj.put("emailCount", req.getEmailCount().toString());
	
		String result = HttpUtils.httpPost(propertiesEntity.getDataUrl()+"/bsApp/favorite/deleteGroupDetailInfoBySourceIds", paramObj);
		JSONObject object = JSONObject.parseObject(result);
		if(object.containsKey("code") && object.getIntValue("code") == 0){
			entity.setData(true);
		}else{
			entity.setCode(-3);
			entity.setData(false);
			entity.setSuccess(false);
			entity.setErrMsg("批量取消关注失败");
		}	
		return entity;	
	}
	
	
	/**
	 * 对外部提供企业数据
	 * @author cuichuanlei
	 * @date 2019年2月17日 下午5:09:13
	 */
	@RequestMapping("/getAgentJoinfInfo")
	public String getAgentJoinfInfo(String address) {

		Map<String, String> params = new HashMap<String, String>();
		params.put("address", address);
		params.put("key", "AIzaSyBHK3cG2537kjyMmxaNvBeoB2-jZgQTgZo");
		String json = HttpUtils.invokeGet(propertiesEntity.getAgentJoinfUrl(), null, params);
		JSONObject obj = null;
		if (StringUtils.isNotBlank(json)) {
			obj = JSONObject.parseObject(json);
			obj.put("code", 0);
		}
		if (obj == null) {
			return null;
		}
		return JSONObject.toJSONString(obj);
	}

	
	/** 更新经纬度 */
	@RequestMapping("/updateBasicInfoLatAndLon")
	public String updateBasicInfoLatAndLon(@RequestBody CompanySearchReq searchReq, HttpServletRequest request) {
		
		if (StringUtils.isEmpty(searchReq.getId()) || StringUtils.isEmpty(searchReq.getLatitude()) || StringUtils.isEmpty(searchReq.getLongitude()))
		return "缺少参数";
		Map<String, String> header = new HashMap<String, String>();
		header.put("Content-Type", "application/json;charset=UTF-8");
		Map<String, String> map = new HashMap<String, String>();
		DecimalFormat df = new DecimalFormat("#.000000");
		// 公司id
		map.put("id", searchReq.getId());
		// 纬度
		map.put("latitude", df.format(Double.valueOf(searchReq.getLatitude().trim())));
		// 经度
		map.put("longitude", df.format(Double.valueOf(searchReq.getLongitude().trim())));

		String json = HttpUtils.connectPostHttps(propertiesEntity.getUpdateLocationUrl(), header, map);
		return json;
	}
	


}
