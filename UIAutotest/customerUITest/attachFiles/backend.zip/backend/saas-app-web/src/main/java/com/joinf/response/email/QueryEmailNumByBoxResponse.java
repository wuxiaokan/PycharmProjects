package com.joinf.response.email;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;


/**
 * Description: 邮件查询返回列表
 *
 * @author zlx
 * @date 2018年1月4日 下午5:42:34
 */
public class QueryEmailNumByBoxResponse implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2105085247053982301L;
	
	public QueryEmailNumByBoxResponse(){}
	
	public QueryEmailNumByBoxResponse(Long boxId,int num){
		this.boxId = boxId;
		this.num = num;
	}
	
	@ApiModelProperty(value = "箱子id 详见箱子枚举")
    private Long boxId;
	@ApiModelProperty(value = "数量")
    private int num;
	
	public Long getBoxId() {
		return boxId;
	}
	public int getNum() {
		return num;
	}
	public void setBoxId(Long boxId) {
		this.boxId = boxId;
	}
	public void setNum(int num) {
		this.num = num;
	}
	
	
}
