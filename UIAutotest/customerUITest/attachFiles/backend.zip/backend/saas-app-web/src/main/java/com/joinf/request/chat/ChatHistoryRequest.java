package com.joinf.request.chat;

import com.joinf.utils.base.BasePage;

import io.swagger.annotations.ApiModelProperty;

public class ChatHistoryRequest extends BasePage{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3078531074538066458L;
	
	@ApiModelProperty("关键词")
	private String key;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}
	

}
