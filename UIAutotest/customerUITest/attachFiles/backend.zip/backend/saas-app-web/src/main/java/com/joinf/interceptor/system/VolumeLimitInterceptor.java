package com.joinf.interceptor.system;

import java.lang.reflect.Method;
import java.lang.reflect.Type;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONObject;
import com.joinf.dto.CompanyDTO;
import com.joinf.exception.CommonException;
import com.joinf.interceptor.login.MultiReadHttpServletRequestWrapper;
import com.joinf.interfaces.UserCenterService;
import com.joinf.request.InsertOrUpdateAttachRequest;
import com.joinf.request.InsertOrUpdateRequest;
import com.joinf.response.UserCenterResponse;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.annotations.VolumeLimit;

/**
 * @author zlx
 * @Description: 容量限制拦截器
 * @date 2018年3月2日 下午2:29:52
 */
public class VolumeLimitInterceptor implements HandlerInterceptor {
	@Autowired
	private UserCenterService userCenterService;
	
	/**
	 * 实现方法
	 */
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		if (handler instanceof HandlerMethod) {
			HandlerMethod handlerMethod = (HandlerMethod) handler;
			Method method = handlerMethod.getMethod();
			VolumeLimit annotation = method.getAnnotation(VolumeLimit.class);

			if (annotation != null) {
				Type[] types = method.getGenericParameterTypes();
				for(Type type:types){
					if(type.getTypeName().equals(InsertOrUpdateRequest.class.getName())){//类似客户新增和修改是同一个方法，如果是修改则不做容量判断
						MultiReadHttpServletRequestWrapper myRequestWrapper = new MultiReadHttpServletRequestWrapper((HttpServletRequest) request);
						InsertOrUpdateRequest dto = new InsertOrUpdateRequest();
						dto =JSONObject.toJavaObject(JSONObject.parseObject(myRequestWrapper.getBody()), InsertOrUpdateRequest.class);
						if(dto.getId() != null){//编辑
							return true;
						}
					}
					if(type.getTypeName().equals(InsertOrUpdateAttachRequest.class.getName())){//类似客户新增和修改是同一个方法，如果是修改则不做容量判断
						MultiReadHttpServletRequestWrapper myRequestWrapper = new MultiReadHttpServletRequestWrapper((HttpServletRequest) request);
						InsertOrUpdateAttachRequest dto = new InsertOrUpdateAttachRequest();
						dto =JSONObject.toJavaObject(JSONObject.parseObject(myRequestWrapper.getBody()), InsertOrUpdateAttachRequest.class);
						if(dto.getId() != null){//编辑
							return true;
						}
					}
				}
				CompanyDTO companyDTO = SessionUtils.getCenterCompanyInfo(request);
				UserCenterResponse<?> httpResponse = userCenterService.volumeValidate(companyDTO.getCompanyId());
				if (!httpResponse.isSuccess()) //判断资源容量
					throw new CommonException("您的系统空间已满，如需增加容量，请进行购买。");
				else
					return true;
			}
			return true;
		}
		return true;
	}

	/**
	 * 实现方法
	 */
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub
	}

	/**
	 * 实现方法
	 */
	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub
	}

	

}
