package com.joinf.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.joinf.annotations.NeedLogin;
import com.joinf.dto.CompanyAndOperatorIdDto;
import com.joinf.entity.SessionUser;
import com.joinf.entity.generator.EmailSignature;
import com.joinf.request.email.QuerySignatureRequest;
import com.joinf.response.email.EmailSignatureResponse;
import com.joinf.response.email.EmailSignatureSimpleResponse;
import com.joinf.service.email.EmailSignatureManagerImpl;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.util.JoinfBeanUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * @author zlx
 * @Description: 邮件签名服务
 * @date 2018年1月16日 上午10:34:37
 */
@RestController
@RequestMapping("email")
@Api(tags="邮件签名服务")
public class EmailSignatureController {
	@Autowired
	private EmailSignatureManagerImpl emailSignatureManager;
	
	/**
	 * 查询签名列表
	 * @return
	 */
	@ApiOperation(value="查询签名列表", notes="查询签名列表")
	@PostMapping("querySignatureList")
	@NeedLogin
	public BaseResponseEntity<List<EmailSignatureResponse>> querySignatureList(HttpServletRequest request){
		BaseResponseEntity<List<EmailSignatureResponse>> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		CompanyAndOperatorIdDto queryDto = new CompanyAndOperatorIdDto();
		queryDto.setCompanyId(user.getCompanyId());
		queryDto.setOperatorId(user.getSwitchOperatorId());
		
		List<EmailSignature> signatureList = emailSignatureManager.querySignatureByCondition(queryDto);
		
		List<EmailSignatureResponse> resultList = JoinfBeanUtils.copyToNewListBean(EmailSignatureResponse.class, signatureList);
		entity.setData(resultList);
		
		return entity;
	}
	
	/**
	 * 查询签名正文
	 * @return
	 */
	@ApiOperation(value="查询签名正文", notes="查询签名正文")
	@PostMapping("querySignatureContent")
	@NeedLogin
	public BaseResponseEntity<String> querySignatureContent(HttpServletRequest request,@ApiParam("签名存储的key") @RequestBody String url){
		BaseResponseEntity<String> entity = new BaseResponseEntity<>(true);
		
		String content = emailSignatureManager.querySignatureContent(url);
		
		entity.setData(content);
		
		return entity;
	}
	
	/**
     * 根据邮件账户id获取签名内容
     * @param senders
     * @param request
     * @return
     */
    @PostMapping("/querySignatureContentBySenders")
    @ApiImplicitParam(name = "req", value = "查询签名请求对象", required = true, dataType = "QuerySignatureRequest")
    @ResponseBody
    @NeedLogin
    public BaseResponseEntity<EmailSignatureSimpleResponse> querySignatureContentBySenders(@RequestBody QuerySignatureRequest  req,HttpServletRequest request) {
        
    	BaseResponseEntity<EmailSignatureSimpleResponse> entity = new BaseResponseEntity<>(true);
    	
    	SessionUser user = SessionUtils.getCurrentUserInfo(request);
    	
    	EmailSignature emailSignature = this.emailSignatureManager.querySignatureContentBySenders(user.getCompanyId(), req.getType(), req.getSenders());
    	
    	entity.setData(emailSignature!=null?JoinfBeanUtils.copyToNewBean(EmailSignatureSimpleResponse.class, emailSignature):null);
        
        return entity;
    }
	
	
	
}
