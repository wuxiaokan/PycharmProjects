package com.joinf.response.help;

import io.swagger.annotations.ApiModelProperty;

public class HelpVideo {

	@ApiModelProperty("id")
	private Long id;
	
	@ApiModelProperty("名称")
	private String name;
	
	@ApiModelProperty("文件名称")
	private String fileName;
	
	@ApiModelProperty("文件后缀")
	private String suffix;
	
	@ApiModelProperty("文件路径")
	private String url;
	
	@ApiModelProperty("文件大小")
	private Long size;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getSuffix() {
		return suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Long getSize() {
		return size;
	}

	public void setSize(Long size) {
		this.size = size;
	}
	
}
