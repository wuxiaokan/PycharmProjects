package com.joinf.request.email;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 查询箱子
 *
 * @author lyj
 * @date 2018年8月17日 下午5:24:37
 */
public class QueryEmailBoxRequest {
	
	
	@ApiModelProperty("0：自定义信箱 1：查询箱")
	private Integer type = 0;

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

}
