package com.joinf.request.businessData;

import java.io.Serializable;
import java.util.List;

/**
 * Description: 商业数据列表查询请求参数
 * @author cuichuanlei
 * @created 2019年1月11日 下午5:36:57
 */
public class BusinessDataSearchReq implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String keywords;// 关键词
	private String domain;
	private List<String> countries;// 国家多选(英文)
	private String countryCodes;
	private List<String> industries;// sic多选（code）
	private Integer employeesFrom;
	private Integer employeesTo;
	private String loginId;
	private int requestCount = 1;
	private boolean sendMessage = true;
	private Integer emailFlag = -1;// 0,no,1,有邮箱
	private Integer urlFlag = -1;// 0,no,1,有网址
	private Integer fullMatch=0;//0,完全匹配,1部分匹配
	/**是否只统计*/
	private boolean onlyCount;
	/**第几页*/
	private Integer pageNum;
	/**每页多少条*/
	private Integer pageSize;	
	/**非自动即手动*/
	private Boolean noAuto;
	/**登录的userId*/
	private Integer loginUserId;
	private Integer searchType=0;//0公司名称,1产品名称 2域名
	
	/**用户中心公司ID*/
	private Long companyId;
	/** 用户中心用户ID */
	private Long userId;
	/** 商业数据是否限制， 不能给默认值，修改企业信息也是使用此Dto，会导致与接口提供方的签名不一致*/
	private Boolean dataNotAstrict = false;
	
	public String getKeywords() {
		return keywords;
	}
	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public List<String> getCountries() {
		return countries;
	}
	public void setCountries(List<String> countries) {
		this.countries = countries;
	}
	public String getCountryCodes() {
		return countryCodes;
	}
	public void setCountryCodes(String countryCodes) {
		this.countryCodes = countryCodes;
	}
	public List<String> getIndustries() {
		return industries;
	}
	public void setIndustries(List<String> industries) {
		this.industries = industries;
	}
	public Integer getEmployeesFrom() {
		return employeesFrom;
	}
	public void setEmployeesFrom(Integer employeesFrom) {
		this.employeesFrom = employeesFrom;
	}
	public Integer getEmployeesTo() {
		return employeesTo;
	}
	public void setEmployeesTo(Integer employeesTo) {
		this.employeesTo = employeesTo;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public int getRequestCount() {
		return requestCount;
	}
	public void setRequestCount(int requestCount) {
		this.requestCount = requestCount;
	}
	public boolean isSendMessage() {
		return sendMessage;
	}
	public void setSendMessage(boolean sendMessage) {
		this.sendMessage = sendMessage;
	}
	public Integer getEmailFlag() {
		return emailFlag;
	}
	public void setEmailFlag(Integer emailFlag) {
		this.emailFlag = emailFlag;
	}
	public Integer getUrlFlag() {
		return urlFlag;
	}
	public void setUrlFlag(Integer urlFlag) {
		this.urlFlag = urlFlag;
	}
	public Integer getFullMatch() {
		return fullMatch;
	}
	public void setFullMatch(Integer fullMatch) {
		this.fullMatch = fullMatch;
	}
	public boolean isOnlyCount() {
		return onlyCount;
	}
	public void setOnlyCount(boolean onlyCount) {
		this.onlyCount = onlyCount;
	}
	public Integer getPageNum() {
		return pageNum;
	}
	public void setPageNum(Integer pageNum) {
		this.pageNum = pageNum;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	public Boolean isNoAuto() {
		return noAuto;
	}
	public void setNoAuto(Boolean noAuto) {
		this.noAuto = noAuto;
	}
	public Integer getLoginUserId() {
		return loginUserId;
	}
	public void setLoginUserId(Integer loginUserId) {
		this.loginUserId = loginUserId;
	}
	public Integer getSearchType() {
		return searchType;
	}
	public void setSearchType(Integer searchType) {
		this.searchType = searchType;
	}
	public Long getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Boolean getDataNotAstrict() {
		return dataNotAstrict;
	}
	public void setDataNotAstrict(Boolean dataNotAstrict) {
		this.dataNotAstrict = dataNotAstrict;
	}

}
