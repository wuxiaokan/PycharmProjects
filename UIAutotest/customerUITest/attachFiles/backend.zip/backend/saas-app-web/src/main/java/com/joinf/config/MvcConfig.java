package com.joinf.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * Description: 跨域请求
 *
 * @author lyj
 * @date 2017年12月6日 上午10:17:21
 */
@Configuration
public class MvcConfig extends WebMvcConfigurerAdapter {
	
	/**
	 * Description:跨域设置
	 *
	 * @author lyj
	 * @date 2017年12月19日 下午5:56:37
	 */
	@Override  
    public void addCorsMappings(CorsRegistry registry) {  
        registry.addMapping("/**")  
                .allowedOrigins("*")  
                .allowCredentials(true)  
                .allowedMethods("GET", "POST", "DELETE", "PUT","OPTION","OPTIONS")  
                .maxAge(3600);  
    }  
	
	  /** 
     * 拦截器配置 
     * @param registry 
     */  
    /*@Override  
    public void addInterceptors(InterceptorRegistry registry) {  
        // 注册监控拦截器  
        registry.addInterceptor(loginInterceptor)  
                .addPathPatterns("/**") ;
        // .excludePathPatterns("/configuration/ui");  
    }*/
	
/*	@Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
    	//指定静态文件的路径
        registry.addResourceHandler("/static/**").addResourceLocations("classpath:/static/");
    }*/
}
