package com.joinf.config.datasource;

import java.util.Collection;
import java.util.LinkedHashSet;

import org.apache.commons.lang3.StringUtils;

import com.dangdang.ddframe.rdb.sharding.api.ShardingValue;
import com.dangdang.ddframe.rdb.sharding.api.strategy.table.SingleKeyTableShardingAlgorithm;
import com.google.common.collect.Range;

/**
 * 分表逻辑
 * @author zlx
 *
 */
public class TableShardingAlgorithm implements SingleKeyTableShardingAlgorithm<Long> {

    /**
     * sql between 规则(目前业务中未涉及跨企业查询数据)
     * select * from t_email where company_id between 10 and 20
     * 		--SELECT * FROM t_email_1 WHERE company_id BETWEEN 10 AND 20
     */
    public Collection<String> doBetweenSharding(Collection<String> tableNames, ShardingValue<Long> shardingValue) {
        Collection<String> result = new LinkedHashSet<String>(tableNames.size());
        Range<Long> range = (Range<Long>) shardingValue.getValueRange();
        for (long i = range.lowerEndpoint(); i <= range.upperEndpoint(); i++) {
            Long modValue = TableShardingRule.getTableIndex(i, shardingValue.getLogicTableName());
            //分表规则匹配上的表
            String table = StringUtils.join(shardingValue.getLogicTableName(), "_", modValue.toString());
            for (String each : tableNames) {
            	if (StringUtils.equals(each, table)) {
                    result.add(each);
                }
            }
        }
        return result;
    }

    /**
     * sql == 规则
     * select * from t_email where company_id = 131
     * 		--SELECT * FROM t_email_1 WHERE company_id = 131
     */
    public String doEqualSharding(Collection<String> tableNames, ShardingValue<Long> shardingValue) {
        Long modValue = TableShardingRule.getTableIndex(Long.valueOf(String.valueOf(shardingValue.getValue())), shardingValue.getLogicTableName());
        //分表规则匹配上的表
        String table = StringUtils.join(shardingValue.getLogicTableName(), "_", modValue.toString());
        for (String each : tableNames) {
        	if (StringUtils.equals(each, table)) {
                return each;
            }
        }
        throw new IllegalArgumentException();
    }

    /**
     * sql in 规则(目前业务中未涉及跨企业查询数据)
     * select * from t_email where company_id in(131,132)
     * 		--SELECT * FROM t_email_1 WHERE company_id in(131,132)
     * 		--SELECT * FROM t_email_2 WHERE company_id in(131,132)
     */
    public Collection<String> doInSharding(Collection<String> tableNames, ShardingValue<Long> shardingValue) {

        Collection<String> result = new LinkedHashSet<String>(tableNames.size());
        for (Object value : shardingValue.getValues()) {
            Long modValue = TableShardingRule.getTableIndex(Long.valueOf(String.valueOf(value)), shardingValue.getLogicTableName());
            //分表规则匹配上的表
            String table = StringUtils.join(shardingValue.getLogicTableName(), "_", modValue.toString());
            for (String tableName : tableNames) {
            	if (StringUtils.equals(tableName, table)) {
                    result.add(tableName);
                }
            }
        }
        return result;
    }
    
}