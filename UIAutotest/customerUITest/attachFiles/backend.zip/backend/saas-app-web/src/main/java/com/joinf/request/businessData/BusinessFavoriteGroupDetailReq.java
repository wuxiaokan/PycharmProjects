package com.joinf.request.businessData;

import java.util.List;

/**
 * Description: 商业数据我的关注对应的组里的数据详细
 * @author cuichuanlei
 * @created 2019年1月25日 上午11:29:36
 */
public class BusinessFavoriteGroupDetailReq extends PageRequest {

	private static final long serialVersionUID = -6466567266837858478L;
	
	/**主键*/
	private int id;	
	/**组Id*/
	private Integer groupId;	
	/**用户中心公司id*/
	private Integer companyId;	
	/**国家*/
	private String countries;	
	/**国家集合*/
	private List<String> country;
	/**行业*/
	private List<String> industries;	
	/**公司名称*/
	private String companyName;	
	/**登录用户userid*/
	private Integer userId;
	/**数据id*/
	private String sourceId;	
	/**邮箱,号分隔*/
	private String emails;	
	/**域名*/
	private String website;
	/**主营产品*/
	private String mainBusiness;
	 /**商业数据是否需要付费true免费查看*/
	private boolean dataNotAstrict;
	
	/***
	 * 邮箱数量
	 */
	private Integer emailCount;
	
	/**商业数据ID集合*/
	private List<String> sourceIds;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Integer getGroupId() {
		return groupId;
	}
	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}
	public Integer getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}
	public String getCountries() {
		return countries;
	}
	public void setCountries(String countries) {
		this.countries = countries;
	}
	public List<String> getCountry() {
		return country;
	}
	public void setCountry(List<String> country) {
		this.country = country;
	}
	public List<String> getIndustries() {
		return industries;
	}
	public void setIndustries(List<String> industries) {
		this.industries = industries;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getSourceId() {
		return sourceId;
	}
	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}
	public String getEmails() {
		return emails;
	}
	public void setEmails(String emails) {
		this.emails = emails;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getMainBusiness() {
		return mainBusiness;
	}
	public void setMainBusiness(String mainBusiness) {
		this.mainBusiness = mainBusiness;
	}
	public boolean isDataNotAstrict() {
		return dataNotAstrict;
	}
	public void setDataNotAstrict(boolean dataNotAstrict) {
		this.dataNotAstrict = dataNotAstrict;
	}
	public Integer getEmailCount() {
		return emailCount;
	}
	public void setEmailCount(Integer emailCount) {
		this.emailCount = emailCount;
	}
	public List<String> getSourceIds() {
		return sourceIds;
	}
	public void setSourceIds(List<String> sourceIds) {
		this.sourceIds = sourceIds;
	}

}