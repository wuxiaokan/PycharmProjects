package com.joinf.request.customer;

import io.swagger.annotations.ApiModelProperty;

public class GetCustomerContactRequest {
	
	@ApiModelProperty(value="数据id(参数id为空则为新增)",required=true)
	private Long id;
	
	@ApiModelProperty(value="客户id",required=true)
	private Long customerId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}


}
