package com.joinf.response.help;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

public class HelpMenuListResponse {	
	
	
	
	@ApiModelProperty("菜单详情")
	private HelpMenuDetail helpDetail;
	
	@ApiModelProperty("视频信息")
	private List<HelpVideo> helpVideoList;

	public HelpMenuDetail getHelpDetail() {
		return helpDetail;
	}

	public void setHelpDetail(HelpMenuDetail helpDetail) {
		this.helpDetail = helpDetail;
	}

	public List<HelpVideo> getHelpVideoList() {
		return helpVideoList;
	}

	public void setHelpVideoList(List<HelpVideo> helpVideoList) {
		this.helpVideoList = helpVideoList;
	}

	

}
