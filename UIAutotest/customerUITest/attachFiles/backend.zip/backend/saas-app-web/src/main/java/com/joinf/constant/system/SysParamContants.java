package com.joinf.constant.system;




/**
 * 系统参数常量类
 * @author zlx
 *
 */
public class SysParamContants {
	/**需要提醒用户到期信息*/
	public final static String NEED_DUE_WARN= "need_due_warn";
	
	/** 系统参数-到期提醒code */
	public final static String DUE_WARN_CODE= "due_warn";
	/**全国服务专线*/
	public final static String  HELP_LINE= "help_line";
	
}

