package com.joinf.request.chat;

import io.swagger.annotations.ApiModelProperty;

public class UpdateNickNameRequest {

	@ApiModelProperty("新昵称")
	private String name;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
