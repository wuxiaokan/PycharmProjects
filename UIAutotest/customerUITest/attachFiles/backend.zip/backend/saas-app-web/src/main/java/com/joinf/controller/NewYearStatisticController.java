package com.joinf.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.joinf.dto.CheckSuccessDto;
import com.joinf.dto.NewYearUserFacesDto;
import com.joinf.dto.OperatorDTO;
import com.joinf.dto.QueryNewYearStatisticDto;
import com.joinf.entity.generator.Company;
import com.joinf.entity.generator.NewYearContinentCountry;
import com.joinf.entity.generator.NewYearEdmCount;
import com.joinf.entity.generator.NewYearEmailCount;
import com.joinf.entity.generator.NewYearLoginCount;
import com.joinf.entity.generator.NewYearMyTrajectory;
import com.joinf.entity.generator.NewYearQuoteOrder;
import com.joinf.entity.generator.Operator;
import com.joinf.entity.generator.StPiwikData;
import com.joinf.interfaces.CompanyService;
import com.joinf.interfaces.OperatorService;
import com.joinf.interfaces.UserCenterService;
import com.joinf.request.newYear.NewYearStatisticRequest;
import com.joinf.response.UserCenterResponse;
import com.joinf.response.newYear.LoginInfoResponse;
import com.joinf.response.newYear.NewYearStatisticResponse;
import com.joinf.service.newYear.NewYearStatisticManagerImpl;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.util.JoinfBeanUtils;

import freemarker.template.TemplateException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * Description: 年度账单统计
 * @author cuichuanlei
 * @created 2019年1月21日 下午1:16:17
 */
@RestController
@RequestMapping("newYear")
@Api(tags="年度账单统计服务")
public class NewYearStatisticController {
	
	@Autowired
	private NewYearStatisticManagerImpl newYearStatisticManager;
	
	@Autowired
	private UserCenterService userCenterService;

	@Autowired
	private CompanyService companyService;
	
	@Autowired
	private OperatorService operatorService;
	
	/**
	 * 查询年度账单统计数据
	 * @param req
	 * @return
	 * @throws TemplateException 
	 * @throws IOException 
	 */
	@ApiOperation(value="获取用户信息", notes="获取用户信息")
	@ApiImplicitParam(name = "req", value = "获取用户信息", required = true, dataType = "NewYearStatisticRequest")
	@PostMapping("getLoginUserInfo")
	public BaseResponseEntity<LoginInfoResponse> getLoginUserInfo(HttpServletRequest request,@RequestBody NewYearStatisticRequest req) throws IOException{
		BaseResponseEntity<LoginInfoResponse> entity = new BaseResponseEntity<>(true);
		
		String username = req.getUsername();
		String password = req.getPassword();
		
		if(username == null || password == null || "".equals(username) || "".equals(password) ){
			entity.setSuccess(false);
			entity.setCode(5004);
			entity.setErrMsg("缺少参数");
			return entity;
		}
		
		CheckSuccessDto centerUserMessage = new CheckSuccessDto();
		UserCenterResponse<CheckSuccessDto> checkResponse = userCenterService.checkUsernameAndPassword(username, password);
    	centerUserMessage = checkResponse.getResponseData();
    	if(!checkResponse.isSuccess()){
    		entity.setSuccess(false);
			entity.setCode(5005);
			entity.setErrMsg("账号或登录密码错误");
			return entity;
    	}
    	
    	OperatorDTO operatorDTO = userCenterService.getOperatorInfo(centerUserMessage.getUserId()).getResponseData();
		if(operatorDTO==null){
			entity.setSuccess(false);
			entity.setCode(5006);
			entity.setErrMsg("账号无效");
			return entity;
		}
    	
 		//查询企业信息
		Company company = companyService.selectByCenterCompanyId(centerUserMessage.getCompanyId());
		Operator operator = operatorService.selectByCenterUserId(centerUserMessage.getUserId());
		LoginInfoResponse response = new LoginInfoResponse();
		response.setCompany(company);
		response.setOperator(operator);
		response.setSex(operatorDTO.getSex());
		entity.setData(response);		
		return entity;
	}

	
	
	/**
	 * 查询年度账单统计数据
	 * @param req
	 * @return
	 * @throws TemplateException 
	 * @throws IOException 
	 */
	@ApiOperation(value="查询年度账单统计数据", notes="查询年度账单统计数据")
	@ApiImplicitParam(name = "req", value = "查询年度账单统计数据", required = true, dataType = "NewYearStatisticRequest")
	@PostMapping("queryNewYearStatistic")
	public BaseResponseEntity<NewYearStatisticResponse> queryNewYearStatistic(HttpServletRequest request,@RequestBody NewYearStatisticRequest req) throws IOException, TemplateException{
		BaseResponseEntity<NewYearStatisticResponse> entity = new BaseResponseEntity<>(true);
		
		Long companyId = req.getCompanyId();
		Long operatorId = req.getOperatorId();
		if(companyId == null || operatorId == null || operatorId.longValue() == 0){
			entity.setSuccess(false);
			entity.setCode(5004);
			entity.setErrMsg("缺少参数");
			return entity;
		}
		
		QueryNewYearStatisticDto queryDto = JoinfBeanUtils.copyToNewBean(QueryNewYearStatisticDto.class, req);
		
		//返回结果
		NewYearStatisticResponse response = new NewYearStatisticResponse();
	
		//不同时段的登陆次数
		NewYearLoginCount newYearLoginCount = newYearStatisticManager.queryNewYearLoginCountByCondition(queryDto);	
		//不同时段的第一次
		List<NewYearMyTrajectory> newYearMyTrajectory = newYearStatisticManager.queryNewYearMyTrajectoryByCondition(queryDto);
		//客户新增等信息
		NewYearContinentCountry newYearContinentCountry = newYearStatisticManager.queryNewYearContinentCountryByCondition(queryDto);	
		//收信、 发信等邮件统计
		NewYearEmailCount newYearEmailCount = newYearStatisticManager.queryNewYearEmailCountByCondition(queryDto);		
		//营销信收发统计
		NewYearEdmCount newYearEdmCount = newYearStatisticManager.queryNewYearEdmCountByCondition(queryDto);		
		//报价、订单信息
		NewYearQuoteOrder newYearQuoteOrder = newYearStatisticManager.queryNewYearQuoteOrderByCondition(queryDto);
		//用户画像
		NewYearUserFacesDto newYearUserFace = newYearStatisticManager.queryNewYearUserFacesByCondition(queryDto);	
		//营销网站统计
		StPiwikData stPiwikData = newYearStatisticManager.queryStPiwikDataByCondition(queryDto);
		
		response.setNewYearLoginCount(newYearLoginCount);
		response.setNewYearMyTrajectory(newYearMyTrajectory);
		response.setNewYearContinentCountry(newYearContinentCountry);
		response.setNewYearEmailCount(newYearEmailCount);
		response.setNewYearEdmCount(newYearEdmCount);
		response.setNewYearUserFace(newYearUserFace);
		response.setNewYearQuoteOrder(newYearQuoteOrder);
		response.setStPiwikData(stPiwikData);
		
		entity.setData(response);		
		return entity;
	}

}