package com.joinf.request.email;

import java.io.Serializable;

import com.joinf.utils.base.BasePage;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 查询客户箱入参
 * @date 2018年1月11日 下午12:54:01
 */
public class QueryCustomerBoxRequest extends BasePage implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2596363725471279783L;
	
	@ApiModelProperty(value = "分类id")
	private Long id;
	@ApiModelProperty(value = "分类类型")
	private int type;
	
	@ApiModelProperty(value = "搜索关键词")
	private String key;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	
	
	

}
