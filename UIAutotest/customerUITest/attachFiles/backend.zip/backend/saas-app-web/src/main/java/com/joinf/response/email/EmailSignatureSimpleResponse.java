package com.joinf.response.email;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 邮件签名接口返回信息
 * @date 2018年8月20日 上午10:47:00
 */
public class EmailSignatureSimpleResponse {
	@ApiModelProperty(value = "id")
	private Long id;
	@ApiModelProperty(value = "签名内容")
	private String content;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
	
}
