package com.joinf.request.chat;

import io.swagger.annotations.ApiModelProperty;

public class UpdateAgentStatusRequest {
	
	
	@ApiModelProperty("0 为在线 1 为离线")
	private Integer status;

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

}
