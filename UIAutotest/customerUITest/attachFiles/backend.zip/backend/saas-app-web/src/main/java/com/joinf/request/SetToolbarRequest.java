package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

import com.joinf.dto.ToolBar;


/**
 * Description: 设置工具栏请求对象
 *
 * @author lyj
 * @date 2018年2月27日 下午4:41:38
 */
public class SetToolbarRequest {
	
	@ApiModelProperty("工具栏信息")
	private List<ToolBar> toolbars;

	public List<ToolBar> getToolbars() {
		return toolbars;
	}

	public void setToolbars(List<ToolBar> toolbars) {
		this.toolbars = toolbars;
	}

}
