package com.joinf.request.product;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

import com.joinf.request.InsertOrUpdateModel;

/**
 * Description: 修改产品规格
 *
 * @author lyj
 * @date 2018年1月17日 上午9:57:07
 */
public class UpdateProductEnchaseRequest {
	
	@ApiModelProperty(value="产品主键id",required=true)
	private Long productId;
	
	@ApiModelProperty(value="参数集合",required=true)
	private List<InsertOrUpdateModel> models;

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public List<InsertOrUpdateModel> getModels() {
		return models;
	}

	public void setModels(List<InsertOrUpdateModel> models) {
		this.models = models;
	}

}
