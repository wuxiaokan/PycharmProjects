package com.joinf.request.customer;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * Description: 删除供应商参数
 *
 * @author lyj
 * @date 2017年12月12日 上午10:30:22
 */
public class DeleteCustomerRequest {
	
	@ApiModelProperty(value="删除id集合",required=true)
	private List<Long> Ids;

	public List<Long> getIds() {
		return Ids;
	}

	public void setIds(List<Long> ids) {
		Ids = ids;
	}

}
