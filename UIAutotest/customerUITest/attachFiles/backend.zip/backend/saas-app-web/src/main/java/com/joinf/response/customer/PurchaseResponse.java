package com.joinf.response.customer;

import java.math.BigDecimal;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 购买项返回
 *
 * @author lyj
 * @date 2017年12月27日 上午10:12:48
 */
public class PurchaseResponse {

	@ApiModelProperty(value = "购买量")
	private int amount;
	
	@ApiModelProperty(value = "价格")
	private BigDecimal price;

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

}
