package com.joinf.request.cloud;

public class UploadCloudFileRequest {
	
	/**
	 * oss key 
	 */
	private String code;
	/**
	 * 文件名称
	 */
	private String name;
	/**
	 * 后缀
	 */
	private String suffix;
	/**
	 * 文件大小
	 */
	private Long size;
	/**
	 * 文件夹id
	 */
	private Long catalogueId;
	/**
	 * 0[共享] 1[个人]
	 */
	private int type;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSuffix() {
		return suffix;
	}
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}
	public Long getSize() {
		return size;
	}
	public void setSize(Long size) {
		this.size = size;
	}
	public Long getCatalogueId() {
		return catalogueId;
	}
	public void setCatalogueId(Long catalogueId) {
		this.catalogueId = catalogueId;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	
}
