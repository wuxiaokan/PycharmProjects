package com.joinf.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.joinf.JoinfClientUtils;
import com.joinf.config.SaasClientConfig;
import com.joinf.entity.PropertiesEntity;
import com.joinf.request.IdRequest;
import com.joinf.response.help.HelpMenuDetail;
import com.joinf.response.help.HelpMenuListResponse;
import com.joinf.response.help.HelpMenuResponse;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.util.HttpUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * Description: 帮助文档
 *
 * @author lyj
 * @date 2018年1月30日 上午9:46:40
 */
@RestController
@RequestMapping("help")
@Api(tags="帮助服务")
public class HelpController {
	
	@Autowired
	private PropertiesEntity propertiesEntity;
	
	@ApiOperation(value="获取菜单", notes="获取菜单")
	@GetMapping("getHelpMenuList")
	public BaseResponseEntity<List<HelpMenuResponse>> getHelpMenuList (HttpServletRequest request
			,@ApiParam(required = true, name = "site", value= "app,b2b")@RequestParam(value = "site") String site) throws IOException{
		BaseResponseEntity<List<HelpMenuResponse>> entity= new BaseResponseEntity<>();
		Map<String,String> param = new HashMap<String, String>();
		param.put("flags", "1");
		if(StringUtils.isBlank(site))
			site = "b2b";
		param.put("site", site);
		String result = HttpUtils.postMapToJsonBody(propertiesEntity.getHelpUrl()+"/getHelpMenuList", param);
		JSONObject object = JSONObject.parseObject(result);
		List<HelpMenuResponse> datas = JSON.parseArray(object.getJSONArray("data").toJSONString(), HelpMenuResponse.class);
		entity.setData(datas);
		entity.setSuccess(true);
		return entity;
	}
	
	
	@ApiOperation(value="获取菜单列表", notes="获取菜单列表")
	@GetMapping("getHelpDetailList")
	public BaseResponseEntity<List<HelpMenuListResponse>> getHelpDetailList(HttpServletRequest request
			,@ApiParam(required = true, name = "site", value= "app,b2b")@RequestParam(value = "site") String site
			,@ApiParam(required = false, name = "menuId", value= "上级菜单id")@RequestParam(value = "menuId",required=false) Long menuId) throws IOException{
		BaseResponseEntity<List<HelpMenuListResponse>> entity= new BaseResponseEntity<>();
		Map<String,String> param = new HashMap<String, String>();
		param.put("flags", "1");
		param.put("site", site);
		if(menuId != null)
			param.put("menuId", String.valueOf(menuId));
		String result = HttpUtils.postMapToJsonBody(propertiesEntity.getHelpUrl()+"/getHelpDetailList", param);
		JSONObject object = JSONObject.parseObject(result);
		List<HelpMenuListResponse> datas = JSON.parseArray(object.getJSONArray("data").toJSONString(), HelpMenuListResponse.class);
		for(HelpMenuListResponse data:datas){
			HelpMenuDetail detail = data.getHelpDetail();
			if(detail != null&&StringUtils.isNotBlank(detail.getContentUrl()))
				detail.setContent(new String(JoinfClientUtils.downloadFile(SaasClientConfig.saasClientConfig,detail.getContentUrl()), "utf-8"));
		}
		entity.setData(datas);
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="获取明细", notes="获取明细")
	@PostMapping("getHelpDetail")
	@ApiImplicitParam(name = "req", value = "获取明细请求对象", required = true, dataType = "IdRequest")
	public BaseResponseEntity<HelpMenuListResponse> getHelpDetail(HttpServletRequest request,@RequestBody IdRequest req) throws IOException{
		BaseResponseEntity<HelpMenuListResponse> entity= new BaseResponseEntity<>();
		Map<String,String> param = new HashMap<String, String>();
		param.put("flags", "1");
		param.put("menuId", String.valueOf(req.getId()));
		String result = HttpUtils.postMapToJsonBody(propertiesEntity.getHelpUrl()+"/getHelpDetail", param);
		JSONObject object = JSONObject.parseObject(result);
		HelpMenuListResponse data = JSON.parseObject(object.getJSONObject("data").toJSONString(), HelpMenuListResponse.class);
		entity.setData(data);
		entity.setSuccess(true);
		return entity;
	}

}
