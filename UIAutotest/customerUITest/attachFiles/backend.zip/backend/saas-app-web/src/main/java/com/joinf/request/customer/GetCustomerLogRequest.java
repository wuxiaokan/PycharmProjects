package com.joinf.request.customer;

import io.swagger.annotations.ApiModelProperty;


/**
 * Description: 查询客户日志
 *
 * @author lyj
 * @date 2018年1月2日 下午5:40:45
 */
public class GetCustomerLogRequest {

	@ApiModelProperty(value="客户id--如果为空则查询所有客户日志",required=false)
	private Long cid;
	
	@ApiModelProperty(value="业务类别(空表示全部)：customer-客户,follow-跟进,email-邮件,order-订单,quote-报价,transfer-客户迁移",required=false)
	private String busType;
	
	@ApiModelProperty(value="开始日期(格式2017-12-01 00:00:00)",required=true)
	private String beginDate;
	@ApiModelProperty(value="截止日期(格式2017-12-31 23:59:59)",required=true)
	private String endDate;
	@ApiModelProperty(value="第几页(从0开始)",required=true)
	private Integer pageStart;
	@ApiModelProperty(value="分页大小",required=true)
	private Integer pageSize;
	public String getBusType() {
		return busType;
	}
	public void setBusType(String busType) {
		this.busType = busType;
	}
	public Long getCid() {
		return cid;
	}
	public void setCid(Long cid) {
		this.cid = cid;
	}
	public String getBeginDate() {
		return beginDate;
	}
	public void setBeginDate(String beginDate) {
		this.beginDate = beginDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public Integer getPageStart() {
		return pageStart;
	}
	public void setPageStart(Integer pageStart) {
		this.pageStart = pageStart;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
}
