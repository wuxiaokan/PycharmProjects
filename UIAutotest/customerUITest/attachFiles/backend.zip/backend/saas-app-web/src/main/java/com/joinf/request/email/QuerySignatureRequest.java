package com.joinf.request.email;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 查询邮件签名参数
 * @date 2018年8月28日 下午5:22:18
 */
public class QuerySignatureRequest {
	
	@ApiModelProperty(value="发件账号id，多个逗号隔开",required=true)
	private String senders;
	
	@ApiModelProperty(value = "写信类型  [0]普通写信/id有值为编辑邮件 [1]回复、[2]回复全部、[3]回复全部带附件、[4]转发、[5]重发、[6]作为附件发送")
	private int type;

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getSenders() {
		return senders;
	}

	public void setSenders(String senders) {
		this.senders = senders;
	}
	
	

	
	
}
