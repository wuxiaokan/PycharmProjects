package com.joinf.interceptor.system;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.joinf.entity.SessionUser;
import com.joinf.exception.RepeatLoginException;
import com.joinf.interceptor.BaseHandlerInterceptor;
import com.joinf.utils.SessionUtils;


/**
 * Description: 判断重复登录
 *
 * @author lyj
 * @date 2018年9月4日 下午3:13:44
 */
public class RepeatLoginInterceptor extends BaseHandlerInterceptor implements HandlerInterceptor {
	
	@Autowired
	private StringRedisTemplate stringRedisTemplate;
	
	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		
		HttpSession session = request.getSession();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		if(user != null){
			String historySessionValue = stringRedisTemplate.opsForValue().get(getUserLoginKey(user));
			if(StringUtils.isNotBlank(historySessionValue)){
				String historySessionId = historySessionValue.substring(0, historySessionValue.indexOf("_"));
				if(!historySessionId.equals(session.getId())){
					session.invalidate();
					throw new RepeatLoginException("<i class=\"pop-i\"></i>你的账号<b>"+user.getUser().getUserName()+"</b>于<b>"+historySessionValue.substring(historySessionValue.indexOf("_")+1)+"</b>在其它设备登录。如果这不是你的操作，请尽快修改你的登录密码。");
				}
			}
		}
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub

	}

}
