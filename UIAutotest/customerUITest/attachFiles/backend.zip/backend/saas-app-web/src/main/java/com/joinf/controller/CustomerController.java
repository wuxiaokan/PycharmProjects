package com.joinf.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import com.joinf.utils.dto.log.LogInfoDto;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.joinf.annotations.NeedLogin;
import com.joinf.constant.Constants;
import com.joinf.constants.Customize;
import com.joinf.dto.BsDataDto;
import com.joinf.dto.CompanyDTO;
import com.joinf.dto.CustomerBirthdayDto;
import com.joinf.dto.CustomerContactSearchResult;
import com.joinf.dto.CustomerEntity;
import com.joinf.dto.DeleteCustomerAttachmentDto;
import com.joinf.dto.DeleteCustomerDto;
import com.joinf.dto.DuplicateCustomerDTO;
import com.joinf.dto.InsertOrUpdateDto;
import com.joinf.dto.LogCountByDayInfo;
import com.joinf.dto.QueryCustomerIdsDto;
import com.joinf.dto.SearchCustomerContactParam;
import com.joinf.dto.UpdateCustomerForMarkDto;
import com.joinf.dto.UserCardScanOrderDto;
import com.joinf.dto.customer.QueryBsDataDto;
import com.joinf.dto.customer.QueryCustomerContactBirthdayDto;
import com.joinf.dto.customer.QueryCustomerDto;
import com.joinf.dto.customer.QueryUnContactCustomerDto;
import com.joinf.dto.customer.ScanCardDto;
import com.joinf.dto.customer.TransferCustomerDto;
import com.joinf.dto.supplier.QueryCustomerObjectDto;
import com.joinf.dto.supplier.QuerySupplierDto;
import com.joinf.dto.supplier.SupplierDetailDto;
import com.joinf.entity.PropertiesEntity;
import com.joinf.entity.ScanCardMessageEntity;
import com.joinf.entity.SessionUser;
import com.joinf.entity.generator.Company;
import com.joinf.entity.generator.Customer;
import com.joinf.entity.generator.CustomerAttachment;
import com.joinf.entity.generator.CustomerContact;
import com.joinf.entity.generator.CustomerWithBLOBs;
import com.joinf.entity.generator.Operator;
import com.joinf.exception.AreadyExsitException;
import com.joinf.exception.CommonException;
import com.joinf.exception.LimitException;
import com.joinf.interfaces.AssignmentService;
import com.joinf.interfaces.CommonManager;
import com.joinf.interfaces.CustomerService;
import com.joinf.interfaces.EmailService;
import com.joinf.interfaces.OperatorService;
import com.joinf.interfaces.customer.CustomerContactManager;
import com.joinf.interfaces.customer.CustomerManager;
import com.joinf.interfaces.customer.PublicCustomerManager;
import com.joinf.request.CreateUserCardScanOrderRequest;
import com.joinf.request.IdRequest;
import com.joinf.request.InsertOrUpdateAttachRequest;
import com.joinf.request.InsertOrUpdateRequest;
import com.joinf.request.ObjectAndAttachEditRequest;
import com.joinf.request.UpdateStatusRequest;
import com.joinf.request.customer.AssignCustomerRequest;
import com.joinf.request.customer.CountCustomerLogRequest;
import com.joinf.request.customer.DeleteCustomerRequest;
import com.joinf.request.customer.GetCustomerContactRequest;
import com.joinf.request.customer.GetCustomerLogRequest;
import com.joinf.request.customer.QueryBsDataRequest;
import com.joinf.request.customer.QueryCustomerConcactRequest;
import com.joinf.request.customer.QueryCustomerRequest;
import com.joinf.request.customer.QueryDuplicateCustomerRequest;
import com.joinf.request.customer.ScanCardRequset;
import com.joinf.request.customer.SearchCustomerContactRequest;
import com.joinf.request.customer.UpdateCustomerForMarkRequest;
import com.joinf.request.customer.UploadCustomerAttachmentRequest;
import com.joinf.response.CustomerContactResponse;
import com.joinf.response.EditDetailResponse;
import com.joinf.response.SuccessResponse;
import com.joinf.response.customer.BsDataResponse;
import com.joinf.response.customer.CardScannerAmountResponse;
import com.joinf.response.customer.CustomerAttachmentResponse;
import com.joinf.response.customer.PurchaseResponse;
import com.joinf.response.supplier.QuerySupplierResponse;
import com.joinf.service.redis.RedisService;
import com.joinf.utils.BaseEntityUtils;
import com.joinf.utils.RegxUtil;
import com.joinf.utils.ReplaceUtil;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.annotations.Permission;
import com.joinf.utils.annotations.ResubmitData;
import com.joinf.utils.annotations.VolumeLimit;
import com.joinf.utils.base.BasePage;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.dto.user.UserInfoDto;
import com.joinf.utils.enums.EsSearchUrlEnum;
import com.joinf.utils.util.EsSearchUtil;
import com.joinf.utils.util.JoinfBeanUtils;
import com.joinf.utils.util.ObjectUtil;
import com.joinf.utils.util.StringUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * Description: 客户服务
 *
 * @author lyj
 * @date 2017年12月4日 下午4:47:34
 */
@RestController
@RequestMapping("customer")
@Api(tags="客户服务")
public class CustomerController extends BaseController{
	
	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());
	
	@Autowired
	private CustomerManager customerManager;
	@Autowired
	private PublicCustomerManager publicCustomerManager;
	
	@Autowired
	private CustomerContactManager contactManager;
	
	@Autowired
	private PropertiesEntity propertiesEntity;
	
	@Autowired
	private CommonManager commonManager;
	
	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private RedisService redisService;
	
	@Autowired
	private AssignmentService assignmentService;
	@Autowired
	private OperatorService operatorService;
	
	@Autowired
	private EmailService emailService;
	
	
	@ApiOperation(value="判断管理权限", notes="判断管理权限")
	@ApiImplicitParam(name = "req", value = "通过客户ID 判断 是否有查看客户的权限", required = true, dataType = "IdRequest")
	@PostMapping("checkCustomerPermit")
	@Permission(require="customer.public.preview")
	public BaseResponseEntity<String> checkCustomerPermit(HttpServletRequest request,@RequestBody IdRequest req){
		BaseResponseEntity<String> entity = new BaseResponseEntity<>(true);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		//通过客户ID 查询客户详情，获取客户所属业务员ID
		CustomerWithBLOBs customer = customerService.queryByKey(req.getId());
		//校验是否拥有数据权限
		if(customer != null && dataPermissionValidateManager.validateDataPermission(user.getSwitchOperatorId(), customer.getOperatorId(), customer.getOperatorIds(), customer.getOpen(), Constants.RESOURCE_CUSTOMER_ID)){
			entity.setData("true");
		}else{
			entity.setData("false");
		}
		
		return entity;
	}
	
	
	/**
	 * 客户查重
	 * @param map
	 * @param request
	 * @return
	 */
	@ApiOperation(value="客户列表查重", notes="客户列表查重")
	@ApiImplicitParam(name = "req", value = "客户列表查重", required = true, dataType = "QueryDuplicateCustomerRequest")
	@PostMapping("/customerDuplicateChecking")
	@Permission(require="customer.list.preview")
	public BaseResponseEntity<List<DuplicateCustomerDTO>> customerDuplicateChecking(HttpServletRequest request,@RequestBody QueryDuplicateCustomerRequest req) {
		QueryCustomerDto dto = new QueryCustomerDto();
		JoinfBeanUtils.copyProperties(dto, req);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setCompanyId(user.getCompanyId());
		
		dto.setWebSite(ObjectUtil.extractPureWebSite(dto.getWebSite()));
		
		BaseResponseEntity<List<DuplicateCustomerDTO>> entity = new BaseResponseEntity<>();
		entity.setSuccess(true);
		List<DuplicateCustomerDTO> customers = customerManager.duplicateCheckingList(dto);
		
		//设置业务员、重新组装联系方式
		for(DuplicateCustomerDTO cus : customers){
			//处理公海业务员
			if(dto.isHighSeas()) {
				cus.setOperatorId(this.customerService.getOperatorIdForPublicCustomer(cus.getId()));
			}
			
			if(dto.getContactWay() != null){
				String contactWay = StringUtils.isNotBlank(cus.getEmail()) && RegxUtil.match(cus.getEmail(), dto.getContactWay()) ? cus.getEmail() : 
										StringUtils.isNotBlank(cus.getMobile()) && RegxUtil.match(cus.getMobile(), dto.getContactWay()) ? cus.getMobile() : 
											StringUtils.isNotBlank(cus.getTelephone()) && RegxUtil.match(cus.getTelephone(), dto.getContactWay()) ? cus.getTelephone() : 
												StringUtils.isNotBlank(cus.getQq()) && RegxUtil.match(cus.getQq(), dto.getContactWay()) ? cus.getQq() : 
													StringUtils.isNotBlank(cus.getFax()) && RegxUtil.match(cus.getFax(), dto.getContactWay()) ? cus.getFax() : 
														StringUtils.isNotBlank(cus.getSkype()) && RegxUtil.match(cus.getSkype(), dto.getContactWay()) ? cus.getSkype() : 
															cus.getWangwang() ;
				
				cus.setContactWay(contactWay);
			}
		}
		
		dealCustomerDuplicateDTOList(customers,dto,request);
		//获取公司下的所有操作员
		Company company = SessionUtils.getCompanyInfo(request);
		List<UserInfoDto> userInfoList = operatorService.getCompanyAllOperators(company.getId());
		Map<Long,String> userInfoMap = new HashMap<Long,String>();
		for(UserInfoDto us : userInfoList){
		    userInfoMap.put(us.getId(), us.getChineseName());
		}
		//处理
		 for(DuplicateCustomerDTO cuplicateCustomerDTO : customers) {
			 Long operatorId = cuplicateCustomerDTO.getOperatorId();
			 //设置操作员名称
			 cuplicateCustomerDTO.setSalesmanName(userInfoMap.get(operatorId));
		 }
		
		if(req.isPaging()){
			customers = ((Page<DuplicateCustomerDTO>) customers).getResult();
			entity.setTotalPage(((Page<DuplicateCustomerDTO>) customers).getPages());
			entity.setTotalRecords(((Page<DuplicateCustomerDTO>) customers).getTotal());
		}
		
		entity.setData(customers);
		return entity;
	}
	
	
	/**
	 * 查询客户列表
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询客户列表", notes="查询客户列表")
	@ApiImplicitParam(name = "req", value = "查询客户列表请求对象", required = true, dataType = "QueryCustomerRequest")
	@PostMapping("queryCustomerList")
	@Permission(require="customer.list.preview")
	public BaseResponseEntity<QuerySupplierResponse> queryCustomerList(HttpServletRequest request,@RequestBody QueryCustomerRequest req){
		long step = System.currentTimeMillis();
		
		QueryCustomerDto dto = new QueryCustomerDto();
		JoinfBeanUtils.copyProperties(dto, req);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setRoleId(user.getRoleId());
		dto.setResourceId(Customize.CustomerList.getResourceId());
		dto.setTableName(Customize.CustomerList.getTableName());
		dto.setModule(Customize.CustomerList.getModule());
		dto.setShare(1);
	
		
		BaseResponseEntity<QuerySupplierResponse> entity = new BaseResponseEntity<>();
		entity.setSuccess(true);
		
		//排序
		if(dto.getSortColumn() != null && StringUtils.isNotBlank(dto.getSortColumn())){
			if("code".equals(dto.getSortColumn()) || "name".equals(dto.getSortColumn())){
				dto.setSortColumn("CONVERT("+dto.getSortColumn()+" USING gbk)");
			}
		}
		
		List<CustomerEntity> customers = customerManager.queryCustomerList(dto);
		List<CustomerEntity> queryEntities = new ArrayList<CustomerEntity>();
		if(req.isPaging()){
			queryEntities = ((Page<CustomerEntity>) customers).getResult();
			entity.setTotalPage(((Page<CustomerEntity>) customers).getPages());
			entity.setTotalRecords(((Page<CustomerEntity>) customers).getTotal());
		
		}else{
			queryEntities = customers;
		}
		
		List<String> showFileds = new ArrayList<String>();
		showFileds.add("code");//代码
		showFileds.add("displayType");//客户类型
		showFileds.add("name");//客户名称
		showFileds.add("lock");//是否锁定
		showFileds.add("isAsterisk");//是否星标
		showFileds.add("displayLastFollowTime");//下次跟进时间
		showFileds.add("displayCreateTime");//创建日期
		showFileds.add("displaySalesman");//业务员
		entity.setData(customerManager.getCustomerListArray(dto, queryEntities, showFileds));//转换数据
		
		logger.info("客户列表查询耗时-{}/s", (System.currentTimeMillis()-step)/1000);
		
		return entity;
	}
	
	/**
	 * 查询客户列表--基本字段
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询客户列表--基本字段", notes="查询客户列表--基本字段")
	@ApiImplicitParam(name = "req", value = "查询客户列表请求对象", required = true, dataType = "QueryCustomerRequest")
	@PostMapping("queryNormalCustomerList")
	@Permission(require="customer.list.preview")
	public BaseResponseEntity<List<CustomerEntity>> queryNormalCustomerList(HttpServletRequest request,@RequestBody QueryCustomerRequest req){
		QueryCustomerDto dto = new QueryCustomerDto();
		JoinfBeanUtils.copyProperties(dto, req);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(user.getUser().getCompanyId());
		dto.setRoleId(user.getRoleId());
		dto.setResourceId(Customize.CustomerList.getResourceId());
		dto.setTableName(Customize.CustomerList.getTableName());
		dto.setModule(Customize.CustomerList.getModule());
		dto.setShare(1);
		
		//排序
		if(dto.getSortColumn() != null && StringUtils.isNotBlank(dto.getSortColumn())){
			if("code".equals(dto.getSortColumn()) || "name".equals(dto.getSortColumn())){
				dto.setSortColumn("CONVERT("+dto.getSortColumn()+" USING gbk)");
			}
		}
		
		BaseResponseEntity<List<CustomerEntity>> entity = new BaseResponseEntity<>();
		entity.setSuccess(true);
		
		List<CustomerEntity> customers = customerManager.queryCustomerList(dto);
		if(req.isPaging()){
			customers = ((Page<CustomerEntity>) customers).getResult();
			entity.setTotalPage(((Page<CustomerEntity>) customers).getPages());
			entity.setTotalRecords(((Page<CustomerEntity>) customers).getTotal());
		}
		
		entity.setData(customers);
		return entity;
	}
	
	@ApiOperation(value="查询即将转入公海客户", notes="查询即将转入公海客户")
	@PostMapping("queryDuringMoveToPublicList")
	@ApiImplicitParam(name = "req", value = "查询客户列表请求对象", required = true, dataType = "QueryCustomerRequest")
	@Permission(require="customer.list.preview")
	public BaseResponseEntity<QuerySupplierResponse> queryDuringMoveToPublicList(HttpServletRequest request,@RequestBody QueryCustomerRequest req){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		Long companyId = user.getCompanyId();
		Long operatorId = user.getSwitchOperatorId();
		QueryCustomerDto dto = new QueryCustomerDto();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setOperatorId(operatorId);
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(companyId);
		dto.setRoleId(user.getUser().getRoleId());
		dto.setResourceId(Customize.CustomerList.getResourceId());
		dto.setTableName(Customize.CustomerList.getTableName());
		dto.setModule(Customize.CustomerList.getModule());
		dto.setShare(1);
		
		//排序
		if(dto.getSortColumn() != null && StringUtils.isNotBlank(dto.getSortColumn())){
			if("code".equals(dto.getSortColumn()) || "name".equals(dto.getSortColumn())){
				dto.setSortColumn("CONVERT("+dto.getSortColumn()+" USING gbk)");
			}
		}
		
		
		BaseResponseEntity<QuerySupplierResponse> entity = new BaseResponseEntity<>();
		entity.setSuccess(true);
		List<CustomerEntity> customers = new ArrayList<CustomerEntity>();
		//待转入的客户id
		List<Long> ids = customerManager.getMovingToPublicCustomerCount(companyId, operatorId);
		if(ids.size()>0){
			dto.setCustomerIds(ids);
			customers = customerManager.queryCustomerList(dto);
			
		}else{
			entity.setTotalRecords(0l);
			return entity;
		}
		
		if(req.isPaging()){
			customers = ((Page<CustomerEntity>) customers).getResult();
			entity.setTotalPage(((Page<CustomerEntity>) customers).getPages());
			entity.setTotalRecords(((Page<CustomerEntity>) customers).getTotal());
			
		}
		
		List<String> showFileds = new ArrayList<String>();
		showFileds.add("code");//代码
		showFileds.add("displayType");//客户类型
		showFileds.add("name");//客户名称
		showFileds.add("lock");//客户名称
		showFileds.add("displayLastFollowTime");//下次跟进时间
		showFileds.add("displayCreateTime");//创建日期
		showFileds.add("displaySalesman");//创建日期
		entity.setData(customerManager.getCustomerListArray(dto, customers, showFileds));//转换数据
		return entity;
	}
	
	@ApiOperation(value="查询30天内未联系客户", notes="查询30天内未联系客户")
	@PostMapping("selectUnContactCustomerByTime")
	@ApiImplicitParam(name = "req", value = "查询30天内未联系客户请求对象", required = true, dataType = "QueryCustomerRequest")
	@Permission(require="customer.list.preview")
	public BaseResponseEntity<QuerySupplierResponse> selectUnContactCustomerByTime(HttpServletRequest request,@RequestBody QueryCustomerRequest req){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		Long companyId = user.getCompanyId();
		Long operatorId = user.getSwitchOperatorId();
		QueryCustomerDto dto = new QueryCustomerDto();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setOperatorId(operatorId);
		dto.setCompanyId(companyId);
		dto.setRoleId(user.getRoleId());
		dto.setResourceId(Customize.CustomerList.getResourceId());
		dto.setTableName(Customize.CustomerList.getTableName());
		dto.setModule(Customize.CustomerList.getModule());
		dto.setShare(1);
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		
		//排序
		if(dto.getSortColumn() != null && StringUtils.isNotBlank(dto.getSortColumn())){
			if("code".equals(dto.getSortColumn()) || "name".equals(dto.getSortColumn())){
				dto.setSortColumn("CONVERT("+dto.getSortColumn()+" USING gbk)");
			}
		}
				
		
		QueryUnContactCustomerDto contactDto = new QueryUnContactCustomerDto();
		JoinfBeanUtils.copyProperties(contactDto, req);
		contactDto.setOperatorId(operatorId);
		contactDto.setCompanyId(companyId);
		contactDto.setDataType("lately_month");
		String operatorIds = commonManager.getAssignmentIds(companyId, operatorId);
		if (StringUtils.isNotBlank(operatorIds)) {
			contactDto.setOperatorIds(StringUtil.toListLong(operatorIds));
		}
		BaseResponseEntity<QuerySupplierResponse> entity = new BaseResponseEntity<>();
		entity.setSuccess(true);
		List<CustomerEntity> customers = customerManager.selectUnContactCustomerByTime(contactDto);
		if(req.isPaging()){
			customers = ((Page<CustomerEntity>) customers).getResult();
			entity.setTotalPage(((Page<CustomerEntity>) customers).getPages());
			entity.setTotalRecords(((Page<CustomerEntity>) customers).getTotal());
			
		}
		
		List<String> showFileds = new ArrayList<String>();
		showFileds.add("code");//代码
		showFileds.add("displayType");//客户类型
		showFileds.add("name");//客户名称
		showFileds.add("lock");//客户名称
		showFileds.add("displayLastFollowTime");//下次跟进时间
		showFileds.add("displayCreateTime");//创建日期
		showFileds.add("displaySalesman");//创建日期
		entity.setData(customerManager.getCustomerListArray(dto, customers, showFileds));//转换数据
		return entity;
	}
	

	/**
	 * 查询公海客户列表
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询公海客户列表", notes="查询公海客户列表")
	@ApiImplicitParam(name = "req", value = "查询公海客户列表请求对象", required = true, dataType = "QueryCustomerRequest")
	@PostMapping("queryPublicCustomerList")
	@Permission(require="customer.public.preview")
	public BaseResponseEntity<QuerySupplierResponse> queryPublicCustomerList(HttpServletRequest request,@RequestBody QueryCustomerRequest req){
		QueryCustomerDto dto = new QueryCustomerDto();
		JoinfBeanUtils.copyProperties(dto, req);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setRoleId(user.getRoleId());
		dto.setResourceId(Customize.CustomerPublicList.getResourceId());
		dto.setTableName(Customize.CustomerPublicList.getTableName());
		dto.setModule(Customize.CustomerPublicList.getModule());
		BaseResponseEntity<QuerySupplierResponse> entity = new BaseResponseEntity<>();
		entity.setSuccess(true);
		//排序
		if(dto.getSortColumn() != null && StringUtils.isNotBlank(dto.getSortColumn())){
			if("code".equals(dto.getSortColumn()) || "name".equals(dto.getSortColumn())){
				dto.setSortColumn("CONVERT("+dto.getSortColumn()+" USING gbk)");
			}
		}
				
		List<CustomerWithBLOBs> customers = publicCustomerManager.queryPublicCustomerList(dto);
		if(req.isPaging()){
			entity.setTotalPage(((Page<CustomerWithBLOBs>) customers).getPages());
			entity.setTotalRecords(((Page<CustomerWithBLOBs>) customers).getTotal());
			customers = ((Page<CustomerWithBLOBs>) customers).getResult();
		
		}
		
		List<String> showFileds = new ArrayList<String>();
		showFileds.add("code");//代码
		showFileds.add("displayType");//客户类型
		showFileds.add("name");//客户名称
		showFileds.add("displaySalesman");//客户名称
		entity.setData(publicCustomerManager.getPublicCustomerListArray(dto, customers, showFileds));//转换数据
		return entity;
	}
	
	@ApiOperation(value="查询公海客户明细", notes="查询公海客户明细")
	@ApiImplicitParam(name = "req", value = "查询客户明细请求对象", required = true, dataType = "IdRequest")
	@PostMapping("getPublicCustomerDetail")
	@Permission(require="customer.public.preview")
	public BaseResponseEntity<List<EditDetailResponse>> getPublicCustomerDetail(HttpServletRequest request,@RequestBody IdRequest req
			,@ApiParam(required = false, name = "permissionCode", value= "权限类别")@RequestParam(value = "permissionCode",required=false) String permissionCode){
		SupplierDetailDto dto = new SupplierDetailDto();
		dto.setId(req.getId());
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setRoleId(user.getUser().getRoleId());
		
		dto.setResourceId(Customize.CustomerEdit.getResourceId());
		dto.setTableName(Customize.CustomerEdit.getTableName());
		dto.setModule(Customize.CustomerEdit.getModule());
		List<EditDetailResponse> details = customerManager.getCustomerEditArray(dto);
		return BaseEntityUtils.successOne(details);
	}
	
	@ApiOperation(value="查询客户明细(参数id为空则为新增)", notes="查询供应商明细(参数id为空则为新增)")
	@ApiImplicitParam(name = "req", value = "查询客户明细请求对象", required = true, dataType = "IdRequest")
	@PostMapping("getCustomerDetail")
	@Permission(require="customer.list.edit")
	public BaseResponseEntity<List<EditDetailResponse>> getCustomerDetail(HttpServletRequest request,@RequestBody IdRequest req
			,@ApiParam(required = false, name = "permissionCode", value= "权限类别")@RequestParam(value = "permissionCode",required=false) String permissionCode){
		SupplierDetailDto dto = new SupplierDetailDto();
		dto.setId(req.getId());
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setRoleId(user.getUser().getRoleId());
		
		dto.setResourceId(Customize.CustomerEdit.getResourceId());
		dto.setTableName(Customize.CustomerEdit.getTableName());
		dto.setModule(Customize.CustomerEdit.getModule());
		List<EditDetailResponse> details = customerManager.getCustomerEditArray(dto);
		return BaseEntityUtils.successOne(details);
	}
	
	
	@ApiOperation(value="获取客户名片扫描信息", notes="获取客户名片扫描信息")
	@PostMapping("getCustomerCardScannerInfo")
	@NeedLogin
	public BaseResponseEntity<CardScannerAmountResponse> getCustomerCardScannerInfo(HttpServletRequest request){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		CompanyDTO companyDTO = SessionUtils.getCenterCompanyInfo(request);
		
		BaseResponseEntity<CardScannerAmountResponse> entity = new BaseResponseEntity<>();
		entity.setSuccess(true);
		entity.setData(customerManager.getCustomerCardScannerInfo(companyDTO.getCompanyId(),user.getCompanyId()));
		return entity;
		
	}
	
	@ApiOperation(value="扫描名片", notes="扫描名片")
	@PostMapping("scanCard")
	@NeedLogin
	public BaseResponseEntity<ScanCardMessageEntity> scanCard(HttpServletRequest request,@RequestBody ScanCardRequset req){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		CompanyDTO companyDTO = SessionUtils.getCenterCompanyInfo(request);
		Long companyId = user.getCompanyId();
		Long operatorId = user.getOperatorId();
		BaseResponseEntity<ScanCardMessageEntity> entity = new BaseResponseEntity<>();
		ScanCardDto scanDto = new ScanCardDto();
		JoinfBeanUtils.copyProperties(scanDto, req);
		scanDto.setCompanyId(companyId);
		scanDto.setCenterCompanyId(companyDTO.getCompanyId());
		scanDto.setCenterOperatorId(user.getUser().getCenterUserId());
		scanDto.setOperatorId(operatorId);
		ScanCardMessageEntity scanData = customerManager.scanCard(scanDto);
		if(scanData == null && scanDto.getType().intValue() == 1){
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg("没有识别到客户信息");
		}else if(scanData == null && scanDto.getType().intValue() == 2){
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg("没有识别到供应商信息");
		}else{
			entity.setData(scanData);
			entity.setSuccess(true);
		}
		return entity;
		
	}
	
	
	
	/**
	 * 查询名片购买信息
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询名片购买信息", notes="查询名片购买信息")
	@PostMapping("getCardScanBuyGoodsInfo")
	public BaseResponseEntity<List<PurchaseResponse>> cardScanBuyGoodsInfo(HttpServletRequest request){
		BaseResponseEntity<List<PurchaseResponse>> entity= new BaseResponseEntity<>();
		entity.setSuccess(true);
		entity.setData(customerManager.getCardScannerPurchaseInfo());
		return entity;
	}
	
	/**
	 * 购买名片订单
	 * @param req
	 * @return
	 */
	@ApiOperation(value="创建购买名片订单", notes="创建购买名片订单")
	@PostMapping("createUserCardScanOrder")
	@ApiImplicitParam(name = "req", value = "客户修改请求对象", required = true, dataType = "CreateUserCardScanOrderRequest")
	@NeedLogin
	public BaseResponseEntity<Long> createUserCardScanOrder(HttpServletRequest request,@RequestBody CreateUserCardScanOrderRequest req){
		
		UserCardScanOrderDto dto = new UserCardScanOrderDto();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setOperatorId(SessionUtils.getSwitchOperatorInfo(request).getCenterUserId());
		dto.setCompanyId(SessionUtils.getCenterCompanyInfo(request).getCompanyId());
		BaseResponseEntity<Long> entity= new BaseResponseEntity<>();
		entity.setSuccess(true);
		entity.setData(customerManager.createUserCardScanOrder(dto));
		return entity;
	}
	
	@ApiOperation(value="客户修改(参数id为空则为新增)", notes="客户修改(参数id为空则为新增)")
	@ApiImplicitParam(name = "req", value = "客户修改请求对象", required = true, dataType = "InsertOrUpdateRequest")
	@PostMapping("insertOrUpdateCustomer")
	@Permission(require="customer.list.new")
	@VolumeLimit
	public BaseResponseEntity<Customer> insertOrUpdateCustomer(HttpServletRequest request,@RequestBody InsertOrUpdateRequest req) throws AreadyExsitException{
		BaseResponseEntity<Customer> entity = new BaseResponseEntity<Customer>();
		
		InsertOrUpdateDto dto = new InsertOrUpdateDto();
		dto.setValues(req.getModels());
		dto.setOldValue(req.getOldValue());
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setOperatorId(user.getOperatorId());
		dto.setOperatorName(user.getUser().getChineseName());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setId(req.getId());
		dto.setTableName(Customize.CustomerEdit.getTableName());
		dto.setRoleId(user.getUser().getRoleId());
		dto.setFileAgencyId(req.getFileAgencyId());
		entity.setData((Customer)customerManager.insertOrUpdateCustomer(dto).getReturnValue());
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="删除客户", notes="删除供客户")
	@ApiImplicitParam(name = "req", value = "删除客户请求对象", required = true, dataType = "DeleteCustomerRequest")
	@PostMapping("deleteCustomer")
	@Permission(require="customer.list.delete")
	public BaseResponseEntity<SuccessResponse> deleteCustomer(HttpServletRequest request,@RequestBody DeleteCustomerRequest req){
		BaseResponseEntity<SuccessResponse> entity = new BaseResponseEntity<SuccessResponse>();
		DeleteCustomerDto dto = new DeleteCustomerDto();
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setUpdateId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setCustomerIds(req.getIds());
		customerManager.deleteCustomer(dto);
		entity.setSuccess(true);
		entity.setData(new SuccessResponse(true));
		return entity;
	}
	

	@ApiOperation(value="查询客户附件", notes="查询客户附件")
	@ApiImplicitParam(name = "req", value = "查询客户附件请求对象", required = true, dataType = "IdRequest")
	@PostMapping("getCustomerAttachments")
	@Permission(require="customer.list.preview")
	public BaseResponseEntity<List<CustomerAttachmentResponse>> getCustomerAttachments(HttpServletRequest request,@RequestBody IdRequest req){
		BaseResponseEntity<List<CustomerAttachmentResponse>> entity = new BaseResponseEntity<>();
		entity.setSuccess(true);
		entity.setData(customerManager.getCustomerAttachments(req.getId()));
		return entity;
	}
	
	@ApiOperation(value="上传客户附件", notes="上传客户附件")
	@ApiImplicitParam(name = "req", value = "上传客户附件请求对象", required = true, dataType = "UploadCustomerAttachmentRequest")
	@PostMapping("uploadCustomerAttachments")
	@Permission(require="customer.list.preview")
	public BaseResponseEntity<SuccessResponse> uploadCustomerAttachments(HttpServletRequest request,@RequestBody UploadCustomerAttachmentRequest req){
		BaseResponseEntity<SuccessResponse> entity = new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		CustomerAttachment attachment = new CustomerAttachment();
		JoinfBeanUtils.copyProperties(attachment, req);
		Date date = new Date();
		attachment.setCompanyId(user.getCompanyId());
		attachment.setCreateTime(date);
		attachment.setFlag(1);
		attachment.setUpdateId(user.getSwitchOperatorId());
		attachment.setUpdateTime(date);
		attachment.setCreateId(user.getSwitchOperatorId());
		customerManager.uploadCustomerAttachment(attachment);
		entity.setSuccess(true);
		entity.setData(new SuccessResponse(true));
		return entity;
	}
	
	
	
	@ApiOperation(value="删除客户客户附件", notes="删除供客户附件")
	@ApiImplicitParam(name = "req", value = "删除客户附件请求对象", required = true, dataType = "DeleteCustomerRequest")
	@PostMapping("deleteCustomerAttachments")
	@Permission(require="customer.list.delete")
	public BaseResponseEntity<SuccessResponse> deleteCustomerAttachments(HttpServletRequest request,@RequestBody DeleteCustomerRequest req){
		BaseResponseEntity<SuccessResponse> entity = new BaseResponseEntity<SuccessResponse>();
		DeleteCustomerAttachmentDto dto = new DeleteCustomerAttachmentDto();
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setUpdateId(user.getOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setIds(req.getIds());
		customerManager.deleteCustomerAttachment(dto);
		entity.setSuccess(true);
		entity.setData(new SuccessResponse(true));
		return entity;
	}
	
	@ApiOperation(value="客户转入公海", notes="客户转入公海")
	@ApiImplicitParam(name = "req", value = "客户转入公海请求对象", required = true, dataType = "DeleteCustomerRequest")
	@PostMapping("moveCustomerToPublic")
	@Permission(require="customer.list.moveToPublic")
	public BaseResponseEntity<SuccessResponse> moveCustomerToPublic(HttpServletRequest request,@RequestBody DeleteCustomerRequest req) throws CommonException{
		BaseResponseEntity<SuccessResponse> entity = new BaseResponseEntity<SuccessResponse>();
		TransferCustomerDto dto = new TransferCustomerDto();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		QueryCustomerIdsDto qdto = new QueryCustomerIdsDto();
		qdto.setCompanyId(user.getCompanyId());
		qdto.setCustomerIds(req.getIds());
		List<Customer> customer = customerService.selectCustomersByIds(qdto);
		for(Customer c : customer){
			if(!this.checkHas(user.getOperatorId(),c.getOperatorId(), Constants.RESOURCE_CUSTOMER_ID)){
				StringBuilder message = new StringBuilder();
				message.append("没有权限！");
				message.insert(0, "转入公海失败!");
				throw new CommonException(message.toString());
			}
		}
		dto.setUpdatedId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setCustomerIds(req.getIds());
		dto.setNewOperatorId(0l);
		customerManager.moveCusotmerToPublic(dto);
		entity.setSuccess(true);
		entity.setData(new SuccessResponse(true));
		return entity;
	}
	
	@ApiOperation(value="领取公海客户", notes="领取公海客户")
	@ApiImplicitParam(name = "req", value = "领取公海客户请求对象", required = true, dataType = "DeleteCustomerRequest")
	@PostMapping("receivePublicCustomer")
	@Permission(require="customer.public.receive")
	public BaseResponseEntity<SuccessResponse> receivePublicCustomer(HttpServletRequest request,@RequestBody DeleteCustomerRequest req) throws CommonException{
		BaseResponseEntity<SuccessResponse> entity = new BaseResponseEntity<SuccessResponse>();
		TransferCustomerDto dto = new TransferCustomerDto();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setUpdatedId(user.getOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setCustomerIds(req.getIds());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setNewOperatorId(user.getSwitchOperatorId());
		customerManager.receivePublicCustomer(dto);
		entity.setSuccess(true);
		entity.setData(new SuccessResponse(true));
		return entity;
	}
	
	@ApiOperation(value="分配公海客户", notes="分配公海客户")
	@ApiImplicitParam(name = "req", value = "分配公海客户请求对象", required = true, dataType = "AssignCustomerRequest")
	@PostMapping("assignPublicCustomer")
	@Permission(require="customer.public.assign")
	public BaseResponseEntity<SuccessResponse> assignPublicCustomer(HttpServletRequest request,@RequestBody AssignCustomerRequest req) throws CommonException{
		BaseResponseEntity<SuccessResponse> entity = new BaseResponseEntity<SuccessResponse>();
		TransferCustomerDto dto = new TransferCustomerDto();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setUpdatedId(user.getOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setCustomerIds(req.getIds());
		dto.setNewOperatorId(req.getNewOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		customerManager.assignPublicCustomer(dto);
		entity.setSuccess(true);
		entity.setData(new SuccessResponse(true));
		return entity;
	}
	
	@ApiOperation(value="查询客户联系人列表", notes="查询客户联系人列表")
	@ApiImplicitParam(name = "req", value = "查询客户联系人列表请求对象", required = true, dataType = "QueryCustomerConcactRequest")
	@PostMapping("queryCustomerContactList")
	@Permission(require="customer.list.preview")
	public BaseResponseEntity<QuerySupplierResponse> querySupplierContactList(HttpServletRequest request,@RequestBody QueryCustomerConcactRequest req) throws Exception{
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		QueryCustomerObjectDto queryDto = new QueryCustomerObjectDto();
		JoinfBeanUtils.copyProperties(queryDto, req);
		queryDto.setCompanyId(user.getUser().getCompanyId());
		
		queryDto.setPaging(false);
		PageHelper.clearPage();
		
		List<CustomerContact> responseList = contactManager.queryCustomerContactList(queryDto);	
		List<CustomerContactResponse> contactResponseList = new ArrayList<CustomerContactResponse>();
		for(int i=0, len=responseList.size(); i<len; i++){
			CustomerContactResponse response = new CustomerContactResponse();
			CustomerContact contact = responseList.get(i);
			BeanUtils.copyProperties(response, contact);
			Long contactId = contact.getId();
			Map<String,Object> param = new HashMap<String,Object>();
			param.put("companyId", queryDto.getCompanyId());
			param.put("customerId", queryDto.getCustomerId());
			param.put("contactId", contactId);
			
			//自己或下属或公海的客户/供应商，查询所有操作日志。 上级共享的客户(包含全开放)，只查询当前业务员的操作日志。
			List<UserInfoDto> list = redisService.getOperatorAssignment(user.getCompanyId(), user.getSwitchOperatorId(),1);
			List<Long> operatorIds = new ArrayList<Long>();
			for(UserInfoDto userInfo : list){
				operatorIds.add(userInfo.getId());
			}
			
			Long searchOperatorId = null;
//			//自己或下属或公海的客户，查询客户相关的所有数据。 上级共享的客户(包含全开放)，只查询当前客户所属业务员的数据。
			searchOperatorId = getSearchCustomerLogOperatorId(user.getCompanyId(),queryDto.getCustomerId(),user.getSwitchOperatorId(),operatorIds);
			
			//查询客户明细
			Customer customer = this.customerService.getCustomerForStatusCheck(queryDto.getCustomerId());
			// 1.如果客户所属业务员为当前切换人，则查询客户的所有邮件
			if(!customer.getOperatorId().equals(user.getSwitchOperatorId())){
				//客户邮件如果设置为共享 	
				if(customer.getPublicEmail() == 1){
					if((null != customer.getOpen()) && (customer.getOpen() == 1)){
						List<Long> arrayOperatorIds = customerService.selectOperatorShareCustomerIds(user.getCompanyId(), user.getSwitchOperatorId());
						param.put("arrayOperatorIds", arrayOperatorIds);
					}else if(null != customer.getOperatorIds()){
						//2.查询查询当前切换人管理范围内的邮件
						String[] arrayOperatorIds = customer.getOperatorIds().split(",");
						param.put("arrayOperatorIds", arrayOperatorIds);
					}
					
				}else{
					// 如果客户不共享，则查询当前切换人的邮件信息
					param.put("operatorId", searchOperatorId);
				}
			}
			
			param.put("noBoxId", new Long[] { -101l, -102l,-103l });
			//不根据归并状态查询
			param.put("mergerType", -1);
			int count = 0;
			count = emailService.selectEmailCountByParam(param);
			
			response.setEmailCount(count);
			contactResponseList.add(response);
		}
		
		//按邮件数量排序
		if(req.getContactNumSort()!= null && req.getContactNumSort()){
			//倒序排序
			contactResponseList = contactResponseList.stream().sorted((p, p2) -> ((p2.getEmailCount() - p.getEmailCount()))).collect(Collectors.toList());	
		}
		
		QuerySupplierDto dto = new QuerySupplierDto();
		dto.setOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setRoleId(user.getRoleId());
		dto.setResourceId(Customize.CustomerContactList.getResourceId());
		dto.setTableName(Customize.CustomerContactList.getTableName());
		dto.setModule(Customize.CustomerContactList.getModule());
		
		BaseResponseEntity<QuerySupplierResponse> entity = new BaseResponseEntity<>();
		List<String> showFields = new ArrayList<String>();//显示哪些字段
		showFields.add("name");//名称
		showFields.add("email");//邮箱
		showFields.add("mobile");//联系人电话
		showFields.add("telephone");//联系人生日
		showFields.add("flag");//状态
		showFields.add("sex");//性别
		showFields.add("emailCount");//邮件数量
		dto.setOperatorId(user.getOperatorId());
		entity.setData(contactManager.getContactList2(dto, contactResponseList, showFields));
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="搜索客户联系人", notes="搜索客户联系人")
	@ApiImplicitParam(name = "req", value = "搜索客户联系人请求对象", required = true, dataType = "SearchCustomerContactRequest")
	@PostMapping("searchCustomerContact")
	@Permission(require="customer.list.preview")
	public BaseResponseEntity<List<CustomerContactSearchResult>> searchCustomerContact(HttpServletRequest request,@RequestBody SearchCustomerContactRequest req){
		BaseResponseEntity<List<CustomerContactSearchResult>> entity = new BaseResponseEntity<List<CustomerContactSearchResult>>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		SearchCustomerContactParam dto = new SearchCustomerContactParam();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getSwitchOperatorId());
		List<CustomerContactSearchResult> datas = this.customerService.customerContactSearch(dto);
		if(req.isPaging()){
			datas = ((Page<CustomerContactSearchResult>)datas).getResult();
			entity.setTotalRecords(((Page<CustomerContactSearchResult>)datas).getTotal());
			entity.setTotalPage(((Page<CustomerContactSearchResult>)datas).getPages());
		}
		entity.setData(datas);
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="搜索公海客户联系人", notes="搜索公海客户联系人")
	@ApiImplicitParam(name = "req", value = "搜索公海客户联系人请求对象", required = true, dataType = "SearchCustomerContactRequest")
	@PostMapping("searchHighSeasCustomerContact")
	@Permission(require="customer.list.preview")
	public BaseResponseEntity<List<CustomerContactSearchResult>> searchHighSeasCustomerContact(HttpServletRequest request,@RequestBody SearchCustomerContactRequest req){
		BaseResponseEntity<List<CustomerContactSearchResult>> entity = new BaseResponseEntity<List<CustomerContactSearchResult>>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		SearchCustomerContactParam dto = new SearchCustomerContactParam();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getSwitchOperatorId());
		List<CustomerContactSearchResult> datas = this.customerService.highSeasCustomerContactSearch(dto);
		if(req.isPaging()){
			datas = ((Page<CustomerContactSearchResult>)datas).getResult();
			entity.setTotalRecords(((Page<CustomerContactSearchResult>)datas).getTotal());
			entity.setTotalPage(((Page<CustomerContactSearchResult>)datas).getPages());
		}
		entity.setData(datas);
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="查询客户联系人明细(参数id为空则为新增)", notes="查询联系人明细(参数id为空则为新增)")
	@ApiImplicitParam(name = "req", value = "查询客户明细请求对象", required = true, dataType = "GetCustomerContactRequest")
	@PostMapping("getCustomerContactDetail")
	@Permission(require="customer.list.edit")
	public BaseResponseEntity<List<EditDetailResponse>> getCustomerContactDetail(HttpServletRequest request,@RequestBody GetCustomerContactRequest req){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		SupplierDetailDto dto = new SupplierDetailDto();
		dto.setId(req.getId());
		dto.setOperatorId(user.getOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setRoleId(user.getUser().getRoleId());
		dto.setResourceId(Customize.CustomerContactList.getResourceId());
		dto.setTableName(Customize.CustomerContactList.getTableName());
		dto.setModule(Customize.CustomerContactList.getModule());
		
		if(req.getCustomerId() != null){
			String type = customerService.queryByKey(req.getCustomerId()).getType();
			dto.setColumnCondition(type);
		}
		else if(req.getId() != null){
			String type = customerService.queryByKey(contactManager.selectByPrimaryKey(req.getId()).getCustomerId()).getType();
			dto.setColumnCondition(type);
		}
		List<EditDetailResponse> details = contactManager.getCustomerContactEditArray(dto);
		return BaseEntityUtils.successOne(details);
	}
	
	
	@ApiOperation(value="获取客户和联系人编辑字段", notes="获取客户和联系人编辑字段")
	@PostMapping("GetCustomerAndContact")
	@Permission(require="customer.list.edit")
	@VolumeLimit
	public BaseResponseEntity<Map<String,List<EditDetailResponse>>> getCustomerAndContactEdit(HttpServletRequest request,@RequestBody ObjectAndAttachEditRequest req){
		Map<String,List<EditDetailResponse>> result = new HashMap<>();
		BaseResponseEntity<Map<String,List<EditDetailResponse>>> entity = new BaseResponseEntity<>();
		
		SupplierDetailDto dto = new SupplierDetailDto();
		dto.setId(req.getId());
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setRoleId(user.getUser().getRoleId());
		
		dto.setResourceId(Customize.CustomerEdit.getResourceId());
		dto.setTableName(Customize.CustomerEdit.getTableName());
		dto.setModule(Customize.CustomerEdit.getModule());
		List<EditDetailResponse> customerDetails = customerManager.getCustomerEditArray(dto);
		result.put("basic", customerDetails);
		
		dto.setResourceId(Customize.CustomerContactList.getResourceId());
		dto.setTableName(Customize.CustomerContactList.getTableName());
		dto.setModule(Customize.CustomerContactList.getModule());
		dto.setId(req.getAttachId());
		List<EditDetailResponse> contactDetails = contactManager.getCustomerContactEditArray(dto);
		result.put("contact", contactDetails);
		entity.setData(result);
		entity.setSuccess(true);
		return entity;
		
	}
	
	@ApiOperation(value="客户联系人修改(参数id为空则为新增)", notes="客户联系人修改(参数id为空则为新增)")
	@ApiImplicitParam(name = "req", value = "客户修改请求对象", required = true, dataType = "InsertOrUpdateAttachRequest")
	@PostMapping("insertOrUpdateCustomerContact")
	@Permission(require="customer.list.edit")
	@VolumeLimit
	public BaseResponseEntity<CustomerContact> insertOrUpdateCustomerContact(HttpServletRequest request,@RequestBody InsertOrUpdateAttachRequest req) throws LimitException{
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		BaseResponseEntity<CustomerContact> entity = new BaseResponseEntity<CustomerContact>();
		if(req.getAttachId()==null){
			entity.setSuccess(false);
			entity.setErrMsg("请先保存供应商！");
		}else{
			InsertOrUpdateDto dto = new InsertOrUpdateDto();
			dto.setValues(req.getModels());
			dto.setOldValue(req.getOldValue());
			dto.setId(req.getId());
			dto.setTableName(Customize.CustomerContactList.getTableName());
			dto.setAttachId(req.getAttachId());
			dto.setRoleId(user.getRoleId());
			dto.setOperatorId(user.getOperatorId());
			dto.setSwitchOperatorId(user.getSwitchOperatorId());
			dto.setCompanyId(user.getCompanyId());
			contactManager.insertOrUpdateContact(dto);
		}
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="删除客户联系人", notes="删除客户联系人")
	@ApiImplicitParam(name = "req", value = "删除客户联系人对象", required = true, dataType = "IdRequest")
	@PostMapping("deleteCustomerContact")
	@Permission(require="customer.list.edit")
	public BaseResponseEntity<SuccessResponse> deleteCustomerContact(HttpServletRequest request,@RequestBody IdRequest req){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		BaseResponseEntity<SuccessResponse> entity = new BaseResponseEntity<SuccessResponse>();
		contactManager.deleteContact(req.getId(), user.getOperatorId(),user.getSwitchOperatorId());
		entity.setSuccess(true);
		entity.setData(new SuccessResponse(true));
		return entity;
	}
	
	
	@ApiOperation(value="修改客户联系人状态", notes="修改客户联系人状态")
	@ApiImplicitParam(name = "req", value = "修改客户联系人状态对象", required = true, dataType = "UpdateStatusRequest")
	@PostMapping("updateCustomerContactStatus")
	@Permission(require="customer.list.edit")
	public BaseResponseEntity<SuccessResponse> updateCustomerContactStatus(HttpServletRequest request,@RequestBody UpdateStatusRequest req){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		BaseResponseEntity<SuccessResponse> entity = new BaseResponseEntity<SuccessResponse>();
		contactManager.updateCustomerContactStatus(req.getId(), user.getOperatorId(),user.getSwitchOperatorId(),req.getFlag());
		entity.setSuccess(true);
		entity.setData(new SuccessResponse(true));
		return entity;
	}
	
	
	@ApiOperation(value="查询最近7天过生日的人", notes="查询最近7天过生日的人")
	@ApiImplicitParam(name = "req", value = "查询最近7天过生日的人请求对象", required = true, dataType = "BasePage")
	@PostMapping("getCustomerBirthdayContact")
	@Permission(require="customer.list.preview")
	public BaseResponseEntity<List<CustomerBirthdayDto>> getCustomerBirthdayContact(HttpServletRequest request,@RequestBody BasePage req){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		BaseResponseEntity<List<CustomerBirthdayDto>> entity = new BaseResponseEntity<>();
		QueryCustomerContactBirthdayDto dto = new QueryCustomerContactBirthdayDto();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getSwitchOperatorId());
		List<CustomerBirthdayDto> contacts = contactManager.getCustomerBirthdayContact(dto);
		if(req.isPaging()){
			entity.setData(((Page<CustomerBirthdayDto>)contacts).getResult());
			entity.setTotalRecords(((Page<CustomerBirthdayDto>)contacts).getTotal());
			entity.setTotalPage(((Page<CustomerBirthdayDto>)contacts).getPages());
		}else{
			entity.setData(contacts);
		}
		entity.setSuccess(true);
		return entity;
	}
	
	
	@ApiOperation(value="查询客户日志", notes="查询客户日志")
	@ApiImplicitParam(name = "req", value = "查询客户日志", required = true, dataType = "GetCustomerLogRequest")
	@PostMapping("getCustomerLogs")
	@NeedLogin
	public BaseResponseEntity<List<LogInfoDto>> getCustomerLogs(HttpServletRequest request, @RequestBody GetCustomerLogRequest req) throws IOException{
		BaseResponseEntity<List<LogInfoDto>> entity = new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		Map<String, Object> searchMap = new HashMap<>();
		searchMap.put("companyId", user.getCompanyId());
		
		//自己或下属或公海的客户/供应商，查询所有操作日志。 上级共享的客户(包含全开放)，只查询当前业务员的操作日志。
		List<UserInfoDto> list = redisService.getOperatorAssignment(user.getCompanyId(), user.getSwitchOperatorId(),1);
		List<Long> operatorIds = new ArrayList<Long>();
		for(UserInfoDto userInfo : list){
			operatorIds.add(userInfo.getId());
		}
		
		Long operatorId = user.getSwitchOperatorId();
		if(req.getCid() != null){
			searchMap.put("cid", req.getCid());
			operatorId = getSearchCustomerLogOperatorId(user.getCompanyId(),req.getCid(),user.getSwitchOperatorId(),operatorIds);
			
			//判断邮件是否共享
			CustomerWithBLOBs customer = customerService.queryByKey(req.getCid());
			if(customer.getPublicEmail().equals(1) && customer.getOperatorIds() != null){
				List<Long> ids = new ArrayList<Long>();
				String[] opids = customer.getOperatorIds().split(",");
				for(String id : opids){
					ids.add(Long.valueOf(id));
				}
				searchMap.put("publicEmail", true);
				searchMap.put("shareCustomerIds", ids);
			}
			
		}
		
		searchMap.put("operatorId", operatorId);
		
		if(StringUtils.isNotBlank(req.getBusType()))
			searchMap.put("tableName", req.getBusType());
		else {
			List<String> modules = getOperatorModules(user);
			searchMap.put("tableName", StringUtils.join(modules, ","));
			if(modules.size() == 0){
				entity.setSuccess(true);
				entity.setTotalRecords(0l);
				return entity;
			}
				
		}
//		List<Long> shareCustomerIds = customerService.selectOperatorShareCustomerIds(user.getCompanyId(), user.getSwitchOperatorId());
		searchMap.put("beginDate", req.getBeginDate());
		searchMap.put("endDate", req.getEndDate());
		searchMap.put("pageStart", req.getPageStart());
		searchMap.put("pageSize", req.getPageSize());
		searchMap.put("from", "app");
//		if(req.getCid()==null)
//			searchMap.put("shareCustomerIds", shareCustomerIds);
		
		BaseResponseEntity<List<LogInfoDto>> result = EsSearchUtil.searchDataList(EsSearchUrlEnum.LOG_SEARCH.getUrl(propertiesEntity.getEsUrl()), searchMap, LogInfoDto.class);
		
		customerManager.convertCustomerLogData(result.getData(), user.getSwitchOperatorId());
		
		entity.setTotalPage((int)result.getTotalPage(req.getPageSize()));
		entity.setTotalRecords(result.getTotalRecords());
		entity.setData(result.getData());
		entity.setSuccess(result.isSuccess());
		return entity;
	}
	
	//自己或下属或公海的客户/供应商，查询所有操作日志。 上级共享的客户(包含全开放)，只查询当前业务员的操作日志。
	private Long getSearchCustomerLogOperatorId(Long companyId,Long customerId,Long operatorId,List<Long> operatorIdList) throws CommonException{
		
		//自己或下属或公海的客户/供应商，查询所有操作日志。 上级共享的客户(包含全开放)，只查询当前业务员的操作日志。
		Long searchOperatorId = null;
		
		//查询客户明细
		Customer customer = this.customerService.queryByKey(customerId);
		
		if(customer==null || customer.getCompanyId() == null) {
			throw new CommonException("客户ID不存在！");
		}
		
		if(customer.getCompanyId().longValue() != companyId.longValue()) {
			throw new CommonException("无效的客户ID");
		}
		
		if(customer.getFlag().intValue()!=1){
			throw new CommonException("客户已删除！");
		}
		
		//公海或自己或下属的客户
		if (customer.getOperatorId() == null || customer.getOperatorId() == 0L || customer.getOperatorId().longValue() == operatorId || operatorIdList.contains(customer.getOperatorId().longValue())) {
			
		}
		//其他情况就是上级全开放或共享给我的客户
		else{
			if(customer.getOpen() != null && customer.getOpen() == 1){
				searchOperatorId = operatorId;
			}else{
				String operatorIds = customer.getOperatorIds();
				logger.info("=============================operatorIds+{}",operatorIds);
				if (operatorIds != null) {
					List<String> shareOperatorIdList = Arrays.asList(operatorIds.split(","));
					if (shareOperatorIdList.contains(operatorId.toString())) {
						searchOperatorId = operatorId;
					}
				}
			}
			//searchOperatorId为空表示没有此客户的查询条件
			if (searchOperatorId == null) {
				throw new CommonException("没有客户的查询权限！");
			}
		}
		
		return searchOperatorId;
	}
	
	
	@ApiOperation(value="按天统计客户日志", notes="按天统计日志")
	@ApiImplicitParam(name = "req", value = "按天统计日志", required = true, dataType = "GetCustomerLogRequest")
	@PostMapping("countLogByDay")
	@NeedLogin
	public BaseResponseEntity<List<LogCountByDayInfo>> countLogByDay(HttpServletRequest request,@RequestBody CountCustomerLogRequest req) throws IOException{
		BaseResponseEntity<List<LogCountByDayInfo>> entity = new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		Map<String, Object> searchMap = new HashMap<>();
//		List<Long> shareCustomerIds = customerService.selectOperatorShareCustomerIds(user.getCompanyId(), user.getSwitchOperatorId());
		searchMap.put("companyId", user.getCompanyId());
		searchMap.put("operatorId", user.getSwitchOperatorId());
		searchMap.put("from", "app");
//		searchMap.put("shareCustomerIds", shareCustomerIds);
		if(req.getCid()!=null){
			searchMap.put("cid", req.getCid());
			Customer customer = customerManager.selectByPrimaryKey(req.getCid());
			if(!String.valueOf(user.getSwitchOperatorId()).equals(String.valueOf(customer.getOperatorId())))//当前客户所属不是当前切换人-过滤别人的信息
				searchMap.put("operatorId", user.getSwitchOperatorId());
		}else{
			searchMap.put("operatorId", user.getSwitchOperatorId());
		}
		if(StringUtils.isNotBlank(req.getBusType()))
			searchMap.put("tableName", req.getBusType());
//		else {
//			List<String> modules = getOperatorModules(user);
//			searchMap.put("tableName", StringUtils.join(modules, ","));
//			if(modules.size() == 0){
//				entity.setSuccess(true);
//				entity.setData(new ArrayList<LogCountByDayInfo>());
//				return entity;
//			}
//				
//		}
		searchMap.put("beginDate", req.getBeginDate());
		searchMap.put("endDate", req.getEndDate());
		
		BaseResponseEntity<List<LogCountByDayInfo>> result = EsSearchUtil.searchDataList(EsSearchUrlEnum.LOG_COUNT_DAY.getUrl(propertiesEntity.getEsUrl()), searchMap, LogCountByDayInfo.class);
		
		entity.setData(result.getData());
		entity.setSuccess(result.isSuccess());
		return entity;
	}
	

	/**
	 * 查询商业数据列表
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询商业数据列表", notes="查询商业数据列表")
	@ApiImplicitParam(name = "req", value = "查询商业数据列表请求对象", required = true, dataType = "QueryBsDataRequest")
	@PostMapping("queryBsDataList")
	public BaseResponseEntity<List<BsDataDto>> queryBsDataList(HttpServletRequest request,@RequestBody QueryBsDataRequest req){

		BaseResponseEntity<List<BsDataDto>> entity = new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		BsDataResponse<List<BsDataDto>> result = new BsDataResponse<List<BsDataDto>>();	
		entity.setData(result.getData());
		
		QueryBsDataDto dto = new QueryBsDataDto();
		JoinfBeanUtils.copyProperties(dto, req);	
		dto.setUserCompanyId(user.getUser().getCompanyId());
		
		result = customerManager.queryBsDataList(dto);
		
		entity.setTotalPage(result.getTotalPage());
		entity.setTotalRecords(result.getTotalRecords());
		entity.setData(result.getData());
		entity.setSuccess(result.isSuccess());
		entity.setErrMsg(result.getErrMsg());
		
		return entity;
	}
	
	
	/**
	 * 客户标记为：星标、取消星标
	 * @param request
	 * @param req
	 * @return
	 */
	@ApiOperation(value="标记客户状态", notes="标记客户状态")
	@ApiImplicitParam(name = "req", value = "标记客户状态请求对象", required = true, dataType = "UpdateCustomerForMarkRequest")
	@PostMapping(value = "/updateCustoemrForMark")
	@ResponseBody
	@NeedLogin
	@ResubmitData
	public BaseResponseEntity<Integer> updateCustoemrForMark(HttpServletRequest request, @RequestBody UpdateCustomerForMarkRequest req) {
		
		BaseResponseEntity<Integer> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		UpdateCustomerForMarkDto updateDto = JoinfBeanUtils.copyToNewBean(UpdateCustomerForMarkDto.class, req);
		updateDto.setCompanyId(user.getCompanyId());
		entity.setData(customerManager.updateCustomerForMark(updateDto));
		
				
		return entity;
	}
	
	
	public List<String> getOperatorModules(SessionUser user){
		List<String> modules = new ArrayList<String>();
		//权限判断    app 的行事日程中包含 客户、邮件、跟进、订单、报价、edm、客户合并等日志，需要判断后传不同的参数上去
		if(this.checkHas(user.getOperatorId(),user.getSwitchOperatorId(), Constants.RESOURCE_CUSTOMER_ID)){
			modules.add("customer");
			modules.add("transfer");
		}
		if(this.checkHas(user.getOperatorId(),user.getSwitchOperatorId(), Constants.RESOURCE_PRODUCT_ID)){
			modules.add("product");
		}
		if(this.checkHas(user.getOperatorId(),user.getSwitchOperatorId(), Constants.RESOURCE_QUOTE_ID)){
			modules.add("quote");
		}
		if(this.checkHas(user.getOperatorId(),user.getSwitchOperatorId(), Constants.RESOURCE_ORDER_ID)){
			modules.add("order");
		}
		if(this.checkHas(user.getOperatorId(),user.getSwitchOperatorId(), Constants.RESOURCE_CUSTOMER_FOLLOW_ID)){
			modules.add("follow");
		}
		if(this.checkHas(user.getOperatorId(),user.getSwitchOperatorId(), Constants.RESOURCE_EMAIL_ID)){
			modules.add("email");
			modules.add("edmEmail");
		}
		if(this.checkHas(user.getOperatorId(),user.getSwitchOperatorId(), Constants.RESOURCE_SUPPLIER_ID)){
			modules.add("supplier");
		}
//		List<String> modules = new ArrayList<String>();
//		if(PermissionInterceptor.hasPermission(user, "customer.list.preview")){
//			modules.add("customer");
//			modules.add("transfer");
//		}
//		if(PermissionInterceptor.hasPermission(user, "product.list.preview")){
//			modules.add("product");
//		}
//		if(PermissionInterceptor.hasPermission(user, "quote.list.preview")){
//			modules.add("quote");
//		}
//		if(PermissionInterceptor.hasPermission(user, "order.list.preview")){
//			modules.add("order");
//		}
//		if(PermissionInterceptor.hasPermission(user, "follow.list.preview")){
//			modules.add("follow");
//		}
//		if(PermissionInterceptor.hasPermission(user, "email.list.preview")){
//			modules.add("email");
//		}
//		if(PermissionInterceptor.hasPermission(user, "supplier.list.preview")){
//			modules.add("supplier");
//		}
		return modules;
	}
	
	
	
	/**
	   * 处理其他	
	   * @param customerDuplicateDTOList
	   * @param map
	   * @param request
	   */
	  private void dealCustomerDuplicateDTOList(List<DuplicateCustomerDTO> customerDuplicateDTOList,
			  QueryCustomerDto dto, HttpServletRequest request) {
		  if(CollectionUtils.isNotEmpty(customerDuplicateDTOList)) {
			Company company = SessionUtils.getCompanyInfo(request);
			Operator operator = SessionUtils.getOperatorInfo(request);
			//当前用户可管理人员
			List<UserInfoDto> assignmentUsers = assignmentService.selectAssignmentUserList(company.getId(), operator.getId());
			  List<Long> ids = new ArrayList<>();
			  if(CollectionUtils.isNotEmpty(assignmentUsers)){
				  for(UserInfoDto userInfo : assignmentUsers) {
					  ids.add(userInfo.getId());
				   }
			   }
			  //获取公司下的所有操作员
			  List<UserInfoDto> userInfoList = operatorService.getCompanyAllOperators(company.getId());
			  Map<Long,String> userInfoMap = new HashMap<Long,String>();
			  for(UserInfoDto us : userInfoList){
				  userInfoMap.put(us.getId(), us.getChineseName());
			  }
			 //处理
			 for(DuplicateCustomerDTO cuplicateCustomerDTO : customerDuplicateDTOList) {
				 Long operatorId = cuplicateCustomerDTO.getOperatorId();
				 //设置操作员名称
				 cuplicateCustomerDTO.setSalesmanName(userInfoMap.get(operatorId));
				//有权限
				 cuplicateCustomerDTO.setUserPermit(true);
				 //判断是否是共享客户
				 String operatorIds = cuplicateCustomerDTO.getOperatorIds();
				 //普通的处理
				 if(!dto.isHighSeas()){
					 if(!ids.contains(operatorId)) {//没有权限的
						//没有权限
						 cuplicateCustomerDTO.setUserPermit(false);
						 if(dto.getName() != null) {//替换客户名称
							 if(cuplicateCustomerDTO.getName() != null && cuplicateCustomerDTO.getName().contains(dto.getName())){
								 cuplicateCustomerDTO.setName(ReplaceUtil.replaceStrNotIn(cuplicateCustomerDTO.getName(), dto.getName()));
								 cuplicateCustomerDTO.setMatchItem(ReplaceUtil.replaceStrNotIn(cuplicateCustomerDTO.getName(), dto.getName()));
								 continue;
							 }
						 }
						 if(dto.getContactName() != null) {//替换联系人名称
							 if(cuplicateCustomerDTO.getContactName() != null && cuplicateCustomerDTO.getContactName().contains(dto.getContactName())){
								 cuplicateCustomerDTO.setContactName(ReplaceUtil.replaceStrNotIn(cuplicateCustomerDTO.getContactName(), dto.getContactName()));
								 cuplicateCustomerDTO.setMatchItem(ReplaceUtil.replaceStrNotIn(cuplicateCustomerDTO.getContactName(), dto.getContactName()));
								 continue;
							 }
						 }
						 if(dto.getContactWay() != null) {//替换联系方式
							 if(cuplicateCustomerDTO.getContactWay() != null && cuplicateCustomerDTO.getContactWay().contains(dto.getContactWay())){
								 cuplicateCustomerDTO.setContactWay(ReplaceUtil.replaceStrNotIn(cuplicateCustomerDTO.getContactWay(), dto.getContactWay()));
								 cuplicateCustomerDTO.setMatchItem(ReplaceUtil.replaceStrNotIn(cuplicateCustomerDTO.getContactWay(), dto.getContactWay()));
								 continue;
							 }
						 }
						 if(dto.getWebSite() != null) {//替换网站
							 if(cuplicateCustomerDTO.getWebSite() != null && cuplicateCustomerDTO.getWebSite().contains(dto.getWebSite())){
								 cuplicateCustomerDTO.setWebSite(ReplaceUtil.replaceStrNotIn(cuplicateCustomerDTO.getWebSite(), dto.getWebSite()));
								 cuplicateCustomerDTO.setMatchItem(ReplaceUtil.replaceStrNotIn(cuplicateCustomerDTO.getWebSite(), dto.getWebSite()));
								 continue;
							 }
						 }
						 if(dto.getContactAddress() != null){//替换联系地址
							 if(cuplicateCustomerDTO.getContactAddress() != null && cuplicateCustomerDTO.getContactAddress().contains(dto.getContactAddress())){
								 cuplicateCustomerDTO.setContactAddress(ReplaceUtil.replaceStrNotIn(cuplicateCustomerDTO.getContactAddress(), dto.getContactAddress()));
								 cuplicateCustomerDTO.setMatchItem(ReplaceUtil.replaceStrNotIn(cuplicateCustomerDTO.getContactAddress(), dto.getContactAddress()));
								 continue;
							 }
						 }
						 
					 }
					 //共享处理
					 if(null != operatorIds){
						 List<String> operatorIdsList = Arrays.asList(operatorIds.split(","));
						 if(!operatorIdsList.contains(operatorId)) {//没有权限的
							 if(dto.getName() != null) {//替换客户名称
								 if(cuplicateCustomerDTO.getName() != null && cuplicateCustomerDTO.getName().contains(dto.getName())){
									 cuplicateCustomerDTO.setName(ReplaceUtil.replaceStrNotIn(cuplicateCustomerDTO.getName(), dto.getName()));
									 cuplicateCustomerDTO.setMatchItem(ReplaceUtil.replaceStrNotIn(cuplicateCustomerDTO.getName(), dto.getName()));
									 continue;
								 }
							 }
							 if(dto.getContactName() != null) {//替换联系人名称
								 if(cuplicateCustomerDTO.getContactName() != null && cuplicateCustomerDTO.getContactName().contains(dto.getContactName())){
									 cuplicateCustomerDTO.setContactName(ReplaceUtil.replaceStrNotIn(cuplicateCustomerDTO.getContactName(), dto.getContactName()));
									 cuplicateCustomerDTO.setMatchItem(ReplaceUtil.replaceStrNotIn(cuplicateCustomerDTO.getContactName(), dto.getContactName()));
									 continue;
									 
								 }
							 }
							 if(dto.getContactWay() != null) {//替换联系方式
								 if(cuplicateCustomerDTO.getContactWay() != null && cuplicateCustomerDTO.getContactWay().contains(dto.getContactWay())){
									 cuplicateCustomerDTO.setContactWay(ReplaceUtil.replaceStrNotIn(cuplicateCustomerDTO.getContactWay(), dto.getContactWay()));
									 cuplicateCustomerDTO.setMatchItem(ReplaceUtil.replaceStrNotIn(cuplicateCustomerDTO.getContactWay(), dto.getContactWay()));
									 continue;
									 
								 }
							 }
							 if(dto.getWebSite() != null) {//替换网站
								 if(cuplicateCustomerDTO.getWebSite() != null && cuplicateCustomerDTO.getWebSite().contains(dto.getWebSite())){
									 cuplicateCustomerDTO.setWebSite(ReplaceUtil.replaceStrNotIn(cuplicateCustomerDTO.getWebSite(), dto.getWebSite()));
									 cuplicateCustomerDTO.setMatchItem(ReplaceUtil.replaceStrNotIn(cuplicateCustomerDTO.getWebSite(), dto.getWebSite()));
									 continue;
									 
								 }
							 }
							 if(dto.getContactAddress() != null){//替换联系地址
								 if(cuplicateCustomerDTO.getContactAddress() != null && cuplicateCustomerDTO.getContactAddress().contains(dto.getContactAddress())){
									 cuplicateCustomerDTO.setContactAddress(ReplaceUtil.replaceStrNotIn(cuplicateCustomerDTO.getContactAddress(), dto.getContactAddress()));
									 cuplicateCustomerDTO.setMatchItem(ReplaceUtil.replaceStrNotIn(cuplicateCustomerDTO.getContactAddress(), dto.getContactAddress()));
									 continue;
								 }
							 }
						 }
					 }
						 
				 }
				 if(dto.getName() != null) {//替换客户名称
					 if(null != cuplicateCustomerDTO.getName() && cuplicateCustomerDTO.getName().contains(dto.getName())){
						 cuplicateCustomerDTO.setMatchItem(cuplicateCustomerDTO.getName());
						 continue;
					 }
				 }
				 if(dto.getContactName() != null) {//替换联系人名称
					 if(null != cuplicateCustomerDTO.getContactName() && cuplicateCustomerDTO.getContactName().contains(dto.getContactName())){
						 cuplicateCustomerDTO.setMatchItem(cuplicateCustomerDTO.getContactName());
						 continue;
					 }
				 }
				 if(dto.getContactWay() != null) {//替换联系方式
					 if(null != cuplicateCustomerDTO.getContactWay() && cuplicateCustomerDTO.getContactWay().contains(dto.getContactWay())){
						 cuplicateCustomerDTO.setMatchItem(cuplicateCustomerDTO.getContactWay());
						 continue;
					 }
				 }
				 if(dto.getWebSite() != null) {//替换网站
					 if(null != cuplicateCustomerDTO.getWebSite() && cuplicateCustomerDTO.getWebSite().contains(dto.getWebSite())){
						 cuplicateCustomerDTO.setMatchItem(cuplicateCustomerDTO.getWebSite());
						 continue;
					 }
				 }
				 if(dto.getContactAddress() != null) {//替换联系地址
					 if(null != cuplicateCustomerDTO.getContactAddress() && cuplicateCustomerDTO.getContactAddress().contains(dto.getContactAddress())){
						 cuplicateCustomerDTO.setMatchItem(cuplicateCustomerDTO.getContactAddress());
						 continue;
					 }
				 }
			 }
		}
	}
}
