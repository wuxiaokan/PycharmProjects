package com.joinf.request.newYear;

import java.io.Serializable;

/**
 * Description: 年度账单统计查询请求参数
 * @author cuichuanlei
 * @created 2019年1月21日 下午1:38:44
 */
public class NewYearStatisticRequest implements Serializable{
	
	private static final long serialVersionUID = -7217815382180098509L;
	/** 企业id */
	protected Long companyId;
	/**
	 * 业务员id
	 */
	protected Long operatorId;
	
	/**
	 * 登陆业务员id
	 */
	protected Long loginOperatorId;
	
	/**
	 * 用户名
	 */
	protected String username;
	
	/**
	 * 密码
	 */
	protected String password;
	

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public Long getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(Long operatorId) {
		this.operatorId = operatorId;
	}

	public Long getLoginOperatorId() {
		return loginOperatorId;
	}

	public void setLoginOperatorId(Long loginOperatorId) {
		this.loginOperatorId = loginOperatorId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	

}
