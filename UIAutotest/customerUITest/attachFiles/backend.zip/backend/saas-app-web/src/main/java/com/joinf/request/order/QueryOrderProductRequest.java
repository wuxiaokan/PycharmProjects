package com.joinf.request.order;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 查询订单商品
 *
 * @author lyj
 * @date 2018年1月24日 下午3:31:44
 */
public class QueryOrderProductRequest {
	
	@ApiModelProperty("订单id")
	private Long orderId;

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

}
