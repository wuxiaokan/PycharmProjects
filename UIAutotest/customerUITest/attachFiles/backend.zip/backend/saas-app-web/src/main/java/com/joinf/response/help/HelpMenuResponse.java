package com.joinf.response.help;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 帮助文档菜单
 *
 * @author lyj
 * @date 2018年1月30日 上午9:48:16
 */
public class HelpMenuResponse {
	
	
	@ApiModelProperty("id")
	private Long id;
	
	@ApiModelProperty("图片")
	private String pictureUrl;
	
	@ApiModelProperty("标题")
	private String title;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPictureUrl() {
		return pictureUrl;
	}

	public void setPictureUrl(String pictureUrl) {
		this.pictureUrl = pictureUrl;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

}
