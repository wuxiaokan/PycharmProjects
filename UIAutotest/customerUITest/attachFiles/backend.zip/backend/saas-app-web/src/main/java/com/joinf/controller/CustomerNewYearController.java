package com.joinf.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.joinf.entity.generator.Company;
import com.joinf.entity.generator.DictCountry;
import com.joinf.interfaces.CustomerNewYearExService;
import com.joinf.mapper.CompanyExMapper;
import com.joinf.mapper.DictCountryExMapper;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("customernewyear")
@Api(tags = "年度统计")
public class CustomerNewYearController {
	
	private Logger logger = LoggerFactory.getLogger(CustomerNewYearController.class.getName());

	@Autowired
	private CompanyExMapper exMapper;
	
	@Autowired
	private CustomerNewYearExService customerNewYearExService;
	@Autowired
	private DictCountryExMapper dictCountryExMapper;

	@ApiOperation(value = "年度统计", notes = "年度统计")
	@PostMapping("statistics")
	public void statistics() {
		
		
		logger.info("======================================年度统计开始=================================================");
		//查询国家和二级简码
		List<DictCountry> dictList = dictCountryExMapper.selectCountryTwoNo();

		Map<String, Object> dictMap = dictList.stream().collect(Collectors.toMap(DictCountry::getTwoNo, DictCountry::getDistrict));
		Map<String, Object> countryMap = dictList.stream().collect(Collectors.toMap(DictCountry::getTwoNo, DictCountry::getName));

		int count = exMapper.selectAllCompanyCount();
		int pageSize = 1000;
		int pageCount = count%pageSize == 0 ? count%pageSize : count/pageSize +1;
		Map<String,Object> map = new HashMap<String,Object>();
		for(int i = 1; i<= pageCount; i++){
			map.put("pageStart", (i -1) * pageSize);
			map.put("pageSize", pageSize);
			// 查询所有企业信息
			List<Company> list = exMapper.selectCompanyByPage(map);
			logger.info(JSON.toJSONString(list));
			for(Company company : list){
				//统计登陆时段、次数相关
				customerNewYearExService.statisticsLoginCountx(company.getId());
				//查询新增客户国家地区统计
				customerNewYearExService.statisticsContinentAndCountry(company.getId());
				//统计各种第一次
				customerNewYearExService.statisticsTheFirst(company.getId());
				//收信、 发信 等  邮件统计
				customerNewYearExService.statisticsEmailCount(company.getId());
				//收EDM、 发EDM 等  邮件统计
				customerNewYearExService.statisticEdmCount(company.getId(),dictMap,countryMap);
				//用户画像 
				customerNewYearExService.statisticUserFaces(company.getId());
				//查询报价订单数量和最多的国家、洲  
				customerNewYearExService.statisticQuoteOrderCount(company.getId());
				
				
			}
			
		}
		
		
		
		logger.info("======================================年度统计结束=================================================");
		
		
	}

}
