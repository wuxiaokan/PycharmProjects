package com.joinf.response.customer;

import io.swagger.annotations.ApiModelProperty;

public class CardScannerAmountResponse {
	@ApiModelProperty(value ="总数量")
	private Integer totalAmount;
	
	@ApiModelProperty(value ="已使用数量")
	private Integer useAmount;
	
	
	public Integer getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Integer totalAmount) {
		this.totalAmount = totalAmount;
	}
	public Integer getUseAmount() {
		return useAmount;
	}
	public void setUseAmount(Integer useAmount) {
		this.useAmount = useAmount;
	}
	
	
	
	
	

}
