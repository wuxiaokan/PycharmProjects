package com.joinf.request.product;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

import com.joinf.utils.base.BasePage;

/**
 * @author lyj
 * @Description: 查询产品
 * @data 2017年12月4日 下午2:38:17
 */
public class QueryProductRequest extends BasePage implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2596363725471279783L;

	@ApiModelProperty(value ="排序字段")
	private String sortColumn;
	
	@ApiModelProperty(value ="排序类别")
	private String sortType;
	
	@ApiModelProperty(value ="关键词")
	private String key;
	
	@ApiModelProperty(value ="1个人 0企业")
	private Integer type;
	
	@ApiModelProperty(value ="分组id--为空表示全部")
	private Long groupId;

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getSortColumn() {
		return sortColumn;
	}

	public void setSortColumn(String sortColumn) {
		this.sortColumn = sortColumn;
	}

	public String getSortType() {
		return sortType;
	}

	public void setSortType(String sortType) {
		this.sortType = sortType;
	}
}
