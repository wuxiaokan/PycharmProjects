package com.joinf.request.customer;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * Description: 分配客户请求参数
 *
 * @author lyj
 * @date 2017年12月12日 上午10:30:22
 */
public class AssignCustomerRequest {
	
	@ApiModelProperty(value="删除客户id集合",required=true)
	private List<Long> Ids;
	
	public Long getNewOperatorId() {
		return newOperatorId;
	}

	public void setNewOperatorId(Long newOperatorId) {
		this.newOperatorId = newOperatorId;
	}

	@ApiModelProperty(value="分配客户id",required=true)
	private Long newOperatorId;

	public List<Long> getIds() {
		return Ids;
	}

	public void setIds(List<Long> ids) {
		Ids = ids;
	}

}
