package com.joinf.request.email;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;

/**
 * 删除邮件标签参数
 * 
 * @author CyNick
 *
 */
public class SaveOrEditEmailTag implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "标签ID")
	private Long id;

	@ApiModelProperty(value = "")
	private String content;

	@ApiModelProperty(value = "颜色")
	private String color;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

}
