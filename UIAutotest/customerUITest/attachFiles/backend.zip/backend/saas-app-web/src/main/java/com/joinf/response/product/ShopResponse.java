package com.joinf.response.product;

import org.apache.commons.lang3.StringUtils;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 获取公司网店
 *
 * @author lyj
 * @date 2018年1月15日 上午11:10:35
 */
public class ShopResponse {
	
	@ApiModelProperty("网店id")
	private Long id;
	
	@ApiModelProperty("网店名称")
	private String name;
	
	@ApiModelProperty("网店类型1=阿里巴巴国际站")
	private Integer type;
	
	@ApiModelProperty("网店类型名称")
	private String typeName;
	
	@ApiModelProperty("是否绑定")
	private boolean isBind =false;
	
	@SuppressWarnings("unused")
	private String aliId;
	
	public void setAliId(String aliId) {
		if(StringUtils.isNotBlank(aliId))
			this.isBind = true;
		this.aliId = aliId;
	}

	public boolean isBind() {
		return isBind;
	}

	public void setBind(boolean isBind) {
		this.isBind = isBind;
	}

	public String getTypeName() {
		if(this.type == 1)
			return "阿里巴巴国际站";
		return typeName;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}


}
