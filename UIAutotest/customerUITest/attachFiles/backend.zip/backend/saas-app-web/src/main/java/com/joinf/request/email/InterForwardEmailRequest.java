package com.joinf.request.email;

import com.joinf.request.IdArrayRequest;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 内部转发请求参数
 * @date 2018年3月9日 下午1:39:52
 */
public class InterForwardEmailRequest extends IdArrayRequest{

	@ApiModelProperty(value="转发至业务员id数组u")
	private Long[] operatorIdArray;

	public Long[] getOperatorIdArray() {
		return operatorIdArray;
	}

	public void setOperatorIdArray(Long[] operatorIdArray) {
		this.operatorIdArray = operatorIdArray;
	}

	
	
	
	
}
