package com.joinf.request.customer;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

import com.joinf.utils.base.BasePage;

public class SearchCustomerContactRequest extends BasePage{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6842878014413408817L;
	
	@ApiModelProperty(" 供应商id集合")
	private List<Long> customerIds;
	
	public List<Long> getCustomerIds() {
		return customerIds;
	}


	public void setCustomerIds(List<Long> customerIds) {
		this.customerIds = customerIds;
	}


	@ApiModelProperty("搜索关键词")
	private String key;


	public String getKey() {
		return key;
	}


	public void setKey(String key) {
		this.key = key;
	}

}
