package com.joinf.response.chat;

import io.swagger.annotations.ApiModelProperty;

public class OnlineVisitorResponse {
	
	@ApiModelProperty("会话id")
	private Long id;
	
	@ApiModelProperty("用户id")
	private String userId;
	
	@ApiModelProperty("访客token")
	private Long token;
	
	@ApiModelProperty("名称")
	private String userName;
	
	@ApiModelProperty("ip")
	private String userIp;
	
	@ApiModelProperty("系统信息")
	private String userAgent;
	
	@ApiModelProperty("客服id")
	private Long agentId;
	
	@ApiModelProperty("客服名称")
	private String agentName;
	
	@ApiModelProperty("状态 0=等候中,1=等待客服人员,2=对谈")
	private Integer state;
	
	@ApiModelProperty("在线时长")
	private Long totalTime;
	
	@ApiModelProperty("等待时长")
	private Long waitingTime;
	
	@ApiModelProperty("第一条信息")
	private String firstMessage;
	
	@ApiModelProperty("站点信息")
	private String referer;
	
	private Boolean canOpen;
	
	private Boolean canView;
	
	private Boolean canBan;
	
	private Boolean ban;
	
	@ApiModelProperty("访客邮箱")
	private String email;
	
	@ApiModelProperty("客户名称")
	private String customerName;
	
	@ApiModelProperty("客户id")
	private Long customerId;
	
	@ApiModelProperty("客户头像图片")
	private String customerImageUrl;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getCustomerImageUrl() {
		return customerImageUrl;
	}

	public void setCustomerImageUrl(String customerImageUrl) {
		this.customerImageUrl = customerImageUrl;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public Long getId() {
		return id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getToken() {
		return token;
	}

	public void setToken(Long token) {
		this.token = token;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserIp() {
		return userIp;
	}

	public void setUserIp(String userIp) {
		this.userIp = userIp;
	}

	public String getUserAgent() {
		return userAgent;
	}

	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}

	public Long getAgentId() {
		return agentId;
	}

	public void setAgentId(Long agentId) {
		this.agentId = agentId;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Long getTotalTime() {
		return totalTime;
	}

	public void setTotalTime(Long totalTime) {
		this.totalTime = totalTime;
	}

	public Long getWaitingTime() {
		return waitingTime;
	}

	public void setWaitingTime(Long waitingTime) {
		this.waitingTime = waitingTime;
	}

	public String getFirstMessage() {
		return firstMessage;
	}

	public void setFirstMessage(String firstMessage) {
		this.firstMessage = firstMessage;
	}

	public String getReferer() {
		return referer;
	}

	public void setReferer(String referer) {
		this.referer = referer;
	}

	public Boolean getCanOpen() {
		return canOpen;
	}

	public void setCanOpen(Boolean canOpen) {
		this.canOpen = canOpen;
	}

	public Boolean getCanView() {
		return canView;
	}

	public void setCanView(Boolean canView) {
		this.canView = canView;
	}

	public Boolean getCanBan() {
		return canBan;
	}

	public void setCanBan(Boolean canBan) {
		this.canBan = canBan;
	}

	public Boolean getBan() {
		return ban;
	}

	public void setBan(Boolean ban) {
		this.ban = ban;
	}

}
