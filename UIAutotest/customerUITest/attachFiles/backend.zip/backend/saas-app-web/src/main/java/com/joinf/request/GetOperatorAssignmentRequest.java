package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 获取可管理业务员参数
 * @date 2018年3月9日 下午2:31:22
 */
public class GetOperatorAssignmentRequest {

	@ApiModelProperty(value="[1]包含自己   其他为所有可管理业务员(不包含自己)")
	private int type;
	
	@ApiModelProperty(value="1当前登入用户，2切换用户")
	private Integer dataType =1;

	public Integer getDataType() {
		return dataType;
	}

	public void setDataType(Integer dataType) {
		this.dataType = dataType;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	
}
