package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: id 请求类
 *
 * @author lyj
 * @date 2017年12月11日 下午2:18:03
 */
public class IdRequest {

	@ApiModelProperty(value="数据id",required=true)
	private Long id;
	
	@ApiModelProperty(value="跟进归属模块",required=true)
	private Integer flowModel;
	
	@ApiModelProperty(value="跟进id集合")
	private String ids;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getFlowModel() {
		return flowModel;
	}

	public void setFlowModel(Integer flowModel) {
		this.flowModel = flowModel;
	}

	public String getIds() {
		return ids;
	}

	public void setIds(String ids) {
		this.ids = ids;
	}

	
}
