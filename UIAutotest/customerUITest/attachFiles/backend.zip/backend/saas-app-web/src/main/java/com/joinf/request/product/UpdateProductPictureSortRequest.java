package com.joinf.request.product;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * Description: 修改产品排序
 *
 * @author lyj
 * @date 2018年4月10日 下午2:38:10
 */
public class UpdateProductPictureSortRequest {
	
	
	@ApiModelProperty("排序信息")
	public List<PictureSort> sorts;

	public List<PictureSort> getSorts() {
		return sorts;
	}

	public void setSorts(List<PictureSort> sorts) {
		this.sorts = sorts;
	}
	
	public static class PictureSort{
		@ApiModelProperty("产品id")
		Long id;
		
		@ApiModelProperty("排序")
		Integer sort;

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public Integer getSort() {
			return sort;
		}

		public void setSort(Integer sort) {
			this.sort = sort;
		}
	}

}

