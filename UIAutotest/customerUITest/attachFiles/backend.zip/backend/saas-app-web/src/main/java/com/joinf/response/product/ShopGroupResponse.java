package com.joinf.response.product;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 网店产品
 *
 * @author lyj
 * @date 2018年1月15日 上午11:06:13
 */
public class ShopGroupResponse {

	@ApiModelProperty("id")
	private Long id;
	
	@ApiModelProperty("分组id")
	private Long groupId;
	
	@ApiModelProperty("网店id")
	private Long shopId;
	
	@ApiModelProperty("分组名称")
	private String name;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
