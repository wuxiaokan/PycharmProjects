package com.joinf.constant;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Constants {

	/**
	 * 固定项
	 * 不需要初始化的BASIC_ID
	 */
	private static final Set<Long> FIXED_BASIC_DATA_ID_LIST = new HashSet<Long>();
	
	static {
//		-- 2:客户分类  3:国家 4:银行  9:单位  10:货币
//		性别:16   联系人状态:17  佣金方法:19  地区:32  运费计算方式:20  26:职务  37:网店币种 38:网店单位  41:PERMIT_PROHIBITED
		
		Long[] ids = {2l,3l,4l,9l,10l,16l,17l,19l,20l,32l,37l,38l,41l}; //26l职务  等t_job表集成后 把这个加进去
		
		for(Long id :ids){
			FIXED_BASIC_DATA_ID_LIST.add(id);
		}
		
	}
	
	/**
	 * 固定项BASIC_ID
	 * @return
	 */
	public static Set<Long> getFixedBasciDataIdList(){
		return FIXED_BASIC_DATA_ID_LIST;
	}
	
	public static void setIsNeedCompanyParam(Map<String,Object> map,Long basicDataId){
		if(Constants.getFixedBasciDataIdList().contains(basicDataId)){
			map.put("notCompanyId", "notCompanyId");
		}
	}
	
	/**
	 * 模块资源ID
	 */
	public final static Long RESOURCE_CUSTOMER_ID = 8L; // 客户
	public final static Long RESOURCE_PRODUCT_ID = 11L; // 产品
	public final static Long RESOURCE_EMAIL_ID = 16L; // 邮件
	public final static Long RESOURCE_QUOTE_ID = 18L; // 报价
	public final static Long RESOURCE_SUPPLIER_ID = 44L; // 供应商
	public final static Long RESOURCE_CUSTOMER_FOLLOW_ID = 90L; // 跟进
	public final static Long RESOURCE_ORDER_ID = 200L; // 订单
	public final static Long RESOURCE_CLOUD_ID = 250L; // 云盘
	public final static Long RESOURCE_MSG_ID = 282L; // 消息
	public final static Long RESOURCE_BUSINESS_ID = 294L; // 商机



	// 固定账号
	public final static Long SZHX_CENTER_ID = 40841L;
	public final static Long SZYS_CENTER_ID = 33338L;
	public final static Long RJF_CENTER_ID = 38036L;
	public final static Long FFY_CENTER_ID = 3357L;





}
