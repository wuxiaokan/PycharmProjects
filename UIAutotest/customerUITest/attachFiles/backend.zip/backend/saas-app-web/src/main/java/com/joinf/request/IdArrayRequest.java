package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 主键参数
 * @date 2018年1月7日 下午4:52:18
 */
public class IdArrayRequest {

	@ApiModelProperty(value="主键id数组")
	private Long[] idArray;

	public Long[] getIdArray() {
		return idArray;
	}

	public void setIdArray(Long[] idArray) {
		this.idArray = idArray;
	}

	
	
}
