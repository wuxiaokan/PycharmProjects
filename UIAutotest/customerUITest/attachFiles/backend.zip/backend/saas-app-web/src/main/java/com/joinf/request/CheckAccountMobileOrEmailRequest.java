package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

public class CheckAccountMobileOrEmailRequest {

	@ApiModelProperty(value="类型(1=手机,2=邮箱)",required=true)
	private Integer type;

	@ApiModelProperty(value="提供校验值",required=true)
	private String checkValue;
	
	@ApiModelProperty(value="用户名",required=true)
	private String loginName;

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getCheckValue() {
		return checkValue;
	}

	public void setCheckValue(String checkValue) {
		this.checkValue = checkValue;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
}
