package com.joinf.request.order;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * 删除订单附件参数
 *
 * @author yzq
 * @date 2019-06-19
 */
public class DeleteOrderRequest {
    @ApiModelProperty(value="删除id集合",required=true)
    private List<Long> Ids;

    public List<Long> getIds() {
        return Ids;
    }

    public void setIds(List<Long> ids) {
        Ids = ids;
    }
}
