package com.joinf.request.clouddish;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 新增或修改文件夹
 *
 * @author lyj
 * @date 2018年4月18日 下午3:22:26
 */
public class InsertOrUpdateCloudDishCatalogueRequest {
	
	@ApiModelProperty("id")
	private Long id;
	
	@ApiModelProperty("父级文件夹")
	private Long parentId;
	
	@ApiModelProperty("名称")
	private String name;
	
	@ApiModelProperty("类别 0 =共享,1=个人")
	private Integer type;
	
	@ApiModelProperty("级别")
	private Integer level;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Integer getLevel() {
		return level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

}
