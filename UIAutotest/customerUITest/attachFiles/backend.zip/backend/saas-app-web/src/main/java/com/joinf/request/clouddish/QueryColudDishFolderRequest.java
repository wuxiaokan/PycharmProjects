package com.joinf.request.clouddish;

import com.joinf.utils.base.BasePage;

import io.swagger.annotations.ApiModelProperty;

public class QueryColudDishFolderRequest extends BasePage{
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 5644788967001120505L;

	@ApiModelProperty("0[共享] 1[个人]")
	private Integer type;
	
	@ApiModelProperty("父级id 0=首级")
	private Long parentId;
	
	@ApiModelProperty(value ="排序字段")
	private String sortColumn;
	
	@ApiModelProperty(value ="排序类别")
	private String sortType;
	
//	@ApiModelProperty(value ="关键词")
//	private String key;

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	public String getSortColumn() {
		return sortColumn;
	}

	public void setSortColumn(String sortColumn) {
		this.sortColumn = sortColumn;
	}

	public String getSortType() {
		return sortType;
	}

	public void setSortType(String sortType) {
		this.sortType = sortType;
	}

//	public String getKey() {
//		return key;
//	}
//
//	public void setKey(String key) {
//		this.key = key;
//	}

}
