package com.joinf.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.joinf.annotations.NeedLogin;
import com.joinf.constants.ApprovalType;
import com.joinf.constants.OperatorType;
import com.joinf.constants.OrderStatus;
import com.joinf.constants.QuoteStatus;
import com.joinf.dto.CheckSuccessDto;
import com.joinf.dto.CompanyDTO;
import com.joinf.dto.EditFlowDto;
import com.joinf.dto.QueryApprovalLsitParam;
import com.joinf.entity.SessionUser;
import com.joinf.entity.generator.Company;
import com.joinf.entity.generator.Operator;
import com.joinf.interfaces.ApprovalManager;
import com.joinf.interfaces.ApprovalService;
import com.joinf.interfaces.order.OrderManager;
import com.joinf.interfaces.quote.QuoteManager;
import com.joinf.request.FlowRequest;
import com.joinf.request.QueryUserApprovalListRequest;
import com.joinf.response.ApprovalResponse;
import com.joinf.service.redis.RedisService;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.annotations.Permission;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.dto.user.UserInfoDto;
import com.joinf.utils.util.JoinfBeanUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * Description: 流程服务
 *
 * @author lyj
 * @date 2018年1月23日 下午4:15:14
 */
@RestController
@RequestMapping("approval")
@Api(tags="流程服务")
public class ApprovalController {


	@Autowired
	private QuoteManager quoteManager;
	
	@Autowired
	private OrderManager orderManager;
	
	@Autowired
	private ApprovalService approvalService;
	
	@Autowired
	private ApprovalManager approvalManager;
	
	@Autowired
	private RedisService redisService;
	
	@ApiOperation(value="审批退回流程", notes="审批流程")
	@PostMapping("backFlowJson")
	@ApiImplicitParam(name = "req", value = "审批退回流程请求对象", required = true, dataType = "FlowRequest")
	@NeedLogin
	@Permission(require="quote.approval.approvalBack")
	public BaseResponseEntity<Integer> backFlowJson(HttpServletRequest request,@RequestBody FlowRequest req){
		BaseResponseEntity<Integer> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		CheckSuccessDto company = SessionUtils.getCenterUserDto(request);
		
		EditFlowDto editDto = new EditFlowDto();
		JoinfBeanUtils.copyProperties(editDto, req);
		editDto.setOperatorId(user.getOperatorId());
		editDto.setSwitchOperatorId(user.getSwitchOperatorId());
		editDto.setCompanyId(user.getCompanyId());
		
		editDto.setCenterCompanyId(company.getCompanyId());
		editDto.setCenterUserId(company.getUserId());
		editDto.setDeviceId(user.getSwitchOperator().getDeviceId());
		
		//切换人管理人员列表
		List<UserInfoDto> list = redisService.getOperatorAssignment(user.getCompanyId(), user.getSwitchOperatorId(),1);	
		UserInfoDto userInfo = list.stream().filter(o -> o.getId().equals(user.getSwitchOperatorId())).findAny().orElse(null);
		editDto.setUserName(userInfo.getUserName());
		editDto.setTrueName(userInfo.getChineseName());
		
		if(req.getType().equals(ApprovalType.Quote.getType())){//报价
			quoteManager.checkQuote(user.getCompanyId(), req.getDataId(), QuoteStatus.ApprovalPending.getStatus()); //2和6待批
			editDto.setMoudleServiceName("QuoteManager");
			editDto.setType(ApprovalType.Quote.getType());
			if(req.getOperatorFlag() == 2){//待批退回
				entity.setData(QuoteStatus.Dfaft.getStatus());
				editDto.setOperatorFlag(OperatorType.ApprovalReturn.getType());
			}
			
			else if(req.getOperatorFlag() == 3){//审批退回
				editDto.setOperatorFlag(OperatorType.ApprovalBack.getType());
				entity.setData(QuoteStatus.Edit.getStatus());
			}
		}
		else if(req.getType().equals(ApprovalType.Order.getType())){
			editDto.setMoudleServiceName("OrderManager");
			orderManager.checkOrder(user.getCompanyId(), req.getDataId(), OrderStatus.ApprovalPending.getStatus());
			if(req.getOperatorFlag() == 2){//待批退回
				editDto.setOperatorFlag(OperatorType.ApprovalReturn.getType());
				entity.setData(OrderStatus.Dfaft.getStatus());
			}
			else if(req.getOperatorFlag() == 3){//审批退回
				editDto.setOperatorFlag(OperatorType.ApprovalReturn.getType());
				entity.setData(OrderStatus.Edit.getStatus());
			}
		}
		approvalService.editFLowOut(editDto);
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="审批流程", notes="审批流程")
	@PostMapping("editFlow")
	@ApiImplicitParam(name = "req", value = "审批流程请求对象", required = true, dataType = "FlowRequest")
	@NeedLogin
	@Permission(require="quote.approval.flowSubmit")
	public BaseResponseEntity<Integer> submitQuoteApproval(HttpServletRequest request,@RequestBody FlowRequest req){
		BaseResponseEntity<Integer> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		CheckSuccessDto company = SessionUtils.getCenterUserDto(request);
		
		EditFlowDto editDto = new EditFlowDto();
		JoinfBeanUtils.copyProperties(editDto, req);
		editDto.setOperatorId(user.getOperatorId());
		editDto.setSwitchOperatorId(user.getSwitchOperatorId());
		editDto.setCompanyId(user.getCompanyId());
		
		//用户中心信息
		editDto.setCenterCompanyId(company.getCompanyId());
		editDto.setCenterUserId(company.getUserId());
		editDto.setDeviceId(user.getSwitchOperator().getDeviceId());
		
		//切换人管理人员列表
		List<UserInfoDto> list = redisService.getOperatorAssignment(user.getCompanyId(), user.getSwitchOperatorId(),1);	
		UserInfoDto userInfo = list.stream().filter(o -> o.getId().equals(user.getSwitchOperatorId())).findAny().orElse(null);
		editDto.setUserName(userInfo.getUserName());
		editDto.setTrueName(userInfo.getChineseName());
		
		if(req.getType().equals(ApprovalType.Quote.getType())){//报价
			quoteManager.checkQuote(user.getCompanyId(), req.getDataId(),QuoteStatus.ApprovalPending.getStatus(),QuoteStatus.ApprovalPending2.getStatus()); //2和6待批
			editDto.setMoudleServiceName("QuoteManager");
			editDto.setType(ApprovalType.Quote.getType());
			entity.setData(quoteManager.selectByPrimaryKey(req.getDataId()).getStatus());//生效
		}
		else if(req.getType().equals(ApprovalType.Order.getType())){
			orderManager.checkOrder(user.getCompanyId(), req.getDataId(), QuoteStatus.ApprovalPending.getStatus(),QuoteStatus.ApprovalPending2.getStatus());
			editDto.setMoudleServiceName("OrderManager");
			editDto.setType(ApprovalType.Order.getType());
			entity.setData(orderManager.selectByPrimaryKey(req.getDataId()).getStatus().intValue());//生效
		}
		
		approvalService.editFlow(editDto);
		if(req.getOperatorFlag().equals(OperatorType.Approval.getType())){
			approvalService.dealQuoteSelfApproval(editDto);
		}
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="查询用户流程", notes="查询用户流程")
	@PostMapping("selectUserApprovals")
	@ApiImplicitParam(name = "req", value = "查询用户流程请求对象", required = true, dataType = "QueryUserApprovalListRequest")
	@NeedLogin
	public BaseResponseEntity<List<ApprovalResponse>> selectQuoteApproval(HttpServletRequest request,@RequestBody QueryUserApprovalListRequest req){
		BaseResponseEntity<List<ApprovalResponse>> entity= new BaseResponseEntity<>();
		Company company = SessionUtils.getCompanyInfo(request);
		CompanyDTO centerCompany = SessionUtils.getCenterCompanyInfo(request);
		Operator operator = SessionUtils.getSwitchOperatorInfo(request);
		entity.setSuccess(true);
		QueryApprovalLsitParam param = new QueryApprovalLsitParam();
		param.setOperator(operator);
		param.setApprovalType(req.getType());
		param.setCompanyType(centerCompany.getCompanyType().intValue());
		param.setCompanyId(company.getId());
		if(req.getType() == ApprovalType.Quote.getType())
			param.setResourceId(18l);
		else if(req.getType() == ApprovalType.Order.getType())
			param.setResourceId(200l);
		entity.setData(JoinfBeanUtils.copyToNewListBean(ApprovalResponse.class, approvalManager.getApprovalsByType(param)));
		return entity;
	}
}
