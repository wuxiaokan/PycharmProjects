package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

public class UpdatePasswordRequest {
	
	@ApiModelProperty(value="用户名id",required=true)
	private String userId;
	
	@ApiModelProperty(value="新密码(base64加密)",required=true)
	private String newPwd;
	
	@ApiModelProperty(value="旧密码(base64加密)",required=true)
	private String olPwd;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getNewPwd() {
		return newPwd;
	}

	public void setNewPwd(String newPwd) {
		this.newPwd = newPwd;
	}

	public String getOlPwd() {
		return olPwd;
	}

	public void setOlPwd(String olPwd) {
		this.olPwd = olPwd;
	}

}
