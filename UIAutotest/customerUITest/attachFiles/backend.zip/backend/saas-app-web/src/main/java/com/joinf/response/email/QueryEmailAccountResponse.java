package com.joinf.response.email;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;


/**
 * 
 * @author zlx
 * @Description: 邮箱账号列表
 * @date 2018年1月11日 上午11:10:35
 */
public class QueryEmailAccountResponse implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2105085247053982301L;
	
	@ApiModelProperty(value = "账号标识")
    private Long id;
	@ApiModelProperty(value = "账号")
    private String account;
	@ApiModelProperty(value ="呢称")
	private String name;
	@ApiModelProperty(value = "状态   [1]启用   [2]禁用")
	private Byte flag;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public Byte getFlag() {
		return flag;
	}
	public void setFlag(Byte flag) {
		this.flag = flag;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	
}
