package com.joinf.request.product;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 查询网店分组
 *
 * @author lyj
 * @date 2018年1月15日 下午1:50:54
 */
public class QueryShopProductGroupRequest {

	@ApiModelProperty("网店id")
	private Long shopId;

	public Long getShopId() {
		return shopId;
	}

	public void setShopId(Long shopId) {
		this.shopId = shopId;
	}
}
