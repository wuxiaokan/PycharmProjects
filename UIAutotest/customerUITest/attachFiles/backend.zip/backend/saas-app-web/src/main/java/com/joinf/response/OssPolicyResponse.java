package com.joinf.response;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 签名返回
 *
 * @author lyj
 * @date 2017年12月29日 上午10:22:43
 */
public class OssPolicyResponse {

	@ApiModelProperty(value="",required=true)
	private String accessid;
	@ApiModelProperty(value="",required=true)
	private String policy;
	@ApiModelProperty(value="签名",required=true)
	private String signature;
	@ApiModelProperty(value="图片key值",required=true)
	private String dir;
	@ApiModelProperty(value="服务地址",required=true)
	private String host;
	@ApiModelProperty(value="过期时间",required=true)
	private String expire;
	@ApiModelProperty(value="回调地址",required=true)
	private String callbackVar;
	@ApiModelProperty(value="回调地址加密",required=true)
	private String callbackSig;
	public String getAccessid() {
		return accessid;
	}
	public void setAccessid(String accessid) {
		this.accessid = accessid;
	}
	public String getPolicy() {
		return policy;
	}
	public void setPolicy(String policy) {
		this.policy = policy;
	}
	public String getSignature() {
		return signature;
	}
	public void setSignature(String signature) {
		this.signature = signature;
	}
	public String getDir() {
		return dir;
	}
	public void setDir(String dir) {
		this.dir = dir;
	}
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public String getExpire() {
		return expire;
	}
	public void setExpire(String expire) {
		this.expire = expire;
	}
	public String getCallbackVar() {
		return callbackVar;
	}
	public void setCallbackVar(String callbackVar) {
		this.callbackVar = callbackVar;
	}
	public String getCallbackSig() {
		return callbackSig;
	}
	public void setCallbackSig(String callbackSig) {
		this.callbackSig = callbackSig;
	}
}
