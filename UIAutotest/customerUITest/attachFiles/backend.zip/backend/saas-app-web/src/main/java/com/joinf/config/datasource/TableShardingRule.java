package com.joinf.config.datasource;

import org.apache.commons.lang3.StringUtils;

/**
 * 分表逻辑
 * @author zlx
 *
 */
public class TableShardingRule {
    
	private static long mod = 5;
	
	
    public static long getTableIndex(long companyId){
		return getTableIndex(companyId, null);
    }
    
    
    public static long getTableIndex(long companyId, String tableName){
    	//关系表有拆分为20张
    	if (StringUtils.equals(tableName, "t_email_related")) {
    		return companyId % 20;
		}else if (StringUtils.equals(tableName, "t_campaigns_detail")){
			return Math.abs(String.valueOf(companyId).hashCode())%mod;
		}else{
			return companyId % 10;
		}
    }
    
	
    public static void main(String[] args) {
		System.out.println(getTableIndex(31558L,"t_campaigns_detail"));
	}
}