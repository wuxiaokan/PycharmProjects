package com.joinf.request.chat;

import io.swagger.annotations.ApiModelProperty;

public class GetCurrentUserMessageRquest {

	@ApiModelProperty("访客id")
	private Long threadId;
	
	@ApiModelProperty("当前会话token")
	private Long token;

	public Long getThreadId() {
		return threadId;
	}

	public void setThreadId(Long threadId) {
		this.threadId = threadId;
	}

	public Long getToken() {
		return token;
	}

	public void setToken(Long token) {
		this.token = token;
	}
}
