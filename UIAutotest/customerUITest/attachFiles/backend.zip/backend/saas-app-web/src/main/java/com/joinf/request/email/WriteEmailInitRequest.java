package com.joinf.request.email;

import java.io.Serializable;

import com.joinf.request.IdRequest;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 写信页面初始请求参数
 * @date 2018年1月15日 下午2:43:21
 */
public class WriteEmailInitRequest  extends IdRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2596363725471279783L;

	@ApiModelProperty(value = "写信类型  [0]普通写信/id有值为编辑邮件 [1]回复、[2]回复全部、[3]回复全部带附件、[4]转发、[5]重发、[6]作为附件发送")
	private int type;

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}
	
	

	
	
}
