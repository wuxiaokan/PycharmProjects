package com.joinf.request.quote;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * Description: 报价状态修改
 *
 * @author lyj
 * @date 2018年1月23日 下午3:41:32
 */
public class BatchUpdateQuoteStatusRequest {
	
	@ApiModelProperty("处理记录id集合")
	private List<Long> dataIds;

	@ApiModelProperty("审批意见")
	private String content;

	public List<Long> getDataIds() {
		return dataIds;
	}

	public void setDataIds(List<Long> dataIds) {
		this.dataIds = dataIds;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

}
