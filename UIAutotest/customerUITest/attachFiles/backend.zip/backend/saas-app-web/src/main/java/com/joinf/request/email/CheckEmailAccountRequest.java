package com.joinf.request.email;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 校验邮箱账号参数
 * @date 2018年1月5日 下午5:21:20
 */
public class CheckEmailAccountRequest implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2596363725471279783L;

	@ApiModelProperty(value = "邮箱账号主键id,编辑时必须传")
	private Long id;
	
	@ApiModelProperty(value = "邮箱账号")
	private String account;
	
	@ApiModelProperty(value = "收件服务")
	private String receiveServer;

	public Long getId() {
		return id;
	}

	public String getAccount() {
		return account;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getReceiveServer() {
		return receiveServer;
	}

	public void setReceiveServer(String receiveServer) {
		this.receiveServer = receiveServer;
	}
	
	

}
