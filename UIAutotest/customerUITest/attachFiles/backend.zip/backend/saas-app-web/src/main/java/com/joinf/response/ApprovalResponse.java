package com.joinf.response;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 流程返回
 *
 * @author lyj
 * @date 2018年1月22日 上午11:24:39
 */
public class ApprovalResponse {

	@ApiModelProperty(value = "审批流程id")
	private Long id;

	@ApiModelProperty(value = "名称")
	private String name;

	@ApiModelProperty(value = "描述")
	private String description;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}


}
