package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

public class GetOssKeyRequest {
	
	@ApiModelProperty(value="文件名",required=true)
	String fileName;
	
	@ApiModelProperty(value="1:业务员头像,2:业务员头像,3:业务员中英文文签章,4:公司中英文logo,"
			+ "5:公司印章,6:自定义图片,7:邮件正文中的cid图片,8:邮件签名中的图片,9:邮件eml包,"
			+ "10:邮件模板,11:身份信息验证附件,12:网店产品详情内嵌文件,13:邮件附件,14:产品主图,15:产品附件,"
			+ "16:报价附件,17:客户附件,18:供应商附件,19:订单附件,20:云盘中的文件,21:云盘中的文件(个人),"
			+ "22:反馈附件,23:报表模板",required=true)
	Integer type;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

}
