package com.joinf.request;

import com.joinf.utils.base.BasePage;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 查询db日志
 *
 * @author lyj
 * @date 2018年3月20日 下午2:27:20
 */
public class QueryLogRequest extends BasePage{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1137259267556844546L;


	@ApiModelProperty("表名(customer-客户,follow-跟进,email-邮件,order-订单,quote-报价,transfer-客户迁移)")
	private String tableName;
	
	
	@ApiModelProperty("对象id")
	private Long objectId;


	public String getTableName() {
		return tableName;
	}


	public void setTableName(String tableName) {
		this.tableName = tableName;
	}


	public Long getObjectId() {
		return objectId;
	}


	public void setObjectId(Long objectId) {
		this.objectId = objectId;
	}
}
