package com.joinf.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * Description: Swagger2api配置类
 *
 * @author lyj
 * @date 2017年12月4日 下午5:02:17
 */
@Configuration
@EnableSwagger2
@Profile({"dev","test"})
public class Swagger2 {

    @Bean
    public Docket createRestApi() {
        return new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(apiInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.joinf.controller"))
                .paths(PathSelectors.any())
                .build();
    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("富通天下-SAAS API接口文档")
                .description("http://192.168.0.185:8080/swagger-ui.html")
                .termsOfServiceUrl("http://ceshi.joinf.com")
                .contact("joinf")
                .version("1.0")
                .build();
    }

}
