package com.joinf.request;

import com.joinf.utils.base.BasePage;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 获取字段字段
 *
 * @author lyj
 * @date 2017年12月13日 下午1:48:25
 */
public class DictRequest extends BasePage{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1936706499671118320L;

	@ApiModelProperty(value="字典类型",required=true)
	private String dataDictionary;
	
	@ApiModelProperty(value="字段类型",required=true)
	private Integer type;
	
	@ApiModelProperty(value="父级id,比如城市对应的省",required=true)
	private Long parentId;
	
	@ApiModelProperty(value="关键词",required=true)
	private String key;
	
	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getDataDictionary() {
		return dataDictionary;
	}

	public void setDataDictionary(String dataDictionary) {
		this.dataDictionary = dataDictionary;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}
	

}
