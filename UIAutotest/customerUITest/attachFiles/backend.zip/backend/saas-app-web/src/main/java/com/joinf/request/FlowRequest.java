package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

public class FlowRequest {

	@ApiModelProperty("处理记录id")
	private Long dataId;

	@ApiModelProperty("审批意见")
	private String content;
	
	@ApiModelProperty("类别1报价,2订单")
	private Integer type;
	
	@ApiModelProperty("审批类别：4审批通过，3审批退回，2待批退回")
	private Integer operatorFlag;

	public Integer getOperatorFlag() {
		return operatorFlag;
	}

	public void setOperatorFlag(Integer operatorFlag) {
		this.operatorFlag = operatorFlag;
	}

	public Long getDataId() {
		return dataId;
	}

	public void setDataId(Long dataId) {
		this.dataId = dataId;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

}
