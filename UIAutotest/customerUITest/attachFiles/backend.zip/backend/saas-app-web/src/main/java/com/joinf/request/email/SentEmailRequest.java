package com.joinf.request.email;

import com.joinf.request.IdRequest;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 发送邮件请求参数
 * @date 2018年1月18日 下午12:56:23
 */
public class SentEmailRequest extends IdRequest{

	@ApiModelProperty(value="发送类型   [0]提交发送  [1]提醒弹框确定直接发送 [2]提交审批")
	private int type;
	@ApiModelProperty(value="审批规则id")
	private Long auditRuleId;

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public Long getAuditRuleId() {
		return auditRuleId;
	}

	public void setAuditRuleId(Long auditRuleId) {
		this.auditRuleId = auditRuleId;
	}
	

	
	
}
