package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;


/**
 * Description: 校验验证码是否正确
 *
 * @author lyj
 * @date 2017年12月25日 下午2:07:10
 */
public class CheckCaptchaRequest {
	
	@ApiModelProperty(value="手机号或邮箱号",required=true)
	private String number;
	
	@ApiModelProperty(value="随机码（跟发送时一样）",required=true)
	private String random;
	
	@ApiModelProperty(value="验证码",required=true)
	private String captcha;

	public String getCaptcha() {
		return captcha;
	}

	public void setCaptcha(String captcha) {
		this.captcha = captcha;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getRandom() {
		return random;
	}

	public void setRandom(String random) {
		this.random = random;
	}

}
