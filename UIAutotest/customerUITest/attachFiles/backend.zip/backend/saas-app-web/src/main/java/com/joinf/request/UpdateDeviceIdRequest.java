package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

public class UpdateDeviceIdRequest {
	
	
	@ApiModelProperty("设备id")
	private String deviceId;
	
	@ApiModelProperty("设备类别1:Android,2:ios")
	private Integer deviceType;

	public Integer getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(Integer deviceType) {
		this.deviceType = deviceType;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

}
