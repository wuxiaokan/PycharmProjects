package com.joinf.controller;

import java.util.*;
import java.util.stream.Collectors;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.joinf.dto.QueryRelResourceByIdsDto;
import com.joinf.entity.RelResourceExtend;
import com.joinf.entity.generator.Assignment;
import com.joinf.exception.CommonException;
import com.joinf.interfaces.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.joinf.LoadPermissionJsonRunner;
import com.joinf.annotations.NeedLogin;
import com.joinf.constant.login.LoginContant;
import com.joinf.constants.Constants;
import com.joinf.dto.OperatorDTO;
import com.joinf.dto.SystemPermissionsDTO;
import com.joinf.dto.ToolBar;
import com.joinf.entity.SessionUser;
import com.joinf.entity.generator.Department;
import com.joinf.entity.generator.Operator;
import com.joinf.entity.generator.RelResource;
import com.joinf.interceptor.BaseHandlerInterceptor;
import com.joinf.request.GetOperatorAssignmentRequest;
import com.joinf.request.IdRequest;
import com.joinf.request.LoginRequest;
import com.joinf.request.SetToolbarRequest;
import com.joinf.response.LoginResponse;
import com.joinf.response.OperatorAssignmentResponse;
import com.joinf.response.SuccessResponse;
import com.joinf.response.UserCenterResponse;
import com.joinf.service.redis.RedisService;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.dto.user.UserInfoDto;
import com.joinf.utils.util.DateUtil;
import com.joinf.utils.util.JoinfBeanUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;


/**
 * Description: 系统服务
 *
 * @author lyj
 * @date 2017年12月20日 上午11:17:17
 */
@RestController
@RequestMapping("system")
@Api(tags="系统服务")
@CrossOrigin
public class SystemController extends BaseHandlerInterceptor{
	
	@Autowired
	private RedisService redisService;
	
	@Autowired
	private StringRedisTemplate stringRedisTemplate;
	
	@Autowired
	private OperatorService operatorService;
	
	@Autowired
	private DepartmentService departmentService;
	
	@Autowired
	private UserCenterService userCenterService;

	@Autowired
	private AssignmentService assignmentService;

	@Autowired
	private RelResourceService relResourceService;

	/**
	 * 登入
	 * @param req
	 * @return
	 */
	@ApiOperation(value="登入", notes="登入")
	@ApiImplicitParam(name = "req", value = "登入列表请求对象", required = true, dataType = "LoginRequest")
	@PostMapping("login")
	public BaseResponseEntity<LoginResponse> login(HttpServletRequest request,@RequestBody LoginRequest req){
		BaseResponseEntity<LoginResponse> entity = new BaseResponseEntity<>();
		LoginResponse response = SessionUtils.getLoginResponse(request);
		
		response.setToolbars(getOperatorToolbar(request));
		entity.setData(response);
		entity.setSuccess(true);
		
		setLoginTime(request);
		return entity;
	}
	
	/**
	 * 登入
	 * @param req
	 * @return
	 */
	@ApiOperation(value="二次验证成功后", notes="二次验证成功后")
	@PostMapping("afterTwoCheck")
	public BaseResponseEntity<LoginResponse> afterTwoCheck(HttpServletRequest request){
		BaseResponseEntity<LoginResponse> entity = new BaseResponseEntity<>();
		LoginResponse response = SessionUtils.getLoginResponse(request);
		response.setToolbars(getOperatorToolbar(request));
		entity.setData(response);
		entity.setSuccess(true);
		setLoginTime(request);
		return entity;
	}
	
	
	private void setLoginTime(HttpServletRequest request){
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		if(user!=null){
			String latestLoginTime = DateUtil.format(new Date(), "MM-dd HH:mm");
			stringRedisTemplate.opsForValue().set(getUserLoginKey(user), request.getSession().getId()+"_"+latestLoginTime);//登入成功后存储当前sessionid,判断是否一个账号同时多个地方登入
		}
	}
	
	//获取自定义菜单
	private List<ToolBar> getOperatorToolbar(HttpServletRequest request){
		List<ToolBar> results = new ArrayList<>();
		String key = SessionUtils.getToolBarKey(request);
		String toolbars = "";
		if(stringRedisTemplate.hasKey(key)){//已经自定义过
			toolbars = stringRedisTemplate.opsForValue().get(key);
		}
		else{
			toolbars = LoadPermissionJsonRunner.toolbarArray.toJSONString();
		}
		results = JSON.parseArray(toolbars, ToolBar.class);
		
		List<ToolBar> defaultData = JSON.parseArray(LoadPermissionJsonRunner.toolbarArray.toJSONString(), ToolBar.class);
		if(defaultData.size() != results.size()) {//比较基础数据，防止新增数据
			for(ToolBar bar:defaultData) {
				ToolBar exsit = results.stream().filter(tool->tool.getIcon().equals(bar.getIcon())).findAny().orElse(null);
				if(exsit == null) {
					results.add(bar);
				}
			}
		}
		
		//判断商业数据权限
		OperatorDTO operatorDto = SessionUtils.getCenterOperatorInfo(request);
		results = hasBusinessDatePermit(results, operatorDto);
		
		results.sort((ToolBar h1, ToolBar h2) -> h1.getSort().compareTo(h2.getSort()));//排序
		return results;
	}

	/**
	 * 登出
	 * @param req
	 * @return
	 */
	@ApiOperation(value="退出", notes="退出")
	@PostMapping("logout")
	public BaseResponseEntity<?> logout(HttpServletRequest request){
		BaseResponseEntity<?> entity = new BaseResponseEntity<>();
		request.getSession().invalidate();
		entity.setSuccess(true);
		return entity;
	}
	
	/**
	 * 获取用户信息
	 * @param request
	 * @return
	 */
	@ApiOperation(value="获取用户信息", notes="获取用户信息")
	@PostMapping("getUserInfo")
	public BaseResponseEntity<LoginResponse> getUserInfo(HttpServletRequest request){
		BaseResponseEntity<LoginResponse> entity = new BaseResponseEntity<>();
		entity.setData(SessionUtils.getLoginResponse(request));
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="设置工具栏", notes="设置工具栏")
	@PostMapping("setMineToolbar")
	@ApiImplicitParam(name = "req", value = "工具栏设置集合", required = true, dataType = "SetToolbarRequest")
	@NeedLogin
	public BaseResponseEntity<?> setMineToolbar(HttpServletRequest request,@RequestBody SetToolbarRequest req){
		BaseResponseEntity<SuccessResponse> response = new BaseResponseEntity<>();
		String result = JSONArray.toJSONString(req.getToolbars());
		stringRedisTemplate.opsForValue().set(SessionUtils.getToolBarKey(request), result);
		response.setSuccess(true);
		return response;
	}
	
	@ApiOperation(value="获取自定义工具栏", notes="获取自定义工具栏")
	@PostMapping("getMineToolbar")
	@NeedLogin
	public BaseResponseEntity<List<ToolBar>> getMineToolbar(HttpServletRequest request){
		BaseResponseEntity<List<ToolBar>> response = new BaseResponseEntity<>();
		response.setData(getOperatorToolbar(request));
		response.setSuccess(true);
		return response;
	}
	
	
	/**
	 * 获取可管理用户信息
	 * @param request
	 * @return
	 */
	@ApiOperation(value="获取可管理用户信息", notes="获取可管理用户信息")
	@PostMapping("getOperatorAssignment")
	@ApiImplicitParam(name = "req", value = "获取可管理用户信息参数", required = true, dataType = "GetOperatorAssignmentRequest")
	@NeedLogin
	public BaseResponseEntity<List<OperatorAssignmentResponse>> getOperatorAssignment(HttpServletRequest request,@RequestBody GetOperatorAssignmentRequest req){
		BaseResponseEntity<List<OperatorAssignmentResponse>> entity = new BaseResponseEntity<>();
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		List<OperatorAssignmentResponse> dataList = new ArrayList<>();
		Long operatorId = user.getOperatorId();
		if(req.getDataType() == 2)
			operatorId = user.getSwitchOperatorId();
		List<UserInfoDto> list = redisService.getOperatorAssignment(user.getCompanyId(), operatorId,req.getType());
		List<Long> departmentIds = new ArrayList<Long>();
		for (UserInfoDto userInfo : list) {
			departmentIds.add(userInfo.getDepartment());
		}
		List<Department> departments = new ArrayList<Department>();
		if(departmentIds.size()>0){
			departments = departmentService.selectByIds(departmentIds);
		}
		for (UserInfoDto userInfo : list) {
			OperatorAssignmentResponse o = JoinfBeanUtils.copyToNewBean(OperatorAssignmentResponse.class, userInfo);
			o.setId(userInfo.getId());
			for(Department department:departments){
				if(department.getId().toString().equals(String.valueOf(userInfo.getDepartment())))
					o.setDepartment(department.getName());
			}
			dataList.add(o);
		}
		entity.setData(dataList);
		
		entity.setSuccess(true);
		return entity;
	}
	
	/**
	 * 获取可管理用户信息
	 * @param request
	 * @return
	 */
	@ApiOperation(value="获取公司所有用户信息", notes="获取公司所有用户信息")
	@PostMapping("getComanyOperators")
	@NeedLogin
	public BaseResponseEntity<List<OperatorAssignmentResponse>> getComanyOperators(HttpServletRequest request){
		BaseResponseEntity<List<OperatorAssignmentResponse>> entity = new BaseResponseEntity<>();
		HttpSession session = request.getSession();
		List<OperatorAssignmentResponse> dataList = new ArrayList<>();
		if(session.getAttribute(LoginContant.COMPANYOPERATORS) != null){
			String operators = (String) session.getAttribute(LoginContant.COMPANYOPERATORS);
			dataList = JSONObject.parseArray(operators, OperatorAssignmentResponse.class);
			
		}else{
			SessionUser user = SessionUtils.getCurrentUserInfo(request);
			List<UserInfoDto> list = operatorService.getCompanyAllOperators(user.getCompanyId());
			for (UserInfoDto userInfo : list) {
				OperatorAssignmentResponse o = JoinfBeanUtils.copyToNewBean(OperatorAssignmentResponse.class, userInfo);
				o.setId(userInfo.getId());
				dataList.add(o);
			}
			session.setAttribute(LoginContant.COMPANYOPERATORS, JSONArray.toJSONString(dataList));
		}
		entity.setData(dataList);
		
		entity.setSuccess(true);
		return entity;
	}

	
	@ApiOperation(value="切换用户", notes="切换用户")
	@PostMapping("switchOperator")
	@ApiImplicitParam(name = "req", value = "切换用户参数", required = true, dataType = "IdRequest")
	@NeedLogin
	public BaseResponseEntity<List<Integer>> switchOperator(HttpServletRequest request,@RequestBody IdRequest req){
		BaseResponseEntity<List<Integer>> entity = new BaseResponseEntity<>();
		Operator operator = operatorService.selectByPrimaryKey(req.getId());
		request.getSession().removeAttribute(LoginContant.SWITCH_OPERATOR);
		request.getSession().setAttribute(LoginContant.SWITCH_OPERATOR, JSONObject.toJSONString(operator));
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);

		//权限代码集合
		List<Integer> permissionCodes = new ArrayList<Integer>();

		//没有权限的代码集合(所有权限)
		List<Integer> resCode = new ArrayList<>();

		List<RelResource> resources = user.getResources();

		if (!user.getUser().getId().equals(user.getSwitchOperator().getId())){

			//没有权限的ID集合(大模块)
			List<Long> resIds = getAssignment(user.getUser().getId(),user.getSwitchOperator().getId());

			if(resIds != null && resIds.size() > 0){
				QueryRelResourceByIdsDto dto = new QueryRelResourceByIdsDto();
				dto.setIds(resIds);
				List<RelResourceExtend> resourceExtendList = relResourceService.selectResourceIdsParByIds(dto);
				resCode.addAll(resourceExtendList.stream().map(RelResourceExtend :: getPermitCode).collect(Collectors.toList()));
			}
		}
		//有权限的代码
		permissionCodes.addAll(resources.stream().filter(r -> r.getPermitCode() != null && !resCode.contains(r.getPermitCode())).map(r -> r.getPermitCode()).collect(Collectors.toList()));

		entity.setData(permissionCodes);
		entity.setSuccess(true);
		return entity;
	}
	
	
	/**
	 * @description 判断是否有商业数据权限
	 * @author cuichuanlei       
	 * @created 2019年3月12日 下午2:08:07 
	 * @param results
	 * @param operatorDto
	 */
	private List<ToolBar> hasBusinessDatePermit(List<ToolBar> results, OperatorDTO operatorDto) {
		
		UserCenterResponse<SystemPermissionsDTO> httpResult = userCenterService.validateSystemPermissions(operatorDto.getUserId(), "data");
		//判断是否有商业数据权限
		if (httpResult != null && httpResult.isSuccess()) {
			SystemPermissionsDTO systemPermissionsDTO = httpResult.getResponseData();
			if (systemPermissionsDTO == null || !systemPermissionsDTO.isAvailable()) {
				return results.stream().filter(toolBar -> (!"商业数据".equals(toolBar.getName()) && !"搜索(商业)数据".equals(toolBar.getName())
						&& !"/businessData".equals(toolBar.getPath()))).collect(Collectors.toList());	
			}
		}
		
		return results;
	}
	
	/**
	 * 获取商业数据权限
	 * @param json
	 * @param request
	 * @return
	 */
	@ApiOperation(value="获取商业数据权限", notes="获取商业数据权限")
	@PostMapping("getBusinessDataPermit")
	@NeedLogin
	public JSONObject getBusinessDataPermit(HttpServletRequest request) {
		JSONObject result = new JSONObject();
		try {
			OperatorDTO operatorDto = SessionUtils.getCenterOperatorInfo(request);
			boolean hasPermit = hasBusinessDataPermit(operatorDto.getUserId());
			if(!hasPermit) {
				result.put(Constants.AJAXRESULT, Constants.AJAXRESULT_FAIL);
				return result;
			}
			result.put(Constants.AJAXRESULT, Constants.AJAXRESULT_SUCCESS);
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			result.put(Constants.AJAXRESULT_MSG, e.getMessage());
		}
		result.put(Constants.AJAXRESULT, Constants.AJAXRESULT_FAIL);
		return result;
	}
	
	
	/**
	 * 是否拥有商业数据权限
	 * @param userId
	 * @return
	 */
	private boolean hasBusinessDataPermit(Long userId) {
		try {	
			UserCenterResponse<SystemPermissionsDTO> httpResult = userCenterService.validateSystemPermissions(userId, "data");
			if (httpResult != null && httpResult.isSuccess()) {
				SystemPermissionsDTO systemPermissionsDTO = httpResult.getResponseData();
				if (systemPermissionsDTO == null || !systemPermissionsDTO.isAvailable()) {
					return false;
				}
			}
		    return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}



	private List<Long> getAssignment(Long managerId, Long staffId ){

		List<Long> resourceIds = new ArrayList<>();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("operatorId", managerId);
		map.put("subordinateIdArray", Arrays.asList(staffId));
		List<Assignment> assignmentList = assignmentService.selectByManagerIdStaffId(map);
		if (null != assignmentList && assignmentList.size() > 0) {
			Assignment assignment = assignmentList.get(0);
			String resAu = assignment.getResourceAuthority();
			if (StringUtils.isNotEmpty(resAu)) {
				JSONArray arr = JSONArray.parseArray(resAu);
				for (int i = 0; i < arr.size(); i++) {
					JSONObject jsonRes = arr.getJSONObject(i);
					// 保存没有资源的权限
					if (!jsonRes.getBooleanValue("checked")) {
						resourceIds.add(jsonRes.getLongValue("resource_id"));
					}
				}
			}
			// 兼容老数据，如果为空或null 则 有全部权限
			else { }
		}
		return  resourceIds;
	}
}