package com.joinf.response.customer;

import java.util.Date;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 客户附件返回
 *
 * @author lyj
 * @date 2018年10月11日 下午3:33:35
 */
public class CustomerAttachmentResponse {

	@ApiModelProperty(value = "客户附件标识")
	private Long id;
	
	@ApiModelProperty(value = "名称")
	private String name;

	@ApiModelProperty(value = "附件地址")
	private String url;

	@ApiModelProperty(value = "文件大小")
	private Long size;

	@ApiModelProperty(value = "文件类型")
	private String type;

	@ApiModelProperty(value = "是否预览:0/否;1/是")
	private Byte preview;

	@ApiModelProperty(value = "创建时间")
	private Date createTime;

	@ApiModelProperty(value = "更新时间")
	private Date updateTime;

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Long getSize() {
		return size;
	}

	public void setSize(Long size) {
		this.size = size;
	}

	public String getType() {
		return type;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Byte getPreview() {
		return preview;
	}

	public void setPreview(Byte preview) {
		this.preview = preview;
	}
}
