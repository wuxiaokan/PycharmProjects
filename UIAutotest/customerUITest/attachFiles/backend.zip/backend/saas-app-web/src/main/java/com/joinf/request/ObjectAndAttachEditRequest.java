package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

public class ObjectAndAttachEditRequest {
	
	@ApiModelProperty(value="主键id",required=true)
	private Long id;
	
	@ApiModelProperty(value="关联id(比如修改联系人 对应的供应商id)",required=true)
	private Long attachId ;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getAttachId() {
		return attachId;
	}

	public void setAttachId(Long attachId) {
		this.attachId = attachId;
	}

}
