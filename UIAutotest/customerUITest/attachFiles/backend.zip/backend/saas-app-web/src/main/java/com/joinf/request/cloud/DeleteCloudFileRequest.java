package com.joinf.request.cloud;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

public class DeleteCloudFileRequest {
	
	@ApiModelProperty("文件id集合")
	private List<Long> ids;
	
	@ApiModelProperty("0=共享,1=个人")
	private Integer type;

	public List<Long> getIds() {
		return ids;
	}

	public void setIds(List<Long> ids) {
		this.ids = ids;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

}
