package com.joinf.response;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 注册成功返回
 *
 * @author lyj
 * @date 2017年12月22日 上午11:21:33
 */
public class RegisterResponse {
	
	@ApiModelProperty(value="用户中心公司id",required=true)
	private Long centerCompanyId;
	
	@ApiModelProperty(value="用户中心用户id",required=true)
	private Long centerUserId;
	
	@ApiModelProperty(value="操作员id",required=true)
	private Long operatorId;
	
	@ApiModelProperty(value="公司id",required=true)
	private Long companyId;
	
	@ApiModelProperty(value="错误数据")
	private String errData;
	

	public Long getCenterCompanyId() {
		return centerCompanyId;
	}

	public void setCenterCompanyId(Long centerCompanyId) {
		this.centerCompanyId = centerCompanyId;
	}

	public Long getCenterUserId() {
		return centerUserId;
	}

	public void setCenterUserId(Long centerUserId) {
		this.centerUserId = centerUserId;
	}

	public Long getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(Long operatorId) {
		this.operatorId = operatorId;
	}

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public String getErrData() {
		return errData;
	}

	public void setErrData(String errData) {
		this.errData = errData;
	}
	
	

}
