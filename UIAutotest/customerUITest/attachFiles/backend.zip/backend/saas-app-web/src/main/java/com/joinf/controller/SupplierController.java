package com.joinf.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.joinf.utils.dto.log.LogInfoDto;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.Page;
import com.joinf.annotations.NeedLogin;
import com.joinf.constant.Constants;
import com.joinf.constants.Customize;
import com.joinf.dto.DeleteSupplierAttachmentDto;
import com.joinf.dto.DeleteSupplierDto;
import com.joinf.dto.InsertOrUpdateDto;
import com.joinf.dto.QueryDBLogParam;
import com.joinf.dto.SearchSupplierContactParam;
import com.joinf.dto.SearchSupplierContactResult;
import com.joinf.dto.supplier.QuerySupplierDto;
import com.joinf.dto.supplier.QuerySupplierObjectDto;
import com.joinf.dto.supplier.SupplierDetailDto;
import com.joinf.entity.SessionUser;
import com.joinf.entity.generator.Supplier;
import com.joinf.entity.generator.SupplierAttachment;
import com.joinf.entity.generator.SupplierBank;
import com.joinf.entity.generator.SupplierContact;
import com.joinf.exception.AreadyExsitException;
import com.joinf.exception.LimitException;
import com.joinf.interfaces.LogInfoEsService;
import com.joinf.interfaces.SupplierService;
import com.joinf.interfaces.supplier.SupplierContactManager;
import com.joinf.interfaces.supplier.SupplierManager;
import com.joinf.request.IdRequest;
import com.joinf.request.InsertOrUpdateAttachRequest;
import com.joinf.request.InsertOrUpdateRequest;
import com.joinf.request.ObjectAndAttachEditRequest;
import com.joinf.request.UpdateStatusRequest;
import com.joinf.request.customer.DeleteCustomerRequest;
import com.joinf.request.supplier.DeleteSupplierRequest;
import com.joinf.request.supplier.QuerySupplierConcactRequest;
import com.joinf.request.supplier.QuerySupplierLogRequest;
import com.joinf.request.supplier.QuerySupplierRequest;
import com.joinf.request.supplier.SearchSupplierContactRequest;
import com.joinf.request.supplier.UploadSupplierAttachmentRequest;
import com.joinf.response.EditDetailResponse;
import com.joinf.response.SuccessResponse;
import com.joinf.response.customer.CustomerAttachmentResponse;
import com.joinf.response.supplier.QuerySupplierResponse;
import com.joinf.service.supplier.SupplierBankManagerImpl;
import com.joinf.utils.BaseEntityUtils;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.annotations.Permission;
import com.joinf.utils.annotations.VolumeLimit;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.util.JoinfBeanUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * Description: 供应商控制类
 *
 * @author lyj
 * @date 2017年12月4日 下午8:39:59
 */
@RestController
@RequestMapping("supplier")
@Api(tags="供应商服务")
public class SupplierController extends BaseController{
	
	@Autowired
	private SupplierManager manager;
	
	@Autowired
	private SupplierContactManager contactManager;
	
	@Autowired
	private SupplierBankManagerImpl bankManager;
	
	@Autowired
	private SupplierService supplierService;
	
	@Autowired
	private LogInfoEsService logInfoEsService;
	
	
	@ApiOperation(value="判断管理权限", notes="判断管理权限")
	@ApiImplicitParam(name = "req", value = "通过供应商ID 判断 是否有查看供应商的权限", required = true, dataType = "IdRequest")
	@PostMapping("checkSupplierPermit")
	@Permission(require="supplier.list.preview")
	public BaseResponseEntity<String> checkSupplierPermit(HttpServletRequest request,@RequestBody IdRequest req){
		BaseResponseEntity<String> entity = new BaseResponseEntity<>(true);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		//通过客户ID 查询客户详情，获取客户所属业务员ID
		Supplier supplier = supplierService.queryByKey(req.getId());
		
		
		//校验是否拥有数据权限
		if(supplier != null && dataPermissionValidateManager.validateDataPermission(user.getSwitchOperatorId(), supplier.getOperatorId(), supplier.getOperatorIds(), supplier.getPublicFlag(), Constants.RESOURCE_SUPPLIER_ID)){
			entity.setData("true");
		}else {
			entity.setData("false");
		}
		
		return entity;
	}
	
	
	@ApiOperation(value="查询供应商列表", notes="查询供应商列表")
	@ApiImplicitParam(name = "req", value = "查询供应商列表请求对象", required = true, dataType = "QuerySupplierRequest")
	@PostMapping("querySupplierList")
	@Permission(require="supplier.list.preview")
	public BaseResponseEntity<QuerySupplierResponse> querySupplierList(HttpServletRequest request,@RequestBody QuerySupplierRequest req){
		QuerySupplierDto dto = new QuerySupplierDto();
		JoinfBeanUtils.copyProperties(dto, req);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getOperatorId());//查询数据用切换人
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setRoleId(user.getRoleId());
		dto.setResourceId(Customize.SupplierList.getResourceId());
		dto.setTableName(Customize.SupplierList.getTableName());
		dto.setModule(Customize.SupplierList.getModule());
		List<Supplier> suppliers = new ArrayList<Supplier>();
		
		//排序
		if(dto.getSortColumn() != null && StringUtils.isNotBlank(dto.getSortColumn())){
			if("name".equals(dto.getSortColumn())){
				dto.setSortColumn("CONVERT("+dto.getSortColumn()+" USING gbk)");
			}
		}
		
		List<Supplier> responseList =manager.querySupplierList(dto);//查询数据
		
		List<String> showFields = new ArrayList<String>();//显示哪些字段
		showFields.add("name");//名称
		showFields.add("factoryCode");//代码
		showFields.add("displayCreateTime");//创建时间
//		
		BaseResponseEntity<QuerySupplierResponse> entity = new BaseResponseEntity<>();
		if(req.isPaging()){
			suppliers = ((Page<Supplier>) responseList).getResult();
			entity.setTotalPage(((Page<Supplier>) responseList).getPages());
			entity.setTotalRecords(((Page<Supplier>) responseList).getTotal());
		}else{
			suppliers = responseList;
		}
		entity.setSuccess(true);
		entity.setData(manager.getSupplierListArray(dto, suppliers,showFields));//转换数据
		return entity;
	}
	
	@ApiOperation(value="供应商修改(参数id为空则为新增)", notes="供应商修改(参数id为空则为新增)")
	@ApiImplicitParam(name = "req", value = "供应商修改请求对象", required = true, dataType = "InsertOrUpdateRequest")
	@PostMapping("insertOrUpdateSupplier")
	@Permission(require="supplier.list.edit")
	@VolumeLimit
	public BaseResponseEntity<Supplier> insertOrUpdateSupplier(HttpServletRequest request,@RequestBody InsertOrUpdateRequest req) throws AreadyExsitException{
		BaseResponseEntity<Supplier> entity = new BaseResponseEntity<Supplier>();
		
		InsertOrUpdateDto dto = new InsertOrUpdateDto();
		dto.setOldValue(req.getOldValue());
		dto.setValues(req.getModels());
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setId(req.getId());
		dto.setTableName(Customize.SupplierList.getTableName());
		dto.setRoleId(user.getUser().getRoleId());
		dto.setFileAgencyId(req.getFileAgencyId());
		entity.setData((Supplier)manager.insertOrUpdateSupplier(dto).getReturnValue());
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="查询供应商明细(参数id为空则为新增)", notes="查询供应商明细(参数id为空则为新增)")
	@ApiImplicitParam(name = "req", value = "查询供应商明细请求对象", required = true, dataType = "IdRequest")
	@PostMapping("getSupplierDetail")
	@Permission(require="supplier.list.edit")
	public BaseResponseEntity<List<EditDetailResponse>> getSupplierDetail(HttpServletRequest request,@RequestBody IdRequest req
			,@ApiParam(required = false, name = "permissionCode", value= "权限类别")@RequestParam(value = "permissionCode",required=false) String permissionCode){
		SupplierDetailDto dto = new SupplierDetailDto();
		dto.setId(req.getId());
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setRoleId(user.getUser().getRoleId());
		dto.setResourceId(Customize.SupplierList.getResourceId());
		dto.setTableName(Customize.SupplierList.getTableName());
		dto.setModule(Customize.SupplierList.getModule());
		List<EditDetailResponse> details = manager.getSupplierEditArray(dto);
		return BaseEntityUtils.successOne(details);
	}
	
	@ApiOperation(value="获取客户和联系人编辑字段", notes="获取客户和联系人编辑字段")
	@PostMapping("GetSupplierAndContact")
	@Permission(require="supplier.list.edit")
	@VolumeLimit
	public BaseResponseEntity<Map<String,List<EditDetailResponse>>> getCustomerAndContactEdit(HttpServletRequest request,@RequestBody ObjectAndAttachEditRequest req){
		Map<String,List<EditDetailResponse>> result = new HashMap<>();
		BaseResponseEntity<Map<String,List<EditDetailResponse>>> entity = new BaseResponseEntity<>();
		
		SupplierDetailDto dto = new SupplierDetailDto();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setId(req.getId());
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setRoleId(user.getUser().getRoleId());
		
		dto.setResourceId(Customize.SupplierList.getResourceId());
		dto.setTableName(Customize.SupplierList.getTableName());
		dto.setModule(Customize.SupplierList.getModule());
		List<EditDetailResponse> supplierDetails = manager.getSupplierEditArray(dto);
		result.put("basic", supplierDetails);
		dto.setId(req.getAttachId());
		dto.setResourceId(Customize.SupplierContactList.getResourceId());
		dto.setTableName(Customize.SupplierContactList.getTableName());
		dto.setModule(Customize.SupplierContactList.getModule());
		List<EditDetailResponse> contactDetails = contactManager.getSupplierContactEditArray(dto);
		result.put("contact", contactDetails);
		entity.setData(result);
		entity.setSuccess(true);
		return entity;
		
	}
	
	@ApiOperation(value="删除供应商", notes="删除供应商")
	@ApiImplicitParam(name = "req", value = "删除供应商请求对象", required = true, dataType = "DeleteSupplierRequest")
	@PostMapping("deleteSupplier")
	@Permission(require="supplier.list.delete")
	public BaseResponseEntity<SuccessResponse> deleteSupplier(HttpServletRequest request,@RequestBody DeleteSupplierRequest req){
		BaseResponseEntity<SuccessResponse> entity = new BaseResponseEntity<SuccessResponse>();
		DeleteSupplierDto dto = new DeleteSupplierDto();
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setCompanyId(user.getCompanyId());
		dto.setUpdateId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		
		dto.setSupplierIds(req.getSupplierIds());
		manager.deleteSupplier(dto);
		entity.setSuccess(true);
		entity.setData(new SuccessResponse(true));
		return entity;
	}
	
	@ApiOperation(value="查询供应商联系人列表", notes="查询供应商联系人列表")
	@ApiImplicitParam(name = "req", value = "查询供应商联系人列表请求对象", required = true, dataType = "QuerySupplierConcactRequest")
	@PostMapping("querySupplierContactList")
	@Permission(require="supplier.list.preview")
	public BaseResponseEntity<QuerySupplierResponse> querySupplierContactList(HttpServletRequest request,@RequestBody QuerySupplierConcactRequest req){
		QuerySupplierObjectDto queryDto = new QuerySupplierObjectDto();
		JoinfBeanUtils.copyProperties(queryDto, req);
		
		List<SupplierContact> contacts = new ArrayList<SupplierContact>();
		List<SupplierContact> responseList = contactManager.querySupplierList(queryDto);
		
		QuerySupplierDto dto = new QuerySupplierDto();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setRoleId(user.getUser().getRoleId());
		dto.setResourceId(Customize.SupplierContactList.getResourceId());
		dto.setTableName(Customize.SupplierContactList.getTableName());
		dto.setModule(Customize.SupplierContactList.getModule());
		
		BaseResponseEntity<QuerySupplierResponse> entity = new BaseResponseEntity<>();
		if(req.isPaging()){
			contacts = ((Page<SupplierContact>) responseList).getResult();
			entity.setTotalPage(((Page<SupplierContact>) responseList).getPages());
			entity.setTotalRecords(((Page<SupplierContact>) responseList).getTotal());
		}else{
			contacts = responseList;
		}
		
		List<String> showFields = new ArrayList<String>();//显示哪些字段
		showFields.add("name");//名称
		showFields.add("email");//邮箱
		showFields.add("mobile");//联系人电话
		showFields.add("telephone");//联系人生日
		showFields.add("flag");//状态
		showFields.add("sex");//性别
		entity.setSuccess(true);
		entity.setData(contactManager.getContactList(dto,contacts,showFields));//转换数据
		return entity;
	}
	
	@ApiOperation(value="查询供应商联系人列表(联系人)", notes="查询供应商联系人列表(联系人)")
	@ApiImplicitParam(name = "req", value = "查询供应商联系人列表请求对象(联系人)", required = true, dataType = "QuerySupplierConcactRequest")
	@PostMapping("querySupplierContactEmail")
	@Permission(require="supplier.list.preview")
	public BaseResponseEntity<List<SupplierContact>> querySupplierContactEmail(HttpServletRequest request,@RequestBody QuerySupplierConcactRequest req){
		QuerySupplierObjectDto queryDto = new QuerySupplierObjectDto();
		JoinfBeanUtils.copyProperties(queryDto, req);
		
		List<SupplierContact> responseList = contactManager.querySupplierList(queryDto);
		
		BaseResponseEntity<List<SupplierContact>> entity = new BaseResponseEntity<>();
		entity.setSuccess(true);
		entity.setData(responseList);//转换数据
		return entity;
	}
	
	@ApiOperation(value="供应商联系人修改(参数id为空则为新增)", notes="供应商联系人修改(参数id为空则为新增)")
	@ApiImplicitParam(name = "req", value = "供应商修改请求对象", required = true, dataType = "InsertOrUpdateAttachRequest")
	@PostMapping("insertOrUpdateSupplierContact")
	@Permission(require="supplier.list.edit")
	@VolumeLimit
	public BaseResponseEntity<SupplierContact> insertOrUpdateSupplierContact(HttpServletRequest request,@RequestBody InsertOrUpdateAttachRequest req) throws LimitException{
		BaseResponseEntity<SupplierContact> entity = new BaseResponseEntity<SupplierContact>();
		if(req.getAttachId()==null){
			entity.setSuccess(false);
			entity.setErrMsg("请先保存供应商！");
		}else{
			InsertOrUpdateDto dto = new InsertOrUpdateDto();
			dto.setValues(req.getModels());
			dto.setOldValue(req.getOldValue());
			dto.setId(req.getId());
			dto.setTableName(Customize.SupplierContactList.getTableName());
			dto.setAttachId(req.getAttachId());
			
			SessionUser user = SessionUtils.getCurrentUserInfo(request);
			dto.setCompanyId(user.getCompanyId());
			dto.setOperatorId(user.getOperatorId());
			dto.setRoleId(user.getRoleId());
			dto.setSwitchOperatorId(user.getSwitchOperatorId());
			contactManager.insertOrUpdateContact(dto);
		}
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="搜索供应商联系人", notes="搜索客供应商")
	@ApiImplicitParam(name = "req", value = "搜索供应商联系人请求对象", required = true, dataType = "SearchSupplierContactRequest")
	@PostMapping("searchSupplierContact")
	@Permission(require="supplier.list.preview")
	public BaseResponseEntity<List<SearchSupplierContactResult>> searchSupplierContact(HttpServletRequest request,@RequestBody SearchSupplierContactRequest req){
		BaseResponseEntity<List<SearchSupplierContactResult>> entity = new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		SearchSupplierContactParam dto = new SearchSupplierContactParam();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getSwitchOperatorId());
		List<SearchSupplierContactResult> datas = this.supplierService.supplierContactSearch(dto);
		if(req.isPaging()){
			datas = ((Page<SearchSupplierContactResult>)datas).getResult();
			entity.setTotalRecords(((Page<SearchSupplierContactResult>)datas).getTotal());
			entity.setTotalPage(((Page<SearchSupplierContactResult>)datas).getPages());
		}
		entity.setData(datas);
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="查询供应商联系人明细(参数id为空则为新增)", notes="查询供应商联系人明细(参数id为空则为新增)")
	@ApiImplicitParam(name = "req", value = "查询供应商联系人明细对象", required = true, dataType = "IdRequest")
	@PostMapping("getSupplierContactDetail")
	@Permission(require="supplier.list.edit")
	public BaseResponseEntity<List<EditDetailResponse>> getSupplierContactDetail(HttpServletRequest request,@RequestBody IdRequest req
			,@ApiParam(required = false, name = "permissionCode", value= "权限类别")@RequestParam(value = "permissionCode",required=false) String permissionCode){
		SupplierDetailDto dto = new SupplierDetailDto();
		dto.setId(req.getId());
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setRoleId(user.getUser().getRoleId());
		dto.setResourceId(Customize.SupplierContactList.getResourceId());
		dto.setTableName(Customize.SupplierContactList.getTableName());
		dto.setModule(Customize.SupplierContactList.getModule());
		List<EditDetailResponse> details = contactManager.getSupplierContactEditArray(dto);
		return BaseEntityUtils.successOne(details);
	}
	
	@ApiOperation(value="删除供应商联系人", notes="删除供应商联系人")
	@ApiImplicitParam(name = "req", value = "删除供应商联系人对象", required = true, dataType = "UpdateStatusRequest")
	@PostMapping("deleteSupplierContact")
	@Permission(require="supplier.list.delete")
	public BaseResponseEntity<SuccessResponse> deleteSupplierContact(HttpServletRequest request,@RequestBody IdRequest req){
		BaseResponseEntity<SuccessResponse> entity = new BaseResponseEntity<SuccessResponse>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		contactManager.deleteContact(req.getId(), user.getUser().getId());
		entity.setSuccess(true);
		entity.setData(new SuccessResponse(true));
		return entity;
	}
	
	@ApiOperation(value="修改供应商联系人状态", notes="修改供应商联系人状态")
	@ApiImplicitParam(name = "req", value = "修改供应商联系人状态对象", required = true, dataType = "UpdateStatusRequest")
	@PostMapping("updateSupplierContactStatus")
	@Permission(require="supplier.list.edit")
	public BaseResponseEntity<SuccessResponse> deleteSupplierContact(HttpServletRequest request,@RequestBody UpdateStatusRequest req){
		BaseResponseEntity<SuccessResponse> entity = new BaseResponseEntity<SuccessResponse>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		contactManager.updateSupplierContactStatus(req.getId(), user.getOperatorId(),user.getSwitchOperatorId(),req.getFlag());
		entity.setSuccess(true);
		entity.setData(new SuccessResponse(true));
		return entity;
	}
	
	@ApiOperation(value="查询供应商银行列表", notes="查询供应商银行列表")
	@ApiImplicitParam(name = "req", value = "查询供应商银行列表请求对象", required = true, dataType = "QuerySupplierConcactRequest")
	@PostMapping("querySupplierBankList")
	@Permission(require="supplier.list.preview")
	public BaseResponseEntity<QuerySupplierResponse> querySupplierBankList(HttpServletRequest request,@RequestBody QuerySupplierConcactRequest req){
		QuerySupplierObjectDto queryDto = new QuerySupplierObjectDto();
		JoinfBeanUtils.copyProperties(queryDto, req);
		
		List<SupplierBank> banks = new ArrayList<SupplierBank>();
		List<SupplierBank> responseList = bankManager.querySupplierBankList(queryDto);
		
		QuerySupplierDto dto = new QuerySupplierDto();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setRoleId(user.getUser().getRoleId());
		dto.setResourceId(Customize.SupplierBank.getResourceId());
		dto.setTableName(Customize.SupplierBank.getTableName());
		dto.setModule(Customize.SupplierBank.getModule());
		
		
		BaseResponseEntity<QuerySupplierResponse> entity = new BaseResponseEntity<>();
		entity.setSuccess(true);
		
		if(req.isPaging()){
			banks = ((Page<SupplierBank>) responseList).getResult();
			entity.setTotalPage(((Page<SupplierBank>) responseList).getPages());
			entity.setTotalRecords(((Page<SupplierBank>) responseList).getTotal());
		}else{
			banks = responseList;
		}
		List<String> showFields = new ArrayList<String>();//显示哪些字段
		entity.setData(bankManager.getBankList(dto,banks,showFields));//转换数据
		return entity;

	}
	
	@ApiOperation(value="供应商银行修改(参数id为空则为新增)", notes="供应商银行修改(参数id为空则为新增)")
	@ApiImplicitParam(name = "req", value = "供应商修改请求对象", required = true, dataType = "InsertOrUpdateAttachRequest")
	@PostMapping("insertOrUpdateSupplierBank")
	@Permission(require="supplier.list.edit")
	@VolumeLimit
	public BaseResponseEntity<SupplierBank> insertOrUpdateSupplierBank(HttpServletRequest request,@RequestBody InsertOrUpdateAttachRequest req) throws LimitException{
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		BaseResponseEntity<SupplierBank> entity = new BaseResponseEntity<SupplierBank>();
		if(req.getAttachId()==null){
			entity.setSuccess(false);
			entity.setErrMsg("请先保存供应商！");
		}else{
			InsertOrUpdateDto dto = new InsertOrUpdateDto();
			dto.setOldValue(req.getOldValue());
			dto.setValues(req.getModels());
			dto.setId(req.getId());
			dto.setTableName(Customize.SupplierBank.getTableName());
			dto.setAttachId(req.getAttachId());
			dto.setCompanyId(user.getCompanyId());
			dto.setOperatorId(user.getOperatorId());
			dto.setSwitchOperatorId(user.getSwitchOperatorId());
			dto.setRoleId(user.getUser().getRoleId());
			bankManager.insertOrUpdateBank(dto);
		}
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="查询供应商银行明细(参数id为空则为新增)", notes="查询供应商银行明细(参数id为空则为新增)")
	@ApiImplicitParam(name = "req", value = "查询供应商银行明细对象", required = true, dataType = "IdRequest")
	@PostMapping("getSupplierBankDetail")
	@Permission(require="supplier.list.edit")
	public BaseResponseEntity<List<EditDetailResponse>> getSupplierBankDetail(HttpServletRequest request,@RequestBody IdRequest req
			,@ApiParam(required = false, name = "permissionCode", value= "权限类别")@RequestParam(value = "permissionCode",required=false) String permissionCode){
		SupplierDetailDto dto = new SupplierDetailDto();
		dto.setId(req.getId());
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setRoleId(user.getUser().getRoleId());
		dto.setResourceId(Customize.SupplierBank.getResourceId());
		dto.setTableName(Customize.SupplierBank.getTableName());
		dto.setModule(Customize.SupplierBank.getModule());
		List<EditDetailResponse> details = bankManager.getSupplierBankEditArray(dto);
		return BaseEntityUtils.successOne(details);
	}
	
	@ApiOperation(value="删除供应银行", notes="删除供应银行")
	@ApiImplicitParam(name = "req", value = "删除供应银行对象", required = true, dataType = "IdRequest")
	@PostMapping("deleteSupplierBank")
	@Permission(require="supplier.list.delete")
	public BaseResponseEntity<SuccessResponse> deleteSupplierBank(HttpServletRequest request,@RequestBody IdRequest req){
		BaseResponseEntity<SuccessResponse> entity = new BaseResponseEntity<SuccessResponse>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		bankManager.deleteBank(req.getId(), user.getOperatorId(),user.getSwitchOperatorId());
		entity.setSuccess(true);
		entity.setData(new SuccessResponse(true));
		return entity;
	}
	
	@ApiOperation(value="查询供应商附件", notes="查询供应商附件")
	@ApiImplicitParam(name = "req", value = "查询供应商附件请求对象", required = true, dataType = "IdRequest")
	@PostMapping("getSupplierAttachments")
	@Permission(require="supplier.list.preview")
	public BaseResponseEntity<List<CustomerAttachmentResponse>> getSupplierAttachments(HttpServletRequest request,@RequestBody IdRequest req){
		BaseResponseEntity<List<CustomerAttachmentResponse>> entity = new BaseResponseEntity<>();
		entity.setSuccess(true);
		entity.setData(manager.getSupplierAttachments(req.getId()));
		return entity;
	}
	
	@ApiOperation(value="上传供应商附件", notes="上传供应商附件")
	@ApiImplicitParam(name = "req", value = "上传供应商附件请求对象", required = true, dataType = "UploadSupplierAttachmentRequest")
	@PostMapping("uploadCustomerAttachments")
	@Permission(require="customer.list.preview")
	public BaseResponseEntity<SuccessResponse> uploadCustomerAttachments(HttpServletRequest request,@RequestBody UploadSupplierAttachmentRequest req){
		BaseResponseEntity<SuccessResponse> entity = new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		SupplierAttachment attachment = new SupplierAttachment();
		JoinfBeanUtils.copyProperties(attachment, req);
		Date date = new Date();
		attachment.setCompanyId(user.getCompanyId());
		attachment.setCreateTime(date);
		attachment.setFlag(1);
		attachment.setUpdateId(user.getSwitchOperatorId());
		attachment.setUpdateTime(date);
		attachment.setCreateId(user.getSwitchOperatorId());
		manager.uploadSupplierAttachment(attachment);
		entity.setSuccess(true);
		entity.setData(new SuccessResponse(true));
		return entity;
	}
	
	
	
	@ApiOperation(value="删除供应商附件", notes="删除供应商附件")
	@ApiImplicitParam(name = "req", value = "删除供应商附件请求对象", required = true, dataType = "DeleteCustomerRequest")
	@PostMapping("deleteCustomerAttachments")
	@Permission(require="customer.list.delete")
	public BaseResponseEntity<SuccessResponse> deleteCustomerAttachments(HttpServletRequest request,@RequestBody DeleteCustomerRequest req){
		BaseResponseEntity<SuccessResponse> entity = new BaseResponseEntity<SuccessResponse>();
		DeleteSupplierAttachmentDto dto = new DeleteSupplierAttachmentDto();
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setUpdateId(user.getOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setIds(req.getIds());
		manager.deleteSupplierAttachment(dto);
		entity.setSuccess(true);
		entity.setData(new SuccessResponse(true));
		return entity;
	}
	
	
	@ApiOperation(value="查询供应商日志", notes="查询供应商日志")
	@PostMapping("logs")
	@ApiImplicitParam(name = "req", value = "查询供应商请求对象", required = true, dataType = "QuerySupplierLogRequest")
	@NeedLogin
	public BaseResponseEntity<List<LogInfoDto>> submitQuoteApproval(HttpServletRequest request, @RequestBody QuerySupplierLogRequest req) throws Exception{
		SessionUser user = SessionUtils.getCurrentUserInfo(request);	
		BaseResponseEntity<List<LogInfoDto>> entity= new BaseResponseEntity<>();
		QueryDBLogParam param = new QueryDBLogParam();
		JoinfBeanUtils.copyProperties(param, req);
		param.setCompamyId(user.getCompanyId());
		BaseResponseEntity<List<LogInfoDto>> result = logInfoEsService.queryDBLogsFollow(param);
		entity.setData(result.getData());
		entity.setTotalRecords(result.getTotalRecords());
		entity.setSuccess(true);
		return entity;
	}
}
