package com.joinf.request.email;

import java.io.Serializable;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;

/**
 * 邮件分发请求对象
 * 
 * @author CyNick
 *
 */
public class EmailDeliveryRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2105085247053982301L;

	@ApiModelProperty(value = "要分发的邮件id,多个逗号隔开")
	private List<Long> ids;
	@ApiModelProperty(value = "接收邮件的业务员,多个逗号隔开")
	private List<Long> operatorIds;
	@ApiModelProperty(value = "转发人意见")
	private String content;
	
	public List<Long> getIds() {
		return ids;
	}

	public void setIds(List<Long> ids) {
		this.ids = ids;
	}

	public List<Long> getOperatorIds() {
		return operatorIds;
	}

	public void setOperatorIds(List<Long> operatorIds) {
		this.operatorIds = operatorIds;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

}
