package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 登入参数
 *
 * @author lyj
 * @date 2017年12月15日 下午6:59:51
 */
public class LoginRequest {

//	@ApiModelProperty(value="用户id",required=true)
//	private Long userId;
//	
//	@ApiModelProperty(value="公司id",required=true)
//	private Long companyId;
	
	@ApiModelProperty(value="用户名",required=true)
	private String username;
	
	@ApiModelProperty(value="密码",required=true)
	private String password;
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

//	public Long getUserId() {
//		return userId;
//	}
//
//	public void setUserId(Long userId) {
//		this.userId = userId;
//	}
//
//	public Long getCompanyId() {
//		return companyId;
//	}
//
//	public void setCompanyId(Long companyId) {
//		this.companyId = companyId;
//	}

}
