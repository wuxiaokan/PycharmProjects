package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 修改或新增模型
 *
 * @author lyj
 * @date 2017年12月11日 下午7:55:19
 */
public class InsertOrUpdateModel {

	@ApiModelProperty(value="字段名称",required=true)
	private String columnName;
	
	@ApiModelProperty(value="字段显示名称",required=true)
	private String columnDisplayName;
	
	@ApiModelProperty(value="字段值",required=true)
	private Object value;
	
	@ApiModelProperty(value="字段值--显示的值只有字符串格式",required=true)
	private String displayValue;
	
	@ApiModelProperty(value="字段值初始值",required=true)
	private String originalValue;

	public String getOriginalValue() {
		return originalValue;
	}

	public void setOriginalValue(String originalValue) {
		this.originalValue = originalValue;
	}

	public String getDisplayValue() {
		return displayValue;
	}

	public void setDisplayValue(String displayValue) {
		this.displayValue = displayValue;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

	public String getColumnDisplayName() {
		return columnDisplayName;
	}

	public void setColumnDisplayName(String columnDisplayName) {
		this.columnDisplayName = columnDisplayName;
	}
}
