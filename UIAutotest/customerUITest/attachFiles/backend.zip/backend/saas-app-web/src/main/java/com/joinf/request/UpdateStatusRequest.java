package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

public class UpdateStatusRequest {

	@ApiModelProperty("记录id")
	private Long id;
	
	@ApiModelProperty("修改状态：1启用，2停用")
	private Integer flag;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getFlag() {
		return flag;
	}

	public void setFlag(Integer flag) {
		this.flag = flag;
	}
}
