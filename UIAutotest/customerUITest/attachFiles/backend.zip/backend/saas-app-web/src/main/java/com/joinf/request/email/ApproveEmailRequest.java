package com.joinf.request.email;

import com.joinf.request.IdRequest;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 审批邮件请求参数
 * @date 2018年1月22日 下午7:26:54
 */
public class ApproveEmailRequest extends IdRequest{

	@ApiModelProperty(value="审批类型   [0]审批通过  [1]审批退回")
	private int type;
	@ApiModelProperty(value="审批内容")
	private String approvalContent;

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getApprovalContent() {
		return approvalContent;
	}

	public void setApprovalContent(String approvalContent) {
		this.approvalContent = approvalContent;
	}
	
	

	
	
}
