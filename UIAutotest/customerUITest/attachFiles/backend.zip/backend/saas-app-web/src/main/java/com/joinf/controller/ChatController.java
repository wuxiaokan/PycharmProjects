package com.joinf.controller;

import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.joinf.annotations.NeedLogin;
import com.joinf.dto.OperatorDTO;
import com.joinf.entity.SessionUser;
import com.joinf.request.chat.ChatHistoryRequest;
import com.joinf.request.chat.GetCurrentUserMessageRquest;
import com.joinf.request.chat.SendMessageRequest;
import com.joinf.request.chat.UpdateAgentStatusRequest;
import com.joinf.request.chat.UpdateNickNameRequest;
import com.joinf.response.chat.ChatHistoryResponse;
import com.joinf.response.chat.OnlineVisitorResponse;
import com.joinf.response.chat.SiteInfo;
import com.joinf.response.chat.UserMessageResonse;
import com.joinf.service.ChatService;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.base.BaseResponseEntity;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Controller
@RequestMapping("chat")
@Api(tags="客服服务")
public class ChatController {
	
	@Value("${chat.url}")
	private String chatUrl;
	
//	@Value("${server.url}")
//	private String serverUrl;
	
	@Autowired
	private ChatService chatService;
	
	@RequestMapping(value = "index", method = RequestMethod.GET)
	public ModelAndView hello() {
		return new ModelAndView("chat");
	}
	
	
//	@ApiOperation(value=" 登录", notes=" 登录")
//	@GetMapping("login")
//	@ResponseBody
//	@NeedLogin
//	public JSONObject login(HttpServletRequest request) {
//		JSONObject object = new JSONObject();
//		SessionUser user = SessionUtils.getCurrentUserInfo(request);
//		String messageUrl = serverUrl+"/chat/onlineVisitor";
//		String loginName = user.getUser().getUserName();
//		String path = chatUrl+"/operator/getUser?name="+loginName+"&&url="+messageUrl;
//		object.put("success", true);
//		try {
//			String data = HttpClientUtils.httpGet(path);
//			JSONObject dataJson = JSONObject.parseObject(data);
//			
//			object.put("data", dataJson);
//			object.put("agentId", dataJson.getJSONObject("agent").getString("id"));
//		} catch (Exception e) {
//			object.put("success", false);
//		}
//		return object;
//	}
	
	
	@ApiOperation(value="获取站点信息", notes="获取站点信息")
	@PostMapping("getSites")
	@ResponseBody
	@NeedLogin
	public BaseResponseEntity<List<SiteInfo>> getSites(HttpServletRequest request){
		OperatorDTO user = SessionUtils.getCenterOperatorInfo(request);
		BaseResponseEntity<List<SiteInfo>> response = new BaseResponseEntity<>(true);
		response.setData(chatService.getSites(user.getCompanyId(), user.getUserId()));
		return response;
		
	}
	
	/**
	 * 获取在线访客数
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@ApiOperation(value="获取在线访客数", notes="获取在线访客数")
	@PostMapping("onLineCount")
	@ResponseBody
	@NeedLogin
	public BaseResponseEntity<Integer> onLineCount(HttpServletRequest request){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		BaseResponseEntity<Integer> response = new BaseResponseEntity<>(true);
		String loginName = user.getUser().getUserName();
		Integer count = chatService.onLineCount(loginName);
		response.setData(count);
		return response;

	}
	
	@ApiOperation(value=" 获取在线信息", notes=" 获取在线信息")
	@PostMapping("onlineVisitor")
	@ResponseBody
	@NeedLogin
	public BaseResponseEntity<List<OnlineVisitorResponse>> getMessage(HttpServletRequest request,@ApiParam(name="siteId",value="站点id",required=false)@RequestParam(value="siteId",required=false)String siteId){
		BaseResponseEntity<List<OnlineVisitorResponse>> response = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		response.setData(chatService.onlineVisitor(user.getUser().getUserName(), user.getCompanyId(),siteId));
		return response;
	}
	
	
	/**
	 * 历史记录
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@ApiOperation(value="查询客服历史记录", notes="查询客服历史记录")
	@PostMapping("history")
	@ResponseBody
	public BaseResponseEntity<List<ChatHistoryResponse>> chatList(@RequestBody ChatHistoryRequest req,HttpServletRequest request){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		return chatService.history(req, user.getCompanyId(),user.getUser().getUserName());

	}
	
	@ApiOperation(value="查询某个用户历史记录", notes="查询某个用户历史记录")
	@PostMapping("userMessageList")
	@ResponseBody
	public BaseResponseEntity<List<UserMessageResonse>> userMessageList(@ApiParam(name="threadId",value="访客id")@RequestParam("threadId")String threadId){
		BaseResponseEntity<List<UserMessageResonse>> response = new BaseResponseEntity<>(true);
		response.setData(chatService.userMessageList(threadId));
		return response;
		
	}
	
	@ApiOperation(value="退出当前聊天", notes="退出当前聊天")
	@PostMapping("quit")
	@ResponseBody
	public BaseResponseEntity<Boolean> quit(@ApiParam(name="threadId",value="访客id")@RequestParam("threadId")String threadId){
		BaseResponseEntity<Boolean> response = new BaseResponseEntity<>(true);
		chatService.closeThread(threadId);
		return response;
		
	}
	
	@ApiOperation(value="当前聊天记录（轮询查询）", notes="当前聊天记录（轮询查询）")
	@PostMapping("currentUserMessage")
	@ResponseBody
	public BaseResponseEntity<List<UserMessageResonse>> currentUserMessage(@RequestBody GetCurrentUserMessageRquest req,HttpServletRequest request){
		BaseResponseEntity<List<UserMessageResonse>> response = new BaseResponseEntity<>(true);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		String loginName = user.getUser().getUserName();
		response.setData(chatService.currentUserMessage(req,user.getCompanyId(),loginName));
		return response;
		
	}
	
	@ApiOperation(value="修改昵称", notes="修改昵称")
	@PostMapping("updateNickName")
	@ResponseBody
	public BaseResponseEntity<Boolean> updateNickName(HttpServletRequest request,@RequestBody UpdateNickNameRequest req){
		BaseResponseEntity<Boolean> response = new BaseResponseEntity<>(true);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		String loginName = user.getUser().getUserName();
		response.setData(chatService.updateNickName(req.getName(),loginName));
		return response;
		
	}
	
	@ApiOperation(value="发送消息", notes="发送消息")
	@PostMapping("/sendMessage")
	@ResponseBody
	public BaseResponseEntity<Boolean> sendMessage(HttpServletRequest request,@RequestBody SendMessageRequest req){
		BaseResponseEntity<Boolean> response = new BaseResponseEntity<>(true);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		String loginName = user.getUser().getUserName();
		response.setData(chatService.sendMessage(req, loginName));
		return response;
		
	}
	
	@ApiOperation(value="获取昵称", notes="获取昵称")
	@PostMapping("getNickName")
	@ResponseBody
	@NeedLogin
	public BaseResponseEntity<String> getNickName(HttpServletRequest request){
		BaseResponseEntity<String> response = new BaseResponseEntity<>(true);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		String loginName = user.getUser().getUserName();
		response.setData(chatService.getNickName(loginName));
		return response;
		
	}
	
	@ApiOperation(value="获取客服状态", notes="获取客服状态")
	@PostMapping("getAgentStatus")
	@ResponseBody
	@NeedLogin
	public BaseResponseEntity<Integer> getAgentStatus(HttpServletRequest request){
		BaseResponseEntity<Integer> response = new BaseResponseEntity<>(true);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		String loginName = user.getUser().getUserName();
		response.setData(chatService.getAgentStatus(loginName));
		return response;
		
	}
	
	@ApiOperation(value="设置客服状态", notes="设置客服状态")
	@PostMapping("setAgentStatus")
	@ResponseBody
	@NeedLogin
	public BaseResponseEntity<Integer> setAgentStatus(HttpServletRequest request,@RequestBody UpdateAgentStatusRequest req){
		BaseResponseEntity<Integer> response = new BaseResponseEntity<>(true);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		String loginName = user.getUser().getUserName();
		response.setData(chatService.setAgentStatus(loginName,req.getStatus()));
		return response;
		
	}
	
}
