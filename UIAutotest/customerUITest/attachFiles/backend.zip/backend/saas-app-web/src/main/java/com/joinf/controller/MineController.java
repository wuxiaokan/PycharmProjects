package com.joinf.controller;

import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.joinf.annotations.NeedLogin;
import com.joinf.dto.CompanyDTO;
import com.joinf.dto.customer.QueryUnContactCustomerDto;
import com.joinf.dto.message.MessageDto;
import com.joinf.dto.message.MessageManageDto;
import com.joinf.entity.SessionUser;
import com.joinf.interfaces.CommonManager;
import com.joinf.interfaces.customer.CustomerContactManager;
import com.joinf.interfaces.customer.CustomerManager;
import com.joinf.interfaces.message.MessageManager;
import com.joinf.request.UpdateSystemMessageReadRequest;
import com.joinf.response.RemainResponse;
import com.joinf.response.SuccessResponse;
import com.joinf.response.msg.SystemMessageResponse;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.util.JoinfBeanUtils;
import com.joinf.utils.util.StringUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

/**
 * Description: 个人信息及提醒相关
 *
 * @author lyj
 * @date 2017年12月22日 下午2:31:50
 */
@Slf4j
@RestController
@RequestMapping("mine")
@Api(tags = "个人信息及提醒相关")
public class MineController {
	
	@Autowired
	private CustomerContactManager customerContactManager;
	
	@Autowired
	private CustomerManager customerManager;
	
//	@Autowired
//	private MessageManagerImpl messageManager;
	
	@Autowired
	private CommonManager commonManager;
	
	@Autowired
	private MessageManager messageManager;
	
	/**
	 * 个人提醒
	 * @param req
	 * @return
	 */
	@ApiOperation(value="个人提醒", notes="个人提醒")
	@PostMapping("getRemain")
	@NeedLogin
	public BaseResponseEntity<RemainResponse> getRemain(HttpServletRequest request){
		BaseResponseEntity<RemainResponse> response = new BaseResponseEntity<RemainResponse>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		Long companyId = user.getCompanyId();
		Long operatorId = user.getSwitchOperatorId();
		Long birthday = customerContactManager.getCustomerBirthdayCount(operatorId, companyId);
		Integer duringMove = customerManager.getMovingToPublicCustomerCount(companyId, operatorId).size();
		
		QueryUnContactCustomerDto queryDto = new QueryUnContactCustomerDto();
		queryDto.setCompanyId(companyId);
		queryDto.setOperatorId(operatorId);
		queryDto.setDataType("lately_month");
		
		String operatorIds = commonManager.getAssignmentIds(companyId, operatorId);
		if (StringUtils.isNotBlank(operatorIds)) {
			queryDto.setOperatorIds(StringUtil.toListLong(operatorIds));
		}
		Long unContact = customerManager.countUnContactCustomerByTime(queryDto);
		
		Integer threeDayFollowUpCustomers = customerManager.getCustomerByFollowUpTime(companyId, operatorId, 72);
		
		RemainResponse remain = new RemainResponse();
		remain.setThreeDayNeedFollowUpCustomer(threeDayFollowUpCustomers);
		remain.setBirthdayCount(birthday);
		remain.setDuringMoveCount(duringMove.longValue());
		remain.setUnContactCount(unContact);
		response.setData(remain);
		response.setSuccess(true);
		return response;
	}
	
	
	
	/**
	 * 未读消息
	 * @param req
	 * @return
	 * @throws ParseException 
	 */
	@ApiOperation(value="未读信息", notes="未读信息")
	@PostMapping("getUnReadMessage")
	@NeedLogin
	public BaseResponseEntity<List<SystemMessageResponse>> getUnReadMessage(HttpServletRequest request) throws ParseException{
		BaseResponseEntity<List<SystemMessageResponse>> entity = new BaseResponseEntity<>();
		CompanyDTO companyDTO = SessionUtils.getCenterCompanyInfo(request);
		List<MessageManageDto> list = messageManager
				.selectNotExpiredMessageManageByCenterCompanyId(companyDTO.getCompanyId(),1);
		List<SystemMessageResponse> resList = JoinfBeanUtils.copyToNewListBean(SystemMessageResponse.class, list);
		entity.setData(resList);
		entity.setSuccess(true);
		return entity;
	}
	/**
	 * 标记消息已读
	 * @param req
	 * @return
	 * @throws ParseException 
	 */
	@ApiOperation(value="标记消息已读", notes="标记消息已读")
	@PostMapping("updateSystemMessageRead")
	@ApiImplicitParam(name = "req", value = "标记消息已读请求对象--参数为list集合", required = true, dataType = "UpdateSystemMessageReadRequest")
	@NeedLogin
	public BaseResponseEntity<SuccessResponse> updateSystemMessageRead(HttpServletRequest request,@RequestBody List<UpdateSystemMessageReadRequest>req) throws ParseException{
		BaseResponseEntity<SuccessResponse> response = new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		MessageDto dto = JoinfBeanUtils.copyToNewBean(MessageDto.class, req);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getOperatorId());
		dto.setRead(true);//标注为已读
		try {
			int i = 0;
			i = messageManager.messageManageRecord(dto);
			if(i == 1){
				response.setSuccess(true);
			}else{
				response.setSuccess(false);
			}
		} catch (Exception e) {
			log.error("全局消息点击记录异常：{}",e.getMessage());
			response.setSuccess(false);
			response.setErrMsg("全局消息点击记录异常!");
		}
		response.setSuccess(true);
		return response;
	}
	
}
