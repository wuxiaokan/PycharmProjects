package com.joinf.request;

/**
 * 签名信息
 * @author zlx
 */
public class AuthReq {
	
	/** 签名时间戳 */
	public String timestamp;
	/** 签名 */
	public String sign;
	/** 签名方式  */
	public String signType;
	
	
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public String getSign() {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}
	public String getSignType() {
		return signType;
	}
	public void setSignType(String signType) {
		this.signType = signType;
	}
	
	

}