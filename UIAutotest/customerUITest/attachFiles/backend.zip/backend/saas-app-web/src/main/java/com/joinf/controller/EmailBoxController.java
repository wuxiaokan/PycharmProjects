package com.joinf.controller;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.joinf.annotations.NeedLogin;
import com.joinf.dto.CompanyAndOperatorIdDto;
import com.joinf.dto.IdArrayDto;
import com.joinf.dto.QueryCustomerBoxDto;
import com.joinf.dto.QueryEmailBoxDto;
import com.joinf.dto.QueryEmailNumByBoxDto;
import com.joinf.email.enums.EmailSimpleBox;
import com.joinf.entity.SessionUser;
import com.joinf.entity.dto.EmailBoxCategoryDto;
import com.joinf.entity.dto.EmailBoxEntityDto;
import com.joinf.entity.dto.EmailNumEntityDto;
import com.joinf.interfaces.MsgService;
import com.joinf.interfaces.order.OrderManager;
import com.joinf.interfaces.quote.QuoteManager;
import com.joinf.request.IdArrayRequest;
import com.joinf.request.email.EmailBoxSaveRequest;
import com.joinf.request.email.QueryCustomerBoxRequest;
import com.joinf.request.email.QueryEmailBoxRequest;
import com.joinf.request.email.QueryEmailNumRequest;
import com.joinf.response.email.EmailBoxCusCategoryResponse;
import com.joinf.response.email.EmailSimpleResponse;
import com.joinf.response.email.QueryEmailNumByBoxResponse;
import com.joinf.service.ChatService;
import com.joinf.service.email.EmailBoxManagerImpl;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.annotations.ResubmitData;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.util.JoinfBeanUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * @author zlx
 * @Description: 邮件箱子服务
 * @date 2018年1月5日 上午11:36:49
 */
@RestController
@RequestMapping("email")
@Api(tags="邮件箱子服务")
public class EmailBoxController {
	
	@Autowired
	private EmailBoxManagerImpl emailBoxManager;
	
	@Autowired
	private QuoteManager quoteManager;
	
	@Autowired
	private OrderManager orderManager;
	
	@Autowired
	private ChatService chatService;
	
	@Autowired
	private MsgService msgService;
	
	/**
	 * 获取邮件基础箱子枚举
	 * @return
	 */
	@ApiOperation(value="获取邮件基础箱子枚举(提供给前端做对照)", notes="获取邮件基础箱子枚举")
	@GetMapping(value = "/queryEmailSimpeBoxEnum")
	@ResponseBody
	public BaseResponseEntity<Map<Long, String>> queryEmailSimpeBoxEnum(HttpSession session) {
		
		BaseResponseEntity<Map<Long, String>> result = new BaseResponseEntity<>(true);
		
		Map<Long, String> map = new LinkedHashMap<>();
		for(EmailSimpleBox p : EmailSimpleBox.values()) {
			map.put(p.value(), EmailSimpleBox.fromValue(p.value()));
        }
		result.setData(map);
		
		return result;
	}
	
	/**
	 * 查询箱子下邮件数量
	 * @return
	 */
	@ApiOperation(value="查询箱子下邮件数量", notes="查询箱子下邮件数量")
	@ApiImplicitParam(name = "req", value = "查询箱子下邮件数量请求对象", required = true, dataType = "QueryEmailNumRequest")
	@PostMapping(value = "/queryEmailNum")
	@ResponseBody
	@NeedLogin
	public BaseResponseEntity<List<QueryEmailNumByBoxResponse>> queryEmailNum(HttpServletRequest request,@RequestBody QueryEmailNumRequest req) {
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		Long companyId = user.getCompanyId();
		Long operatorId = user.getSwitchOperatorId();
		BaseResponseEntity<List<QueryEmailNumByBoxResponse>> entity = new BaseResponseEntity<>(true);
		
		
		QueryEmailNumByBoxDto queryDto = JoinfBeanUtils.copyToNewBean(QueryEmailNumByBoxDto.class, req);
		queryDto.setCompanyId(companyId);
		queryDto.setOperatorId(operatorId);
		
		//审批箱所需参数
		queryDto.setAuditOperatorId(user.getSwitchOperatorId());
		queryDto.setLoginOperatorId(user.getOperatorId()); //实际登陆人id
		
		List<EmailNumEntityDto> emailNumList = this.emailBoxManager.queryEmailNumByBox(queryDto);
		
		List<QueryEmailNumByBoxResponse> resultList = JoinfBeanUtils.copyToNewListBean(QueryEmailNumByBoxResponse.class, emailNumList);
		
		
		for(Long boxId:req.getBoxIdArray()){
			//待批合同
			if(boxId.equals(EmailSimpleBox.APPROVALORDER.value()))
				resultList.add(new QueryEmailNumByBoxResponse(EmailSimpleBox.APPROVALORDER.value(),orderManager.getApprovalOrderNum(companyId, operatorId).intValue()));
			//待批报价
			if(boxId.equals(EmailSimpleBox.APPROVALQUOTE.value()))
				resultList.add(new QueryEmailNumByBoxResponse(EmailSimpleBox.APPROVALQUOTE.value(),quoteManager.selectApprovalQuotes(companyId, operatorId).intValue()));
			if(boxId.equals(EmailSimpleBox.CHATMESSAGE.value()))
				resultList.add(new QueryEmailNumByBoxResponse(EmailSimpleBox.CHATMESSAGE.value(),chatService.onLineCount(user.getUser().getUserName())));
			if(boxId.equals(EmailSimpleBox.SYSTEMMESSAGE.value())){
				Map<String,Object> map = new HashMap<String,Object>();
				map.put("companyId", companyId);
				map.put("operatorId", operatorId);
				map.put("has_read", 0);
				resultList.add(new QueryEmailNumByBoxResponse(EmailSimpleBox.SYSTEMMESSAGE.value(),msgService.selectCountByTypeAndOperatorId(map).intValue()));
			}
				
				
		}
		entity.setData(resultList);
		
		return entity;
	}

	/**
	 * 查询内部联系人箱子列表
	 * @return
	 */
	@ApiOperation(value="查询内部联系人箱子列表", notes="查询内部联系人箱子列表")
	@PostMapping(value = "/queryInternalOperatorBox")
	@ResponseBody
	@NeedLogin
	public BaseResponseEntity<List<EmailSimpleResponse>> queryInternalOperatorBox(HttpServletRequest request) {
		
		BaseResponseEntity<List<EmailSimpleResponse>> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		CompanyAndOperatorIdDto queryDto = new CompanyAndOperatorIdDto();
		queryDto.setCompanyId(user.getCompanyId());
		queryDto.setLoginOperatorId(user.getOperatorId());
		queryDto.setOperatorId(user.getSwitchOperatorId());
		
		List<EmailBoxEntityDto> emailBoxList = this.emailBoxManager.queryInternalOperatorBox(queryDto,user.getUser().getChineseName());
		
		List<EmailSimpleResponse> resultList = JoinfBeanUtils.copyToNewListBean(EmailSimpleResponse.class, emailBoxList);
		entity.setData(resultList);
		
		return entity;
	}
	
	/**
	 * 查询自定义箱子列表
	 * @return
	 */
	@ApiOperation(value="查询自定义箱子列表", notes="查询自定义箱子列表")
	@PostMapping(value = "/querySelfDefinitionBox")
	@ResponseBody
	@NeedLogin
	public BaseResponseEntity<List<EmailSimpleResponse>> querySelfDefinitionBox(HttpServletRequest request,@RequestBody QueryEmailBoxRequest req) {
		
		BaseResponseEntity<List<EmailSimpleResponse>> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		QueryEmailBoxDto queryDto = new QueryEmailBoxDto();
		queryDto.setCompanyId(user.getCompanyId());
		queryDto.setOperatorId(user.getSwitchOperatorId());
		queryDto.setType(req.getType());
		List<EmailBoxEntityDto> emailBoxList = this.emailBoxManager.querySelfDefinitionEmailBoxList(queryDto);
		
		List<EmailSimpleResponse> resultList = JoinfBeanUtils.copyToNewListBean(EmailSimpleResponse.class, emailBoxList);
		entity.setData(resultList);
		
		return entity;
	}
	
	/**
	 * 自定义邮箱新建、修改
	 * @param request
	 * @param req
	 * @return
	 */
	@ApiOperation(value="自定义箱修改(参数id为空则为新增)", notes="自定义箱修改(参数id为空则为新增)")
	@ApiImplicitParam(name = "req", value = "自定义箱修改请求对象", required = true, dataType = "EmailBoxSaveRequest")
	@PostMapping("insertOrUpdateSelfEmailBox")
    @ResponseBody
    @NeedLogin
    @ResubmitData
    public BaseResponseEntity<Long> insertOrUpdateSelfEmailBox(HttpServletRequest request,@RequestBody EmailBoxSaveRequest req) {
		
		BaseResponseEntity<Long> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		EmailBoxEntityDto saveDto = JoinfBeanUtils.copyToNewBean(EmailBoxEntityDto.class, req);
		saveDto.setCompanyId(user.getCompanyId());
		saveDto.setOperatorId(user.getSwitchOperatorId());
		
		Long id = this.emailBoxManager.insertOrUpdateEmailBox(saveDto);
		
		entity.setData(id);
		
		return entity;
    }
	
	/**
	 * 删除自定义箱
	 * @param request
	 * @param req
	 * @return
	 */
    @ApiOperation(value="删除自定义箱", notes="删除自定义箱")
	@ApiImplicitParam(name = "req", value = "删除自定义箱请求对象", required = true, dataType = "IdArrayRequest")
	@PostMapping("deleteSelfEmailBox")
    @ResponseBody
    @NeedLogin
    public BaseResponseEntity<Integer> deleteSelfEmailBox(HttpServletRequest request,@RequestBody IdArrayRequest req) {
    	BaseResponseEntity<Integer> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		IdArrayDto deleteto = JoinfBeanUtils.copyToNewBean(IdArrayDto.class, req);
		deleteto.setCompanyId(user.getCompanyId());
		deleteto.setOperatorId(user.getSwitchOperatorId());
		
		int num = this.emailBoxManager.deleteSelfEmailBox(deleteto);
		
		entity.setData(num);
		
		return entity;
    }
    
    
    /**
	 * 查询客户箱分类列表
	 * @return
	 */
	@ApiOperation(value="查询客户箱分类列表", notes="查询客户箱分类列表")
	@PostMapping(value = "/queryCustomerBoxCategory")
	@ResponseBody
	@NeedLogin
	public BaseResponseEntity<List<EmailBoxCusCategoryResponse>> queryCustomerBoxCategory(HttpServletRequest request) {
		
		BaseResponseEntity<List<EmailBoxCusCategoryResponse>> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		CompanyAndOperatorIdDto queryDto = new CompanyAndOperatorIdDto();
		queryDto.setCompanyId(user.getCompanyId());
		queryDto.setOperatorId(user.getSwitchOperatorId());
		
		List<EmailBoxCategoryDto> cusCategoryList = this.emailBoxManager.queryCustomerBoxCategory(queryDto);
		
		List<EmailBoxCusCategoryResponse> resultList = JoinfBeanUtils.copyToNewListBean(EmailBoxCusCategoryResponse.class, cusCategoryList);
		entity.setData(resultList);
		
		return entity;
	}
	
	@ApiOperation(value="查询供应商分类列表", notes="查询供应商分类列表")
	@PostMapping(value = "/querySupplierBoxCategory")
	@ResponseBody
	@NeedLogin
	public BaseResponseEntity<List<EmailBoxCusCategoryResponse>> querySupplierBoxCategory(HttpServletRequest request) {
		
		BaseResponseEntity<List<EmailBoxCusCategoryResponse>> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		CompanyAndOperatorIdDto queryDto = new CompanyAndOperatorIdDto();
		queryDto.setCompanyId(user.getCompanyId());
		queryDto.setOperatorId(user.getSwitchOperatorId());
		
		List<EmailBoxCategoryDto> cusCategoryList = this.emailBoxManager.querySupplierBoxCategory(queryDto);
		
		List<EmailBoxCusCategoryResponse> resultList = JoinfBeanUtils.copyToNewListBean(EmailBoxCusCategoryResponse.class, cusCategoryList);
		entity.setData(resultList);
		
		return entity;
	}
	
	
	 /**
	 * 查询客户箱列表
	 * @return
	 */
	@ApiOperation(value="查询客户箱列表", notes="查询客户箱列表")
	@PostMapping(value = "/queryCustomerBox")
	@ResponseBody
	@NeedLogin
	public BaseResponseEntity<List<EmailSimpleResponse>> queryCustomerBox(HttpServletRequest request,@RequestBody QueryCustomerBoxRequest req) {
		
		BaseResponseEntity<List<EmailSimpleResponse>> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		QueryCustomerBoxDto queryDto = JoinfBeanUtils.copyToNewBean(QueryCustomerBoxDto.class, req);
		queryDto.setCompanyId(user.getCompanyId());
		queryDto.setOperatorId(user.getSwitchOperatorId());
		
		List<EmailBoxEntityDto> emailBoxList = this.emailBoxManager.queryCustomerBoxList(queryDto);
		
		List<EmailSimpleResponse> resultList = JoinfBeanUtils.copyToNewListBean(EmailSimpleResponse.class, emailBoxList);
		entity.setData(resultList);
		
		return entity;
	}
	
	/**
	 * 查询客户箱列表
	 * @return
	 */
	@ApiOperation(value="查询供应商列表", notes="查询供应商列表")
	@PostMapping(value = "/querySupplierBox")
	@ResponseBody
	@NeedLogin
	public BaseResponseEntity<List<EmailSimpleResponse>> querySupplierBox(HttpServletRequest request,@RequestBody QueryCustomerBoxRequest req) {
		
		BaseResponseEntity<List<EmailSimpleResponse>> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		QueryCustomerBoxDto queryDto = JoinfBeanUtils.copyToNewBean(QueryCustomerBoxDto.class, req);
		queryDto.setCompanyId(user.getCompanyId());
		queryDto.setOperatorId(user.getSwitchOperatorId());
		
		List<EmailBoxEntityDto> emailBoxList = this.emailBoxManager.querySupplierBoxList(queryDto);
		
		List<EmailSimpleResponse> resultList = JoinfBeanUtils.copyToNewListBean(EmailSimpleResponse.class, emailBoxList);
		entity.setData(resultList);
		
		return entity;
	}
	
	
	
	
}
