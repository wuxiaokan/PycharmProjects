package com.joinf.request.email;

import java.io.Serializable;

public class CometEmailDto implements Serializable{
	
private static final long serialVersionUID = 1L;
	
	/**
	 * 条数
	 */
	private int count;
	/**
	 * 邮件ID
	 */
	private Long id;
	
	/**
	 * 箱子ID
	 */
	private Long boxId;
	
	/**
	 * 邮件标题
	 */
	private String subject;
	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getBoxId() {
		return boxId;
	}

	public void setBoxId(Long boxId) {
		this.boxId = boxId;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	
	
	
	
}
