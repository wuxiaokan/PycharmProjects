package com.joinf.request.email;

import java.io.Serializable;

import com.joinf.request.IdArrayRequest;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 标记邮件状态
 * @date 2018年1月12日 下午2:43:01
 */
public class UpdateEmailForMarkRequest extends IdArrayRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2596363725471279783L;

	@ApiModelProperty(value="标记类型  [0]已读、[1]未读、[2]免回复、[3]取消免回复、[4]星标、[5]取消星标")
	private int type;
	

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}


}
