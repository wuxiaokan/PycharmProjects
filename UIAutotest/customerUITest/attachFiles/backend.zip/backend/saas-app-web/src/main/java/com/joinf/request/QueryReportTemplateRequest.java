package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 查询报表模板
 *
 * @author lyj
 * @date 2018年4月9日 下午3:19:07
 */
public class QueryReportTemplateRequest {
	
	@ApiModelProperty(value = "模板类型:[1]订单模板;[2]报价模板;[3]产品模板;")
	private Integer type;

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

}
