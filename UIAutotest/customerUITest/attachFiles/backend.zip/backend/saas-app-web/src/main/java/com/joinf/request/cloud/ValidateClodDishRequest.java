package com.joinf.request.cloud;

import io.swagger.annotations.ApiModelProperty;

public class ValidateClodDishRequest {

	@ApiModelProperty("0[共享] 1[个人]")
	private Integer type;
	
	@ApiModelProperty("文件id")
	private Long catalogueId;

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Long getCatalogueId() {
		return catalogueId;
	}

	public void setCatalogueId(Long catalogueId) {
		this.catalogueId = catalogueId;
	}
}
