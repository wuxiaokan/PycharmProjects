package com.joinf.request.customer;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 标记客户状态
 * @date 2018年1月12日 下午2:43:01
 */
public class UpdateCustomerForMarkRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2596363725471279783L;
	
	@ApiModelProperty(value="客户id")
	private Long customerId;

	@ApiModelProperty(value="标记类型 [0]星标、[1]取消星标")
	private int type;
	

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	

}
