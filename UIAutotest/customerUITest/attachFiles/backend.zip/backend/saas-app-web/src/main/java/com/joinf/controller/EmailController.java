package com.joinf.controller;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.joinf.utils.dto.log.LogRecordResultDto;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.Page;
import com.joinf.JoinfClientUtils;
import com.joinf.annotations.NeedLogin;
import com.joinf.config.SaasClientConfig;
import com.joinf.dto.ApproveEmailDto;
import com.joinf.dto.AttachmentBaseDto;
import com.joinf.dto.CompanyDTO;
import com.joinf.dto.InterForwardEmailDto;
import com.joinf.dto.QueryByIdDto;
import com.joinf.dto.QuerySimpleEmailDto;
import com.joinf.dto.QueryEmailDetailDto;
import com.joinf.dto.QueryEmailDto;
import com.joinf.dto.RestoredEmailDto;
import com.joinf.dto.SaveAttachmentBaseDto;
import com.joinf.dto.SaveEmailDto;
import com.joinf.dto.SentEmailDto;
import com.joinf.dto.SentReceiptEmailDto;
import com.joinf.dto.UpdateEmailForMarkDto;
import com.joinf.dto.WriteEmailInitDto;
import com.joinf.dto.email.EmailDeliveryDto;
import com.joinf.dto.email.QueryEmailContactMailboxDto;
import com.joinf.dto.email.SentEmailResponseDto;
import com.joinf.email.enums.EmailOperate;
import com.joinf.email.enums.EmailStatus;
import com.joinf.entity.SessionUser;
import com.joinf.entity.dto.CheckBlackSaveDto;
import com.joinf.entity.dto.EmailDetailEntityDto;
import com.joinf.entity.dto.EmailEntityDto;
import com.joinf.entity.dto.EmailWriteEntityDto;
import com.joinf.request.IdRequest;
import com.joinf.request.email.ApproveEmailRequest;
import com.joinf.request.email.CheckSendFrequencyRequest;
import com.joinf.request.email.DeleteEmailRequest;
import com.joinf.request.email.EmailDeliveryRequest;
import com.joinf.request.email.InterForwardEmailRequest;
import com.joinf.request.email.QueryEmailDetailRequest;
import com.joinf.request.email.QueryEmailListRequest;
import com.joinf.request.email.SaveEmailAttachmentRequest;
import com.joinf.request.email.SaveEmailRequest;
import com.joinf.request.email.SentEmailRequest;
import com.joinf.request.email.SentReceiptEmailRequest;
import com.joinf.request.email.UpdateEmailForMarkRequest;
import com.joinf.request.email.WriteEmailInitRequest;
import com.joinf.response.email.EmailAttachmentResponse;
import com.joinf.response.email.QueryEmailContactMailboxResponse;
import com.joinf.response.email.QueryEmailDetailResponse;
import com.joinf.response.email.QueryEmailResponse;
import com.joinf.response.email.SentEmailResponse;
import com.joinf.response.email.WriteEmailInitResponse;
import com.joinf.service.email.EmailManagerImpl;
import com.joinf.service.email.EmailSentMqManagerImpl;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.annotations.Permission;
import com.joinf.utils.annotations.ResubmitData;
import com.joinf.utils.annotations.VolumeLimit;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.util.JoinfBeanUtils;

import freemarker.template.TemplateException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * Description: 邮件服务
 *
 * @author zlx
 * @date 2018年1月4日 下午5:42:34
 */
@RestController
@RequestMapping("email")
@Api(tags="邮件服务")
public class EmailController {
	@Autowired
	private EmailManagerImpl emailManager;
	@Autowired
	private EmailSentMqManagerImpl emailSentMqManager;
	
	/**
	 * 获取邮件状态枚举
	 * @param session
	 * @return
	 */
	@ApiOperation(value="获取邮件状态枚举(提供给前端做对照)", notes="获取邮件状态枚举")
	@GetMapping(value = "/queryEmailStatusEnum")
	@ResponseBody
	public BaseResponseEntity<Map<Integer, String>> queryEmailStatusEnum(HttpSession session) {
		
		BaseResponseEntity<Map<Integer, String>> result = new BaseResponseEntity<>(true);
		
		Map<Integer, String> map = new LinkedHashMap<>();
		for(EmailStatus p : EmailStatus.values()) {
			map.put(p.value(), EmailStatus.fromValue(p.value()));
        }
		result.setData(map);
		
		return result;
	}
	
	/**
	 * 获取标记为操作类型枚举
	 * @param session
	 * @return
	 */
	@ApiOperation(value="获取标记为操作类型枚举(提供给前端做对照)", notes="获取标记为操作类型枚举")
	@GetMapping(value = "/queryEmailOperateEnum")
	@ResponseBody
	public BaseResponseEntity<Map<Integer, String>> queryEmailOperateEnum(HttpSession session) {
		
		BaseResponseEntity<Map<Integer, String>> result = new BaseResponseEntity<>(true);
		
		Map<Integer, String> map = new LinkedHashMap<>();
		for(EmailOperate p : EmailOperate.values()) {
			map.put(p.value(), EmailOperate.fromValue(p.value()));
        }
		result.setData(map);
		
		return result;
	}
	
	/**
	 * 查询邮件列表
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询邮件列表", notes="查询邮件列表")
	@ApiImplicitParam(name = "req", value = "查询邮件列表请求对象", required = true, dataType = "QueryEmailListRequest")
	@PostMapping("queryEmailList")
	@Permission(require="email.list.preview")
	@NeedLogin
	public BaseResponseEntity<List<QueryEmailResponse>> queryEmailList(HttpServletRequest request,@RequestBody QueryEmailListRequest req){
		BaseResponseEntity<List<QueryEmailResponse>> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		QueryEmailDto queryDto = JoinfBeanUtils.copyToNewBean(QueryEmailDto.class, req);
		queryDto.setCompanyId(user.getCompanyId());
		queryDto.setOperatorId(user.getSwitchOperatorId());
		
		
		//审批箱所需参数
		queryDto.setAuditOperatorId(user.getSwitchOperatorId());
		queryDto.setLoginOperatorId(user.getOperatorId());
		
		List<EmailEntityDto> emailList = emailManager.queryEmailListByCondition(queryDto);
		if(req.isPaging()){
			entity.setTotalPage(((Page<EmailEntityDto>) emailList).getPages());
			entity.setTotalRecords(((Page<EmailEntityDto>) emailList).getTotal());
		}
		
		List<QueryEmailResponse> resultList = JoinfBeanUtils.copyToNewListBean(QueryEmailResponse.class, emailList);
		entity.setData(resultList);
		
		return entity;
	}
	
	

	/**
	 * 查询邮件详情
	 * @param req
	 * @return
	 * @throws TemplateException 
	 * @throws IOException 
	 */
	@ApiOperation(value="查询邮件详情", notes="查询邮件详情")
	@ApiImplicitParam(name = "req", value = "查询邮件详情请求对象", required = true, dataType = "QueryEmailDetailRequest")
	@PostMapping("queryEmailDetail")
	@NeedLogin
	@Permission(require="email.list.preview")
	public BaseResponseEntity<QueryEmailDetailResponse> queryEmailDetail(HttpServletRequest request,@RequestBody QueryEmailDetailRequest req) throws IOException, TemplateException{
		BaseResponseEntity<QueryEmailDetailResponse> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		QueryEmailDetailDto queryDto = JoinfBeanUtils.copyToNewBean(QueryEmailDetailDto.class, req);
		queryDto.setCompanyId(user.getCompanyId());
		queryDto.setOperatorId(user.getSwitchOperatorId());
		queryDto.setLoginOperatorId(user.getOperatorId());
		
		EmailDetailEntityDto emailDetailEntityDto = emailManager.queryEmailDetailByCondition(queryDto);
		
		QueryEmailDetailResponse queryEmailDetailResponse = JoinfBeanUtils.copyToNewBean(QueryEmailDetailResponse.class, emailDetailEntityDto);
		if(emailDetailEntityDto.getEmailAttachmentList() != null){
			List<EmailAttachmentResponse> attachmentList = JoinfBeanUtils.copyToNewListBean(EmailAttachmentResponse.class, emailDetailEntityDto.getEmailAttachmentList());
			for (EmailAttachmentResponse emailAttachmentResponse : attachmentList) {
				emailAttachmentResponse.setUrl(JoinfClientUtils.getUrl(SaasClientConfig.saasClientConfig,emailAttachmentResponse.getFileCode()));
			}
			queryEmailDetailResponse.setAttachmentList(attachmentList);
		}
		
		//原样返回数据
		queryEmailDetailResponse.setRowNum(req.getRowNum());
		queryEmailDetailResponse.setNum(req.getNum());
		
		entity.setData(queryEmailDetailResponse);
		
		return entity;
	}
	
	
	/**
	 * 邮件标记为：已读、未读、免回复、取消免回复、星标、取消星标
	 * @param request
	 * @param req
	 * @return
	 */
	@ApiOperation(value="标记邮件状态", notes="标记邮件状态")
	@ApiImplicitParam(name = "req", value = "标记邮件状态请求对象", required = true, dataType = "UpdateEmailForMarkRequest")
	@PostMapping(value = "/updateEmailForMark")
	@ResponseBody
	@NeedLogin
	@ResubmitData
	public BaseResponseEntity<Integer> updateEmailForMark(HttpServletRequest request, @RequestBody UpdateEmailForMarkRequest req) {
		
		BaseResponseEntity<Integer> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		UpdateEmailForMarkDto updateDto = JoinfBeanUtils.copyToNewBean(UpdateEmailForMarkDto.class, req);
		updateDto.setCompanyId(user.getCompanyId());
		if (updateDto.getIdArray() != null && updateDto.getIdArray().length > 0) {
			if(updateDto.getIdArray()[0] != null){
				entity.setData(emailManager.updateEmailForMark(updateDto));
			}
		}
		
				
		return entity;
	}
	
	
	/**
	 * 删除或清空邮件
	 * @param request
	 * @param req
	 * @return
	 */
	@ApiOperation(value="删除或清空邮件", notes="删除或清空邮件")
	@ApiImplicitParam(name = "req", value = "删除或清空邮件请求对象", required = true, dataType = "DeleteEmailRequest")
	@PostMapping(value = "/deleteEmail")
	@ResponseBody
	@NeedLogin
	@Permission(require = "email.list.delete")
	@ResubmitData
	public BaseResponseEntity<Integer> deleteEmail(HttpServletRequest request, @RequestBody DeleteEmailRequest req) {
		
		BaseResponseEntity<Integer> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		QuerySimpleEmailDto queryDto = JoinfBeanUtils.copyToNewBean(QuerySimpleEmailDto.class, req);
		queryDto.setCompanyId(user.getCompanyId());
		queryDto.setOperatorId(user.getSwitchOperatorId());
		
		queryDto.setOperatorUserName(user.getUser().getUserName());
		queryDto.setOperatorTrueName(user.getSwitchOperator().getZhName());

		LogRecordResultDto<Integer> deleteResult = emailManager.deleteEmail(queryDto);

		entity.setData(deleteResult.getData());
				
		return entity;
	}
	
	/**
	 * 拒收邮件
	 * @param request
	 * @param req
	 * @return
	 */
	@ApiOperation(value="拒收邮件", notes="拒收邮件")
	@ApiImplicitParam(name = "req", value = "拒收邮件请求对象", required = true, dataType = "IdRequest")
	@PostMapping(value = "/refuseEmail")
	@ResponseBody
	@NeedLogin
	@ResubmitData
	public BaseResponseEntity<CheckBlackSaveDto> refuseEmail(HttpServletRequest request, @RequestBody IdRequest req) {
		
		BaseResponseEntity<CheckBlackSaveDto> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		QueryByIdDto dto = JoinfBeanUtils.copyToNewBean(QueryByIdDto.class, req);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getSwitchOperatorId());
		dto.setLoginOperatorId(user.getOperatorId());
		
		entity.setData(emailManager.refuseEmail(dto));
				
		return entity;
	}
	
	
	/**
	 * 恢复邮件
	 * @param request
	 * @param req
	 * @return
	 */
	@ApiOperation(value="恢复邮件", notes="恢复邮件")
	@ApiImplicitParam(name = "req", value = "恢复邮件请求对象", required = true, dataType = "DeleteEmailRequest")
	@PostMapping(value = "/restoredEmail")
	@ResponseBody
	@NeedLogin
	@ResubmitData
	public BaseResponseEntity<Integer> restoredEmail(HttpServletRequest request, @RequestBody DeleteEmailRequest req) {
		
		BaseResponseEntity<Integer> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		RestoredEmailDto deleteDto = JoinfBeanUtils.copyToNewBean(RestoredEmailDto.class, req);
		deleteDto.setCompanyId(user.getCompanyId());
		deleteDto.setOperatorId(user.getSwitchOperatorId());
		
		deleteDto.setOperatorUserName(user.getUser().getUserName());
		deleteDto.setOperatorTrueName(user.getSwitchOperator().getZhName());

		LogRecordResultDto<Integer> restoredResult = emailManager.restoredEmail(deleteDto);

		entity.setData(restoredResult.getData());
				
		return entity;
	}
	
	/**
	 * 发送回执邮件
	 * @param request
	 * @param req
	 * @return
	 * @throws TemplateException 
	 * @throws IOException 
	 */
	@ApiOperation(value="发送回执邮件", notes="发送回执邮件")
	@ApiImplicitParam(name = "req", value = "发送回执邮件请求对象", required = true, dataType = "SentReceiptEmailRequest")
	@PostMapping(value = "/sentReceiptEmail")
	@ResponseBody
	@NeedLogin
	@VolumeLimit
	@ResubmitData
	public BaseResponseEntity<Boolean> sentReceiptEmail(HttpServletRequest request, @RequestBody SentReceiptEmailRequest req) throws IOException, TemplateException {
		
		BaseResponseEntity<Boolean> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		SentReceiptEmailDto sentDto = JoinfBeanUtils.copyToNewBean(SentReceiptEmailDto.class, req);
		sentDto.setCompanyId(user.getCompanyId());
		sentDto.setOperatorId(user.getSwitchOperatorId());
		
		entity.setData(emailManager.sentReceiptEmail(sentDto));
				
		return entity;
	}
	
	
	/**
	 * 写信页面信息初始
	 * @param request
	 * @param req
	 * @return
	 * @throws TemplateException 
	 * @throws IOException 
	 */
	@ApiOperation(value="写信页面信息初始", notes="写信页面信息初始")
	@ApiImplicitParam(name = "req", value = "写信页面信息初始请求对象", required = true, dataType = "WriteEmailInitRequest")
	@PostMapping(value = "/writeEmailInit")
	@ResponseBody
	@NeedLogin
	@VolumeLimit
	public BaseResponseEntity<WriteEmailInitResponse> writeEmailInit(HttpServletRequest request, @RequestBody WriteEmailInitRequest req) throws IOException, TemplateException {
		
		BaseResponseEntity<WriteEmailInitResponse> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		WriteEmailInitDto writeDto = JoinfBeanUtils.copyToNewBean(WriteEmailInitDto.class, req);
		writeDto.setCompanyId(user.getCompanyId());
		writeDto.setOperatorId(user.getSwitchOperatorId());
		
		EmailWriteEntityDto writeEntiryDto = emailManager.writeEmailInit(writeDto);
		
		WriteEmailInitResponse writeEmailInitResponse = JoinfBeanUtils.copyToNewBean(WriteEmailInitResponse.class, writeEntiryDto);
		if(writeEntiryDto.getEmailAttachmentList() != null){
			List<EmailAttachmentResponse> attachmentList = JoinfBeanUtils.copyToNewListBean(EmailAttachmentResponse.class, writeEntiryDto.getEmailAttachmentList());
			for (EmailAttachmentResponse emailAttachmentResponse : attachmentList) {
				emailAttachmentResponse.setUrl(JoinfClientUtils.getUrl(SaasClientConfig.saasClientConfig,emailAttachmentResponse.getFileCode()));
			}
			writeEmailInitResponse.setAttachmentList(attachmentList);
		}
		
		entity.setData(writeEmailInitResponse);
				
		return entity;
	}
	
	/**
	 * 保存邮件草稿
	 * @param request
	 * @param req
	 * @return
	 * @throws TemplateException 
	 * @throws IOException 
	 */
	@ApiOperation(value="保存邮件草稿", notes="保存邮件草稿")
	@ApiImplicitParam(name = "req", value = "保存邮件草稿请求对象", required = true, dataType = "SaveEmailRequest")
	@PostMapping(value = "/saveEmailAsDraft")
	@ResponseBody
	@NeedLogin
	@VolumeLimit
	@ResubmitData
	public BaseResponseEntity<String> saveEmailAsDraft(HttpServletRequest request, @RequestBody SaveEmailRequest req) throws IOException, TemplateException {
		
		BaseResponseEntity<String> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
	
		SaveEmailDto saveDto = JoinfBeanUtils.copyToNewBean(SaveEmailDto.class, req);
		saveDto.setCompanyId(user.getCompanyId());
		saveDto.setOperatorId(user.getSwitchOperatorId());
		saveDto.setLoginOperatorId(user.getOperatorId());
		
		saveDto.setOperatorUserName(user.getUser().getUserName());  //用户户名
		saveDto.setOperatorTrueName(user.getSwitchOperator().getZhName()); //获取登陆人姓名
		
		//云文件ID集合
		saveDto.setCloudIdList(req.getCloudIdList());
		saveDto.setAttachmentIdList(req.getAttachmentIdList());
		
		Long emailId = emailManager.saveEmailAsDraft(saveDto);
		
		//必须转成String,Long类型转换数据大时会导致数据失真
		entity.setData(String.valueOf(emailId));
				
		return entity;
	}
	
	
	/**
	 * 保存邮件并发送
	 * @param request
	 * @param req
	 * @return
	 * @throws TemplateException 
	 * @throws IOException 
	 */
	@ApiOperation(value="保存邮件并发送", notes="保存邮件并发送")
	@ApiImplicitParam(name = "req", value = "保存邮件并发送请求对象", required = true, dataType = "SaveEmailRequest")
	@PostMapping(value = "/saveEmailAndSent")
	@ResponseBody
	@NeedLogin
	@VolumeLimit
	@ResubmitData
	public BaseResponseEntity<SentEmailResponse> saveEmailAndSent(HttpServletRequest request, @RequestBody SaveEmailRequest req) throws IOException, TemplateException {
		
		BaseResponseEntity<SentEmailResponse> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		CompanyDTO company = SessionUtils.getCenterCompanyInfo(request);
		
		SaveEmailDto saveDto = JoinfBeanUtils.copyToNewBean(SaveEmailDto.class, req);
		saveDto.setCompanyId(user.getCompanyId());
		saveDto.setOperatorId(user.getSwitchOperatorId());
		saveDto.setLoginOperatorId(user.getOperatorId());
		saveDto.setOperatorRoleId(user.getUser().getRoleId());
		saveDto.setCompanyType(company.getCompanyType().byteValue());
		
		saveDto.setOperatorUserName(user.getUser().getUserName());  //用户户名
		saveDto.setOperatorTrueName(user.getSwitchOperator().getZhName()); //获取登陆人姓名
		
		//云文件ID集合
		saveDto.setCloudIdList(req.getCloudIdList());
		saveDto.setAttachmentIdList(req.getAttachmentIdList());
		
		SentEmailResponseDto sentEmailDto = emailManager.saveEmailAndSent(saveDto);
		if (sentEmailDto.getSentEmailForMq() != null) {
			//消息放到controller执行，是为了防止service层事务未提交，收发服务提前消费消息，会造成数据不一致
			this.emailSentMqManager.sendEmailMQ(sentEmailDto.getSentEmailForMq());
		}
		
		SentEmailResponse sentEmailResponse = JoinfBeanUtils.copyToNewBean(SentEmailResponse.class, sentEmailDto);
		entity.setData(sentEmailResponse);		
		
		return entity;
	}
	
	
	/**
	 * 发送邮件或提交审批
	 * @param request
	 * @param req
	 * @return
	 * @throws TemplateException 
	 * @throws IOException 
	 */
	@ApiOperation(value="发送邮件或提交审批", notes="发送邮件或提交审批")
	@ApiImplicitParam(name = "req", value = "发送邮件或提交审批请求对象", required = true, dataType = "SentEmailRequest")
	@PostMapping(value = "/sentEmail")
	@ResponseBody
	@NeedLogin
	@ResubmitData
	public BaseResponseEntity<SentEmailResponse> sentEmail(HttpServletRequest request, @RequestBody SentEmailRequest req) throws IOException, TemplateException {
		
		BaseResponseEntity<SentEmailResponse> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		CompanyDTO company = SessionUtils.getCenterCompanyInfo(request);
		
		SentEmailDto sentDto = JoinfBeanUtils.copyToNewBean(SentEmailDto.class, req);
		sentDto.setCompanyId(user.getCompanyId());
		sentDto.setOperatorId(user.getSwitchOperatorId());
		sentDto.setLoginOperatorId(user.getOperatorId());
		sentDto.setOperatorRoleId(user.getUser().getRoleId());
		sentDto.setCompanyType(company.getCompanyType().byteValue());
		
		sentDto.setOperatorUserName(user.getUser().getUserName());
		sentDto.setOperatorTrueName(user.getSwitchOperator().getZhName());
		
		SentEmailResponseDto sentEmailDto = emailManager.sentEmail(sentDto);
		if (sentEmailDto.getSentEmailForMq() != null) {
			//消息放到controller执行，是为了防止service层事务未提交，收发服务提前消费消息，会造成数据不一致
			this.emailSentMqManager.sendEmailMQ(sentEmailDto.getSentEmailForMq());
		}
		
		SentEmailResponse sentEmailResponse = JoinfBeanUtils.copyToNewBean(SentEmailResponse.class, sentEmailDto);
		entity.setData(sentEmailResponse);		
		
		return entity;
	}
	
	/**
	 * 审批邮件
	 * @param request
	 * @param req
	 * @return
	 */
	@ApiOperation(value="审批邮件", notes="审批邮件")
	@ApiImplicitParam(name = "req", value = "审批邮件请求对象", required = true, dataType = "ApproveEmailRequest")
	@PostMapping(value = "/approveEmail")
	@ResponseBody
	@NeedLogin
	@ResubmitData
	public BaseResponseEntity<String> approveEmail(HttpServletRequest request, @RequestBody ApproveEmailRequest req) {
		
		BaseResponseEntity<String> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		ApproveEmailDto approveDto = JoinfBeanUtils.copyToNewBean(ApproveEmailDto.class, req);
		approveDto.setCompanyId(user.getCompanyId());
		approveDto.setOperatorId(user.getSwitchOperatorId());
		approveDto.setLoginOperatorId(user.getOperatorId());
		
		approveDto.setOperatorUserName(user.getUser().getUserName());
		approveDto.setOperatorTrueName(user.getSwitchOperator().getZhName());
		
		SentEmailResponseDto sentEmailResponseDto = emailManager.examineAndApproveEmail(approveDto);
		if (sentEmailResponseDto.getSentEmailForMq() != null) {
			//消息放到controller执行，是为了防止service层事务未提交，收发服务提前消费消息，会造成数据不一致
			this.emailSentMqManager.sendEmailMQ(sentEmailResponseDto.getSentEmailForMq());
		}
		
		entity.setData(sentEmailResponseDto.getMessage());		
		
		return entity;
	}
	
	/**
	 * 内部转发邮件
	 * @param request
	 * @param req
	 * @return
	 * @throws TemplateException 
	 * @throws IOException 
	 */
	@ApiOperation(value="内部转发邮件", notes="内部转发邮件")
	@ApiImplicitParam(name = "req", value = "内部转发邮件请求对象", required = true, dataType = "InterForwardEmailRequest")
	@PostMapping(value = "/interForwardEmail")
	@ResponseBody
	@NeedLogin
	@ResubmitData
	public BaseResponseEntity<Integer> interForwardEmail(HttpServletRequest request, @RequestBody InterForwardEmailRequest req) throws IOException, TemplateException {
		
		BaseResponseEntity<Integer> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		InterForwardEmailDto forwardDto = JoinfBeanUtils.copyToNewBean(InterForwardEmailDto.class, req);
		forwardDto.setCompanyId(user.getCompanyId());
		forwardDto.setOperatorId(user.getSwitchOperatorId());
		forwardDto.setLoginOperatorId(user.getOperatorId());
		
		forwardDto.setOperatorUserName(user.getUser().getUserName());
		forwardDto.setOperatorTrueName(user.getSwitchOperator().getZhName());
		
		entity.setData(emailManager.interForwardEmail(forwardDto));		
		
		return entity;
	}
	
	
	/**
	 * 保存邮件附件
	 * @param request
	 * @param req
	 * @return
	 */
	@ApiOperation(value="保存邮件附件", notes="保存邮件附件,返回附件id")
	@ApiImplicitParam(name = "req", value = "保存邮件附件请求对象", required = true, dataType = "SaveEmailAttachmentRequest")
	@PostMapping(value = "/saveEmailAttachment")
	@ResponseBody
	@NeedLogin
	@ResubmitData
	public BaseResponseEntity<List<String>> saveEmailAttachment(HttpServletRequest request, @RequestBody SaveEmailAttachmentRequest req) {
		
		BaseResponseEntity<List<String>> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		SaveAttachmentBaseDto saveDto = JoinfBeanUtils.copyToNewBean(SaveAttachmentBaseDto.class, req);
		saveDto.setList(JoinfBeanUtils.copyToNewListBean(AttachmentBaseDto.class, req.getList()));
		saveDto.setCompanyId(user.getCompanyId());
		saveDto.setOperatorId(user.getSwitchOperatorId());
		saveDto.setCreateId(user.getSwitchOperatorId());
		saveDto.setUpdateId(user.getSwitchOperatorId());
		
		entity.setData(emailManager.saveEmailAttachment(saveDto));
		
		return entity;
	}
	
	
	/**
	 * 查询邮件可存为客户/供应商/联系人的往来邮箱（查询邮件的新联系人）
	 * @param request
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询邮件可存为客户/供应商/联系人的往来邮箱", notes="查询邮件可存为客户/供应商/联系人的往来邮箱")
	@ApiImplicitParam(name = "req", value = "请求对象", required = true, dataType = "IdRequest")
	@PostMapping(value = "/queryEmailNewContactMailbox")
	@ResponseBody
	@NeedLogin
	public BaseResponseEntity<List<QueryEmailContactMailboxResponse>> queryEmailNewContactMailbox(HttpServletRequest request, @RequestBody IdRequest req) {
		
		BaseResponseEntity<List<QueryEmailContactMailboxResponse>> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		QueryByIdDto queryDto = JoinfBeanUtils.copyToNewBean(QueryByIdDto.class, req);
		queryDto.setCompanyId(user.getCompanyId());
		queryDto.setOperatorId(user.getSwitchOperatorId());
		
		List<QueryEmailContactMailboxDto> dtoList = emailManager.queryEmailNewContactMailbox(queryDto);
		if(dtoList != null && dtoList.size() > 0)
			entity.setData(JoinfBeanUtils.copyToNewListBean(QueryEmailContactMailboxResponse.class, dtoList));
		
		return entity;
		
	}

	
	/**
	 * 校验发送频率(此校验忽略预警信息)
	 * @param request
	 * @param req
	 * @return
	 */
	@ApiOperation(value="校验发送频率", notes="校验发送频率")
	@ApiImplicitParam(name = "req", value = "请求对象", required = true, dataType = "CheckSendFrequencyRequest")
	@PostMapping(value = "/checkSendFrequency")
	@ResponseBody
	@NeedLogin
	public BaseResponseEntity<String> checkSendFrequency(HttpServletRequest request, @RequestBody CheckSendFrequencyRequest req) {
		
		BaseResponseEntity<String> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		CompanyDTO company = SessionUtils.getCenterCompanyInfo(request);
		
		SaveEmailDto saveDto = JoinfBeanUtils.copyToNewBean(SaveEmailDto.class, req);
		saveDto.setCompanyId(user.getCompanyId());
		saveDto.setOperatorId(user.getSwitchOperatorId());
		
		saveDto.setLoginOperatorId(user.getOperatorId());
		saveDto.setOperatorRoleId(user.getUser().getRoleId());
		saveDto.setCompanyType(company.getCompanyType().byteValue());
		
		//表示只校验收件人数量
		saveDto.setCheckType(1);
		
		emailManager.checkSendFrequency(saveDto);
		
		return entity;

	}
	
	
	
	/**
	 * 邮件分发
	 * @param dto
	 * @param request
	 * @return
	 */
	@ApiOperation(value="邮件分发", notes="邮件分发")
	@ApiImplicitParam(name = "req", value = "邮件分发请求对象", required = true, dataType = "EmailDeliveryRequest")
	@PostMapping(value = "/emailDelivery")
	@NeedLogin
	@ResponseBody
	public BaseResponseEntity<String> delivery(@RequestBody EmailDeliveryRequest req, HttpServletRequest request) {
		BaseResponseEntity<String> entity = new BaseResponseEntity<>(true);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		CompanyDTO companyDTO = SessionUtils.getCenterCompanyInfo(request);
		
		EmailDeliveryDto dto = new EmailDeliveryDto();
		BeanUtils.copyProperties(req, dto);
		
		dto.setCompanyId(user.getCompanyId());
		dto.setCenterCompanyId(companyDTO.getCompanyId());
		dto.setOperatorId(user.getSwitchOperatorId());
		dto.setUserName(user.getUser().getUserName());
		dto.setName(user.getSwitchOperator().getZhName());
		
		dto.setLoginOperatorId(user.getOperatorId());

		LogRecordResultDto<Boolean> logRecordResultDto = emailManager.delivery(request, dto);
		entity.setSuccess(logRecordResultDto.getData());
		return entity;
	}
}
