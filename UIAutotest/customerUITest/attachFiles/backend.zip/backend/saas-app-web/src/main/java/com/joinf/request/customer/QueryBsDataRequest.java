package com.joinf.request.customer;

import com.joinf.utils.base.BasePage;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 商业搜索查询参数
 * @author cuichuanlei
 * @created 2018年10月8日 下午3:31:53
 */
public class QueryBsDataRequest extends BasePage {
	
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value="搜索-关键词",required=false)
	private String customerName;
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	

}