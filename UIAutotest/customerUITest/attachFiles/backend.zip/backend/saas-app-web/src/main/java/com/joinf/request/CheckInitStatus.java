package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 查询初始化状态
 *
 * @author lyj
 * @date 2017年12月27日 下午7:55:32
 */
public class CheckInitStatus {
	
	@ApiModelProperty(value="公司id",required=true)
	private Long companyId;

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

}
