package com.joinf.request.email;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.joinf.helper.LongJsonDeserializer;
import com.joinf.helper.LongJsonSerializer;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 保存邮件入参
 * @date 2018年1月16日 下午7:40:52
 */
public class SaveEmailRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2105085247053982301L;

	@JsonSerialize(using = LongJsonSerializer.class)
	@JsonDeserialize(using = LongJsonDeserializer.class)
	@ApiModelProperty(value = "邮件标识")
	private Long id;
	@ApiModelProperty(value = "邮件主题")
	private String subject;
	@ApiModelProperty(value = "发件邮箱账号")
	private String fromMail;
	@ApiModelProperty(value = "收件人")
	private String recipients;
	@ApiModelProperty(value = "抄送人")
	private String cc;
	@ApiModelProperty(value = "密送人")
	private String bc;
	@ApiModelProperty(value ="内部用户(用户名逗号拼接)")
	private String inter;
	
	@ApiModelProperty(value = "发送邮箱账号id,多个逗号隔开")
	private String senders;
	@ApiModelProperty(value = "签名id")
	private Long signatureId;
	@ApiModelProperty(value = "回复原邮件id")
	private Long oldEmailId;
	@ApiModelProperty(value = "转发原邮件id")
	private Long fwOldEmailId;
	@ApiModelProperty(value = "分发原邮件id")
	private Long originalEmailId;
	
	@ApiModelProperty(value ="设置定时邮件发送时间")
    private Date sendTime;
	
	@ApiModelProperty(value ="是否紧急:0/否;1/是")
	private Integer urgent;
	
    @ApiModelProperty(value ="[0]:不需要追踪;[1]:需要追踪;[2]:已有追踪记录")
    private Integer isTrace;

	@ApiModelProperty(value ="回执状态:0/不需要回执;1/需要回执;2/已回执;3/不回执")
    private Integer receipt;

	
    @ApiModelProperty(value ="是否群发邮件")
    private Boolean isMassEmail;

	@ApiModelProperty(value = "正文")
	private String content = "";

	@ApiModelProperty(value = "附件id集合")
	private List<Long> attachmentIdList;
	
	@ApiModelProperty(value = "云文件id集合")
	private List<Long> cloudIdList;
	
	@ApiModelProperty(value="发送类型   [0]提交发送  [1]提醒弹框确定直接发送 ")
	private int type;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getFromMail() {
		return fromMail;
	}

	public void setFromMail(String fromMail) {
		this.fromMail = fromMail;
	}

	public String getRecipients() {
		return recipients;
	}

	public void setRecipients(String recipients) {
		this.recipients = recipients;
	}

	public String getCc() {
		return cc;
	}

	public void setCc(String cc) {
		this.cc = cc;
	}

	public String getBc() {
		return bc;
	}

	public void setBc(String bc) {
		this.bc = bc;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getSenders() {
		return senders;
	}

	public void setSenders(String senders) {
		this.senders = senders;
	}

	public Long getSignatureId() {
		return signatureId;
	}

	public void setSignatureId(Long signatureId) {
		this.signatureId = signatureId;
	}

	public Long getOldEmailId() {
		return oldEmailId;
	}

	public void setOldEmailId(Long oldEmailId) {
		this.oldEmailId = oldEmailId;
	}

	public Long getFwOldEmailId() {
		return fwOldEmailId;
	}

	public void setFwOldEmailId(Long fwOldEmailId) {
		this.fwOldEmailId = fwOldEmailId;
	}

	public Long getOriginalEmailId() {
		return originalEmailId;
	}

	public void setOriginalEmailId(Long originalEmailId) {
		this.originalEmailId = originalEmailId;
	}

	public Date getSendTime() {
		return sendTime;
	}

	public void setSendTime(Date sendTime) {
		this.sendTime = sendTime;
	}

	public Boolean getIsMassEmail() {
		return isMassEmail;
	}

	public void setIsMassEmail(Boolean isMassEmail) {
		this.isMassEmail = isMassEmail;
	}

	public List<Long> getCloudIdList() {
		return cloudIdList;
	}

	public void setCloudIdList(List<Long> cloudIdList) {
		this.cloudIdList = cloudIdList;
	}

	public List<Long> getAttachmentIdList() {
		return attachmentIdList;
	}

	public void setAttachmentIdList(List<Long> attachmentIdList) {
		this.attachmentIdList = attachmentIdList;
	}

	public String getInter() {
		return inter;
	}

	public void setInter(String inter) {
		this.inter = inter;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public Integer getUrgent() {
		return urgent;
	}

	public void setUrgent(Integer urgent) {
		this.urgent = urgent;
	}

	public Integer getIsTrace() {
		return isTrace;
	}

	public void setIsTrace(Integer isTrace) {
		this.isTrace = isTrace;
	}

	public Integer getReceipt() {
		return receipt;
	}

	public void setReceipt(Integer receipt) {
		this.receipt = receipt;
	}

	
	
	

}
