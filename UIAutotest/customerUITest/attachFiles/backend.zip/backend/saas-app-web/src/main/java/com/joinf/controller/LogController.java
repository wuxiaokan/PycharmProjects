package com.joinf.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.joinf.annotations.NeedLogin;
import com.joinf.dto.DBLogDataDto;
import com.joinf.dto.QueryDBLogParam;
import com.joinf.entity.SessionUser;
import com.joinf.interfaces.LogInfoEsService;
import com.joinf.request.QueryLogRequest;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.util.JoinfBeanUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;


@RestController
@RequestMapping("log")
@Api(tags="日志")
public class LogController {
	
	@Autowired
	private LogInfoEsService logInfoEsService;
	
	
	@ApiOperation(value="查询db日志", notes="查询db日志")
	@PostMapping("db/logs")
	@ApiImplicitParam(name = "req", value = "查询db日志请求对象", required = true, dataType = "QueryLogRequest")
	@NeedLogin
	public BaseResponseEntity<List<DBLogDataDto>> submitQuoteApproval(HttpServletRequest request,@RequestBody QueryLogRequest req) throws Exception{
		SessionUser user = SessionUtils.getCurrentUserInfo(request);	
		BaseResponseEntity<List<DBLogDataDto>> entity= new BaseResponseEntity<>();
		QueryDBLogParam param = new QueryDBLogParam();
		JoinfBeanUtils.copyProperties(param, req);
		param.setCompamyId(user.getCompanyId());

		BaseResponseEntity<List<DBLogDataDto>>result = logInfoEsService.queryDBLogs(param);
		entity.setData(result.getData());
		entity.setTotalRecords(result.getTotalRecords());
		entity.setSuccess(true);
		return entity;
	}

}
