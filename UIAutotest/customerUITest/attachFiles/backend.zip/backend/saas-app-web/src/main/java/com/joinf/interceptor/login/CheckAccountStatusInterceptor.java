package com.joinf.interceptor.login;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.joinf.config.Platform;
import com.joinf.constant.login.LoginContant;
import com.joinf.constant.login.LoginRedirect;
import com.joinf.dto.CheckSuccessDto;
import com.joinf.dto.CompanyDTO;
import com.joinf.dto.OperatorDTO;
import com.joinf.dto.StartInitDto;
import com.joinf.dto.UserValidateDto;
import com.joinf.entity.generator.Company;
import com.joinf.entity.generator.Operator;
import com.joinf.exception.LoginFailException;
import com.joinf.interfaces.CompanyService;
import com.joinf.interfaces.OperatorService;
import com.joinf.interfaces.RegistManager;
import com.joinf.interfaces.UserCenterService;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.util.DateUtil;

/**
 * Description: 校验账号信息
 *
 * @author lyj
 * @date 2017年12月18日 下午2:00:32
 */
public class CheckAccountStatusInterceptor implements HandlerInterceptor{
	
	private static Logger logger = LoggerFactory.getLogger(CheckAccountStatusInterceptor.class);

	@Autowired
	private UserCenterService userCenterService;
	
	@Autowired
	private CompanyService companyService;
	
	@Autowired
	private OperatorService operatorService;
	
	@Autowired
	private RegistManager registService;
	
	/**
	 * 实现方法
	 */
	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		HttpSession session = request.getSession();
		CheckSuccessDto dto = SessionUtils.getCenterUserDto(request);
		if(dto ==null){
			throw new LoginFailException("登入信息已过期");
		}
		
		//获取用户中心企业信息
		logger.info("获取用户中心企业信息");
		CompanyDTO companyDTO = userCenterService.getCompanyCompletedInfo(dto.getCompanyId(), null, null).getResponseData();
		//获取用户中心用户信息
		logger.info("获取用户中心用户信息");
		OperatorDTO operatorDTO = userCenterService.getOperatorInfo(dto.getUserId()).getResponseData();
		if(companyDTO == null||operatorDTO==null){
			throw new LoginFailException("账号无效");
		}
		
		if (StringUtils.isBlank(operatorDTO.getStatus())) {
			//移出跳转路径
			session.removeAttribute(LoginContant.REDIRECT_URL);
			
			throw new LoginFailException("云平台不支持该账号登陆");
		}
		
		session.setAttribute(LoginContant.CENTER_OPERATOR_INFO,JSONObject.toJSONString(operatorDTO));
		session.setAttribute(LoginContant.CENTER_COMPANY_INFO, JSONObject.toJSONString(companyDTO));
		//试用时间
		Date probationDisableTime = DateUtil.parse(companyDTO.getProbationDisableTime(),"yyyy-MM-dd HH:mm:ss");
		//创建时间
		Date createTime = DateUtil.parse(companyDTO.getCreateTime(),"yyyy-MM-dd HH:mm:ss");
		
		logger.info("开始校验是否过期--校验把b2b平台");
		UserValidateDto validate = userCenterService.probationValidate("b2b",dto.getUserId()).getResponseData();
		
		boolean probation = validate.isAvailable();
		
		if(!probation){
			Integer type = validate.getType();
			if(type == 1){//到期
				//移出跳转路径
				session.removeAttribute(LoginContant.REDIRECT_URL);
				
				if(createTime.after(probationDisableTime)){//新注册
					logger.info("试用到期--新注册");
					throw new LoginFailException("账号未获得操作权限，请至cloud.joinf.com申请试用或购买套餐。");
				}else{
					logger.info("试用到期");
					throw new LoginFailException("账号已到期，请至电脑端cloud.joinf.com进行操作");
				}
			}
			else if(type == 2){//被管理员禁用
				//移出跳转路径
				session.removeAttribute(LoginContant.REDIRECT_URL);
				
				logger.info("外贸管理系统已被禁用");
				throw new LoginFailException("外贸管理系统已被禁用");
				
			}
			else if(type == 3){//主账号未激活
				session.setAttribute(LoginContant.REDIRECT_URL, LoginRedirect.CompleteInfo.getPath());
				throw new LoginFailException("账号信息不完整");
				
			}
			else if(type == 4){//子帐号未激活
				//移出跳转路径
				session.removeAttribute(LoginContant.REDIRECT_URL);
				
				logger.info("子帐号未激活");
				throw new LoginFailException("子帐号未激活");
				
			}
			else if(type == 5){//就是不让用(人才网子帐号)
				//移出跳转路径
				session.removeAttribute(LoginContant.REDIRECT_URL);
				
				logger.info("就是不让用(人才网子帐号)");
				throw new LoginFailException("账户受限");
				
			}
		}else{//校验下 site 和 data的 平台权限
			List<String> paltforms = new ArrayList<>();
			validate = userCenterService.probationValidate("site",dto.getUserId()).getResponseData();
			if(validate.isAvailable())
				paltforms.add("site");
			validate = userCenterService.probationValidate("data",dto.getUserId()).getResponseData();
			if(validate.isAvailable())
				paltforms.add("data");
			
			session.setAttribute(LoginContant.PLATFORMS, JSONArray.toJSONString(paltforms));
			//["b2c","site","globaleagle","auto","b2b","data","adwords","autogip","customs","ecb2b","sns","edm"]
		}
		
		//获取状态信息
		int status = (StringUtils.equals("A", operatorDTO.getStatus()) ? 1 : 0);
		if(status == 0){
			//移出跳转路径
			session.removeAttribute(LoginContant.REDIRECT_URL);
			
			throw new LoginFailException("账号信息已冻结");
		}
		//获取来源
		String from = operatorDTO.getFrom();
		//获取主账号信息
		String parentId = operatorDTO.getParentId();
		//查询企业信息
		Company company = companyService.selectByCenterCompanyId(dto.getCompanyId());
		Operator operator = operatorService.selectByCenterUserId(dto.getUserId());
		if(company !=null){
			company.setCompanyType(companyDTO.getCompanyType()!=null?companyDTO.getCompanyLevel().byteValue():null);
			company.setCompanyLevel(companyDTO.getCompanyLevel());
			company.setOrderStatus(companyDTO.getOrderStatus()!=null?companyDTO.getOrderStatus().byteValue():null);
			session.setAttribute(LoginContant.COMPANY_INFO, JSONObject.toJSONString(company));
		}
		if(operator!=null)session.setAttribute(LoginContant.OPERATOR_INFO,JSONObject.toJSONString(operator));
		
		if(parentId == null){ //parentId为空表示为主账号
			if(company == null){ //企业信息如果为空,则表示身份信息不完整、
				session.setAttribute(LoginContant.REDIRECT_URL, LoginRedirect.CompleteInfo.getPath());
				throw new LoginFailException("账号信息不完整");
			}
		}else{ //子帐号处理
			if(StringUtils.equals(from, Platform.JOB.getPlatType()) || company == null){//人才网的子帐号一律不等登陆saas 或者   子帐号登陆时，企业信息如果为空,则直接禁止登陆
				//移出跳转路径
				session.removeAttribute(LoginContant.REDIRECT_URL);
				
				throw new LoginFailException("账号无效");
			}
		}
		
		//获取企业的状态
	    int companyFlag = company.getFlag().intValue();
	    if(companyFlag == -101){
	    	//移出跳转路径
			session.removeAttribute(LoginContant.REDIRECT_URL);
			
	    	throw new LoginFailException("账号信息已注销");
		}else if(companyFlag == -1){
			session.setAttribute(LoginContant.REDIRECT_URL, LoginRedirect.InitSystem.getPath());
			//开始初始化
			StartInitDto startDto = new StartInitDto();
			startDto.setCenterCompany(companyDTO);
			startDto.setCenterUser(operatorDTO);
			startDto.setOperator(operator);
			startDto.setCompany(company);
			registService.startInit(startDto);
			throw new LoginFailException("账号信息未初始化");
		}else if(companyFlag == 0){
			//移出跳转路径
			session.removeAttribute(LoginContant.REDIRECT_URL);
			
			throw new LoginFailException("账号信息被禁用");
		}else if(companyFlag == -2){
			throw new LoginFailException("正在初始化");
		}
	    
	    if(operator == null){
	    	//移出跳转路径
			session.removeAttribute(LoginContant.REDIRECT_URL);
			
	    	throw new LoginFailException("账号信息初始化未成功");
	    }
		if ((companyDTO.getCompanyType() == null || companyDTO.getCompanyType().intValue()==0)
				&& operator.getPrimaryAccount().intValue() ==0) {// 判断为单用户,而且为子账号
			//移出跳转路径
			session.removeAttribute(LoginContant.REDIRECT_URL);
			
			throw new LoginFailException("子账号登录受限");
		}
		
		return true;
	}

	/**
	 * 实现方法
	 */
	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub
		
	}

	/**
	 * 实现方法
	 */
	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub
		
	}

}
