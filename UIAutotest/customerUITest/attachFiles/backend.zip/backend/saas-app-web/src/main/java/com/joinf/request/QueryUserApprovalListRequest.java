package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

public class QueryUserApprovalListRequest {
	
	@ApiModelProperty("1=报价，2订单")
	private Integer type;

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

}
