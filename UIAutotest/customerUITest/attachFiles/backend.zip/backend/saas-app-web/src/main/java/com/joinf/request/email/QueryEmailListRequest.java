package com.joinf.request.email;

import java.io.Serializable;

/**
 * @author zlx
 * @Description: 邮件列表查询参数
 * @date 2018年1月4日 下午5:42:34
 */
public class QueryEmailListRequest extends QueryEmailBaseDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
}
