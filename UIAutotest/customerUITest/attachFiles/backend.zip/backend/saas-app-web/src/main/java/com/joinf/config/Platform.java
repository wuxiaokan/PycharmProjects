package com.joinf.config;
/**
 * 平台类型枚举
 * @author liuwei
 *
 */
public enum Platform {
	
	B2B("b2b"),B2C("b2c"),SNS("sns"),JOB("job"),LIVE("live");
	
	/**
	 * 类型
	 */
	private String type;
	
	/**
	 * 构造方法
	 * @param type
	 */
	Platform(String type){
		this.type = type;
	}

	/**
	 * 获取类型
	 * @return
	 */
	public String getPlatType() {
		return type;
	}
}
