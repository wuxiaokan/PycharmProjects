package com.joinf.request.product;

import io.swagger.annotations.ApiModelProperty;

public class InsertProductPictureRequest {

	@ApiModelProperty(value = "所属产品ID")
	private Long productId;

	@ApiModelProperty(value = "名称")
	private String name;

	@ApiModelProperty(value = "图片地址")
	private String url;

	@ApiModelProperty(value = "排序")
	private Integer sort;

	@ApiModelProperty(value = "文件大小(字节)")
	private Long size;

	@ApiModelProperty(value = "文件后缀")
	private String suffix;

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	public Long getSize() {
		return size;
	}

	public void setSize(Long size) {
		this.size = size;
	}

	public String getSuffix() {
		return suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

}
