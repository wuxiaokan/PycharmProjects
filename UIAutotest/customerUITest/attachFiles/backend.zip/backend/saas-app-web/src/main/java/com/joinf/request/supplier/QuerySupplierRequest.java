package com.joinf.request.supplier;

import com.joinf.utils.base.BasePage;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 查询供应商列表参数类
 *
 * @author lyj
 * @date 2017年12月4日 下午8:42:36
 */
public class QuerySupplierRequest extends BasePage {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6533245614328212210L;
	
	/**
	 * 
	 */
	@ApiModelProperty(value="关键词",required=false)
	private String key;
	
	@ApiModelProperty(value="排序字段",required=true)
	private String sortColumn;
	
	@ApiModelProperty(value="排序类别",required=true)
	private String sortType;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getSortColumn() {
		return sortColumn;
	}

	public void setSortColumn(String sortColumn) {
		this.sortColumn = sortColumn;
	}

	public String getSortType() {
		return sortType;
	}

	public void setSortType(String sortType) {
		this.sortType = sortType;
	}
	
}
