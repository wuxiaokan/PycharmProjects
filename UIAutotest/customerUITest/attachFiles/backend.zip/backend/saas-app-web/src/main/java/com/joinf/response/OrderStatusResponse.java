package com.joinf.response;

import io.swagger.annotations.ApiModelProperty;

public class OrderStatusResponse {
	
	@ApiModelProperty(value="状态：-2:已删除/-1:已关闭/0:待支付/1:已支付成功/2:已失效/3:回调异常'",required=true)
	private Integer stauts;

	public Integer getStauts() {
		return stauts;
	}

	public void setStauts(Integer stauts) {
		this.stauts = stauts;
	}

}
