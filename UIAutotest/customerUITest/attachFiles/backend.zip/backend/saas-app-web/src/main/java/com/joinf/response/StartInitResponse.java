package com.joinf.response;

/**
 * Description: 启动初始化返回类
 *
 * @author lyj
 * @date 2017年12月22日 上午10:35:01
 */
public class StartInitResponse {

	/**
	 * 是否成功
	 */
	private boolean success;
	
	/**
	 * 错误信息
	 */
	private String errmsg;

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getErrmsg() {
		return errmsg;
	}

	public void setErrmsg(String errmsg) {
		this.errmsg = errmsg;
	} 
}
