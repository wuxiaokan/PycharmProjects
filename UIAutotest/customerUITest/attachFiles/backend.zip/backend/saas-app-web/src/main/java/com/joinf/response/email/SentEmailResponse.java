package com.joinf.response.email;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.joinf.helper.LongJsonDeserializer;
import com.joinf.helper.LongJsonSerializer;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 发送邮件返回数据
 * @date 2018年1月17日 下午2:26:58
 */
public class SentEmailResponse {
	@JsonSerialize(using = LongJsonSerializer.class)
	@JsonDeserialize(using = LongJsonDeserializer.class)
	@ApiModelProperty(value = "邮件id")
	private Long id;
	@ApiModelProperty(value = "0：成功   2：弹框提醒,根据用户选择处理")
	private int type;
	@ApiModelProperty(value="审批规则id")
	private Long auditRuleId;
	@ApiModelProperty(value = "错误或提醒内容")
	private String message;
	@ApiModelProperty(value="邮件状态")
    private Integer status;
	@ApiModelProperty(value="信箱id")
    private Long boxId;
	
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getAuditRuleId() {
		return auditRuleId;
	}
	public void setAuditRuleId(Long auditRuleId) {
		this.auditRuleId = auditRuleId;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Long getBoxId() {
		return boxId;
	}
	public void setBoxId(Long boxId) {
		this.boxId = boxId;
	}
	
	
	
}
