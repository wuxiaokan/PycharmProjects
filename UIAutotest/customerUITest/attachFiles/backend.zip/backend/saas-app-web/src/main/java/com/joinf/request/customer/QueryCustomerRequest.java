package com.joinf.request.customer;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

import com.joinf.utils.base.BasePage;

/**
 * @author lyj
 * @Description: 客户跟进主键查询参数
 * @data 2017年12月4日 下午2:38:17
 */
public class QueryCustomerRequest extends BasePage implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2596363725471279783L;

	@ApiModelProperty(value ="排序字段")
	private String sortColumn;
	
	@ApiModelProperty(value ="排序类别")
	private String sortType;
	
	@ApiModelProperty(value ="关键词")
	private String key;
	
	@ApiModelProperty(value ="剩余跟进时长（单位小时）")
	private Integer followUpTimeVal;
	
	@ApiModelProperty(value ="客户类别id")
	private Long dictCustTypeId;

	public Long getDictCustTypeId() {
		return dictCustTypeId;
	}

	public void setDictCustTypeId(Long dictCustTypeId) {
		this.dictCustTypeId = dictCustTypeId;
	}

	public Integer getFollowUpTimeVal() {
		return followUpTimeVal;
	}

	public void setFollowUpTimeVal(Integer followUpTimeVal) {
		this.followUpTimeVal = followUpTimeVal;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getSortColumn() {
		return sortColumn;
	}

	public void setSortColumn(String sortColumn) {
		this.sortColumn = sortColumn;
	}

	public String getSortType() {
		return sortType;
	}

	public void setSortType(String sortType) {
		this.sortType = sortType;
	}
}
