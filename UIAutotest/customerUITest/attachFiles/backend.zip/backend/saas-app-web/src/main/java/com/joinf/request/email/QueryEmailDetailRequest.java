package com.joinf.request.email;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 邮件详情查询参数
 * @date 2018年1月4日 下午5:42:34
 */
public class QueryEmailDetailRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2596363725471279783L;
	@ApiModelProperty(value = "邮件id")
	private Long id;
	@ApiModelProperty(value = "箱子id")
	private Long boxId;
	@ApiModelProperty(value="第几页",required=true)
	private int num;
	@ApiModelProperty(value = "邮件在列表上所在序号")
	private int rowNum;
	@ApiModelProperty(value = "客户 0 ，供应商 1")
	private int flowModel;
	
	
	
	public Long getId() {
		return id;
	}

	public int getRowNum() {
		return rowNum;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setRowNum(int rowNum) {
		this.rowNum = rowNum;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public Long getBoxId() {
		return boxId;
	}

	public void setBoxId(Long boxId) {
		this.boxId = boxId;
	}

	public int getFlowModel() {
		return flowModel;
	}

	public void setFlowModel(int flowModel) {
		this.flowModel = flowModel;
	}
	
	
	
	

}
