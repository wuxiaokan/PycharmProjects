package com.joinf.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.joinf.annotations.NeedLogin;
import com.joinf.dto.CheckEmailAccountDto;
import com.joinf.dto.EmailAccountResult;
import com.joinf.dto.QueryAccountListDto;
import com.joinf.dto.QueryByIdDto;
import com.joinf.dto.SaveEmailAccountDto;
import com.joinf.entity.SessionUser;
import com.joinf.entity.dto.CheckEmailAccountEntityDto;
import com.joinf.entity.dto.CheckEmailAccountSaveDto;
import com.joinf.entity.generator.EmailAccount;
import com.joinf.request.IdRequest;
import com.joinf.request.email.CheckEmailAccountRequest;
import com.joinf.request.email.EmailAccountDetailRequest;
import com.joinf.response.email.CheckEmailAccountResponse;
import com.joinf.response.email.EmailAccountDetailResponse;
import com.joinf.response.email.EmailAccountSaveResponse;
import com.joinf.response.email.QueryEmailAccountResponse;
import com.joinf.service.email.EmailAccountManagerImpl;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.annotations.ResubmitData;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.util.JoinfBeanUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * @author zlx
 * @Description: 邮件账号服务
 * @date 2018年1月5日 上午11:36:49
 */
@RestController
@RequestMapping("email")
@Api(tags="邮件账号服务")
public class EmailAccountController {
	
	@Autowired
	private EmailAccountManagerImpl emailAccountManager;
	
	
	@ApiOperation(value="校验绑定邮箱账号唯一性", notes="校验绑定邮箱账号唯一性")
	@ApiImplicitParam(name = "req", value = "校验绑定邮箱账号唯一性请求对象", required = true, dataType = "CheckEmailAccountRequest")
	@PostMapping(value = "/checkAccountUniqueness")
	@ResponseBody
	@NeedLogin
	public BaseResponseEntity<CheckEmailAccountResponse> checkAccountUniqueness(HttpServletRequest request, @RequestBody CheckEmailAccountRequest req) {
		
		BaseResponseEntity<CheckEmailAccountResponse> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		CheckEmailAccountDto checkDto = JoinfBeanUtils.copyToNewBean(CheckEmailAccountDto.class, req);
		checkDto.setCompanyId(user.getCompanyId());
		checkDto.setOperatorId(user.getSwitchOperatorId());
		
		CheckEmailAccountEntityDto checkEmailAccountEntityDto = emailAccountManager.checkEmailAccountExsit(checkDto);
		
		CheckEmailAccountResponse responseEntity = JoinfBeanUtils.copyToNewBean(CheckEmailAccountResponse.class, checkEmailAccountEntityDto);
		
		entity.setData(responseEntity);
				
		return entity;
	}
	
	@ApiOperation(value="验证邮箱配置是否正确", notes="验证邮箱配置是否正确")
	@ApiImplicitParam(name = "req", value = "验证邮箱配置是否正确请求对象", required = true, dataType = "EmailAccountDetailRequest")
	@PostMapping(value = "/checkAccountConfig")
	@ResponseBody
	@NeedLogin
	public BaseResponseEntity<String> checkAccountConfig(HttpServletRequest request, @RequestBody EmailAccountDetailRequest req) {
		
		BaseResponseEntity<String> entity = new BaseResponseEntity<>(true);
		
		SaveEmailAccountDto checkDto = JoinfBeanUtils.copyToNewBean(SaveEmailAccountDto.class, req);
		
		EmailAccountResult emailAccountResult = emailAccountManager.checkEmailAccountConfig(checkDto);
		
		if(!emailAccountResult.isSuccess()){
			entity.setSuccess(false);
			entity.setErrMsg(emailAccountResult.getMessage());
			entity.setData(emailAccountResult.getInfo());
		}
				
		return entity;
	}
	
	@ApiOperation(value="邮箱账号修改(参数id为空则为新增)", notes="邮箱账号修改(参数id为空则为新增)")
	@ApiImplicitParam(name = "req", value = "邮箱账号修改请求对象", required = true, dataType = "EmailAccountDetailRequest")
	@PostMapping("insertOrUpdateEmailAccount")
	@ResponseBody
	@NeedLogin
	@ResubmitData
	public BaseResponseEntity<EmailAccountSaveResponse> insertOrUpdateEmailAccount(HttpServletRequest request,@RequestBody EmailAccountDetailRequest req) {
		BaseResponseEntity<EmailAccountSaveResponse> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		SaveEmailAccountDto saveDto = JoinfBeanUtils.copyToNewBean(SaveEmailAccountDto.class, req);
		saveDto.setCompanyId(user.getCompanyId());
		saveDto.setOperatorId(user.getSwitchOperatorId());
		
		CheckEmailAccountSaveDto emailAccountSaveEntityDto = emailAccountManager.insertOrUpdateEmailAccount(saveDto);
		
		EmailAccountSaveResponse responseEntity = JoinfBeanUtils.copyToNewBean(EmailAccountSaveResponse.class, emailAccountSaveEntityDto);
		
		entity.setData(responseEntity);
				
		return entity;
	}
	
	
	@ApiOperation(value="查询邮箱账号列表", notes="查询邮箱账号列表")
	@PostMapping("queryEmailAccountList")
	@NeedLogin
	public BaseResponseEntity<List<QueryEmailAccountResponse>> queryEmailAccountList(HttpServletRequest request){
		BaseResponseEntity<List<QueryEmailAccountResponse>> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		QueryAccountListDto queryDto = new QueryAccountListDto();
		queryDto.setCompanyId(user.getCompanyId());
		queryDto.setOperatorId(user.getSwitchOperatorId());
		
		List<EmailAccount> emailAccountList = emailAccountManager.queryAccountByCondition(queryDto);
		
		
		List<QueryEmailAccountResponse> resultList = JoinfBeanUtils.copyToNewListBean(QueryEmailAccountResponse.class, emailAccountList);
		
		entity.setData(resultList);
		
		return entity;
	}
	
	
	@ApiOperation(value="查询邮箱账号详细信息", notes="查询邮箱账号详细信息")
	@ApiImplicitParam(name = "req", value = "查询邮箱账号详细信息请求对象", required = true, dataType = "IdRequest")
	@PostMapping("queryEmailAccountDetail")
	@ResponseBody
	@NeedLogin
	public BaseResponseEntity<EmailAccountDetailResponse> queryEmailAccountDetail(HttpServletRequest request,@RequestBody IdRequest req) {
		BaseResponseEntity<EmailAccountDetailResponse> entity = new BaseResponseEntity<>(true);
		
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		QueryByIdDto idDto = JoinfBeanUtils.copyToNewBean(QueryByIdDto.class, req);
		idDto.setCompanyId(user.getCompanyId());
		idDto.setOperatorId(user.getSwitchOperatorId());
		
		EmailAccount emailAccount = emailAccountManager.queryAccountById(idDto);
		
		if(emailAccount != null)
		{
			EmailAccountDetailResponse responseEntity = JoinfBeanUtils.copyToNewBean(EmailAccountDetailResponse.class, emailAccount);
			responseEntity.setReceiveServer(emailAccount.getPopServer());
			responseEntity.setReceivePort(emailAccount.getPopPort());
			responseEntity.setReceiveSsl(emailAccount.getPopSsl() != null && emailAccount.getPopSsl()==1?true:false);
			responseEntity.setSmtpSsl(emailAccount.getSmtpSsl() != null && emailAccount.getSmtpSsl()==1?true:false);
			responseEntity.setDefaultAccount(emailAccount.getDefaultAccount() != null && emailAccount.getDefaultAccount()==1?true:false);
			entity.setData(responseEntity);
		}
				
		return entity;
	}
	
}
