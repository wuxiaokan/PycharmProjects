package com.joinf.request.quote;

import com.joinf.utils.base.BasePage;

import io.swagger.annotations.ApiModelProperty;

public class QueryQuoteRequest extends BasePage{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1806555022701729333L;
	
	@ApiModelProperty("查询箱子1=完成箱,3=草稿箱,6=待审批,7=待批箱 ,8=已批箱 ")
	private Long boxId;
	
	
	@ApiModelProperty("关键词")
	private String key;

	@ApiModelProperty("搜索类型 1基本 2产品")
	private Integer searchType = 1;

	@ApiModelProperty("排序字段")
	private String sortColumn;
	
	
	@ApiModelProperty("排序类别 ")
	private String sortType;


	public Long getBoxId() {
		return boxId;
	}


	public void setBoxId(Long boxId) {
		this.boxId = boxId;
	}


	public String getKey() {
		return key;
	}


	public Integer getSearchType() {
		return searchType;
	}


	public void setSearchType(Integer searchType) {
		this.searchType = searchType;
	}


	public void setKey(String key) {
		this.key = key;
	}


	public String getSortColumn() {
		return sortColumn;
	}


	public void setSortColumn(String sortColumn) {
		this.sortColumn = sortColumn;
	}


	public String getSortType() {
		return sortType;
	}


	public void setSortType(String sortType) {
		this.sortType = sortType;
	}

}
