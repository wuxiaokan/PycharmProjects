package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 标记系统消息已读
 *
 * @author lyj
 * @date 2017年12月25日 下午7:38:25
 */
public class UpdateSystemMessageReadRequest {

	@ApiModelProperty(value="消息id",required=true)
	private Long id;
	
	@ApiModelProperty(value="消息类型",required=true)
	private Integer type;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}
	
}
