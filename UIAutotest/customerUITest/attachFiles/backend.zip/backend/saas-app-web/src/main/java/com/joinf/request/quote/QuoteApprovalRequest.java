package com.joinf.request.quote;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * Description: 报价流程请求
 *
 * @author lyj
 * @date 2018年1月19日 上午9:34:31
 */
public class QuoteApprovalRequest {

	@ApiModelProperty("报价id集合")
	List<Long> quoteIds;

	public List<Long> getQuoteIds() {
		return quoteIds;
	}

	public void setQuoteIds(List<Long> quoteIds) {
		this.quoteIds = quoteIds;
	}
}
