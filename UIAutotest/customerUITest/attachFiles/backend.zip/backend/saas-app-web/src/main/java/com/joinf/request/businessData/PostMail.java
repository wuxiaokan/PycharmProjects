package com.joinf.request.businessData;

import java.util.List;

/**
 *  邮件发送对象
 * @author cuichuanlei
 * @created 2019年2月14日
 */
public class PostMail {
	
	/**edm组信息*/
	private List<Integer> edmGroupSendList;
	private Integer userId;
	private Integer companyId;
	/**不是用户中心的公司id*/
	private Long notCenterCompanyId;
	/**操作人id*/
	private Long operatorId;
	/**登录的userId*/
	private int loginUserId;
	public List<Integer> getEdmGroupSendList() {
		return edmGroupSendList;
	}
	public void setEdmGroupSendList(List<Integer> edmGroupSendList) {
		this.edmGroupSendList = edmGroupSendList;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public Integer getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}
	public Long getNotCenterCompanyId() {
		return notCenterCompanyId;
	}
	public void setNotCenterCompanyId(Long notCenterCompanyId) {
		this.notCenterCompanyId = notCenterCompanyId;
	}
	public Long getOperatorId() {
		return operatorId;
	}
	public void setOperatorId(Long operatorId) {
		this.operatorId = operatorId;
	}
	public int getLoginUserId() {
		return loginUserId;
	}
	public void setLoginUserId(int loginUserId) {
		this.loginUserId = loginUserId;
	}

}