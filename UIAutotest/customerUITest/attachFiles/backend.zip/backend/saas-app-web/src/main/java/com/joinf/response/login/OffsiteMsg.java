package com.joinf.response.login;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 异地登入信息
 *
 * @author lyj
 * @date 2017年12月20日 下午2:00:44
 */
public class OffsiteMsg {
	
	@ApiModelProperty(value="最后登录时间",required=true)
	private String latestLoginTime;
	
	@ApiModelProperty(value="最后登录省份",required=true)
	private String latestLoginRegion;
	
	@ApiModelProperty(value="最后登录城市",required=true)
	private String latestLoginCity;
	
	@ApiModelProperty(value="最后登录ip",required=true)
	private String latestLoginIp;

	public String getLatestLoginTime() {
		return latestLoginTime;
	}

	public void setLatestLoginTime(String latestLoginTime) {
		this.latestLoginTime = latestLoginTime;
	}

	public String getLatestLoginRegion() {
		return latestLoginRegion;
	}

	public void setLatestLoginRegion(String latestLoginRegion) {
		this.latestLoginRegion = latestLoginRegion;
	}

	public String getLatestLoginCity() {
		return latestLoginCity;
	}

	public void setLatestLoginCity(String latestLoginCity) {
		this.latestLoginCity = latestLoginCity;
	}

	public String getLatestLoginIp() {
		return latestLoginIp;
	}

	public void setLatestLoginIp(String latestLoginIp) {
		this.latestLoginIp = latestLoginIp;
	}

}
