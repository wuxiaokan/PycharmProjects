package com.joinf.request.businessData;

import java.io.Serializable;
import java.util.List;

/**
 * Description: 商业数据搜索参数
 * @author cuichuanlei
 * @created 2019年1月24日 下午4:03:10
 */
public class CompanySearchReq implements Serializable{

	private static final long serialVersionUID = 6615409440183436384L;

	/**是否需要扣除富通币*/
	private String type;
	
	private List<String> ids;
	/**0为过滤的Edm,1为不过滤*/
	private int index;
	private String  id;
	/**邓白氏数据*/
	private String duns;
	/**搜索关键字*/
	private String keywords;
	/**国家*/
	private String countries;	
	/**国家code*/
	private String countryCodes;	
	/**行业*/
	private List<String> industries;	
	/**销售额*/
	private String sales;
	/**员工数量*/
	private String employees;	
	/**第几页*/
	private Integer pageNum;
	/**每页多少条*/
	private Integer pageSize;
	/**icomet任务区分用字段*/
	private String loginId;
	
	private int requestCount =1;
	
	/**登录用户id*/
	private Integer userId;
	private Integer userCompanyId;
	/**公司级别*/
	private int companyLevel;
	/**公司名称*/
	private String companyName;
	
	private String latitude;
	
	private String longitude;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public List<String> getIds() {
		return ids;
	}
	public void setIds(List<String> ids) {
		this.ids = ids;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDuns() {
		return duns;
	}
	public void setDuns(String duns) {
		this.duns = duns;
	}
	public String getKeywords() {
		return keywords;
	}
	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}
	public String getCountries() {
		return countries;
	}
	public void setCountries(String countries) {
		this.countries = countries;
	}
	public String getCountryCodes() {
		return countryCodes;
	}
	public void setCountryCodes(String countryCodes) {
		this.countryCodes = countryCodes;
	}
	public List<String> getIndustries() {
		return industries;
	}
	public void setIndustries(List<String> industries) {
		this.industries = industries;
	}
	public String getSales() {
		return sales;
	}
	public void setSales(String sales) {
		this.sales = sales;
	}
	public String getEmployees() {
		return employees;
	}
	public void setEmployees(String employees) {
		this.employees = employees;
	}
	public Integer getPageNum() {
		return pageNum;
	}
	public void setPageNum(Integer pageNum) {
		this.pageNum = pageNum;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public int getRequestCount() {
		return requestCount;
	}
	public void setRequestCount(int requestCount) {
		this.requestCount = requestCount;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public Integer getUserCompanyId() {
		return userCompanyId;
	}
	public void setUserCompanyId(Integer userCompanyId) {
		this.userCompanyId = userCompanyId;
	}
	public int getCompanyLevel() {
		return companyLevel;
	}
	public void setCompanyLevel(int companyLevel) {
		this.companyLevel = companyLevel;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	
	
	
}
