package com.joinf.request.product;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: TODO
 *
 * @author lyj
 * @date 2018年1月16日 下午3:20:50
 */
public class QueryProductEnchaseRequest {
	
	@ApiModelProperty("产品id")
	private Long proudctId;

	public Long getProudctId() {
		return proudctId;
	}

	public void setProudctId(Long proudctId) {
		this.proudctId = proudctId;
	}

}
