package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * 校验输入值是否存在
 * Description: TODO
 *
 * @author lyj
 * @date 2018年10月19日 下午10:01:51
 */
public class CheckDataExistRequest {
	
	@ApiModelProperty("表名：customer-客户,customerContact-客户联系人,supplier-供应商,supplierContact-供应商联系人")
	private String tableName;
	
	@ApiModelProperty("name-客户/供应商 名称,code-客户/供应商 代码,email-客户/供应商 邮箱")
	private String columnName;
	
	@ApiModelProperty("校验值")
	private String value;
	
	@ApiModelProperty("去除当前数据id")
	private Long id;

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSystemTableName(){
		String tb = "";
		switch (this.tableName) {
		case "customer":
			tb ="t_customer";
			break;
		case "customerContact":
			tb ="t_customer_contact";
			break;
		case "supplier":
			tb ="t_supplier";
			break;
		case "supplierContact":
			tb ="t_supplier_contact";
			break;

		default:
			break;
		}
		return tb;
	}
}
