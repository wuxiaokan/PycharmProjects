package com.joinf.request.supplier;

import io.swagger.annotations.ApiModelProperty;

public class UploadSupplierAttachmentRequest {

	@ApiModelProperty(value = "所属供应商ID")
	private Long supplierId;

	@ApiModelProperty(value = "名称")
	private String name;

	@ApiModelProperty(value = "附件地址")
	private String url;

	@ApiModelProperty(value = "文件大小")
	private Long size;

	@ApiModelProperty(value = "文件类型")
	private String type;

	@ApiModelProperty(value = "是否预览:0/否;1/是")
	private Byte preview;


	public Long getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(Long supplierId) {
		this.supplierId = supplierId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Long getSize() {
		return size;
	}

	public void setSize(Long size) {
		this.size = size;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Byte getPreview() {
		return preview;
	}

	public void setPreview(Byte preview) {
		this.preview = preview;
	}

}
