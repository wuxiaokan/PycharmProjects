package com.joinf.constant.login;

/**
 * Description: 登入中涉及的常量
 *
 * @author lyj
 * @date 2017年12月18日 上午9:56:44
 */
public interface LoginContant {

	/**
	 * 登入失败次数统计
	 */
	public final static String LOGFAIL_COUNT="login_logfail_count";
	
	/**
	 * 校验用户中心成功后保存的对象（userId,companyID）
	 */
	public final static String CENTER_USER_MESSAGE="login_center_user_message";
	
	/**
	 * 登录账号当前可以操作的所有系统集合
	 */
	public final static String PLATFORMS="available_platforms";
	
	/**
	 * 登入失败跳转路径（如果需要跳转）
	 */
	public final static String REDIRECT_URL="login_redirect_url";
	
	/**
	 * 登入成功企业信息（非详细信息--Company）
	 */
	public final static String COMPANY_INFO="login_company_info";
	/**
	 * 登入成功操作员信息
	 */
	public final static String OPERATOR_INFO="login_operator_info";
	
	/**
	 * 登入成功企业信息（用户中心数据）
	 */
	public final static String CENTER_COMPANY_INFO="login_center_company_info";
	/**
	 * 登入成功操作员信息（用户中心数据）
	 */
	public final static String CENTER_OPERATOR_INFO="login_center_operator_info";
	/**
	 * 登入成功企业到期提醒信息
	 */
	public final static String COMPANY_DUE_INFO="login_company_due_info";
	/**
	 * 登入成功企业到期信息
	 */
	public final static String COMPANY_EXPIRE_INFO="login_company_expire_info";
	
	/**
	 * 企业是否过期
	 */
	public final static String COMPANY_HAS_EXPIRED="login_company_has_expire";
	
	/**
	 * 当前用户资源醒醒
	 */
	public final static String OPERATOR_RESOURCES="login_operator_reources";
	/**
	 * 当前用户资源醒醒
	 */
	public final static String OFFSITE_LOGIN="login_offsite_msg";
	
	/**
	 * 切换用户信息
	 */
	public final static String SWITCH_OPERATOR="login_switch_operator_message";
	
	/**企业登陆二次验证 key*/
	public final static String TWO_CHECK_KEY="two_check_%d";
	
	public final static String USER_LOGIN_MESSAGE= "app_user_login_%s";
	
	/**
	 * 当前公司所有用户
	 */
	public final static String COMPANYOPERATORS = "app-company-all-operators";

	
}
