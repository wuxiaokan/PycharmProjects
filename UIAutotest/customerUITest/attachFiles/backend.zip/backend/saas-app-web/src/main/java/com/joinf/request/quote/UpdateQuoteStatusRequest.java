package com.joinf.request.quote;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 报价状态修改
 *
 * @author lyj
 * @date 2018年1月23日 下午3:41:32
 */
public class UpdateQuoteStatusRequest {
	
	@ApiModelProperty("处理记录id")
	private Long dataId;

	@ApiModelProperty("审批意见")
	private String content;

	public Long getDataId() {
		return dataId;
	}

	public void setDataId(Long dataId) {
		this.dataId = dataId;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

}
