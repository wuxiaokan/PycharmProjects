package com.joinf.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.joinf.interfaces.DataPermissionValidateManager;

public class BaseController {

	protected Logger logger = Logger.getLogger(BaseController.class.getName());

	@Autowired
	protected DataPermissionValidateManager dataPermissionValidateManager;

	/**
	 * 校验当前业务员是否有模块权限
	 * 
	 * @param id
	 *            登陆人ID
	 * @param operatorId
	 *            资源所属操作员ID
	 * @param resourceId
	 *            资源ID
	 * @return
	 * @throws Exception
	 */
	protected boolean checkHas(Long id, Long operatorId, Long resourceId) {
		return dataPermissionValidateManager.validateMangerPermission(id, operatorId, resourceId);
	}


}
