package com.joinf.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.joinf.constant.login.LoginContant;
import com.joinf.dto.CheckCaptchaDto;
import com.joinf.dto.CheckSuccessDto;
import com.joinf.dto.CompleteCompanyDto;
import com.joinf.dto.RegisterDto;
import com.joinf.entity.generator.Company;
import com.joinf.interfaces.CompanyService;
import com.joinf.interfaces.RegistManager;
import com.joinf.interfaces.UserCenterService;
import com.joinf.request.CheckInitStatus;
import com.joinf.request.CompleteCompanyRequest;
import com.joinf.request.RegisterRequest;
import com.joinf.response.CompleteCompanyResponse;
import com.joinf.response.InitStatusResponse;
import com.joinf.response.LoginResponse;
import com.joinf.response.RegisterResponse;
import com.joinf.response.UserCenterResponse;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.util.CheckingUtil;
import com.joinf.utils.util.JoinfBeanUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * Description: 注册服务
 *
 * @author lyj
 * @date 2017年12月13日 下午1:46:38
 */
@RestController
@RequestMapping("regist")
@Api(tags = "注册服务")
public class RegistController {
	
	@Autowired
	private UserCenterService service;
	
	@Autowired
	private RegistManager registService;
	
	@Autowired
	private CompanyService companyService;
	
	@Autowired
	private UserCenterService userCenterService;
	
	/**
	 * 注册
	 * 
	 * @param req
	 * @return
	 */
	@ApiOperation(value = "注册", notes = "注册")
	@ApiImplicitParam(name = "req", value = "注册请求对象", required = true, dataType = "RegisterRequest")
	@PostMapping("app")
	public BaseResponseEntity<RegisterResponse> register(HttpServletRequest request,
			@RequestBody @Valid RegisterRequest req, BindingResult bindingResult) {
		request.getSession().invalidate();
		BaseResponseEntity<RegisterResponse> entity = new BaseResponseEntity<>();
		
		if(bindingResult.hasErrors()) {
			for(ObjectError objectError: bindingResult.getAllErrors()){
				entity.setErrMsg(objectError.getDefaultMessage());
				entity.setSuccess(false);
				return entity;
			}
		}
		
		RegisterResponse registerResponse = new RegisterResponse();

		RegisterDto dto = new RegisterDto();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setIp(CheckingUtil.getIpAddress(request));
		CompleteCompanyResponse response = registService.register(dto);
		if(response.isSuccess()){
			registerResponse.setCenterCompanyId(response.getCenterCompany().getCompanyId());
			registerResponse.setCenterUserId(response.getCenterUser().getUserId());
			registerResponse.setCompanyId(response.getCompany().getId());
			registerResponse.setOperatorId(response.getOperator().getId());
			entity.setData(registerResponse);
			//保存用户信息
			UserCenterResponse<CheckSuccessDto> checkResponse = userCenterService.checkUsernameAndPassword(Base64.encodeBase64String(req.getUserName().getBytes()).toString(), req.getPassword());
			request.getSession().setAttribute(LoginContant.CENTER_USER_MESSAGE, JSONObject.toJSONString(checkResponse.getResponseData()));
			request.getSession().setAttribute(LoginContant.REDIRECT_URL,"home");//完善信息后重定向到首页
		}else{
			
			registerResponse.setErrData(response.getErrorMsg());
			if(response.getCode()!= null)
				entity.setCode(response.getCode());
			entity.setData(registerResponse);
		}
		entity.setSuccess(response.isSuccess());
		entity.setErrMsg(response.getErrorMsg());
		return entity;
	}
	
	/**
	 * 完善信息
	 * 
	 * @param req
	 * @return
	 */
	@ApiOperation(value = "完善信息", notes = "完善信息")
	@ApiImplicitParam(name = "req", value = "完善信息请求对象", required = true, dataType = "CompleteCompanyRequest")
	@PostMapping("completeInfo")
	public BaseResponseEntity<RegisterResponse> completeInfo(HttpServletRequest request,@RequestBody CompleteCompanyRequest req) {
		BaseResponseEntity<RegisterResponse> entity = new BaseResponseEntity<>();
		
		RegisterResponse registerResponse= new RegisterResponse();
		
		CompleteCompanyDto dto = new CompleteCompanyDto();
		JoinfBeanUtils.copyProperties(dto, req);
		Integer checkType =req.getCheckType();
		//用户中心不能直接修改邮箱或手机 要校验才能修改
		dto.setMobile(null);
		dto.setEmail(null);
		if(checkType!=null&&!checkType.equals(0)){//校验验证码
			CheckCaptchaDto checkDto = new CheckCaptchaDto();
			JoinfBeanUtils.copyProperties(checkDto, req);
			checkDto.setIp(CheckingUtil.getIpAddress(request));
			UserCenterResponse<String> checkResponse = registService.checkCaptcha(checkDto);
			if(!checkResponse.isSuccess()){
				registerResponse.setErrData(checkResponse.getResponseData());
				
				entity.setSuccess(checkResponse.isSuccess());
				entity.setErrMsg(checkResponse.getErrorMsg());
				if (NumberUtils.isNumber(checkResponse.getCode())) {
					entity.setCode(Integer.valueOf(checkResponse.getCode()));
				}
				entity.setData(registerResponse);
				return entity;
			}else{
				if(checkType.equals(2)){//邮箱校验
					dto.setCheckEmail("y");
					dto.setEmail(req.getEmail());
				}else{
					dto.setCheckMobile("y");
					dto.setMobile(req.getMobile());
				}
			}
		}
		CompleteCompanyResponse response = registService.completeCompany(dto);
		entity.setSuccess(response.isSuccess());
		entity.setErrMsg(response.getErrorMsg());
		if(entity.isSuccess()){
			registerResponse.setCenterCompanyId(response.getCenterCompany().getCompanyId());
			registerResponse.setCenterUserId(response.getCenterUser().getUserId());
			registerResponse.setCompanyId(response.getCompany().getId());
			registerResponse.setOperatorId(response.getOperator().getId());
			entity.setData(registerResponse);
        	
			request.getSession().setAttribute(LoginContant.REDIRECT_URL,"home");//完善信息后重定向到首页
		}
		return entity;
	}
	
	/**
	 *初始化成功后调用
	 * 
	 * @param req
	 * @return
	 */
	@ApiOperation(value = " 初始化成功后调用", notes = "初始化成功后调用")
	@PostMapping("afterInit")
	public BaseResponseEntity<LoginResponse> afterInit(HttpServletRequest request){
		BaseResponseEntity<LoginResponse> entity = new BaseResponseEntity<>();
		entity.setData(SessionUtils.getLoginResponse(request));
		entity.setSuccess(true);//在拦截器中调用
		return entity;
	}
	
	
	/**
	 *查询初始化状态
	 * 
	 * @param req
	 * @return
	 */
	@ApiOperation(value = " 查询初始化状态", notes = " 查询初始化状态")
	@ApiImplicitParam(name = "req", value = " 查询初始化状态请求对象", required = true, dataType = "CheckInitStatus")
	@PostMapping("checkInitStatus")
	public BaseResponseEntity<InitStatusResponse> checkInitStatus(HttpServletRequest request,@RequestBody CheckInitStatus req) {
		BaseResponseEntity<InitStatusResponse> entity = new BaseResponseEntity<>();
		Company company = companyService.selectByPrimaryKey(req.getCompanyId());
		if(company == null){
			entity.setSuccess(false);
			entity.setErrMsg("没有查询到初始化信息");
		}else{
			InitStatusResponse response = new InitStatusResponse();
			Integer flag = company.getFlag();
			response.setFlag(flag);
			entity.setData(response);
		}
		entity.setSuccess(true);
		return entity;
	}
	
}
