package com.joinf.request.email;

import java.io.Serializable;

import com.joinf.request.IdArrayRequest;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 删除邮件请求参数
 * @date 2018年1月13日 下午6:48:26
 */
public class DeleteEmailRequest  extends IdArrayRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2596363725471279783L;

	@ApiModelProperty(value = "当前所在箱子id  客户箱/内部联系人箱传-11")
	protected Long boxId;

	public Long getBoxId() {
		return boxId;
	}

	public void setBoxId(Long boxId) {
		this.boxId = boxId;
	}
	
	
}
