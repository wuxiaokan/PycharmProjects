package com.joinf.response.product;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 网店产品
 *
 * @author lyj
 * @date 2018年1月15日 下午2:16:03
 */
public class ShopProudctResponse {
	
	@ApiModelProperty("id")
	private Long id;
	
	@ApiModelProperty("名称")
	private String subject;
	
	@ApiModelProperty("单价")
	private String price;
	
	@ApiModelProperty("最小起订量")
	private String minOrder;
	
	@ApiModelProperty("产品图片")
	private String url;
	
	@ApiModelProperty(value ="商品详情描述，可包含图片中心的图片URL")
    private String description;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getMinOrder() {
		return minOrder;
	}

	public void setMinOrder(String minOrder) {
		this.minOrder = minOrder;
	}

}
