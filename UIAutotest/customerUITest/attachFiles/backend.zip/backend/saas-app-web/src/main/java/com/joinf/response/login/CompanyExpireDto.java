package com.joinf.response.login;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * Description: 过期信息
 *
 * @author lyj
 * @date 2017年12月18日 下午5:01:12
 */
public class CompanyExpireDto implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5923195980249247041L;

	@ApiModelProperty(value="过期时间",required=true)
	private String expireDate;
	
	@ApiModelProperty(value="是否付费:[0]未订购[1]包年服务（1年）",required=true)
	private Integer orderStatus;
	
	public String getExpireDate() {
		return expireDate;
	}

	public void setExpireDate(String expireDate) {
		this.expireDate = expireDate;
	}

	public Integer getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(Integer orderStatus) {
		this.orderStatus = orderStatus;
	}
	
	
}
