package com.joinf.request.quote;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * 报价删除请求参数
 *
 * @author yzq
 * @date 2019-06-19
 */
public class DeleteQuoteRequest {
    @ApiModelProperty(value="删除id集合",required=true)
    private List<Long> Ids;

    public List<Long> getIds() {
        return Ids;
    }

    public void setIds(List<Long> ids) {
        Ids = ids;
    }
}
