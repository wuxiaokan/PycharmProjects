package com.joinf.request.email;

import java.io.Serializable;

import com.joinf.request.IdRequest;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 发送回执邮件请求参数
 * @date 2018年1月16日 下午2:17:49
 */
public class SentReceiptEmailRequest extends IdRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2596363725471279783L;

	@ApiModelProperty(value = "下次是否自动回执")
	protected boolean autoReceipt;

	
	public boolean isAutoReceipt() {
		return autoReceipt;
	}

	public void setAutoReceipt(boolean autoReceipt) {
		this.autoReceipt = autoReceipt;
	}

	
	
}
