package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 发送验证码参数
 *
 * @author lyj
 * @date 2017年12月25日 下午1:31:08
 */
public class SendCapthcaCodeRequest {
	
	@ApiModelProperty(value="类别(1:手机发送,2:邮箱发送)",required=true)
	private Integer type;
	
	@ApiModelProperty(value="验证码类型('regist-注册,reset-重置密码,unbind-解绑,bind-绑定,login-二次验证')",required=true)
	private String source;
	
	@ApiModelProperty(value="接收者姓名",required=true)
	private String received;
	
	@ApiModelProperty(value="随机码-校验使用",required=true)
	private String random;
	
	@ApiModelProperty(value="接收者号码-手机或邮箱",required=true)
	private String receivedNumber;

	public String getReceivedNumber() {
		return receivedNumber;
	}

	public void setReceivedNumber(String receivedNumber) {
		this.receivedNumber = receivedNumber;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getReceived() {
		return received;
	}

	public void setReceived(String received) {
		this.received = received;
	}

	public String getRandom() {
		return random;
	}

	public void setRandom(String random) {
		this.random = random;
	}

}
