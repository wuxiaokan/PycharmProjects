package com.joinf.request.email;

import java.io.Serializable;
import java.util.Date;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 校验发送频率参数
 * @date 2018年1月31日 下午4:37:29
 */
public class CheckSendFrequencyRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2105085247053982301L;


	@ApiModelProperty(value = "发送邮箱账号id,多个逗号隔开")
	private String senders;
	@ApiModelProperty(value = "发送邮箱账号,多个逗号隔开")
	private String fromMail;
	
	@ApiModelProperty(value = "收件人")
	private String recipients;
	@ApiModelProperty(value = "抄送人")
	private String cc;
	@ApiModelProperty(value = "密送人")
	private String bc;
	
	@ApiModelProperty(value ="设置定时邮件发送时间")
    private Date sendTime;
    @ApiModelProperty(value ="是否定时发送")
    private Boolean isTimingSent;

	
    @ApiModelProperty(value ="是否群发邮件")
    private Boolean isMassEmail;


	public String getSenders() {
		return senders;
	}


	public void setSenders(String senders) {
		this.senders = senders;
	}


	public String getRecipients() {
		return recipients;
	}


	public void setRecipients(String recipients) {
		this.recipients = recipients;
	}


	public String getCc() {
		return cc;
	}


	public void setCc(String cc) {
		this.cc = cc;
	}


	public String getBc() {
		return bc;
	}


	public void setBc(String bc) {
		this.bc = bc;
	}


	public Date getSendTime() {
		return sendTime;
	}


	public void setSendTime(Date sendTime) {
		this.sendTime = sendTime;
	}


	public Boolean getIsTimingSent() {
		return isTimingSent;
	}


	public void setIsTimingSent(Boolean isTimingSent) {
		this.isTimingSent = isTimingSent;
	}


	public Boolean getIsMassEmail() {
		return isMassEmail;
	}


	public void setIsMassEmail(Boolean isMassEmail) {
		this.isMassEmail = isMassEmail;
	}


	public String getFromMail() {
		return fromMail;
	}


	public void setFromMail(String fromMail) {
		this.fromMail = fromMail;
	}
	
	

    

}
