package com.joinf.interceptor;

import com.joinf.interfaces.email.EmailLogManager;
import com.joinf.utils.annotations.DataLog;
import com.joinf.utils.dto.log.LogRecordBaseDto;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.lang.reflect.Method;

/**
 * @description: 操作日志记录
 * @author zlx
 * @date 2019年7月4日 上午10:17:42
 * @revisionHistory
 */
@Slf4j
@Aspect
@Component
public class LogRecordAspect {
	
	@Resource
	private EmailLogManager emailLogManager;

	@AfterReturning(returning="result",pointcut="@annotation(com.joinf.utils.annotations.DataLog)")
	public void afterMethodInvoke(JoinPoint pjp, LogRecordBaseDto result) throws Throwable {
		
		try {
			MethodSignature sign = (MethodSignature) pjp.getSignature();
	        Method method = sign.getMethod();
	        //获取方法上的注解
	        DataLog annotation = method.getAnnotation(DataLog.class);
	        if (annotation != null) {
	        	//模块
	        	String module = annotation.type().getModule().name().toLowerCase();
	        	//操作功能
	        	String type = annotation.type().getCode();
	        	
	        	log.info("log record module:{}, type:{}, data:{}", module, type, result);
	        	
	        	emailLogManager.saveEmailLog(annotation.type(), (LogRecordBaseDto)result);
	        }
		} catch (Exception e) {
			//日志记录异常不影响用户交互
			log.error("记录日志异常", e);
		}
		
	}

}