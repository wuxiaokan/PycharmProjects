package com.joinf.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.collect.Lists;
import com.joinf.Response.QueryQuoteResponse;
import com.joinf.annotations.NeedLogin;
import com.joinf.constant.Constants;
import com.joinf.constants.Customize;
import com.joinf.dto.CheckSuccessDto;
import com.joinf.dto.CompanyDTO;
import com.joinf.dto.DeleteQuoteAttachmentDto;
import com.joinf.dto.DownLoadFileParam;
import com.joinf.dto.quote.QueryQuoteDto;
import com.joinf.dto.quote.QuoteFlowDto;
import com.joinf.dto.supplier.SupplierDetailDto;
import com.joinf.entity.SessionUser;
import com.joinf.entity.generator.CustomizeResourceColumn;
import com.joinf.entity.generator.QuoteAttachment;
import com.joinf.entity.generator.QuoteProduct;
import com.joinf.interfaces.CustomizeResourceColumnService;
import com.joinf.interfaces.FileService;
import com.joinf.interfaces.quote.QuoteManager;
import com.joinf.interfaces.quote.QuoteProudctManager;
import com.joinf.request.IdRequest;
import com.joinf.request.quote.BatchUpdateQuoteStatusRequest;
import com.joinf.request.quote.DeleteQuoteRequest;
import com.joinf.request.quote.QueryQuoteProductRequest;
import com.joinf.request.quote.QueryQuoteRequest;
import com.joinf.request.quote.QuoteApprovalRequest;
import com.joinf.request.quote.QuoteFlowRequest;
import com.joinf.request.quote.SendQuoteEmailRequest;
import com.joinf.request.quote.UpdateQuoteStatusRequest;
import com.joinf.request.quote.UploadQuoteAttachmentRequest;
import com.joinf.response.EditDetailResponse;
import com.joinf.response.SuccessResponse;
import com.joinf.response.quote.QuoteAttachmentResponse;
import com.joinf.response.supplier.QuerySupplierResponse;
import com.joinf.service.redis.RedisService;
import com.joinf.utils.BaseEntityUtils;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.annotations.Permission;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.dto.user.UserInfoDto;
import com.joinf.utils.util.JoinfBeanUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * Description: 报价服务
 *
 * @author lyj
 * @date 2018年1月17日 下午5:09:43
 */
@RestController
@RequestMapping("quote")
@Api(tags="报价服务")
public class QuoteController {


	@Autowired
	private QuoteManager quoteManager;
	
	@Autowired
	private QuoteProudctManager quoteProudctManager;

	@Autowired
	private CustomizeResourceColumnService customizeResourceColumnService;

	@Autowired
	private RedisService redisService;
	
	@Autowired
	private FileService fileService;
	
	/**
	 * 查询报价列表
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询报价列表", notes="查询报价列表")
	@ApiImplicitParam(name = "req", value = "查询报价列表请求对象", required = true, dataType = "QueryQuoteRequest")
	@PostMapping("queryQuoteList")
	@NeedLogin
	@Permission(require="quote.list.preview")
	public BaseResponseEntity<QuerySupplierResponse> queryQuoteList(HttpServletRequest request,@RequestBody QueryQuoteRequest req){
		
		QueryQuoteDto dto = new QueryQuoteDto();
		JoinfBeanUtils.copyProperties(dto, req);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);

		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setRoleId(user.getUser().getRoleId());
		dto.setResourceId(Customize.QuoteList.getResourceId());
		dto.setTableName(Customize.QuoteList.getTableName());
		dto.setModule(Customize.QuoteList.getModule());
		
		QueryQuoteResponse data = quoteManager.selectQuote(dto);
		BaseResponseEntity<QuerySupplierResponse> entity = new BaseResponseEntity<>();
		entity.setSuccess(true);
		
		List<String> showFileds = new ArrayList<String>();
		showFileds.add("code");//代码
		showFileds.add("showStatus");//状态
		showFileds.add("QuoteName");//报价名称
		showFileds.add("currencyName");//货币名称
		showFileds.add("contactName");//联系人名称
		showFileds.add("quoteDate");//报价日期
		showFileds.add("totalAmount");//报价总额
		showFileds.add("salemanId");//业务员
		showFileds.add("customerName");//客户名称
		QuerySupplierResponse querySupplierResponse = quoteManager.getQuoteListArray(dto, data.getQuotes(), null);
		Integer decimalNumber = null;
		List<Long> resourceIds = Lists.newArrayList(14l);
		List<String> columnIds = Lists.newArrayList("totalAmount");
		List<CustomizeResourceColumn> customizeResourceColumnList = customizeResourceColumnService.selectListByResourceIdsAndColumnIds(user.getCompanyId(), resourceIds, columnIds);
		if (!CollectionUtils.isEmpty(customizeResourceColumnList)) {
			decimalNumber = customizeResourceColumnList.get(0).getDecimalNumber();
		}
		CompanyDTO companyDTO = SessionUtils.getCenterCompanyInfo(request);
		Long centerId = companyDTO.getCompanyId();
		boolean aFlag = Constants.SZHX_CENTER_ID.equals(centerId) ;
		boolean bFlag = Constants.SZYS_CENTER_ID.equals(centerId);
		boolean cFlag = Constants.RJF_CENTER_ID.equals(centerId);  // 任竞帆
		boolean dFlag = Constants.FFY_CENTER_ID.equals(centerId);  // ffy
		if (aFlag) {
			//decimalNumber = 5;
		} else if (bFlag) {
			decimalNumber = 2;
		} else if (cFlag) {
			decimalNumber = 2;
		} else if (dFlag) {
			decimalNumber = 4;
		}
		querySupplierResponse.setDecimalNumber(decimalNumber);
		entity.setData(querySupplierResponse);
		entity.setTotalRecords(data.getTotal());
		return entity;
	}
	
	@ApiOperation(value="查询报价明细", notes="查询报价明细")
	@ApiImplicitParam(name = "req", value = "查询报价明细请求对象", required = true, dataType = "IdRequest")
	@PostMapping("getQuoteDetail")
	@NeedLogin
	@Permission(require="quote.list.preview")
	public BaseResponseEntity<List<EditDetailResponse>> getSupplierDetail(HttpServletRequest request,@RequestBody IdRequest req){
		SupplierDetailDto dto = new SupplierDetailDto();
		dto.setId(req.getId());
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(user.getUser().getCompanyId());
		dto.setRoleId(user.getUser().getRoleId());
		
		dto.setResourceId(Customize.QuoteEdit.getResourceId());
		dto.setTableName(Customize.QuoteEdit.getTableName());
		dto.setModule(Customize.QuoteEdit.getModule());
	
		List<EditDetailResponse> details = quoteManager.getQuoteEditArray(dto);
		return BaseEntityUtils.successOne(details);
	}
	
	
	/**
	 * 查询报价列表
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询报价商品列表", notes="查询商品报价列表")
	@ApiImplicitParam(name = "req", value = "查询商品列表请求对象", required = true, dataType = "QueryQuoteProductRequest")
	@PostMapping("queryQuoteProductList")
	@NeedLogin
	@Permission(require="quote.list.preview")
	public BaseResponseEntity<QuerySupplierResponse> queryQuoteProductList(HttpServletRequest request,@RequestBody QueryQuoteProductRequest req){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		Long companyId = user.getCompanyId();
		QueryQuoteDto dto = new QueryQuoteDto();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(companyId);
		dto.setRoleId(user.getRoleId());
		dto.setResourceId(Customize.QuoteProduct.getResourceId());
		dto.setTableName(Customize.QuoteProduct.getTableName());
		dto.setModule(Customize.QuoteProduct.getModule());
		
		List<QuoteProduct> produts = quoteProudctManager.getQuoteProducts(req.getQuoteId(), companyId);
		BaseResponseEntity<QuerySupplierResponse> entity = new BaseResponseEntity<>();
		entity.setSuccess(true);
		QuerySupplierResponse querySupplierResponse = quoteProudctManager.getQuoteProductListArray(dto, produts, null);
		Integer decimalNumber = null;
		List<Long> resourceIds = Lists.newArrayList(15l);
		List<String> columnIds = Lists.newArrayList("price");
		List<CustomizeResourceColumn> customizeResourceColumnList = customizeResourceColumnService.selectListByResourceIdsAndColumnIds(user.getCompanyId(), resourceIds, columnIds);
		if (!CollectionUtils.isEmpty(customizeResourceColumnList)) {
			decimalNumber = customizeResourceColumnList.get(0).getDecimalNumber();
		}
		CompanyDTO companyDTO = SessionUtils.getCenterCompanyInfo(request);
		Long centerId = companyDTO.getCompanyId();
		boolean aFlag = Constants.SZHX_CENTER_ID.equals(centerId) ;
		boolean bFlag = Constants.SZYS_CENTER_ID.equals(centerId);
		boolean cFlag = Constants.RJF_CENTER_ID.equals(centerId);  // 任竞帆
		boolean dFlag = Constants.FFY_CENTER_ID.equals(centerId);  // ffy
		if (aFlag) {
			decimalNumber = 5;
		} else if (bFlag) {
			decimalNumber = 2;
		} else if (cFlag) {
			decimalNumber = 2;
		} else if (dFlag) {
			decimalNumber = 5;
		}
		querySupplierResponse.setDecimalNumber(decimalNumber);
		entity.setData(querySupplierResponse);

		return entity;
	}
	
	
	@ApiOperation(value="查询订单产品明细", notes="查询订单产品明细")
	@ApiImplicitParam(name = "req", value = "查询订单产品明细请求对象", required = true, dataType = "IdRequest")
	@PostMapping("getQuoteProductDetail")
	@Permission(require="quote.list.edit")
	public BaseResponseEntity<List<EditDetailResponse>> getOrderProductDetail(HttpServletRequest request,@RequestBody IdRequest req){
		SupplierDetailDto dto = new SupplierDetailDto();
		dto.setId(req.getId());
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setRoleId(user.getUser().getRoleId());
		
		dto.setResourceId(Customize.QuoteProduct.getResourceId());
		dto.setTableName(Customize.QuoteProduct.getTableName());
		dto.setModule(Customize.QuoteProduct.getModule());
		
		List<EditDetailResponse> details = quoteProudctManager.getQuoteProductEditArray(dto);
		return BaseEntityUtils.successOne(details);
	}
	
	/**
	 * 删除报价
	 * @param req
	 * @return
	 */
	@ApiOperation(value="删除报价", notes="删除报价")
	@ApiImplicitParam(name = "req", value = "删除报价请求对象", required = true, dataType = "QuoteApprovalRequest")
	@PostMapping("deleteQuotes")
	@NeedLogin
	@Permission(require="quote.list.delete")
	public BaseResponseEntity<?> deleteQuotes(HttpServletRequest request,@RequestBody QuoteApprovalRequest req){
		BaseResponseEntity<?> entity = new BaseResponseEntity<>();
		entity.setSuccess(true);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		quoteManager.deleteQuoteByIds(user.getOperatorId(),user.getSwitchOperatorId(), req.getQuoteIds());
		return entity;
	}
	
	@ApiOperation(value="报价提交审批流程", notes="报价提交审批流程")
	@PostMapping("submitQuoteApproval")
	@ApiImplicitParam(name = "req", value = "报价提交审批流程请求对象", required = true, dataType = "QuoteFlowRequest")
	@NeedLogin
	@Permission(require="quote.approval.flowSubmit")
	public BaseResponseEntity<Integer> submitQuoteApproval(HttpServletRequest request,@RequestBody QuoteFlowRequest req){
		BaseResponseEntity<Integer> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		CheckSuccessDto company = SessionUtils.getCenterUserDto(request);
		entity.setSuccess(true);
		QuoteFlowDto dto = new QuoteFlowDto();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		
		//新加的参数
		dto.setCenterCompanyId(company.getCompanyId());
		dto.setCenterUserId(company.getUserId());
		dto.setDeviceId(user.getSwitchOperator().getDeviceId());
		
		//切换人管理人员列表
		List<UserInfoDto> list = redisService.getOperatorAssignment(user.getCompanyId(), user.getSwitchOperatorId(),1);	
		UserInfoDto userInfo = list.stream().filter(o -> o.getId().equals(user.getSwitchOperatorId())).findAny().orElse(null);
		dto.setUserName(userInfo.getUserName());
		dto.setTrueName(userInfo.getChineseName());
		
		quoteManager.submitQuoteFlow(dto);
		entity.setData(quoteManager.selectByPrimaryKey(req.getDataId()).getStatus());
		return entity;
	}
	
	@ApiOperation(value="报价已批退回", notes="报价已批退回")
	@PostMapping("approvedBack")
	@ApiImplicitParam(name = "req", value = "报价已批退回请求对象", required = true, dataType = "UpdateQuoteStatusRequest")
	@NeedLogin
	@Permission(require="quote.approval.yipiBack")
	public BaseResponseEntity<Integer> approvedBack(HttpServletRequest request,@RequestBody UpdateQuoteStatusRequest req){
		BaseResponseEntity<Integer> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		CheckSuccessDto company = SessionUtils.getCenterUserDto(request);
		entity.setSuccess(true);
		QuoteFlowDto dto = new QuoteFlowDto();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		//新加的参数
		dto.setCenterCompanyId(company.getCompanyId());
		dto.setCenterUserId(company.getUserId());
		dto.setDeviceId(user.getSwitchOperator().getDeviceId());
		
		//切换人管理人员列表
		List<UserInfoDto> list = redisService.getOperatorAssignment(user.getCompanyId(), user.getSwitchOperatorId(),1);	
		UserInfoDto userInfo = list.stream().filter(o -> o.getId().equals(user.getSwitchOperatorId())).findAny().orElse(null);
		dto.setUserName(userInfo.getUserName());
		dto.setTrueName(userInfo.getChineseName());
		
		entity.setData(quoteManager.approvedBack(dto).getStatus());
		return entity;
	}
	
	@ApiOperation(value="报价完成退回", notes="报价完成退回")
	@PostMapping("completedBack")
	@ApiImplicitParam(name = "req", value = "报价完成退回请求对象", required = true, dataType = "UpdateQuoteStatusRequest")
	@NeedLogin
	@Permission(require="quote.approval.doneBack")
	public BaseResponseEntity<Integer> completedBack(HttpServletRequest request,@RequestBody UpdateQuoteStatusRequest req){
		BaseResponseEntity<Integer> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		entity.setSuccess(true);
		QuoteFlowDto dto = new QuoteFlowDto();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		entity.setData(quoteManager.quoteCompleteToUnComplete(dto).getStatus());
		return entity;
	}
	
	
	@ApiOperation(value="报价完成", notes="报价完成")
	@PostMapping("quoteComplete")
	@ApiImplicitParam(name = "req", value = "报价完成请求对象", required = true, dataType = "UpdateQuoteStatusRequest")
	@NeedLogin
	@Permission(require="quote.approval.complete")
	public BaseResponseEntity<Integer> quoteComplete(HttpServletRequest request,@RequestBody UpdateQuoteStatusRequest req){
		BaseResponseEntity<Integer> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		entity.setSuccess(true);
		QuoteFlowDto dto = new QuoteFlowDto();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		entity.setData(quoteManager.quoteComplete(dto).getStatus());
		return entity;
	}
	
	
	@ApiOperation(value="批量处理报价完成", notes="批量处理报价完成")
	@PostMapping("quoteBatchComplete")
	@ApiImplicitParam(name = "req", value = "批量处理报价完成请求对象", required = true, dataType = "BatchUpdateQuoteStatusRequest")
	@NeedLogin
	@Permission(require="quote.approval.complete")
	public BaseResponseEntity<Integer> quoteBatchComplete(HttpServletRequest request,@RequestBody BatchUpdateQuoteStatusRequest req){
		BaseResponseEntity<Integer> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		entity.setSuccess(true);
		for(Long dataId:req.getDataIds()){//校验
			quoteManager.checkQuote(user.getCompanyId(), dataId, 4);
		}
		for(Long dataId:req.getDataIds()){
			QuoteFlowDto dto = new QuoteFlowDto();
			dto.setDataId(dataId);
			dto.setContent(req.getContent());
			dto.setCompanyId(user.getCompanyId());
			dto.setOperatorId(user.getOperatorId());
			dto.setSwitchOperatorId(user.getSwitchOperatorId());
			quoteManager.quoteComplete(dto);
		}
		entity.setData(8);
		return entity;
	}

	@ApiOperation(value="查询报价附件", notes="查询报价附件")
	@ApiImplicitParam(name = "req", value = "查询报价附件请求对象", required = true, dataType = "IdRequest")
	@PostMapping("getQuoteAttachments")
	@Permission(require="quote.list.preview")
	public BaseResponseEntity<List<QuoteAttachmentResponse>> getQuoteAttachments(HttpServletRequest request, @RequestBody IdRequest req){
		BaseResponseEntity<List<QuoteAttachmentResponse>> entity = new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);

		entity.setSuccess(true);
		entity.setData(quoteManager.getQuoteAttachments(req.getId(),user.getCompanyId()));
		return entity;
	}

	@ApiOperation(value="上传报价附件", notes="上传报价附件")
	@ApiImplicitParam(name = "req", value = "上传报价附件请求对象", required = true, dataType = "UploadQuoteAttachmentRequest")
	@PostMapping("uploadQuoteAttachments")
	@Permission(require="quote.list.preview")
	public BaseResponseEntity<SuccessResponse> uploadQuoteAttachments(HttpServletRequest request,@RequestBody UploadQuoteAttachmentRequest req){
		BaseResponseEntity<SuccessResponse> entity = new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		QuoteAttachment attachment = new QuoteAttachment();
		JoinfBeanUtils.copyProperties(attachment, req);
		Date date = new Date();
		attachment.setCompanyId(user.getCompanyId());
		attachment.setOperatorId(user.getOperatorId());
		attachment.setCreateTime(date);
		attachment.setFlag(1);
		attachment.setUpdateId(user.getSwitchOperatorId());
		attachment.setUpdateTime(date);
		attachment.setCreateId(user.getSwitchOperatorId());
		quoteManager.uploadQuoteAttachment(attachment);
		entity.setSuccess(true);
		entity.setData(new SuccessResponse(true));
		return entity;
	}

	@ApiOperation(value="删除报价附件", notes="删除报价附件")
	@ApiImplicitParam(name = "req", value = "删除报价附件请求对象", required = true, dataType = "DeleteQuoteRequest")
	@PostMapping("deleteQuoteAttachments")
	@Permission(require="quote.list.delete")
	public BaseResponseEntity<SuccessResponse> deleteQuoteAttachments(HttpServletRequest request,@RequestBody DeleteQuoteRequest req){
		BaseResponseEntity<SuccessResponse> entity = new BaseResponseEntity<SuccessResponse>();
		DeleteQuoteAttachmentDto dto = new DeleteQuoteAttachmentDto();

		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setUpdateId(user.getOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setIds(req.getIds());
		quoteManager.deleteQuoteAttachment(dto);
		entity.setSuccess(true);
		entity.setData(new SuccessResponse(true));
		return entity;
	}
	
	/**
	 * 发送邮件插入报价模板
	 * @param map
	 * @param request
	 * @return
	 */
	@ApiOperation(value="生成Excel报价", notes="生成Excel报价")
	@PostMapping("generateQuote")
	@ApiImplicitParam(name = "req", value = "生成Excel报价请求对象", required = true, dataType = "SendQuoteEmailRequest")
	@NeedLogin
	@Permission(require="product.list.sendemail")
	public BaseResponseEntity<List<String>> getMailInsertProduct(HttpServletRequest request,@RequestBody SendQuoteEmailRequest req){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		BaseResponseEntity<List<String>> entity = new BaseResponseEntity<>();
		DownLoadFileParam param = new DownLoadFileParam();
		param.setOperatorId(user.getSwitchOperatorId());
		param.setSuffix(req.getSuffix() == null ? "excel" : req.getSuffix());
		param.setTemplateId(req.getTemplateId());
		param.setType(1);
		entity.setSuccess(true);
		List<String> quoteList = new ArrayList<String>();
		for(Long id : req.getQuoteIds()){
			param.setBusinessIds(String.valueOf(id));
			quoteList.add(fileService.getQuoteReportTemplateData(param));
		}
		entity.setData(quoteList);
		return entity;
	}
}
