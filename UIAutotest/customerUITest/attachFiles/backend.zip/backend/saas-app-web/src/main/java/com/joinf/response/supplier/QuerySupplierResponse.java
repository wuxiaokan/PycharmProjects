package com.joinf.response.supplier;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.List;

import com.alibaba.fastjson.JSONArray;
import com.joinf.response.CustomizeResponse;


/**
 * Description: 供应商查询返回列表/单个类
 *
 * @author lyj
 * @date 2017年12月4日 下午8:25:08
 */
public class QuerySupplierResponse implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2105085247053982301L;
	
	@ApiModelProperty(value="列名集合",required=true)
	private List<CustomizeResponse> headLists;
	
	@ApiModelProperty(value="数值",required=true)
	private JSONArray values;

	@ApiModelProperty(value="小数位数",required=false)
	private Integer decimalNumber;
	
	public List<CustomizeResponse> getHeadLists() {
		return headLists;
	}

	public void setHeadLists(List<CustomizeResponse> headLists) {
		this.headLists = headLists;
	}

	public JSONArray getValues() {
		return values;
	}

	public void setValues(JSONArray values) {
		this.values = values;
	}

	public Integer getDecimalNumber() {
		return decimalNumber;
	}

	public void setDecimalNumber(Integer decimalNumber) {
		this.decimalNumber = decimalNumber;
	}
}
