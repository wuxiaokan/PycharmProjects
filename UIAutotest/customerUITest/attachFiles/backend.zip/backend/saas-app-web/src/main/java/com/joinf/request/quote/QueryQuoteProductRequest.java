package com.joinf.request.quote;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 查询报价商品
 *
 * @author lyj
 * @date 2018年1月18日 下午2:51:00
 */
public class QueryQuoteProductRequest {
	
	@ApiModelProperty("报价id")
	private Long quoteId;

	public Long getQuoteId() {
		return quoteId;
	}

	public void setQuoteId(Long quoteId) {
		this.quoteId = quoteId;
	}

}
