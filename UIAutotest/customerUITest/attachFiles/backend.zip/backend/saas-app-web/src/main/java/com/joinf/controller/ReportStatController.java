package com.joinf.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.joinf.constant.ReportConstants;
import com.joinf.dto.report.QueryReportDto;
import com.joinf.entity.SessionUser;
import com.joinf.entity.generator.Company;
import com.joinf.interfaces.AssignmentService;
import com.joinf.interfaces.OperatorService;
import com.joinf.interfaces.report.ReportStatService;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.dto.user.UserInfoDto;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * 统计报表服务
 * 
 * @author CyNick
 *
 */
@RestController
@RequestMapping("report")
@Api(tags = "统计报表")
public class ReportStatController {

	@Autowired
	private OperatorService operatorService;
	@Autowired
	private AssignmentService assignmentService;
	@Autowired
	private ReportStatService reportStatService;

	/**
	 * 列表查询
	 * 
	 * @param json
	 * @return
	 */
	@ApiOperation(value="PK", notes="PK")
	@PostMapping("reportList")
	@ApiImplicitParam(name = "req", value = "统计报表PK", required = true, dataType = "QueryReportDto")
	@ResponseBody
	public BaseResponseEntity<JSONObject> reportList(@RequestBody QueryReportDto req, HttpServletRequest request) {
		BaseResponseEntity<JSONObject> entity = new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		Company company = SessionUtils.getCompanyInfo(request);
		// 获取公司下的所有操作员
		List<UserInfoDto> salesmanList = operatorService.getCompanyAllOperators(user.getCompanyId());
		// 获取管理范围内的所有业务员
		List<UserInfoDto> assignmentUsers = assignmentService.selectAssignmentUserList(user.getCompanyId(),
				user.getSwitchOperatorId());

		JSONObject json = (JSONObject) JSONObject.toJSON(req);
		json.put("salesmanList", salesmanList);
		json.put("operatorIds", getAllOperatorIds(assignmentUsers));
		json.put("centerCompanyId", company.getCenterCompanyId());
		if(StringUtils.isEmpty(json.getString("operatorId"))){
			json.put("operatorId", user.getSwitchOperatorId());
		}
		
		JSONObject data = reportStatService.reportList(json, user, pageHelp(json.getString("reportType")));
		// 处理结果集
		entity.setData(data);
		entity.setSuccess(true);
		return entity;

	}

	/**
	 * 全部能管理的用户
	 * 
	 * @param query
	 * @param assignmentUserList
	 */
	private Long[] getAllOperatorIds(List<UserInfoDto> assignmentUserList) {
		Long[] operatorIds = null;
		if (!CollectionUtils.isEmpty(assignmentUserList)) {
			Set<Long> set = new HashSet<Long>();
			for (UserInfoDto o : assignmentUserList) {
				if (o != null) {
					set.add(o.getId());
				}
			}
			operatorIds = set.toArray(new Long[0]);
		}
		return operatorIds;
	}
	
	
	private boolean pageHelp(String reportType){
		if (StringUtils .equals(reportType, ReportConstants.MODEL_PRODUCT)
				&& (StringUtils .equals(reportType, ReportConstants.PRODUCT_TOP_ORDER)
				|| StringUtils .equals(reportType, ReportConstants.PRODUCT_TOP_QUOTE))) {// 产品模块
			return false;
		} else if (StringUtils .equals(reportType, ReportConstants.MODEL_PK)) {// 业务员PK
			return false;
		}
		return true;
	}
}
