package com.joinf.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.joinf.annotations.NeedLogin;
import com.joinf.entity.SessionUser;
import com.joinf.entity.generator.EmailTag;
import com.joinf.entity.generator.EmailWithBLOBs;
import com.joinf.interfaces.EmailService;
import com.joinf.request.email.DelEmailTag;
import com.joinf.request.email.SaveOrEditEmailTag;
import com.joinf.response.email.EmailTagResponse;
import com.joinf.service.email.EmailManagerImpl;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.annotations.ResubmitData;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.util.JoinfBeanUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 *  邮件标签控制类
 *  
 * @author CyNick
 *
 */
@Controller
@RequestMapping("/emailTag")
@Api(tags="邮件标签服务")
public class EmailTagController {
	
	protected Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private EmailManagerImpl emailManager;
	@Autowired
	private EmailService emailService;
	
	
	/**
	 * 删除标签
	 * @param dto
	 * @param request
	 * @return
	 */
	@ApiOperation(value="删除标签", notes="删除标签")
	@ApiImplicitParam(name = "req", value = "删除标签请求对象", required = true, dataType = "DelEmailTag")
	@PostMapping("/deleteEmailTag")
	@ResponseBody
	@NeedLogin
	@ResubmitData
	public BaseResponseEntity<Integer> deleteEmailTag(HttpServletRequest request,@RequestBody DelEmailTag req){
		
		BaseResponseEntity<Integer> entity = new BaseResponseEntity<>(true);
		
		try {
			SessionUser user = SessionUtils.getCurrentUserInfo(request);
			
			EmailTag tag = JoinfBeanUtils.copyToNewBean(EmailTag.class, req);
			
			tag.setCompanyId(user.getCompanyId());
			tag.setOperatorId(user.getSwitchOperatorId());
			tag.setUpdateId(user.getSwitchOperatorId());
			tag.setUpdateTime(new Date());
			emailManager.deleteEmailTag(tag);
			entity.setSuccess(true);
		} catch (Exception e) {
			logger.error("",e);
			entity.setSuccess(false);
		}
		
		return entity;
	}
	
	/**
	 * 新增或者修改标签
	 * @param tag
	 * @param request
	 * @return
	 */
	@ApiOperation(value="新增或者修改标签", notes="新增或者修改标签")
	@PostMapping("/addOrUpdateEmailTag")
	@ResponseBody
	@ApiImplicitParam(name = "req", value = "新增或者修改标签请求对象", required = true, dataType = "SaveOrEditEmailTag")
	@NeedLogin
	@ResubmitData
	public BaseResponseEntity<Integer> addOrUpdateEmailTag(HttpServletRequest request,@RequestBody SaveOrEditEmailTag req){
		BaseResponseEntity<Integer> entity = new BaseResponseEntity<>(true);
		try {
			SessionUser user = SessionUtils.getCurrentUserInfo(request);

			EmailTag tag = JoinfBeanUtils.copyToNewBean(EmailTag.class, req);
			
			tag.setCompanyId(user.getCompanyId());
			tag.setOperatorId(user.getSwitchOperatorId());
			tag.setCreateId(user.getSwitchOperatorId());
			tag.setCreateTime(new Date());
			tag.setFlag(1);
			tag.setUpdateId(user.getSwitchOperatorId());
			tag.setUpdateTime(new Date());
			
			if(tag.getId()==null) {//新增
			    Map<String, Object> map = new HashMap<String, Object>();
				map.put("companyId", user.getCompanyId());
				map.put("operatorId", user.getSwitchOperatorId());
				map.put("flag", 1);
			    List<EmailTagResponse> tagList = emailManager.getEmailTagList(map);
			    int total = 20;//总数量
				if(tagList.size() >= total){//最多不超过total数量
					entity.setSuccess(false);
					entity.setErrMsg("最多新建"+total+"条标签！");
				}
				
			} 
			
			int result = emailManager.addOrUpdateEmailTag(tag);
			if(result == -1){
				entity.setSuccess(false);
				entity.setErrMsg("该标签已存在！");
			}else{
				entity.setSuccess(true);
			}
			return entity;
		} catch (Exception e) {
			logger.error("", e);
			String msg = e.getMessage();
			entity.setData(0);
			entity.setErrMsg(msg);
			return entity;
		}
	}
	
	/**
	 * 获取标签列表
	 * @param tag
	 * @param request
	 * @return
	 */
	@ApiOperation(value="获取标签列表", notes="获取标签列表")
	@PostMapping("/queryEmailTagList")
	@ApiImplicitParam(name = "req", value = "获取标签列表请求对象", required = true, dataType = "DelEmailTag")
	@ResponseBody
	@NeedLogin
	@ResubmitData
	public BaseResponseEntity<List<EmailTagResponse>> queryEmailTagList(HttpServletRequest request,@RequestBody DelEmailTag req){
		BaseResponseEntity<List<EmailTagResponse>> entity = new BaseResponseEntity<>(true);
		try {
			SessionUser user = SessionUtils.getCurrentUserInfo(request);
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("companyId", user.getCompanyId());
			map.put("operatorId", user.getSwitchOperatorId());
			map.put("emailId",req.getEmailId());
			
			List<EmailTagResponse> list = this.emailManager.getEmailTagList(map);
			
			entity.setData(list);
			entity.setSuccess(true);
		} catch (Exception e) {
			logger.error("", e);
			String msg = e.getMessage();
			entity.setSuccess(false);
			entity.setErrMsg(msg);
		}
		return entity;
	}
	
	/**
	 * （设置邮件标签）加标签
	 * @param {emailId:13012,remark:[{id:1,content:'标记',color:'#3333'}]}
	 * @param request
	 * @return
	 */
	@ApiOperation(value="（设置邮件标签）加标签", notes="（设置邮件标签）加标签")
	@ApiImplicitParam(name = "req", value = "（设置邮件标签）加标签请求对象", required = true, dataType = "DelEmailTag")
	@PostMapping("/setRemark")
	@ResponseBody
	@NeedLogin
	@ResubmitData
	public BaseResponseEntity<Integer> setRemark(@RequestBody DelEmailTag req, HttpServletRequest request) {
		BaseResponseEntity<Integer> entity = new BaseResponseEntity<>(true);
		try {
			SessionUser user = SessionUtils.getCurrentUserInfo(request);
			
			JSONArray remarkArray = JSON.parseArray(req.getRemark());
			EmailWithBLOBs email = new EmailWithBLOBs();
			
			email.setCompanyId(user.getCompanyId());
			email.setId(req.getEmailId());
			
			StringBuffer tagIds =new StringBuffer();
			StringBuffer tagContents =new StringBuffer();
			if (remarkArray.size() > 0) {
				for (int i = 0; i < remarkArray.size(); i++) {
					JSONObject remark = remarkArray.getJSONObject(i);
					if (StringUtils.isNotBlank(tagIds.toString())) {
						tagIds.append(",");
					}
					tagIds.append(remark.getString("id"));

					if (StringUtils.isNotBlank(tagContents.toString())) {
						tagContents.append(",");
					}
					tagContents.append(remark.getString("content"));
				}
			}
			email.setTagId(tagIds.toString());
			email.setTagContent(tagContents.toString());
			email.setRemark(remarkArray.size()>0?remarkArray.toString():"");
			emailService.updateEmailByIdAndCompanyId(email);
			entity.setSuccess(true);
			return entity;
		} catch (Exception e) {
			
			logger.error("", e);
			entity.setSuccess(false);
			return entity;
		}
	}
	
//	/**
//	 * 清空标签
//	 * @param dto
//	 * @param request
//	 * @return
//	 */
//	@RequestMapping("/cancelRemark")
//	@ResponseBody
//	public Map<String,Object> cancelRemark(@RequestBody com.alibaba.fastjson.JSONObject json, HttpServletRequest request) {
//		try {
//			OperateDto dto = com.alibaba.fastjson.JSONObject.toJavaObject(json, OperateDto.class);
//			
//			Operator operator = this.getOperator(request.getSession());
//			dto.setCompanyId( operator.getCompanyId());
//			dto.setOperatorId(operator.getId());
//			dto.setRemark(null);
//			dto.setTagIds(null);
//			int modify = this.emailOperateService.updateRemark(dto);
//			
//			if(modify > 0){
//				return this.getSuccessResultMap(getMessage("system.operation.success", request));
//			}else {
//				return this.getErrorResultMap(getMessage("system.operation.error", request));
//			}
//		} catch (Exception e) {
//			
//			logger.error("", e);
//			return this.getErrorResultMap(e.getMessage());
//		}
//	}
	
	
	
}
