package com.joinf.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.joinf.annotations.NeedLogin;
import com.joinf.dto.CustomerTagDto;
import com.joinf.dto.CustomerTagResult;
import com.joinf.entity.SessionUser;
import com.joinf.entity.generator.CustomerTag;
import com.joinf.entity.generator.CustomerTagPersonal;
import com.joinf.interfaces.customer.CustomerTagManager;
import com.joinf.request.customer.OperateCustomerTagRequest;
import com.joinf.request.customer.QueryCustomerTagRequest;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.util.JoinfBeanUtils;
import com.joinf.utils.util.StringUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * Description: 客户标签服务
 * @author cuichuanlei
 * @created 2019年2月26日 上午9:54:34
 */
@RestController
@RequestMapping("customer")
@Api(tags="客户标签服务")
public class CustomerTagController extends BaseController{
	
	@Autowired
	private CustomerTagManager customerTagManager;
	
	/**
	 * 获取标签列表
	 * @param req
	 * @returncustomerTagListJson
	 */
	@ApiOperation(value="获取标签列表", notes="查询标签列表")
	@PostMapping("customerTagListJson")
	@NeedLogin
	public BaseResponseEntity<List<CustomerTagResult>> customerTagListJson(HttpServletRequest request, @RequestBody QueryCustomerTagRequest req){
		BaseResponseEntity<List<CustomerTagResult>> response = new BaseResponseEntity<>(true);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		Long companyId = user.getCompanyId();
		Long operatorId = user.getSwitchOperatorId();
		Long customerId = req.getCustomerId();	
		response.setData(customerTagManager.getCustomerTagList(companyId, operatorId, customerId));
		return response;
	}
	
	
	/**
	 * 新增或者修改标签
	 * @param req
	 * @return
	 */
	@ApiOperation(value="新增或者修改标签", notes="新增或者修改标签")
	@PostMapping("operateCustomerTag")
	@NeedLogin
	public BaseResponseEntity<Boolean> operateCustomerTag(HttpServletRequest request, @RequestBody OperateCustomerTagRequest req){
		BaseResponseEntity<Boolean> response = new BaseResponseEntity<>(true);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		Long companyId = user.getCompanyId();
		Long operatorId = user.getSwitchOperatorId();
		
		CustomerTag tagDto = JoinfBeanUtils.copyToNewBean(CustomerTag.class, req);
		if(tagDto.getId() == null){//表示新增
			//校验当前条数是否超过8条
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("companyId", companyId);
			param.put("operatorId", operatorId);
			param.put("flag", 1);
			int count  = customerTagManager.selectCustomerTagCountByParam(param);
			int total = 20;//总数量
			if(count >= total){
				response.setCode(-3);
				response.setData(false);
				response.setSuccess(false);
				response.setErrMsg("最多新建"+total+"条标签！");
				return response;
			}
		}
		
		Date date = new Date();
		tagDto.setCompanyId(companyId);
		tagDto.setOperatorId(operatorId);
		tagDto.setUpdateId(operatorId);
		tagDto.setUpdateTime(date);
		
		if(tagDto.getId()==null) {
			tagDto.setFlag(1);
		} 
		Map<String,Object> resultMap = customerTagManager.addOrUpdateCustomerTag(tagDto);
		Boolean success = (Boolean) resultMap.get("success");
		String msg = (String) resultMap.get("msg");
		if(!success){  //新增或者修改标签
			response.setCode(-3);
			response.setData(false);
			response.setSuccess(false);
			response.setErrMsg(msg);
			return response;
		}
		response.setData(true);
		return response;
	}
	
	/**
	 * 删除标签
	 * @param req
	 * @return
	 */
	@ApiOperation(value="删除标签", notes="删除标签")
	@PostMapping("deleteTag")
	@NeedLogin
	public BaseResponseEntity<Boolean> deleteTag(HttpServletRequest request, @RequestBody OperateCustomerTagRequest req){
		BaseResponseEntity<Boolean> response = new BaseResponseEntity<>(true);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		Long companyId = user.getCompanyId();
		Long operatorId = user.getSwitchOperatorId();
		
		CustomerTag tagDto = JoinfBeanUtils.copyToNewBean(CustomerTag.class, req);
		
		Date date = new Date();
		tagDto.setCompanyId(companyId);
		tagDto.setOperatorId(operatorId);
		tagDto.setUpdateId(operatorId);
		tagDto.setUpdateTime(date);
	
		//删除标签
		customerTagManager.delete(tagDto);
		response.setData(true);
		return response;
	}
	
	/**
	 * 加标签
	 * @param req
	 * @return
	 */
	@ApiOperation(value="加标签", notes="加标签")
	@PostMapping("setRemark")
	@NeedLogin
	public BaseResponseEntity<Boolean> setRemark(HttpServletRequest request, @RequestBody OperateCustomerTagRequest req){
		BaseResponseEntity<Boolean> response = new BaseResponseEntity<>(true);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		Long companyId = user.getCompanyId();
		Long operatorId = user.getSwitchOperatorId();
		if(req.getCustomerId() == null || req.getTagList() == null){
			response.setCode(-3);
			response.setData(false);
			response.setSuccess(false);
			response.setErrMsg("缺少参数");
			return response;
		}
		
		String customerId = req.getCustomerId();
		List<Long> customerIdList = StringUtil.toListLong(customerId);
		List<CustomerTagDto> tagList = req.getTagList();
		
		//加标签
		Map<String,Object> resultMap = customerTagManager.setRemarkBatch(customerIdList, tagList, companyId, operatorId);
		Boolean success = (Boolean) resultMap.get("success");
		String msg = (String) resultMap.get("msg");
		if(!success){  //添加标签失败
			response.setCode(-3);
			response.setData(false);
			response.setSuccess(false);
			response.setErrMsg(msg);
			return response;
		}
		response.setData(true);
		return response;
	}
	
	/**
	 * 获取客户标签
	 * @param req
	 * @return
	 */
	@ApiOperation(value="获取客户标签", notes="获取客户标签")
	@PostMapping("getCustomerTagPersonalList")
	@NeedLogin
	public BaseResponseEntity<List<CustomerTagPersonal>> getCustomerTagPersonalList(HttpServletRequest request, @RequestBody QueryCustomerTagRequest req){
		BaseResponseEntity<List<CustomerTagPersonal>> response = new BaseResponseEntity<>(true);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		Long companyId = user.getCompanyId();
		Long operatorId = user.getSwitchOperatorId();
		if(req.getCustomerId() == null){
			response.setCode(-3);
			response.setSuccess(false);
			response.setErrMsg("缺少参数");
			return response;
		}
		Long customerId = req.getCustomerId();	
		Map<String, Object> tagPersonalParam = new HashMap<String, Object>();
		tagPersonalParam.put("companyId", companyId);
		tagPersonalParam.put("operatorId", operatorId);
		tagPersonalParam.put("customerId", customerId);
		
		response.setData(customerTagManager.selectCustomerTagPersonalByParam(tagPersonalParam));
		return response;
	}

}
