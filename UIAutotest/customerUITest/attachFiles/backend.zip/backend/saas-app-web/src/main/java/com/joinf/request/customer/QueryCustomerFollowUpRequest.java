package com.joinf.request.customer;

import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

/**
 * Description: 查询跟进信息
 *
 * @author lyj
 * @date 2018年1月5日 下午5:54:47
 */
public class QueryCustomerFollowUpRequest {
	
	@ApiModelProperty(value="查询哪天",required=true)
	private Date date;

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

}
