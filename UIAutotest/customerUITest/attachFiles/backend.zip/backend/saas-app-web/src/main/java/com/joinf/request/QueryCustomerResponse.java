package com.joinf.request;

import com.joinf.entity.generator.CustomerWithBLOBs;


/**
 * @author lyj
 * @Description: 客户对象返回实例
 * @data 2017年12月4日 下午2:38:42
 */
public class QueryCustomerResponse extends CustomerWithBLOBs {

	/**
	 * 
	 */
	private static final long serialVersionUID = -865585949216784237L;

}
