package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 修改头像参数
 *
 * @author lyj
 * @date 2017年12月22日 下午2:03:56
 */
public class UpdateOperatorInfoRequest {
	
	@ApiModelProperty(value="新头像(修改可以不用传)",required=false)
	private String head;

	@ApiModelProperty(value="新邮箱(修改可以不用传)",required=false)
	private String email;
	
	@ApiModelProperty(value="新手机(修改可以不用传)",required=false)
	private String mobile;

	public String getHead() {
		return head;
	}

	public void setHead(String head) {
		this.head = head;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}


}
