package com.joinf.response.email;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 邮件往来邮箱Response
 * @date 2018年1月29日 上午11:26:33
 */
public class QueryEmailContactMailboxResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2105085247053982301L;
	
	@ApiModelProperty(value = "联系人名称")
	private String name;
	@ApiModelProperty(value = "联系人邮箱")
	private String email;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	

}
