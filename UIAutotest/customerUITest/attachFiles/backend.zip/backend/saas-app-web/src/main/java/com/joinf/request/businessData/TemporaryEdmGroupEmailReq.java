package com.joinf.request.businessData;

import java.util.List;

/**
 * Description: 临时邮箱发送参数
 * @author cuichuanlei
 * @created 2019年2月20日 上午10:55:41
 */
public class TemporaryEdmGroupEmailReq {
	
	/**公司名称*/
	private String companyName;
	/**邮箱列表*/
	private List<String> emailList;
	/**商业数据bvdid*/
	private String sourceId;
	private Integer userId;
	private Integer companyId;
	/**不是用户中心的公司id*/
	private Long notCenterCompanyId;
	/**操作人id*/
	private Long operatorId;
	
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public List<String> getEmailList() {
		return emailList;
	}
	public void setEmailList(List<String> emailList) {
		this.emailList = emailList;
	}
	public String getSourceId() {
		return sourceId;
	}
	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public Integer getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}
	public Long getNotCenterCompanyId() {
		return notCenterCompanyId;
	}
	public void setNotCenterCompanyId(Long notCenterCompanyId) {
		this.notCenterCompanyId = notCenterCompanyId;
	}
	public Long getOperatorId() {
		return operatorId;
	}
	public void setOperatorId(Long operatorId) {
		this.operatorId = operatorId;
	}

}
