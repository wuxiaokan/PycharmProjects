package com.joinf.request.businessData;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 查询国家/行业请求参数
 * @author cuichuanlei
 * @created 2019年1月11日 下午4:26:17
 */
public class CountryRequest {
	
	@ApiModelProperty("关键词")
	private String keywords;
	
	@ApiModelProperty("第几页")
	private Integer pageNum;
	
	@ApiModelProperty("页大小")
	private Integer pageSize;

	public String getKeywords() {
		return keywords;
	}

	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}

	public Integer getPageNum() {
		return pageNum;
	}

	public void setPageNum(Integer pageNum) {
		this.pageNum = pageNum;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	

}
