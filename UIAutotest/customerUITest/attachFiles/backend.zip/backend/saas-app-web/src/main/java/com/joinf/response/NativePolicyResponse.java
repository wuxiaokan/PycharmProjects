package com.joinf.response;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 获取原生文件上传签名
 *
 * @author lyj
 * @date 2017年12月29日 下午4:38:06
 */
public class NativePolicyResponse {

	@ApiModelProperty(value="id加密",required=true)
	private String accessKeyId;
	
	@ApiModelProperty(value="秘钥加密",required=true)
	private String accessKeySecret;
	
	@ApiModelProperty(value="token",required=true)
	private String securityToken;
	
	@ApiModelProperty(value="过期时间加密",required=true)
	private String expiration;
	
	@ApiModelProperty(value="签名",required=true)
	private String sign;
	
	@ApiModelProperty(value="bucket名称",required=true)
	private String bucketName;
	
	@ApiModelProperty(value="访问路径",required=true)
	private String endPonit;

	public String getAccessKeyId() {
		return accessKeyId;
	}

	public void setAccessKeyId(String accessKeyId) {
		this.accessKeyId = accessKeyId;
	}

	public String getAccessKeySecret() {
		return accessKeySecret;
	}

	public void setAccessKeySecret(String accessKeySecret) {
		this.accessKeySecret = accessKeySecret;
	}

	public String getSecurityToken() {
		return securityToken;
	}

	public void setSecurityToken(String securityToken) {
		this.securityToken = securityToken;
	}

	public String getExpiration() {
		return expiration;
	}

	public void setExpiration(String expiration) {
		this.expiration = expiration;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getBucketName() {
		return bucketName;
	}

	public void setBucketName(String bucketName) {
		this.bucketName = bucketName;
	}

	public String getEndPonit() {
		return endPonit;
	}

	public void setEndPonit(String endPonit) {
		this.endPonit = endPonit;
	}
}
