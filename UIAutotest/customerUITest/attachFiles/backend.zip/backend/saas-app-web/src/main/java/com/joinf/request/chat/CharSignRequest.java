package com.joinf.request.chat;

import io.swagger.annotations.ApiModelProperty;

public class CharSignRequest {
	
	@ApiModelProperty("")
	private String cb;
	
	@ApiModelProperty("用户id")
	private String userId;

	public String getCb() {
		return cb;
	}

	public void setCb(String cb) {
		this.cb = cb;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}
