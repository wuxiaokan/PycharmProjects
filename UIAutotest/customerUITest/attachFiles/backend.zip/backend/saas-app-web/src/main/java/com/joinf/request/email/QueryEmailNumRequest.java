package com.joinf.request.email;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 查询箱子下邮件数量参数
 * @date 2018年1月5日 下午5:21:20
 */
public class QueryEmailNumRequest implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2596363725471279783L;

	@ApiModelProperty(value = "箱子id数组")
	private Long[] boxIdArray;

	public Long[] getBoxIdArray() {
		return boxIdArray;
	}

	public void setBoxIdArray(Long[] boxIdArray) {
		this.boxIdArray = boxIdArray;
	}

	
	
	

}
