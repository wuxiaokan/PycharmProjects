package com.joinf.request.email;

import java.io.Serializable;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 新增邮件附件参数
 * @date 2018年1月25日 下午3:20:35
 */
public class SaveEmailAttachmentRequest implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value ="邮件附件集合")
	private List<EmailAttachmentRequest> list;

	public List<EmailAttachmentRequest> getList() {
		return list;
	}

	public void setList(List<EmailAttachmentRequest> list) {
		this.list = list;
	}
	
	
    
}
