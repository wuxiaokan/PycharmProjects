package com.joinf.response.newYear;

import java.io.Serializable;
import com.joinf.entity.generator.Company;
import com.joinf.entity.generator.Operator;

/**
 * Description: 登录验证后返回结果
 * @author cuichuanlei
 * @created 2019年1月22日 下午2:41:20
 */
public class LoginInfoResponse implements Serializable{
	
	/**  描述   (@author: cuichuanlei) */
	private static final long serialVersionUID = 4604130661875010242L;
	
	/** 公司ID */
	private Company company;
	/** 操作人ID */
	private Operator operator;
	/** 性别 */
	private String sex;
	
	public Company getCompany() {
		return company;
	}
	public void setCompany(Company company) {
		this.company = company;
	}
	public Operator getOperator() {
		return operator;
	}
	public void setOperator(Operator operator) {
		this.operator = operator;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}

}
