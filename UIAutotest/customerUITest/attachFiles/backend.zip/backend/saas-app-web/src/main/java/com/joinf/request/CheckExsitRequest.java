package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 校验是否存在参数
 *
 * @author lyj
 * @date 2017年12月21日 下午4:10:49
 */
public class CheckExsitRequest {
	
	@ApiModelProperty(value="类型(1=手机,2=邮箱,3=登录名,4邀请码)",required=true)
	private Integer type;

	@ApiModelProperty(value="提供校验值",required=true)
	private String checkValue;
	
	@ApiModelProperty(value="排除自己:0否,1是",required=true)
	private Integer excludeSelf = 0;

	public Integer getExcludeSelf() {
		return excludeSelf;
	}

	public void setExcludeSelf(Integer excludeSelf) {
		this.excludeSelf = excludeSelf;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getCheckValue() {
		return checkValue;
	}

	public void setCheckValue(String checkValue) {
		this.checkValue = checkValue;
	}
}
