package com.joinf.request.customer;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 扫描客户名片
 *
 * @author lyj
 * @date 2018年1月2日 上午11:36:01
 */
public class ScanCardRequset {

	@ApiModelProperty(value="文件名",required=true)
	String fileName;
	@ApiModelProperty(value="ossKey",required=true)
	String key;
	
	@ApiModelProperty(value="1=客户,2=供应商",required=true)
	private Integer type = 1;
	
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
}
