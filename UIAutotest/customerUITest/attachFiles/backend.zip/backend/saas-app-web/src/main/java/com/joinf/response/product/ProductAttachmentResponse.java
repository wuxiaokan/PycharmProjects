package com.joinf.response.product;

import io.swagger.annotations.ApiModelProperty;

public class ProductAttachmentResponse {
	
	@ApiModelProperty("id")
	private Long id;
	
	@ApiModelProperty("名称")
	private String name;
	
	@ApiModelProperty("图片")
	private String url;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}
