package com.joinf.response.email;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.joinf.helper.LongJsonDeserializer;
import com.joinf.helper.LongJsonSerializer;

import io.swagger.annotations.ApiModelProperty;


/**
 * Description: 邮件查询返回列表
 *
 * @author zlx
 * @date 2018年1月4日 下午5:42:34
 */
public class QueryEmailResponse implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2105085247053982301L;
	
	@JsonSerialize(using = LongJsonSerializer.class)
	@JsonDeserialize(using = LongJsonDeserializer.class)
	@ApiModelProperty(value = "邮件标识")
    private Long id;
	@ApiModelProperty(value = "邮件主题")
    private String subject = "无主题";
	@ApiModelProperty(value = "是否紧急")
    private boolean urgent = false;
	@ApiModelProperty(value = "状态  详见邮件状态枚举 ")
    private Integer status;
	@ApiModelProperty(value = "箱子id 详见箱子枚举")
    private Long boxId;
	@ApiModelProperty(value = "邮件发送/接收时间")
    private Date sentDate;
	@ApiModelProperty(value = "是否已读")
    private boolean hasRead = false;
	@ApiModelProperty(value = "是否包含附件")
    private boolean containAttachment = false;
	@ApiModelProperty(value = "发件人/收件人  多个逗号分隔")
    private String mailbox = "";
	@ApiModelProperty(value = "发件人")
	private String fromMail;
	@ApiModelProperty(value = "收件人")
	private String recipients;
	@ApiModelProperty(value = "是否回复")
    private boolean isReply = false;
	@ApiModelProperty(value = "是否转发")
    private boolean isFw = false;
	@ApiModelProperty(value = "是否内部转发")
    private boolean isFwIn = false;
	@ApiModelProperty(value = "是否定时邮件")
    private boolean isTimingSent = false;
	@ApiModelProperty(value = "是否免回复")
    private boolean avoidReply = false;
	@ApiModelProperty(value = "是否标星")
	private boolean isAsterisk = false;
	@ApiModelProperty(value = "追踪类型  0[不需要追踪] 1[需要追踪] 2[已有追踪记录]")
    private int isTrace;
	@ApiModelProperty(value ="回执状态:0/不需要回执;1/需要回执;2/已回执;3/不回执")
	private int receipt;
	@ApiModelProperty(value ="[0]:收信 [1]:发信 [2]:导入")
    private int emailType;
	@ApiModelProperty(value ="设置邮件发送时间")
	private Date sendTime;
	@ApiModelProperty(value = "联系人类型  0[新客户 ] 1[老客户] 2[内部联系人] 3[供应商]")
    private int contactType = 0;
	@ApiModelProperty(value = "正文预览")
    private String contentView = "";
	
	@ApiModelProperty(value = "是否进入编辑页")
	private boolean canEdit;
	
	@ApiModelProperty(value = "标记")
	private String remark;
	
	 @ApiModelProperty(value = "标记id")
	private String tagId;
	 
	@ApiModelProperty(value = "客户id(第一个客户)")
	private Long customerId;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public boolean isUrgent() {
		return urgent;
	}
	public void setUrgent(boolean urgent) {
		this.urgent = urgent;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Long getBoxId() {
		return boxId;
	}
	public void setBoxId(Long boxId) {
		this.boxId = boxId;
	}
	public Date getSentDate() {
		return sentDate;
	}
	public void setSentDate(Date sentDate) {
		this.sentDate = sentDate;
	}
	public boolean isHasRead() {
		return hasRead;
	}
	public void setHasRead(boolean hasRead) {
		this.hasRead = hasRead;
	}
	public boolean isContainAttachment() {
		return containAttachment;
	}
	public void setContainAttachment(boolean containAttachment) {
		this.containAttachment = containAttachment;
	}
	public String getMailbox() {
		return mailbox;
	}
	public void setMailbox(String mailbox) {
		this.mailbox = mailbox;
	}
	public boolean getIsReply() {
		return isReply;
	}
	public void setIsReply(boolean isReply) {
		this.isReply = isReply;
	}
	public boolean getIsFw() {
		return isFw;
	}
	public void setIsFw(boolean isFw) {
		this.isFw = isFw;
	}
	public boolean getIsFwIn() {
		return isFwIn;
	}
	public void setIsFwIn(boolean isFwIn) {
		this.isFwIn = isFwIn;
	}
	public boolean getIsTimingSent() {
		return isTimingSent;
	}
	public void setIsTimingSent(boolean isTimingSent) {
		this.isTimingSent = isTimingSent;
	}
	public boolean getAvoidReply() {
		return avoidReply;
	}
	public void setAvoidReply(boolean avoidReply) {
		this.avoidReply = avoidReply;
	}
	public int getIsTrace() {
		return isTrace;
	}
	public void setIsTrace(int isTrace) {
		this.isTrace = isTrace;
	}
	public int getContactType() {
		return contactType;
	}
	public void setContactType(int contactType) {
		this.contactType = contactType;
	}
	public String getContentView() {
		return contentView;
	}
	public void setContentView(String contentView) {
		this.contentView = contentView;
	}
	public boolean getIsAsterisk() {
		return isAsterisk;
	}
	public void setIsAsterisk(boolean isAsterisk) {
		this.isAsterisk = isAsterisk;
	}
	public int getReceipt() {
		return receipt;
	}
	public void setReceipt(int receipt) {
		this.receipt = receipt;
	}
	public Date getSendTime() {
		return sendTime;
	}
	public void setSendTime(Date sendTime) {
		this.sendTime = sendTime;
	}
	public String getFromMail() {
		return fromMail;
	}
	public void setFromMail(String fromMail) {
		this.fromMail = fromMail;
	}
	public String getRecipients() {
		return recipients;
	}
	public void setRecipients(String recipients) {
		this.recipients = recipients;
	}
	public boolean isCanEdit() {
		return canEdit;
	}
	public void setCanEdit(boolean canEdit) {
		this.canEdit = canEdit;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getTagId() {
		return tagId;
	}
	public void setTagId(String tagId) {
		this.tagId = tagId;
	}
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	
	
	
	
	
	
}
