package com.joinf.interceptor.login;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONObject;
import com.joinf.constant.login.LoginContant;
import com.joinf.constant.login.LoginRedirect;
import com.joinf.dto.CheckSuccessDto;
import com.joinf.dto.CompanyDTO;
import com.joinf.dto.LoginDto;
import com.joinf.dto.OperatorDTO;
import com.joinf.exception.LoginFailException;
import com.joinf.interfaces.UserCenterService;
import com.joinf.interfaces.UserOrderService;
import com.joinf.response.UserCenterResponse;
import com.joinf.utils.util.JoinfBeanUtils;

/**
 * Description: 校验用户名和密码
 *
 * @author lyj
 * @date 2017年12月15日 下午7:52:39
 */
public class CheckUsernameAndPasswordInterceptor implements HandlerInterceptor {
	
	@Autowired
	private UserCenterService userCenterService;
	
	@Autowired
	private UserOrderService userOrderService;
	
	private static Logger logger = LoggerFactory.getLogger(CheckUsernameAndPasswordInterceptor.class);
	
	/**
	 * 获取登入请求参数
	 * @param request
	 * @return
	 * @throws IOException
	 */
	private LoginDto getLoginParams(HttpServletRequest request) throws IOException{
		MultiReadHttpServletRequestWrapper myRequestWrapper = new MultiReadHttpServletRequestWrapper((HttpServletRequest) request);
		LoginDto dto = new LoginDto();
		dto =JSONObject.toJavaObject(JSONObject.parseObject(myRequestWrapper.getBody()), LoginDto.class);
		return dto;
	}
	
	/**
	 * 校验用户名密码
	 */
	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		// TODO Auto-generated method stub
		request.getSession().invalidate();
		CheckSuccessDto centerUserMessage = new CheckSuccessDto();
        LoginDto dto = this.getLoginParams(request);
        logger.info("开始校验用户名和密码");
        if(StringUtils.isBlank(dto.getPassword())&& StringUtils.isBlank(dto.getUsername())){
        	JoinfBeanUtils.copyProperties(centerUserMessage, dto);
        }else{
        	UserCenterResponse<CheckSuccessDto> checkResponse = userCenterService.checkUsernameAndPassword(dto.getUsername(), dto.getPassword());
        	centerUserMessage = checkResponse.getResponseData();
        	if(!checkResponse.isSuccess()){
        		throw new LoginFailException("账号或登录密码错误");
        	}
        }
        logger.info("用户名和密码正确");
        HttpSession session = request.getSession();
        session.setAttribute(LoginContant.CENTER_USER_MESSAGE, JSONObject.toJSONString(centerUserMessage));
        boolean isTwoCheck = userOrderService.isCompanyTwoCheck(centerUserMessage.getCompanyId());
        if (isTwoCheck) {//二次验证
        	request.getSession().setAttribute(LoginContant.REDIRECT_URL, LoginRedirect.TwoCheck.getPath());
        	//获取用户中心企业信息
    		logger.info("获取用户中心企业信息");
    		CompanyDTO companyDTO = userCenterService.getCompanyCompletedInfo(centerUserMessage.getCompanyId(), null, null).getResponseData();
    		//获取用户中心用户信息
    		logger.info("获取用户中心用户信息");
    		OperatorDTO operatorDTO = userCenterService.getOperatorInfo(centerUserMessage.getUserId()).getResponseData();
    		if(companyDTO == null||operatorDTO==null){
    			throw new LoginFailException("账号无效");
    		}
    		session.setAttribute(LoginContant.CENTER_OPERATOR_INFO,JSONObject.toJSONString(operatorDTO));
    		session.setAttribute(LoginContant.CENTER_COMPANY_INFO, JSONObject.toJSONString(companyDTO));
			throw new LoginFailException("二次验证");
        }
        //保存用户信息
		return true;
	}

	/**
	 * 实现方法
	 */
	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub

	}

	/**
	 * 实现方法
	 */
	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub

	}
}
