package com.joinf.response.email;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 新增或修改邮箱账号返回对象
 * @date 2018年1月8日 上午10:55:48
 */
public class EmailAccountSaveResponse extends CheckEmailAccountResponse{
	@ApiModelProperty(value = "数据id")
	private Long id;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
}
