package com.joinf.response.newYear;

import java.util.List;
import com.joinf.dto.NewYearUserFacesDto;
import com.joinf.entity.generator.NewYearContinentCountry;
import com.joinf.entity.generator.NewYearEdmCount;
import com.joinf.entity.generator.NewYearEmailCount;
import com.joinf.entity.generator.NewYearLoginCount;
import com.joinf.entity.generator.NewYearMyTrajectory;
import com.joinf.entity.generator.NewYearQuoteOrder;
import com.joinf.entity.generator.StPiwikData;

/**
 * Description: 新年账单请求结果返回
 * @author cuichuanlei
 * @created 2019年1月21日 下午4:11:16
 */
public class NewYearStatisticResponse {
	
	/**不同时段的登陆次数*/
	private NewYearLoginCount newYearLoginCount;
	/**不同时段的第一次*/
	private List<NewYearMyTrajectory> newYearMyTrajectory;
	/**客户新增等信息*/
	private NewYearContinentCountry newYearContinentCountry;
	/**收信、发信等邮件统计信息*/
	private NewYearEmailCount newYearEmailCount;
	/**营销信收发统计信息*/
	private NewYearEdmCount newYearEdmCount;
	/**用户画像*/
	private NewYearUserFacesDto newYearUserFace;
	/**订单报价相关信息*/
	private NewYearQuoteOrder newYearQuoteOrder;
	/**营销网站统计 */
	private StPiwikData stPiwikData;
	
	public NewYearLoginCount getNewYearLoginCount() {
		return newYearLoginCount;
	}
	public void setNewYearLoginCount(NewYearLoginCount newYearLoginCount) {
		this.newYearLoginCount = newYearLoginCount;
	}
	public List<NewYearMyTrajectory> getNewYearMyTrajectory() {
		return newYearMyTrajectory;
	}
	public void setNewYearMyTrajectory(List<NewYearMyTrajectory> newYearMyTrajectory) {
		this.newYearMyTrajectory = newYearMyTrajectory;
	}
	public NewYearContinentCountry getNewYearContinentCountry() {
		return newYearContinentCountry;
	}
	public void setNewYearContinentCountry(NewYearContinentCountry newYearContinentCountry) {
		this.newYearContinentCountry = newYearContinentCountry;
	}
	public NewYearEmailCount getNewYearEmailCount() {
		return newYearEmailCount;
	}
	public void setNewYearEmailCount(NewYearEmailCount newYearEmailCount) {
		this.newYearEmailCount = newYearEmailCount;
	}
	public NewYearEdmCount getNewYearEdmCount() {
		return newYearEdmCount;
	}
	public void setNewYearEdmCount(NewYearEdmCount newYearEdmCount) {
		this.newYearEdmCount = newYearEdmCount;
	}
	public NewYearUserFacesDto getNewYearUserFace() {
		return newYearUserFace;
	}
	public void setNewYearUserFace(NewYearUserFacesDto newYearUserFace) {
		this.newYearUserFace = newYearUserFace;
	}
	public NewYearQuoteOrder getNewYearQuoteOrder() {
		return newYearQuoteOrder;
	}
	public void setNewYearQuoteOrder(NewYearQuoteOrder newYearQuoteOrder) {
		this.newYearQuoteOrder = newYearQuoteOrder;
	}
	public StPiwikData getStPiwikData() {
		return stPiwikData;
	}
	public void setStPiwikData(StPiwikData stPiwikData) {
		this.stPiwikData = stPiwikData;
	}
	

}
