package com.joinf.request.chat;

import com.joinf.request.AuthReq;

import io.swagger.annotations.ApiModelProperty;

public class ChatRemindRequest extends AuthReq{

	@ApiModelProperty("用户id")
	private Long userId;
	
	@ApiModelProperty("站点id")
	private String siteId;
	
	@ApiModelProperty("站点名称")
	private String siteName;
	
	@ApiModelProperty("访客名称")
	private String visitorName;
	
	@ApiModelProperty("访客邮箱")
	private String visitorEmail;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public String getSiteName() {
		return siteName;
	}

	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	public String getVisitorName() {
		return visitorName;
	}

	public void setVisitorName(String visitorName) {
		this.visitorName = visitorName;
	}

	public String getVisitorEmail() {
		return visitorEmail;
	}

	public void setVisitorEmail(String visitorEmail) {
		this.visitorEmail = visitorEmail;
	}
}
