package com.joinf.request.customer;

import io.swagger.annotations.ApiModelProperty;

import java.util.Date;
import java.util.List;

/**
 * Description: 客户新增请求对象
 *
 * @author lyj
 * @date 2018年1月5日 下午2:39:26
 */
public class UpdateCustomerFollowUpRequest {
	
	@ApiModelProperty(value="当前跟进id",required=true)
	private Long id;
	
	@ApiModelProperty(value="联系人id",required=true)
	private Long contactId;
	
	@ApiModelProperty(value="跟进内容",required=true)
	private String contactContent;
	
	@ApiModelProperty(value="背景颜色",required=true)
	private String bgColor;
	
	@ApiModelProperty(value="跟进类型:customer,quote,order,email",required=true)
	private String followType;
	
	@ApiModelProperty(value="计划跟进时间",required=true)
	private Date planningTime;

	@ApiModelProperty(value="是否批量更新（1是0否）",required=true)
	private Integer updateBatch=0;
	
	@ApiModelProperty(value="跟进阶段",required=true)
	private Long flowStep;
	
	@ApiModelProperty(value="跟进方式",required=true)
	private Long flowMethod;
	
	@ApiModelProperty(value="附件ID集合",required=true)
	private List<Long> attachmentIdList;
	
	@ApiModelProperty(value="跟进归属模块 0/客户跟进 1/供应商跟进",required=true)
	private Long flowModel;
	
	@ApiModelProperty(value ="跟进周期ID")
    private Long cycleId;
	
	@ApiModelProperty(value ="跟进周期")
	private String repeatCycle;

	@ApiModelProperty(value ="跟进开始时间")
	private Date cycleEndDay;
	
	@ApiModelProperty(value ="跟进结束时间")
	private Date cycleStartDay;
	
	
	
	public Long getFlowStep() {
		return flowStep;
	}

	public void setFlowStep(Long flowStep) {
		this.flowStep = flowStep;
	}

	public Integer getUpdateBatch() {
		return updateBatch;
	}

	public void setUpdateBatch(Integer updateBatch) {
		this.updateBatch = updateBatch;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getContactId() {
		return contactId;
	}

	public void setContactId(Long contactId) {
		this.contactId = contactId;
	}

	public String getContactContent() {
		return contactContent;
	}

	public void setContactContent(String contactContent) {
		this.contactContent = contactContent;
	}

	public String getBgColor() {
		return bgColor;
	}

	public void setBgColor(String bgColor) {
		this.bgColor = bgColor;
	}

	public String getFollowType() {
		return followType;
	}

	public void setFollowType(String followType) {
		this.followType = followType;
	}

	public Date getPlanningTime() {
		return planningTime;
	}

	public void setPlanningTime(Date planningTime) {
		this.planningTime = planningTime;
	}

	public List<Long> getAttachmentIdList() {
		return attachmentIdList;
	}

	public void setAttachmentIdList(List<Long> attachmentIdList) {
		this.attachmentIdList = attachmentIdList;
	}

	public Long getFlowMethod() {
		return flowMethod;
	}

	public void setFlowMethod(Long flowMethod) {
		this.flowMethod = flowMethod;
	}

	public Long getFlowModel() {
		return flowModel;
	}

	public void setFlowModel(Long flowModel) {
		this.flowModel = flowModel;
	}

	public Long getCycleId() {
		return cycleId;
	}

	public void setCycleId(Long cycleId) {
		this.cycleId = cycleId;
	}

	public String getRepeatCycle() {
		return repeatCycle;
	}

	public void setRepeatCycle(String repeatCycle) {
		this.repeatCycle = repeatCycle;
	}

	public Date getCycleEndDay() {
		return cycleEndDay;
	}

	public void setCycleEndDay(Date cycleEndDay) {
		this.cycleEndDay = cycleEndDay;
	}

	public Date getCycleStartDay() {
		return cycleStartDay;
	}

	public void setCycleStartDay(Date cycleStartDay) {
		this.cycleStartDay = cycleStartDay;
	}
	

}
