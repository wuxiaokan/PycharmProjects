package com.joinf.request.chat;

import io.swagger.annotations.ApiModelProperty;

public class SendMessageRequest extends GetCurrentUserMessageRquest{
	
	@ApiModelProperty("发送的消息")
	private String message;
	
	@ApiModelProperty("用户id")
	private String userId;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
