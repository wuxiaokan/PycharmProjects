package com.joinf.request.supplier;

import com.joinf.utils.base.BasePage;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 根据供应商查询联系人
 *
 * @author lyj
 * @date 2017年12月11日 下午4:23:12
 */
public class QuerySupplierConcactRequest extends BasePage {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4863273331389720786L;
	
	@ApiModelProperty(value="供应商id",required=true)
	private Long supplierId;

	public Long getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(Long supplierId) {
		this.supplierId = supplierId;
	}

}
