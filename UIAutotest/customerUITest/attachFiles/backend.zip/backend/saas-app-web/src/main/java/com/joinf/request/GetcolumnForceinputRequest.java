package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

public class GetcolumnForceinputRequest {
	
	@ApiModelProperty("表名：customer-客户,customerContact-客户联系人等")
	private String tableName;
	
	@ApiModelProperty("条件:客户-客户类别id")
	private String moduleId;

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getModuleId() {
		return moduleId;
	}

	public void setModuleId(String moduleId) {
		this.moduleId = moduleId;
	}

}
