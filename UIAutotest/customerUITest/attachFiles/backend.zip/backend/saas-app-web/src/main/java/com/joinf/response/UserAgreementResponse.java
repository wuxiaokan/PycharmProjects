package com.joinf.response;

import io.swagger.annotations.ApiModelProperty;


/**
 * Description: 用户协议
 *
 * @author lyj
 * @date 2018年1月19日 下午2:45:34
 */
public class UserAgreementResponse {
	
	@ApiModelProperty("用户协议")
	private String agreement;
	
	@ApiModelProperty("隐私协议")
	private String privacy;

	public String getAgreement() {
		return agreement;
	}

	public void setAgreement(String agreement) {
		this.agreement = agreement;
	}

	public String getPrivacy() {
		return privacy;
	}

	public void setPrivacy(String privacy) {
		this.privacy = privacy;
	}
	

}
