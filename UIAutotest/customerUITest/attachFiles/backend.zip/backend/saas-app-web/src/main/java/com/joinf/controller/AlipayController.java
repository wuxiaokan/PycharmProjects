package com.joinf.controller;

import java.io.IOException;
import java.net.MalformedURLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.dom4j.DocumentException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alipay.api.AlipayApiException;
import com.joinf.annotations.NeedLogin;
import com.joinf.exception.CommonException;
import com.joinf.request.IdRequest;
import com.joinf.service.AlipayService;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.base.BaseResponseEntity;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;


@RestController
@RequestMapping("alipay")
@Api(tags="支付")
public class AlipayController {
	
	@Autowired
	private AlipayService alipayService;

	@ApiOperation(value="获取支付订单信息", notes="获取支付订单信息")
	@ApiImplicitParam(name = "req", value = "获取支付订单信息请求对象", required = true, dataType = "IdRequest")
	@PostMapping("getOrderInfo")
	@NeedLogin
	public BaseResponseEntity<String> checkCapthca(HttpServletRequest request,HttpServletResponse response,@RequestBody IdRequest req) throws MalformedURLException, DocumentException, IOException{
		Long companyId = SessionUtils.getCenterCompanyInfo(request).getCompanyId();
		BaseResponseEntity<String> entity= new BaseResponseEntity<>();
		String url = null;
		try {
			url = alipayService.getOrderInfo(req.getId(), companyId);
		} catch (AlipayApiException e) {
			throw new CommonException("获取信息失败!");
		}
		entity.setData(url);
		entity.setSuccess(true);
		return entity;
	}
}
