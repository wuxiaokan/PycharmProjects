package com.joinf.controller.api;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.joinf.annotations.NeedLogin;
import com.joinf.dto.CustomerContactDto;
import com.joinf.dto.PushJGMessageDto;
import com.joinf.dto.QueryCustomerContactByEmailParam;
import com.joinf.entity.generator.Operator;
import com.joinf.interfaces.CustomerContactService;
import com.joinf.interfaces.CustomerService;
import com.joinf.interfaces.OperatorService;
import com.joinf.request.chat.CharSignRequest;
import com.joinf.request.chat.ChatRemindRequest;
import com.joinf.service.ChatService;
import com.joinf.utils.Jpush;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.util.ObjectUtil;
import com.joinf.utils.util.SignUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("api/chat")
@Api(tags="对外接口")
public class ChatRemindController {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());
	
	@Autowired
	private OperatorService operatorService;
	
	@Autowired
	private CustomerContactService customerContactService;
	
	@Autowired
	private CustomerService customerService;

	@Value("${jiguang.appKey}")
	private String jiguangAppKey;
	@Value("${jiguang.masterSecret}")
	private String jiguangMasterSecret;
	
	@Autowired
	private ChatService chatService;

	@ApiOperation(value="消息提醒", notes="消息提醒")
	@PostMapping("remind")
	@ResponseBody
	public BaseResponseEntity<Boolean> remind(HttpServletRequest request,@RequestBody ChatRemindRequest req){
		BaseResponseEntity<Boolean> response = new BaseResponseEntity<>(true);
		response.setData(true);
		Map<String, String> params = ObjectUtil.objToMap(req);
		// 验证签名
		boolean verifySuccess = SignUtils.verifySign(params,req.getSign(),req.getSignType());
		if (!verifySuccess) {
			response.setErrMsg("签名错误");
			return response;
		}
		PushJGMessageDto dto = new PushJGMessageDto();
		Operator operator = operatorService.selectByCenterUserId(req.getUserId());
		if(operator != null && StringUtils.isNotBlank(operator.getDeviceId())) {
			String receiveId = operator.getDeviceId();
			dto.setTitle("营销网站");
			dto.setReceiveId(receiveId);
			String content = "您收到了访客("+req.getVisitorEmail()+")发来的信息";
			QueryCustomerContactByEmailParam param = new QueryCustomerContactByEmailParam();
			param.setCompanyId(operator.getCompanyId());
			param.setEmail(req.getVisitorEmail());
			CustomerContactDto contact = customerContactService.selectCustomerContactByEmail(param);
			if(contact != null) {
				String name = customerService.queryByKey(contact.getCustomerId()).getName();
//				Long companyId = companyService.selectByPrimaryKey(operator.getCompanyId()).getCenterCompanyId();
//				UserCenterResponse<CompanyDTO> companyDto = userCenterService.getCompanyCompletedInfo(companyId, null, null);
				content = "您收到了客户"+contact.getName()+"("+name+")发来的信息";
			}
			dto.setContent(content);
			Jpush.sendMessage(jiguangAppKey, jiguangMasterSecret, dto);
		}
		logger.info("chatremind：--{}--{}",JSONObject.toJSON(req),JSONObject.toJSONString(dto));
		return response;
		
	}
	
	@ApiOperation(value="发送聊天前调用", notes="发送聊天前调用")
	@PostMapping("sign")
	@ResponseBody
	@NeedLogin
	public BaseResponseEntity<?> sign(HttpServletRequest request,@RequestBody CharSignRequest req){
		BaseResponseEntity<Integer> response = new BaseResponseEntity<>(true);
//		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		chatService.sign(req.getCb(), req.getUserId());
		return response;
		
	}
	
	public static JSONObject getPostParam(Object obj){
		Date d = new Date();
		SimpleDateFormat sp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dataStr = sp.format(d);
		Map<String, String> paramMap = ObjectUtil.objToMap(obj);
		paramMap.put("timestamp", dataStr);
		String sign = SignUtils.sign(paramMap, SignUtils.SIGN_TYPE_AES);

		paramMap.put("signType", SignUtils.SIGN_TYPE_AES);
		paramMap.put("sign", sign);
		
		String jsonStr = JSONObject.toJSONString(paramMap);
		JSONObject resultJson = JSONObject.parseObject(jsonStr);
		return resultJson;
	}
	
	public static void main(String[] args) {
		ChatRemindRequest req = new ChatRemindRequest();
		req.setSiteId("test");
		req.setSiteName("1212");
		req.setUserId(129064l);
		req.setVisitorEmail("healthyzxc@163.com");
		req.setVisitorName("aaaaaaaa");
		System.out.println(getPostParam(req));
	}
}
