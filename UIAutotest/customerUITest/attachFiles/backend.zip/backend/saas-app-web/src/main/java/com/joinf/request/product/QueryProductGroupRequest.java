package com.joinf.request.product;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author lyj
 * @Description: 查询分组
 * @data 2017年12月4日 下午2:38:17
 */
public class QueryProductGroupRequest{


	@ApiModelProperty(value ="1个人 0企业")
	private Integer type;

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}
	
}
