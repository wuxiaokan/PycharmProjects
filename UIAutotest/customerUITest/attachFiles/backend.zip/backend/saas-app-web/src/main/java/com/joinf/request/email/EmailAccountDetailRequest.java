package com.joinf.request.email;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 邮箱账号详细信息入参
 * @date 2018年1月7日 下午4:52:18
 */
public class EmailAccountDetailRequest implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value ="邮箱标识")
    private Long id;

    @ApiModelProperty(value ="邮箱账户")
    private String account;

    @ApiModelProperty(value ="邮箱密码(base64编码过的值)")
    private String passwd;

    @ApiModelProperty(value ="呢称")
    private String name;

    @ApiModelProperty(value ="接收服务器类型  [3]pop [4]:imap")
    private Integer type;

    @ApiModelProperty(value ="收件服务器地址")
    private String receiveServer;

    @ApiModelProperty(value ="收件是否ssl加密")
    private boolean receiveSsl;

    @ApiModelProperty(value ="收件端口")
    private Integer receivePort;

    @ApiModelProperty(value ="发件服务器地址")
    private String smtpServer;

    @ApiModelProperty(value ="发件是否ssl加密")
    private boolean smtpSsl;

    @ApiModelProperty(value ="发件端口")
    private Integer smtpPort;

    @ApiModelProperty(value ="是否默认账号")
    private boolean defaultAccount;

    @ApiModelProperty(value ="是否STARTTLS加密传输")
    private boolean starttls;

    @ApiModelProperty(value ="发件是否同步")
    private boolean sync;

    @ApiModelProperty(value ="是否同步下载已发箱的邮件")
    private boolean syncSendbox;
    
	@ApiModelProperty(value = "是否再次提交(再次提交部分不需要校验) 1:是")
	private Integer reSubmit;
	
	@ApiModelProperty(value = "收件账号(部分邮局可设置独立账号登陆)")
    private String receiveLoginName;
	
	@ApiModelProperty(value = "发件账号(部分邮局可设置独立账号登陆)")
    private String sendLoginName;
	
	@ApiModelProperty(value = "发件密码")
    private String sendPasswd;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getReceiveServer() {
		return receiveServer;
	}

	public void setReceiveServer(String receiveServer) {
		this.receiveServer = receiveServer;
	}

	public boolean isReceiveSsl() {
		return receiveSsl;
	}

	public void setReceiveSsl(boolean receiveSsl) {
		this.receiveSsl = receiveSsl;
	}

	public Integer getReceivePort() {
		return receivePort;
	}

	public void setReceivePort(Integer receivePort) {
		this.receivePort = receivePort;
	}

	public String getSmtpServer() {
		return smtpServer;
	}

	public void setSmtpServer(String smtpServer) {
		this.smtpServer = smtpServer;
	}

	public boolean isSmtpSsl() {
		return smtpSsl;
	}

	public void setSmtpSsl(boolean smtpSsl) {
		this.smtpSsl = smtpSsl;
	}

	public Integer getSmtpPort() {
		return smtpPort;
	}

	public void setSmtpPort(Integer smtpPort) {
		this.smtpPort = smtpPort;
	}

	public boolean isDefaultAccount() {
		return defaultAccount;
	}

	public void setDefaultAccount(boolean defaultAccount) {
		this.defaultAccount = defaultAccount;
	}

	public boolean isStarttls() {
		return starttls;
	}

	public void setStarttls(boolean starttls) {
		this.starttls = starttls;
	}

	public boolean isSync() {
		return sync;
	}

	public void setSync(boolean sync) {
		this.sync = sync;
	}

	public boolean isSyncSendbox() {
		return syncSendbox;
	}

	public void setSyncSendbox(boolean syncSendbox) {
		this.syncSendbox = syncSendbox;
	}

	public Integer getReSubmit() {
		return reSubmit;
	}

	public void setReSubmit(Integer reSubmit) {
		this.reSubmit = reSubmit;
	}

	public String getReceiveLoginName() {
		return receiveLoginName;
	}

	public void setReceiveLoginName(String receiveLoginName) {
		this.receiveLoginName = receiveLoginName;
	}

	public String getSendLoginName() {
		return sendLoginName;
	}

	public void setSendLoginName(String sendLoginName) {
		this.sendLoginName = sendLoginName;
	}

	public String getSendPasswd() {
		return sendPasswd;
	}

	public void setSendPasswd(String sendPasswd) {
		this.sendPasswd = sendPasswd;
	}
	
	
	
    
	
}
