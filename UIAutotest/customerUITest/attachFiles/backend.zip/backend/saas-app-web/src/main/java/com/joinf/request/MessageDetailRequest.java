package com.joinf.request;

import com.joinf.utils.base.BasePage;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * 消息详情请求
 * 
 * @author CyNick
 *
 */
public class MessageDetailRequest extends BasePage {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "数据id", required = true)
	private Long id;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

}
