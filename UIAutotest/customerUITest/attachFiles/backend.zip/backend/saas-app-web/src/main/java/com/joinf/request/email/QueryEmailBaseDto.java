package com.joinf.request.email;

import java.io.Serializable;

import com.joinf.utils.base.BasePage;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 查询邮件基本条件
 * @date 2018年1月13日 下午1:35:28
 */
public class QueryEmailBaseDto extends BasePage implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4015899913881112127L;
	
	@ApiModelProperty(value = "箱子id  供应商箱/客户箱/内部联系人箱传-11 ,查询箱-12")
	protected Long boxId;
	@ApiModelProperty(value = "是否已读")
	protected Boolean hasRead;
	@ApiModelProperty(value = "是否包含附件")
	protected Boolean containAttachment;
	@ApiModelProperty(value = "是否回复")
	protected Boolean isReply;
	@ApiModelProperty(value = "是否转发")
	protected Boolean isFw;
	@ApiModelProperty(value = "是否星标")
	protected Boolean isAsterisk;
	@ApiModelProperty(value = "客户id")
	protected Long customerId;
	@ApiModelProperty(value = "供应商id")
	protected Long supplierId;
	@ApiModelProperty(value = "内部联系人id")
	protected Long internalOperatorId;
	
	@ApiModelProperty(value = "查询箱的id")
	protected Long queryBoxId;
	
	@ApiModelProperty(value = "根据邮箱账号ID过滤")
	protected String senders;
	@ApiModelProperty(value = "绑定邮箱账号(查询账号收到或发出的邮件)")
	protected String account;
	
	@ApiModelProperty(value ="[0]:收信;[1]:发信;[-1]:全部")
    private Integer emailType;

	@ApiModelProperty(value = "搜索关键词")
	protected String key;

	public Long getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(Long supplierId) {
		this.supplierId = supplierId;
	}

	public Long getQueryBoxId() {
		return queryBoxId;
	}

	public void setQueryBoxId(Long queryBoxId) {
		this.queryBoxId = queryBoxId;
	}
	
	public Long getBoxId() {
		return boxId;
	}

	public Boolean getHasRead() {
		return hasRead;
	}

	public Boolean getContainAttachment() {
		return containAttachment;
	}

	public Boolean getIsReply() {
		return isReply;
	}

	public Boolean getIsFw() {
		return isFw;
	}

	public Boolean getIsAsterisk() {
		return isAsterisk;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public Long getInternalOperatorId() {
		return internalOperatorId;
	}

	public String getKey() {
		return key;
	}

	public void setBoxId(Long boxId) {
		this.boxId = boxId;
	}

	public void setHasRead(Boolean hasRead) {
		this.hasRead = hasRead;
	}

	public void setContainAttachment(Boolean containAttachment) {
		this.containAttachment = containAttachment;
	}

	public void setIsReply(Boolean isReply) {
		this.isReply = isReply;
	}

	public void setIsFw(Boolean isFw) {
		this.isFw = isFw;
	}

	public void setIsAsterisk(Boolean isAsterisk) {
		this.isAsterisk = isAsterisk;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public void setInternalOperatorId(Long internalOperatorId) {
		this.internalOperatorId = internalOperatorId;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getSenders() {
		return senders;
	}

	public void setSenders(String senders) {
		this.senders = senders;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public Integer getEmailType() {
		return emailType;
	}

	public void setEmailType(Integer emailType) {
		this.emailType = emailType;
	}

	
	

}
