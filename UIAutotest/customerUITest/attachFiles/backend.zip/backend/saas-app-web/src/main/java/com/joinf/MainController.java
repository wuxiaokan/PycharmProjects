package com.joinf;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.embedded.ConfigurableEmbeddedServletContainer;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Controller;

import com.joinf.interceptor.login.RequestWrapperFilter;
import com.joinf.util.ValidateEmailAccountUtil;

@SpringBootApplication
@EnableScheduling //添加定时计划
@Controller
public class MainController {
	
	@Value("${proxy.host}")
	private String proxyHost;
	@Value("${proxy.port}")
	private String proxyPort;
	
	/**
	 * 程序入口
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			SpringApplication.run(new Object[]{MainController.class,ApplicationRunner.class}, args);
		}catch (Exception e){
			e.printStackTrace();
		}
	}
	
	/**
	 * 会话时间
	 * @return
	 */
	@Bean
	public EmbeddedServletContainerCustomizer containerCustomizer() {
		return new EmbeddedServletContainerCustomizer() {
			@Override
			public void customize(ConfigurableEmbeddedServletContainer container) {
				container.setSessionTimeout(-1);// 单位为S
			}
		};
	}
	
	/**
	 * 注册拦截器
	 * @return
	 */
	@Bean
	public FilterRegistrationBean filterRegistrationBean() {
	   FilterRegistrationBean registrationBean = new FilterRegistrationBean();
	   registrationBean.setFilter(requestWrapperFilter());
	   List<String> urlPatterns = new ArrayList<String>();
	   urlPatterns.add("/*");
	   registrationBean.setUrlPatterns(urlPatterns);
	   return registrationBean;
	}
	
	/**
	 * 重复获取数据拦截器
	 * @return
	 */
	@Bean
	public Filter requestWrapperFilter(){
		return new RequestWrapperFilter();
	}
	
	/**
	 * 设置代理
	 * @return
	 */
	@Bean
	public String setProxy(){
		System.getProperties().put(ValidateEmailAccountUtil.PROXY_HOST_PROPERTY_KEY, proxyHost);  
        System.getProperties().put(ValidateEmailAccountUtil.PROXY_PORT_PROPERTY_KEY, proxyPort);  
        return "ok";
	}

}
