package com.joinf.request.customer;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 客户标签请求参数
 * @author cuichuanlei
 * @created 2019年2月26日 下午1:55:17
 */
public class QueryCustomerTagRequest {
	
	@ApiModelProperty(value="客户id",required=true)
	private Long customerId;

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

}
