package com.joinf.response;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 提醒返回类
 *
 * @author lyj
 * @date 2017年12月22日 下午5:27:43
 */
public class RemainResponse {

	@ApiModelProperty(value="7天内将要过生日",required=true)
	private Long birthdayCount;
	
	@ApiModelProperty(value="即将被自动转入公海的客户",required=true)
	private Long duringMoveCount;
	
	@ApiModelProperty(value="30天内没有联系的客户",required=true)
	private Long unContactCount;
	
	@ApiModelProperty(value="3天内需要的跟进的客户",required=true)
	private Integer threeDayNeedFollowUpCustomer;

	public Integer getThreeDayNeedFollowUpCustomer() {
		return threeDayNeedFollowUpCustomer;
	}

	public void setThreeDayNeedFollowUpCustomer(Integer threeDayNeedFollowUpCustomer) {
		this.threeDayNeedFollowUpCustomer = threeDayNeedFollowUpCustomer;
	}

	public Long getBirthdayCount() {
		return birthdayCount;
	}

	public void setBirthdayCount(Long birthdayCount) {
		this.birthdayCount = birthdayCount;
	}

	public Long getDuringMoveCount() {
		return duringMoveCount;
	}

	public void setDuringMoveCount(Long duringMoveCount) {
		this.duringMoveCount = duringMoveCount;
	}

	public Long getUnContactCount() {
		return unContactCount;
	}

	public void setUnContactCount(Long unContactCount) {
		this.unContactCount = unContactCount;
	}
}
