package com.joinf.interceptor.login;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.joinf.constant.login.LoginContant;
import com.joinf.constant.login.LoginRedirect;
import com.joinf.dto.LoginLogDto;
import com.joinf.dto.QueryLoginLogDto;
import com.joinf.entity.RelResourceExtend;
import com.joinf.entity.SessionUser;
import com.joinf.entity.generator.Company;
import com.joinf.entity.generator.LoginLog;
import com.joinf.entity.generator.Operator;
import com.joinf.exception.NoLoginException;
import com.joinf.interceptor.BaseHandlerInterceptor;
import com.joinf.interfaces.AssignmentService;
import com.joinf.interfaces.EmailAccountService;
import com.joinf.interfaces.LoginLogService;
import com.joinf.interfaces.OperatorService;
import com.joinf.interfaces.RelRoleResService;
import com.joinf.response.login.OffsiteMsg;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.dto.user.UserInfoDto;
import com.joinf.utils.util.CheckingUtil;
import com.joinf.utils.util.DateUtil;
import com.joinf.utils.util.HttpUtils;
import com.joinf.utils.util.SignUtils;

/**
 * Description: 初始化登录成功后一些信息
 *
 * @author lyj
 * @date 2017年12月18日 下午7:49:45
 */
public class InitSessionReourceInterceptor extends BaseHandlerInterceptor implements HandlerInterceptor {

	private static Logger logger = LoggerFactory.getLogger(InitSessionReourceInterceptor.class);

	@Autowired
	private StringRedisTemplate stringRedisTemplate;

	@Autowired
	private AssignmentService assignmentService;

	@Autowired
	private RelRoleResService relRoleResService;

	@Autowired
	private OperatorService operatorService;

	@Autowired
	private EmailAccountService emailAccountService;

	@Autowired
	private LoginLogService logService;
	
	@Value("${center.orderCenter}")
	private String orderCenterUrl; 
	
	@Value("${aliyun.appKey}")
	private String appKey;
	
	@Value("${aliyun.appSecret}")
	private  String appSecret;
	
	@Value("${aliyun.appCode}")
	private  String appCode;
	
	/**
	 * 实现方法
	 */
	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		HttpSession session = request.getSession();
		Company company = SessionUtils.getCompanyInfo(request);
		Operator operator = SessionUtils.getOperatorInfo(request);
		if(company==null || operator==null)
			throw new NoLoginException();
		
		logger.info("获取当前用户可以管理人员");
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		//当前用户可管理人员
		List<UserInfoDto> assignmentUsers = assignmentService.selectAssignmentUserList(company.getId(), operator.getId());
		String key = String.format(AssignmentService.OPERATOR_ASSIGNMENT_USERS, company.getId(),operator.getId());
		stringRedisTemplate.opsForValue().set(key, JSONArray.toJSONString(assignmentUsers),120,TimeUnit.MINUTES);
		
		//当前用户权限
		List<RelResourceExtend> resources = relRoleResService.queryOperatorResources(operator);
		session.setAttribute(LoginContant.OPERATOR_RESOURCES, JSONArray.toJSONString(resources));
		
		//登入成功日志
		String ip = addLog(request,user);
		if(StringUtils.isNotBlank(ip)){
			OffsiteMsg msg = offSiteLogin(ip, operator.getCompanyId(), operator.getId());
			if(msg != null){
				session.setAttribute(LoginContant.OFFSITE_LOGIN, JSONObject.toJSONString(msg));
			}
		}
		
		//恢复不自动收信的邮箱账号
		this.emailAccountService.restoredAuthSuccessByLogin(operator.getCompanyId(), operator.getId(), company.getCompanyType()!=null?company.getCompanyType().intValue():null);
		
		session.setAttribute(LoginContant.REDIRECT_URL,LoginRedirect.Index.getPath());
		//清除登入次数
		session.removeAttribute(LoginContant.LOGFAIL_COUNT);
		
		return true;
	}

	/**
	 * 登入成功日志
	 * 
	 * @param request
	 * @param user
	 * @return
	 */
	private String addLog(HttpServletRequest request, SessionUser user) {
		String ip = "";
		UserInfoDto operator = user.getUser();
		ip = CheckingUtil.getIpAddress(request);
		if (StringUtils.isBlank(ip)) {
			
		}
		
		// 更新登录次数
		Operator updateOperator = new Operator();
		updateOperator.setId(operator.getId());
		updateOperator.setLoginCount(operator.getLoginCount() == null ? 1 : operator.getLoginCount() + 1);
		operatorService.updateByPrimaryKeySelective(updateOperator);

		LoginLog log = new LoginLog();
		log.setCompanyId(operator.getCompanyId());
		log.setOperatorId(operator.getId());
		log.setIp(ip);
		// 解析IP信息
		String ipInfoStr = CheckingUtil.parseIpAddress(appKey, appSecret, appCode, ip);
		log.setLoginInfo(ipInfoStr);
		log.setBrowserVersion(request.getHeader("User-Agent"));
		log.setLoginTime(new Date());
		log.setOperatorName(user.getUser().getChineseName());
		// log.setEcs(elastic_compute_service);
		logService.insertSelective(log);
		
		//增加订单中心日志
		LoginLogDto logDto = new LoginLogDto();
		logDto.setCompanyId(SessionUtils.getCenterCompanyInfo(request).getCompanyId());
		logDto.setUserId(operator.getCenterUserId());
		logDto.setCompanyName(SessionUtils.getCenterCompanyInfo(request).getName());
		logDto.setUserLoginName(user.getUser().getUserName());
		logDto.setUserChineseName(user.getUser().getChineseName());
		logDto.setBrowserInfo(request.getHeader("User-Agent"));
		logDto.setLoginIp(ip);
		logDto.setLoginSite("b2b_app");
		
		try {
			String url = StringUtils.join(orderCenterUrl,"/api/loginLog/addLoginLog");			
			//生成签名
			String jsonStr = SignUtils.dealGenerateSign(logDto);		
			JSONObject json = JSON.parseObject(jsonStr);	
			
			String resultStr = HttpUtils.postStringToJsonBody(url, json.toJSONString());
			JSONObject resultJson = JSONObject.parseObject(resultStr);
			if (resultJson != null) {
				if (resultJson.getBoolean("success")) {
					logger.info("订单中心日志记录成功");
				}else{
					logger.error("订单中心日志记录失败，"+ resultJson.getString("msg"));
				}
			}else{
				logger.info("订单中心日志记录成功");
			}
		} catch (IOException e) {
			logger.error("订单中心日志记录失败，"+ e.getLocalizedMessage());
		}		
		
		return ip;
	}

	/**
	 * 查看是否为登录异常
	 * 
	 * @param companyId
	 * @param operatorId
	 * @param loginExceptionMap
	 */
	private OffsiteMsg offSiteLogin(String ip, Long companyId, Long operatorId) {
		OffsiteMsg msg = null;
		// 装载参数
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("companyId", companyId);
		param.put("operatorId", operatorId);
		QueryLoginLogDto dto = new QueryLoginLogDto();
		dto.setCompanyId(companyId);
		dto.setOperatorId(operatorId);
		// 查询改操作员最后一次登录的IP新
		LoginLog loginLog = logService.selectLastLoginInfo(dto);
		if (loginLog != null) {
			String loginInfo = loginLog.getLoginInfo();
			if (StringUtils.isNotBlank(loginInfo)) {
				JSONObject ipJsonResult = JSONObject.parseObject(loginInfo);
				String latestLoginIp = ipJsonResult.getString("ip");
				if (!StringUtils.equals(ip, latestLoginIp)) {// 不一样的情况下给出异常提示
					String latestLoginTime = DateUtil.format(loginLog.getLoginTime(), "MM-dd HH:mm");// 登录时间
					String latestLoginRegion = ipJsonResult.getString("region");// 省份
					String latestLoginCity = ipJsonResult.getString("city");// 城市
					msg = new OffsiteMsg();
					msg.setLatestLoginCity(latestLoginCity);
					msg.setLatestLoginIp(latestLoginIp);
					msg.setLatestLoginRegion(latestLoginRegion);
					msg.setLatestLoginTime(latestLoginTime);
				}
			}
		}
		return msg;
	}

	/**
	 * 实现方法
	 */
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub

	}

	/**
	 * 实现方法
	 */
	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub

	}

}
