package com.joinf.response.login;

import io.swagger.annotations.ApiModelProperty;


public class CompanyDueDto{
	
	@ApiModelProperty(value="到期日期",required=true)
    private String disableDate;
   
	@ApiModelProperty(value="{X}天，{X}小时",required=true)
    private String mess;
    
	@ApiModelProperty(value="全国服务专线",required=true)
    private String helpLine;

	public String getDisableDate() {
		return disableDate;
	}

	public void setDisableDate(String disableDate) {
		this.disableDate = disableDate;
	}

	public String getMess() {
		return mess;
	}

	public void setMess(String mess) {
		this.mess = mess;
	}

	public String getHelpLine() {
		return helpLine;
	}

	public void setHelpLine(String helpLine) {
		this.helpLine = helpLine;
	}
	
	
     
	
}
