package com.joinf.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.dom4j.DocumentException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.joinf.ClientConfig;
import com.joinf.JoinfClientUtils;
import com.joinf.annotations.NeedLogin;
import com.joinf.config.SaasClientConfig;
import com.joinf.constants.Customize;
import com.joinf.dto.CheckExsitDto;
import com.joinf.dto.CheckNumLimitDto;
import com.joinf.dto.CompanyDTO;
import com.joinf.dto.CustomizeDictDto;
import com.joinf.dto.GenerateCodeDto;
import com.joinf.dto.OperatorDTO;
import com.joinf.dto.QueryCustomerDataDto;
import com.joinf.dto.QueryCustomizeForceinputParam;
import com.joinf.dto.QueryReportTemplateParam;
import com.joinf.dto.QuerySizeByObjectName;
import com.joinf.dto.SearchData;
import com.joinf.dto.SendCaptchaDto;
import com.joinf.dto.UpdateOperatorInfoDto;
import com.joinf.entity.OSSConfig;
import com.joinf.entity.PropertiesEntity;
import com.joinf.entity.SessionUser;
import com.joinf.entity.UserOrder;
import com.joinf.entity.generator.AppVersionInfo;
import com.joinf.entity.generator.Company;
import com.joinf.entity.generator.CustomizeForceinput;
import com.joinf.entity.generator.DictCountry;
import com.joinf.entity.generator.Operator;
import com.joinf.entity.generator.Version;
import com.joinf.exception.CommonException;
import com.joinf.interfaces.CommonManager;
import com.joinf.interfaces.CommonService;
import com.joinf.interfaces.OperatorService;
import com.joinf.interfaces.ReportTemplateService;
import com.joinf.interfaces.UserCenterService;
import com.joinf.interfaces.UserOrderService;
import com.joinf.mapper.CustomizeForceinputExMapper;
import com.joinf.mapper.DictCountryExMapper;
import com.joinf.request.CheckAccountMobileOrEmailRequest;
import com.joinf.request.CheckCaptchaRequest;
import com.joinf.request.CheckDataExistRequest;
import com.joinf.request.CheckExsitRequest;
import com.joinf.request.CheckNumLimitRequest;
import com.joinf.request.DictRequest;
import com.joinf.request.GenerateCodeRequest;
import com.joinf.request.GetOSSPolicyRequest;
import com.joinf.request.GetOssKeyRequest;
import com.joinf.request.GetcolumnForceinputRequest;
import com.joinf.request.IdRequest;
import com.joinf.request.QueryCustomizeCodeDataRequest;
import com.joinf.request.QueryReportTemplateRequest;
import com.joinf.request.ResetPasswordRequest;
import com.joinf.request.SearchCompanyRequest;
import com.joinf.request.SendCapthcaCodeRequest;
import com.joinf.request.UpdateDeviceIdRequest;
import com.joinf.request.UpdateOperatorInfoRequest;
import com.joinf.request.UpdatePasswordRequest;
import com.joinf.response.CustomizeCodeResponse;
import com.joinf.response.CustomizeDictResponse;
import com.joinf.response.DictCountryResponse;
import com.joinf.response.NativePolicyResponse;
import com.joinf.response.OrderStatusResponse;
import com.joinf.response.OssPolicyResponse;
import com.joinf.response.ReportTemplateResponse;
import com.joinf.response.SuccessResponse;
import com.joinf.response.UserAgreementResponse;
import com.joinf.response.UserCenterResponse;
import com.joinf.service.AlipayService;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.alipay.AlipaySubmit;
import com.joinf.utils.base.BaseEntityBuilder;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.enums.UploadDataTypeEnum;
import com.joinf.utils.util.CheckingUtil;
import com.joinf.utils.util.FileUtil;
import com.joinf.utils.util.HttpUtils;
import com.joinf.utils.util.JoinfBeanUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
 * Description: 基础服务
 *
 * @author lyj
 * @date 2017年12月13日 下午1:46:38
 */
@RestController
@RequestMapping("common")
@Api(tags="基础服务")
public class CommonController {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());
	
	@Autowired
	private CommonManager manager;
	
	@Autowired
	private AlipayService alipayService;
	
	@Autowired
	private UserOrderService userOrderService;
	
	@Autowired
	private OSSConfig ossConfig;
	
	@Value("${obs.callback}")
	private String obsCallBackUrl;
	
	@Autowired
	private CommonService commonService;
	
	@Autowired
	private OperatorService operatorService;
	
	@Autowired
	private DictCountryExMapper dictCountryExMapper;
	
	@Autowired
	private CustomizeForceinputExMapper customizeForceinputExMapper;
	
	@Autowired
	private PropertiesEntity propertiesEntity;
	
	@Autowired
	private ReportTemplateService reportTemplateService;
	
	@Autowired
	private UserCenterService userCenterService;
	
	@Autowired
	private StringRedisTemplate stringRedisTemplate;
	
	@GetMapping("test")
	public void test() throws Exception{
//		dictInitService.initCompanyBasicData(30366l, 30060l);
//		mongoTemplate.remove(new Query(Criteria.where("objectId").is("250680")), "follow_0");
		Set<String> keys =stringRedisTemplate.keys("*-assignment");
		stringRedisTemplate.delete(keys);
		Set<String> toolbarKeys =stringRedisTemplate.keys("TOOLBAR_*");
		stringRedisTemplate.delete(toolbarKeys);
	}
	
	/**
	 * 获取系统版本信息
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询公司", notes="查询公司")
	@ApiImplicitParam(name = "req", value = "查询字段字典请求对象", required = true, dataType = "SearchCompanyRequest")
	@PostMapping("searchCompany")
	public BaseResponseEntity<List<SearchData>> searchCompany(@RequestBody SearchCompanyRequest req){
		BaseResponseEntity<List<SearchData>> entity = new BaseResponseEntity<>();
		Map<String,String> params = new HashMap<>();
		params.put("keywords", req.getKeywords());
		params.put("pageNum", String.valueOf(req.getPageNum()));
		params.put("pageSize", String.valueOf(req.getPageSize()));
		String url = HttpUtils.getEncodeUrl(propertiesEntity.getDataSearchUrl()+"/wb/getCompanyInfoList", params);
		String result = HttpUtils.invokeGet(url);
		entity = JSON.parseObject(result, new TypeReference<BaseResponseEntity<List<SearchData>>>(){});
		return entity;
		
	}
	
	/**
	 * 获取系统版本信息
	 * @param req
	 * @return
	 */
	@ApiOperation(value="获取系统发布信息", notes="获取系统发布信息")
	@PostMapping("agreement")
	public BaseResponseEntity<UserAgreementResponse> agreement(){
		BaseResponseEntity<UserAgreementResponse> entity = new BaseResponseEntity<>();
		UserAgreementResponse resonse = new UserAgreementResponse();
		byte[] buf1 = null;
		byte[] buf2 = null;
		String agreement = "";
		String privacy = "";
		try {
			buf1 = JoinfClientUtils.downloadFile(SaasClientConfig.saasClientConfig,"agreement/agreement.html");//用户协议
			agreement = replaceAllCidHtmlFileContent(buf1,1);
		    buf2 = JoinfClientUtils.downloadFile(SaasClientConfig.saasClientConfig,"agreement/privacy.html"); //隐私协议
		    privacy = replaceAllCidHtmlFileContent(buf2,1);
		    resonse.setAgreement(agreement);
		    resonse.setPrivacy(privacy);
		} catch (Exception e) {
			throw new CommonException("获取用户协议失败");
		}
		entity.setData(resonse);
		entity.setSuccess(true);
		return entity;
	}
	
	/**
	 * 获取模板
	 * @param req
	 * @return
	 */
	@ApiOperation(value="获取模板", notes="获取模板")
	@PostMapping("getReportTemplate")
	@ApiImplicitParam(name = "req", value = "获取模板请求对象", required = true, dataType = "QueryReportTemplateRequest")
	@NeedLogin
	public BaseResponseEntity<List<ReportTemplateResponse>> getAppVersionInfo(HttpServletRequest request,@RequestBody QueryReportTemplateRequest req){
		BaseResponseEntity<List<ReportTemplateResponse>> response =  new BaseResponseEntity<List<ReportTemplateResponse>>();
		QueryReportTemplateParam param = new QueryReportTemplateParam();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		param.setType(req.getType());
		param.setCompanyId(user.getUser().getCompanyId());
		response.setSuccess(true);
		List<ReportTemplateResponse> datas = JoinfBeanUtils.copyToNewListBean(ReportTemplateResponse.class, reportTemplateService.selectTmplate(param));
		for(ReportTemplateResponse reportTemplate:datas){
			String excelCode = reportTemplate.getExcelCode();
			if(StringUtils.isNotBlank(excelCode)) {//转换excel
				reportTemplate.setExcelCode(JoinfClientUtils.getUrl(SaasClientConfig.saasClientConfig,excelCode));
			}
			String pdfCode = reportTemplate.getPdfCode();
			if(StringUtils.isNotBlank(pdfCode)) {//转换pdf
				reportTemplate.setPdfCode(JoinfClientUtils.getUrl(SaasClientConfig.saasClientConfig,pdfCode));
			}
			
			String htmlCode = reportTemplate.getHtmlCode();
			if(StringUtils.isNotBlank(htmlCode)) {//转换html
				reportTemplate.setHtmlCode(JoinfClientUtils.getUrl(SaasClientConfig.saasClientConfig,htmlCode));
			}
		}
		response.setData(datas);
		return response;
	}
	
	
	/**
	 * 获取当前app版本信息
	 * @param req
	 * @return
	 */
	@ApiOperation(value="获取当前app版本信息", notes="获取当前app版本信息")
	@PostMapping("getAppVersionInfo")
	public AppVersionInfo getAppVersionInfo(){
		return commonService.getCurrentAppVersion();
	}
	
	/**
	 * 获取系统版本信息
	 * @param req
	 * @return
	 */
	@ApiOperation(value="获取系统发布信息", notes="获取系统发布信息")
	@PostMapping("getVersionInfo")
	public BaseResponseEntity<List<Version>> getVersionInfo(){
		BaseResponseEntity<List<Version>> entity = new BaseResponseEntity<>();
		entity.setData(commonService.getVerisons(1));
		entity.setSuccess(true);
		return entity;
	}
	/**
	 * 查询字段字典
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询字段字典列表", notes="查询字段字典列表")
	@ApiImplicitParam(name = "req", value = "查询字段字典请求对象", required = true, dataType = "DictRequest")
	@PostMapping("queryColumnDictList")
	@NeedLogin
	public BaseResponseEntity<JSONArray> queryColumnDictList(HttpServletRequest request,@RequestBody DictRequest req){
		BaseResponseEntity<JSONArray> entity= new BaseResponseEntity<JSONArray>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		CustomizeDictDto dto = new CustomizeDictDto();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getSwitchOperatorId());
		dto.setAddBigDict(true);
		dto.setAddDict(true);
		dto.setKey(req.getKey());
		CustomizeDictResponse resonse = manager.getDictCollection(dto);
		entity.setData(resonse.getDicts());
		entity.setTotalPage(resonse.getPages());
		entity.setTotalRecords(resonse.getTotalRecord());
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="查询表必填项", notes="查询表必填项")
	@PostMapping("getcolumnForceinput")
	@ApiImplicitParam(name = "req", value = "查询表必填项请求对象", required = true, dataType = "GetcolumnForceinputRequest")
	@NeedLogin
	public BaseResponseEntity<List<String>> getcolumnForceinput(HttpServletRequest request,@RequestBody GetcolumnForceinputRequest req){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		BaseResponseEntity<List<String>> entity = new BaseResponseEntity<>();
		entity.setSuccess(true);
		QueryCustomizeForceinputParam param = new QueryCustomizeForceinputParam();
		param.setColumnCondition(req.getModuleId()+",");
		param.setCompanyId(user.getUser().getCompanyId());
		Customize cus = Customize.getByLogTableName(req.getTableName());
		param.setTableName(cus == null?null:cus.getTableName());
		CustomizeForceinput forceinput = customizeForceinputExMapper.findbyTableAndColumnIds(param);
		if(forceinput!= null)
			entity.setData(Arrays.asList(forceinput.getColumnForcename().split(",")));
		return entity;
	}
	
	@ApiOperation(value="根据国家名称查询数据库id", notes="根据国家名称查询数据库id")
	@GetMapping("getDBCountryIdByName")
	@NeedLogin
	public BaseResponseEntity<DictCountryResponse> getDBCountryIdByName(
			@ApiParam(required = true, name = "name", value= "国家名称")@RequestParam(value = "name",required=true) String name){
		BaseResponseEntity<DictCountryResponse> entity = new BaseResponseEntity<>();
		DictCountry country = dictCountryExMapper.getDBCountryIdByName(name);
		if(country !=null){
			DictCountryResponse response = new DictCountryResponse();
			JoinfBeanUtils.copyProperties(response, country);
			entity.setData(response);
		}
		entity.setSuccess(true);
		return entity;
	}
	
	/**
	 * 查询自定义code选择值
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询自定义code选择值", notes="查询自定义code选择值")
	@ApiImplicitParam(name = "req", value = "查询自定义code选择值请求对象", required = true, dataType = "QueryCustomizeCodeDataRequest")
	@PostMapping("getCustomizeCodeData")
	@NeedLogin
	public BaseResponseEntity<List<CustomizeCodeResponse>> getCustomizeCodeData(HttpServletRequest request,@RequestBody QueryCustomizeCodeDataRequest req){
		BaseResponseEntity<List<CustomizeCodeResponse>> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		QueryCustomerDataDto dto = new QueryCustomerDataDto();
		dto.setCompanyId(user.getUser().getCompanyId());
		dto.setParameterId(req.getParameterId());
		dto.setType(11);
		entity.setSuccess(true);
		entity.setData(manager.getCustomerCustomizeCodeData(dto));
		return entity;
	}
	/**
	 * 生成自定义code
	 * @param req
	 * @return
	 */
	@ApiOperation(value="生成自定义code", notes="生成自定义code")
	@ApiImplicitParam(name = "req", value = "生成自定义code请求对象", required = true, dataType = "GenerateCodeRequest")
	@PostMapping("generateCode")
	public BaseResponseEntity<String> generateCode(HttpServletRequest request,@RequestBody GenerateCodeRequest req){
		BaseResponseEntity<String> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		GenerateCodeDto dto = new GenerateCodeDto();
//		dto.setCompanyId(720l);
		dto.setCompanyId(user.getUser().getCompanyId());
		dto.setList(req.getList());
		dto.setParameterId(req.getParameterId());
		entity.setSuccess(true);
		entity.setData(manager.generateCode(dto));
		return entity;
	}
	
	/**
	 * 重置密码
	 * @param req
	 * @return
	 */
	@ApiOperation(value="重置密码", notes="重置密码")
	@ApiImplicitParam(name = "req", value = "重置密码请求对象", required = true, dataType = "ResetPasswordRequest")
	@PostMapping("resetPassword")
	public SuccessResponse resetPassword(HttpServletRequest request,@RequestBody ResetPasswordRequest req){
		return manager.resetPassword(req.getLoginName(), req.getPassword(),req.getEmail(),req.getMobile());
	}
	
	/**
	 * 修改密码
	 * @param req
	 * @return
	 */
	@ApiOperation(value="修改密码", notes="修改密码")
	@ApiImplicitParam(name = "req", value = "修改密码请求对象", required = true, dataType = "UpdatePasswordRequest")
	@PostMapping("updatePassword")
	public SuccessResponse updatePassword(HttpServletRequest request,@RequestBody UpdatePasswordRequest req){
		return manager.updatePassword(req.getUserId(), req.getOlPwd(), req.getNewPwd());
	}
	
	/**
	 * 修改用户信息
	 * @param req
	 * @return
	 */
	@ApiOperation(value="修改用户信息", notes="修改用户信息")
	@ApiImplicitParam(name = "req", value = "修改用户信息请求对象", required = true, dataType = "UpdateOperatorInfoRequest")
	@PostMapping("updateOperatorInfo")
	@NeedLogin
	@ResponseBody
	public BaseResponseEntity<?> UpdateOperatorInfo(HttpServletRequest request,@RequestBody UpdateOperatorInfoRequest req){
		
		logger.info("param:{}", JSON.toJSONString(req));
		
		UpdateOperatorInfoDto dto = new UpdateOperatorInfoDto();
		JoinfBeanUtils.copyProperties(dto, req);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setUserId(user.getUser().getCenterUserId());
		dto.setCompanyId(SessionUtils.getCenterCompanyInfo(request).getCompanyId());
		
		SuccessResponse successResponse = manager.UpdateOperatorInfoRequest(dto);
		if (successResponse.isSuccess()) {
			return BaseEntityBuilder.success();
		}else{
			return BaseEntityBuilder.fail(successResponse.getError());
		}
	}
	
	/**
	 * 校验是否存在
	 * @param req
	 * @return
	 */
	@ApiOperation(value="校验是否存在", notes="校验是否存在")
	@ApiImplicitParam(name = "req", value = "校验是否存在请求对象", required = true, dataType = "CheckExsitRequest")
	@PostMapping("checkExsit")
	public BaseResponseEntity<?> checkExsit(HttpServletRequest request,@RequestBody CheckExsitRequest req){
		BaseResponseEntity<?> entity= new BaseResponseEntity<>();
		CheckExsitDto dto = new CheckExsitDto();
		JoinfBeanUtils.copyProperties(dto, req);
		if(req.getExcludeSelf() == 1){//排除自己
			OperatorDTO operatorDTO =SessionUtils.getCenterOperatorInfo(request);
			if(operatorDTO == null)
				throw new CommonException("请先登录");
			dto.setCenterCompanyId(operatorDTO.getCompanyId());
//			dto.setCenterUserId(operatorDTO.getUserId());
		}
//		boolean success = manager.checkExist(dto);
		boolean success = false;
		entity.setSuccess(success);
		entity.setErrMsg(success?"存在":"不存在");
		return entity;
	}
	
	/**
	 * 校验是否存在
	 * @param req
	 * @return
	 */
	@ApiOperation(value="校验数据是否存在", notes="校验数据是否存在")
	@ApiImplicitParam(name = "req", value = "校验数据是否存在请求对象", required = true, dataType = "CheckDataExistRequest")
	@PostMapping("checkDataExsit")
	@NeedLogin
	public BaseResponseEntity<?> checkDataExsit(HttpServletRequest request,@RequestBody CheckDataExistRequest req){
		BaseResponseEntity<?> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		QuerySizeByObjectName param = new QuerySizeByObjectName();
		param.setTableName(req.getSystemTableName());
		param.setId(req.getId());
		param.setObjectName(req.getColumnName());
		param.setValue(req.getValue());
		param.setCompanyId(user.getCompanyId());
		boolean success = manager.selectCountByObjectName(param) > 0;
		entity.setSuccess(success);
		entity.setErrMsg(success?"存在":"不存在");
		return entity;
	} 
	
	@ApiOperation(value="校验是否是主账号", notes="校验是否是主账号")
	@GetMapping("checkPrimaryAccount")
	public BaseResponseEntity<?> checkPrimaryAccount(HttpServletRequest request
			,@ApiParam(required = true, name = "loginName", value= "用户名")@RequestParam(value = "loginName") String loginName){
		BaseResponseEntity<?> entity= new BaseResponseEntity<>();
		boolean success = manager.checkIsPrimaryAccount(loginName);
		entity.setSuccess(success);
		entity.setErrMsg(success?"是":"否");
		return entity;
	}
	
	
	
	@ApiOperation(value="校验数量是否超过限制", notes="校验数量是否超过限制")
	@ApiImplicitParam(name = "req", value = "校验数量是否超过限制请求对象", required = true, dataType = "CheckNumLimitRequest")
	@PostMapping("checkLimit")
	@NeedLogin
	public BaseResponseEntity<?> checkLimit(HttpServletRequest request
			,@RequestBody CheckNumLimitRequest req){
		BaseResponseEntity<?> entity= new BaseResponseEntity<>();
		CheckNumLimitDto dto = new CheckNumLimitDto();
		JoinfBeanUtils.copyProperties(dto, req);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setOperatorId(user.getUser().getId());
		dto.setCompanyId(user.getUser().getCompanyId());
		boolean success = manager.checkNumLimit(dto);
		entity.setSuccess(success);
		entity.setErrMsg(success?"是":"否");
		return entity;
	}
	
	@ApiOperation(value="校验企业容量是否超过限制", notes="校验企业容量是否超过限制")
	@PostMapping("checkVolumeLimit")
	@NeedLogin
	public BaseResponseEntity<?> checkVolumeLimit(HttpServletRequest request){
		BaseResponseEntity<?> entity= new BaseResponseEntity<>();
		CompanyDTO user = SessionUtils.getCenterCompanyInfo(request);
		UserCenterResponse<?> httpResponse = userCenterService.volumeValidate(user.getCompanyId());
		entity.setSuccess(!httpResponse.isSuccess());
		entity.setErrMsg(!httpResponse.isSuccess()?"是":"否");
		return entity;
	}
	
	@ApiOperation(value="校验用户名和邮箱或手机是否匹配", notes="校验用户名和邮箱或手机是否匹配")
	@ApiImplicitParam(name = "req", value = "校验用户名和邮箱或手机是否匹配请求对象", required = true, dataType = "CheckAccountMobileOrEmailRequest")
	@PostMapping("checkAccountMobileOrEmail")
	public BaseResponseEntity<?> checkAccountMobileOrEmail(HttpServletRequest request
			,@RequestBody CheckAccountMobileOrEmailRequest req){
		BaseResponseEntity<?> entity= new BaseResponseEntity<>();
		OperatorDTO dto = manager.getCenterOperatorByLoginName(req.getLoginName());
		boolean success = false;
		if(dto == null)
			throw new CommonException("用户不存在");
		CompanyDTO company = null;
		if(req.getType() == 1){
			company = manager.getCenterCompanyInfo(dto.getCompanyId(), null, req.getCheckValue());
		}
		else if(req.getType() == 2){
			company = manager.getCenterCompanyInfo(dto.getCompanyId(),  req.getCheckValue(),null);
		}
		success = company!=null;
		entity.setSuccess(success);
		entity.setErrMsg(success?"是":"否");
		return entity;
	}
	
	/**
	 * 发送验证码
	 * @param req
	 * @return
	 */
	@ApiOperation(value="发送验证码", notes="发送验证码")
	@ApiImplicitParam(name = "req", value = "发送验证码请求对象", required = true, dataType = "SendCapthcaCodeRequest")
	@PostMapping("sendCapthca")
	public BaseResponseEntity<String> sendCapthca(HttpServletRequest request,@RequestBody SendCapthcaCodeRequest req){
		BaseResponseEntity<String> entity= new BaseResponseEntity<>();
		SendCaptchaDto dto = new SendCaptchaDto();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setIp(CheckingUtil.getIpAddress(request));
		
		UserCenterResponse<String> sendResult = manager.sendCaptcha(dto);
		
		entity.setSuccess(sendResult.isSuccess());
		if(NumberUtils.isNumber(sendResult.getCode())){
			entity.setCode(Integer.valueOf(sendResult.getCode()));
		}
		entity.setData(sendResult.getResponseData());
		entity.setErrMsg(sendResult.getErrorMsg());
		return entity;
	}
	/**
	 * 校验验证码
	 * @param req
	 * @return
	 */
	@ApiOperation(value="校验验证码", notes="校验验证码")
	@ApiImplicitParam(name = "req", value = "校验验证码请求对象", required = true, dataType = "CheckCaptchaRequest")
	@PostMapping("checkCapthca")
	public BaseResponseEntity<String> checkCapthca(HttpServletRequest request,@RequestBody CheckCaptchaRequest req){
		BaseResponseEntity<String> entity= new BaseResponseEntity<>();
		
		UserCenterResponse<String> sendResult = manager.captchaIsEqual(req.getNumber(), req.getRandom(), req.getCaptcha(), CheckingUtil.getIpAddress(request));
		
		entity.setSuccess(sendResult.isSuccess());
		if(NumberUtils.isNumber(sendResult.getCode())){
			entity.setCode(Integer.valueOf(sendResult.getCode()));
		}
		entity.setData(sendResult.getResponseData());
		entity.setErrMsg(sendResult.getErrorMsg());
		return entity;
	}
	
	/**
	 * 唤醒支付
	 * @param req
	 * @return
	 * @throws IOException 
	 * @throws DocumentException 
	 * @throws MalformedURLException 
	 */
	@ApiOperation(value="唤醒支付", notes="唤醒支付")
	@ApiImplicitParam(name = "req", value = "唤醒支付请求对象", required = true, dataType = "IdRequest")
	@PostMapping("notifyPay")
	@NeedLogin
	public BaseResponseEntity<String> checkCapthca(HttpServletRequest request,HttpServletResponse response,@RequestBody IdRequest req) throws MalformedURLException, DocumentException, IOException{
		BaseResponseEntity<String> entity= new BaseResponseEntity<>();
		String url = alipayService.initAliPay(req.getId(), SessionUtils.getCenterCompanyInfo(request).getCompanyId(), AlipaySubmit.getIpAddress(request));
		entity.setData(url);
		entity.setSuccess(true);
		return entity;
	}
	/**
	 * 查看订单状态
	 * @param req
	 * @return
	 * @throws IOException 
	 * @throws DocumentException 
	 * @throws MalformedURLException 
	 */
	@ApiOperation(value="查看订单状态", notes="查看订单状态")
	@ApiImplicitParam(name = "req", value = "查看订单状态请求对象", required = true, dataType = "IdRequest")
	@PostMapping("checkOrderStatus")
	@NeedLogin
	public BaseResponseEntity<OrderStatusResponse> checkOrderStatus(HttpServletRequest request,HttpServletResponse response,@RequestBody IdRequest req) throws MalformedURLException, DocumentException, IOException{
		BaseResponseEntity<OrderStatusResponse> entity= new BaseResponseEntity<>();
		CompanyDTO company = SessionUtils.getCenterCompanyInfo(request);
		UserOrder order = userOrderService.selectByOrderId(req.getId(), company.getCompanyId());
		if(order == null){
			entity.setErrMsg("订单不存在");
			entity.setSuccess(false);
		}else{
			OrderStatusResponse status = new OrderStatusResponse();
			status.setStauts(order.getOrderStatus());
			entity.setData(status);
			entity.setSuccess(true);
		}
		return entity;
	}
	
	@ApiOperation(value="修改绑定设备id", notes="修改绑定设备id")
	@ApiImplicitParam(name = "req", value = "修改绑定设备id请求对象", required = true, dataType = "UpdateDeviceIdRequest")
	@PostMapping("updateDeviceId")
	@NeedLogin
	public BaseResponseEntity<?> updateDeviceId(HttpServletRequest request,HttpServletResponse response,@RequestBody UpdateDeviceIdRequest req) throws MalformedURLException, DocumentException, IOException{
		BaseResponseEntity<?> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		Operator operator = new Operator();
		operator.setId(user.getUser().getId());
		
		operator.setDeviceId(req.getDeviceId());
		operator.setDeviceType(req.getDeviceType());
		operatorService.updateByPrimaryKeySelective(operator);
		entity.setSuccess(true);
		return entity;
	}

	/**
	 * 获取oss签名--直传
	 * @param req
	 * @return
	 * @throws Exception 
	 */
	@ApiOperation(value="获取oss签名", notes="获取oss签名")
	@ApiImplicitParam(name = "req", value = "获取oss签名请求对象", required = true, dataType = "GetOSSPolicyRequest")
	@PostMapping("getJsOssPolicy")
	@NeedLogin
	public BaseResponseEntity<OssPolicyResponse> getJsOssPolicy(HttpServletRequest request,@RequestBody GetOSSPolicyRequest req) throws Exception {
		BaseResponseEntity<OssPolicyResponse> entity = new BaseResponseEntity<>();
		String companyCode = SessionUtils.getCompanyInfo(request).getCode();
		String key = FileUtil.getFileKey(companyCode, String.valueOf(req.getType()), null);
		String callbackUrl = ossConfig.getCallback();
		
		ClientConfig config = JoinfBeanUtils.copyToNewBean(ClientConfig.class, SaasClientConfig.saasClientConfig);
//		JSONObject result = JoinfClientUtils.getPolicy(1000*60*15, key, fileUploadCallback, null);
		com.alibaba.fastjson.JSONObject result = JoinfClientUtils.getPolicy(config, 1000*60*15, key, callbackUrl, null);

		OssPolicyResponse response = new OssPolicyResponse();
		response.setAccessid(result.getString("accessid"));
		response.setPolicy(result.getString("policy"));
		response.setSignature(result.getString("signature"));
		response.setDir(result.getString("dir"));
		response.setHost(result.getString("host"));
		response.setExpire(result.getString("expire"));
		response.setCallbackVar(callbackUrl);
		response.setCallbackSig(result.getString("callback"));
		entity.setSuccess(true);
		entity.setData(response);
		return entity;
	}
	
	@ApiOperation(value = "获取obs直传签名")
	@RequestMapping(value = "/getToken", method = RequestMethod.POST)
	@ResponseBody
	public BaseResponseEntity<JSONObject> getToken(HttpServletRequest request, @RequestBody GetOSSPolicyRequest req) {
		BaseResponseEntity<JSONObject> result = new BaseResponseEntity<>(true);

		String companyCode = SessionUtils.getCompanyInfo(request).getCode();
		String key = FileUtil.getFileKey(companyCode, String.valueOf(req.getType()), null);
		
		Map<String, Object> paramMap = new HashMap<String, Object>();

		long expireTime = 500; // 500秒后过期
		try {
			JSONObject resJson = new JSONObject();
			resJson = JoinfClientUtils.getPolicy(SaasClientConfig.saasClientConfig, expireTime, key, obsCallBackUrl,
					paramMap);

			result.setData(resJson);
			return result;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	/**
	 * oss回调请求--直传
	 */
	@GetMapping("ossCallback")
	public void jsCallback(
			@RequestParam(value = "file_name", required = false) String fileName,
			@RequestParam(value = "size", required = false) String size,
			@RequestParam(value = "mime_type", required = false) String mimeType,
			@RequestParam(value = "format", required = false) String format,
			@RequestParam(value = "type", required = false) String type,
			HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception{
		String key = URLEncoder.encode(fileName, "utf-8");
		JSONObject result = new JSONObject();
		result.put("success", true);
		result.put("Status", "OK");
		result.put("key", key);
		result.put("url", JoinfClientUtils.getUrl(SaasClientConfig.saasClientConfig,key));
		String results = result.toString();	
		String callbackFunName = request.getParameter("callback");
		response.addHeader("Content-Length", String.valueOf(results.length()));
		if (callbackFunName == null || callbackFunName.equalsIgnoreCase(""))
			response.getWriter().println(results);
		else
			response.getWriter().println(callbackFunName + "( " + results + " )");
		
		response.setHeader("Content-Type", "text/html");
		response.setStatus(HttpServletResponse.SC_OK);
		response.flushBuffer();
	}
	
	 /**
     * oss回调请求--直传
     */
    @PostMapping("obsCallback")
    public void jsObsCallback(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	
    	JSONObject result = new JSONObject();
    	result.put("success", true);
    	result.put("Status", "OK");
    	
//    	String bucket = request.getParameter("bucket");
		String key = request.getParameter("key");
//		String etag = request.getParameter("etag");
    		
		result.put("key", key);
		result.put("url", JoinfClientUtils.getUrl(SaasClientConfig.saasClientConfig,key));
		String results = result.toString();
		
		response.getWriter().println(results);
    	
    	response.setHeader("Content-Type", "text/html;charset=utf-8");
    	response.setCharacterEncoding("utf-8");
    	response.setStatus(HttpServletResponse.SC_OK);
    	response.flushBuffer();
    }

	
	
	/**
	 * 获取签名-原生调用
	 * @return
	 */
	@GetMapping("getNativePolicy")
	@ApiOperation(value="获取签名-原生调用", notes="获取签名-原生调用")
	public BaseResponseEntity<NativePolicyResponse> getNativePolicy(){
		BaseResponseEntity<NativePolicyResponse> entity = new BaseResponseEntity<NativePolicyResponse>();
		NativePolicyResponse resonse = manager.getNativePolicy();
		entity.setData(resonse);
		entity.setSuccess(true);
		return entity;
	}
	
	/**
	 * 获取上传文件key
	 * @return
	 */
	@PostMapping("getOssKey")
	@ApiImplicitParam(name = "req", value = "获取文件key值请求对象", required = true, dataType = "GetOssKeyRequest")
	@ApiOperation(value="获取文件key值", notes="获取文件key值")
	@NeedLogin
	public BaseResponseEntity<String> getOssKey(HttpServletRequest request,@RequestBody GetOssKeyRequest req){
		
		logger.info("param:{}", JSON.toJSONString(req));
		
		BaseResponseEntity<String> entity = new BaseResponseEntity<>();
		Company company = SessionUtils.getCompanyInfo(request);
		if(company != null){
			UploadDataTypeEnum name = UploadDataTypeEnum.getByType(req.getType());
			if(name == null){
				entity.setSuccess(false);
				entity.setErrMsg("没有找到文件类型");
			}else{
				String key = FileUtil.getFileKey(company.getCode(), name.name(), null)+"/"+req.getFileName();
				entity.setData(key);
				entity.setSuccess(true);
			}
		}
		return entity;
	}
	
	/**
	 * 将html页面中所有包含cid的标签全部使用图片url替换掉
	 * @return
	 */
     private String replaceAllCidHtmlFileContent(byte[] buffer,int type){
		String htmlContentStr = "";
		if (buffer == null) {
			return htmlContentStr;
		}
		try {
			htmlContentStr = new String(buffer,"utf-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
			htmlContentStr =  new String(buffer);
		}
		if(htmlContentStr.indexOf("CID:") != -1 || htmlContentStr.indexOf("CID：") != -1){
			htmlContentStr = htmlContentStr.replaceAll("CID:", "cid:");								
		}
		if(htmlContentStr.indexOf("CID:") != -1 || htmlContentStr.indexOf("CID：") != -1){
			htmlContentStr = htmlContentStr.replaceAll("CID：", "cid:");
		}
		if (htmlContentStr.contains("$")) {
			htmlContentStr = htmlContentStr.replaceAll("\\$", "");
		}
		return htmlContentStr;
	}		
	
}
