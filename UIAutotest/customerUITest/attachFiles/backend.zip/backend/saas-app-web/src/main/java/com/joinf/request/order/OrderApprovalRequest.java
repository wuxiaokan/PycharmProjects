package com.joinf.request.order;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * Description: 订单流程请求
 *
 * @author lyj
 * @date 2018年1月19日 上午9:34:31
 */
public class OrderApprovalRequest {

	@ApiModelProperty("订单id集合")
	List<Long> orderIds;

	public List<Long> getOrderIds() {
		return orderIds;
	}

	public void setOrderIds(List<Long> orderIds) {
		this.orderIds = orderIds;
	}

}
