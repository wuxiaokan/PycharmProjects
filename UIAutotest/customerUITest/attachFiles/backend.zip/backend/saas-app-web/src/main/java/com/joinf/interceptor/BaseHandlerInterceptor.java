package com.joinf.interceptor;

import com.joinf.constant.login.LoginContant;
import com.joinf.entity.SessionUser;

public class BaseHandlerInterceptor {
	
	protected String getUserLoginKey(SessionUser user){
		String key = String.format(LoginContant.USER_LOGIN_MESSAGE, user.getOperatorId().toString());
		return key;
	}

}
