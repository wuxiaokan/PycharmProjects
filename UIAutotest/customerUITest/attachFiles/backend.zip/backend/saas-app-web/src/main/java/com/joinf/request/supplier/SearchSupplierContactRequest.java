package com.joinf.request.supplier;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

import com.joinf.utils.base.BasePage;

public class SearchSupplierContactRequest extends BasePage{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6842878014413408817L;
	
	@ApiModelProperty("供应商id集合")
	private List<Long> supplierIds;

	public List<Long> getSupplierIds() {
		return supplierIds;
	}


	public void setSupplierIds(List<Long> supplierIds) {
		this.supplierIds = supplierIds;
	}


	@ApiModelProperty("搜索关键词")
	private String key;


	public String getKey() {
		return key;
	}


	public void setKey(String key) {
		this.key = key;
	}

}
