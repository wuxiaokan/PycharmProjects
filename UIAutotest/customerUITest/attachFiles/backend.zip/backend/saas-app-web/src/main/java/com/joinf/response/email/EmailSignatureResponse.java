package com.joinf.response.email;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 邮件签名返回对象
 * @date 2018年1月16日 上午10:49:23
 */
public class EmailSignatureResponse extends EmailSimpleResponse{
	@ApiModelProperty(value = "签名存储的key")
	private String url;

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
	
}
