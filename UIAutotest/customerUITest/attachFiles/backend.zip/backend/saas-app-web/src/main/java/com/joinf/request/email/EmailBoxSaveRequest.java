package com.joinf.request.email;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 新增或修改自定义箱参数
 * @date 2018年1月7日 下午4:52:18
 */
public class EmailBoxSaveRequest  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value="主键id")
	private Long id;
	
	@ApiModelProperty(value="箱子名称",required=true)
	private String name;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
}
