package com.joinf.request.clouddish;

import com.joinf.utils.base.BasePage;

import io.swagger.annotations.ApiModelProperty;

public class QueryColudDishFileRequest extends BasePage{
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -3320381824460530195L;

	@ApiModelProperty("0[共享] 1[个人]")
	private Integer type;
	
	@ApiModelProperty("文件id")
	private Long catalogueId;
	
	@ApiModelProperty("数据id")
	private Long dataId;
	
	@ApiModelProperty(value ="排序字段")
	private String sortColumn;
	
	@ApiModelProperty(value ="排序类别")
	private String sortType;
	
	@ApiModelProperty(value ="关键词")
	private String key;

	public Long getDataId() {
		return dataId;
	}

	public void setDataId(Long dataId) {
		this.dataId = dataId;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}


	public Long getCatalogueId() {
		return catalogueId;
	}

	public void setCatalogueId(Long catalogueId) {
		this.catalogueId = catalogueId;
	}

	public String getSortColumn() {
		return sortColumn;
	}

	public void setSortColumn(String sortColumn) {
		this.sortColumn = sortColumn;
	}

	public String getSortType() {
		return sortType;
	}

	public void setSortType(String sortType) {
		this.sortType = sortType;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

}
