package com.joinf.request.customer;

import java.util.List;

import com.joinf.dto.CustomerTagDto;

/**
 * Description: 客户标签请求对象
 * @author cuichuanlei
 * @created 2019年2月26日 下午2:57:10
 */
public class OperateCustomerTagRequest {
	
	/**标签ID */
    private Long id;
	/**标签内容*/
    private String content;
    /**颜色*/
    private String color;
    /**标志*/
    private Integer flag;
    
    /**客户ID*/
    private String customerId;
    
    /**标签列表*/
    private List<CustomerTagDto> tagList;
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public Integer getFlag() {
		return flag;
	}
	public void setFlag(Integer flag) {
		this.flag = flag;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public List<CustomerTagDto> getTagList() {
		return tagList;
	}
	public void setTagList(List<CustomerTagDto> tagList) {
		this.tagList = tagList;
	}

}