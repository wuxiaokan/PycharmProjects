(function (Mibew, _) {
	let revision = 0
	Mibew.options = {}
	Mibew.Objects = {}
	Mibew.app = {
		start(options) {
			Mibew.options = options
			Mibew.Objects.server = new Mibew.Server(_.extend({
					'interactionType': MibewAPIUsersInteraction
				},
				Mibew.options.server
			));
			Mibew.Objects.server.runUpdater();
			Mibew.Objects.server.callFunctionsPeriodically(
				function () {
					// Build functions list
					return [{
						"function": "update",
						"arguments": {
							"return": {},
							"references": {},
							"agentId": Mibew.options.agent.id+''
						}
					}];
				},
				function () {

				}
			);
			Mibew.app.update()
			
		},
		update() {
			Mibew.Objects.server.callFunctionsPeriodically(
				function () {
					return [{
							'function': 'currentTime',
							'arguments': {
								'agentId': Mibew.options.agent.id + '',
								'return': {
									'time': 'currentTime'
								},
								'references': {}
							}
						},
						{
							'function': 'updateThreads',
							'arguments': {
								'agentId': Mibew.options.agent.id +'',
								'revision': revision,
								'return': {
									'threads': 'threads',
									'lastRevision': 'lastRevision'
								},
								'references': {}
							}
						}
					];
				},
				function(args) {
					console.log(args)
				}
			);
		},
		updateThreads(args) {
			revision = args.lastRevision;
			console.log(args)
		}
	}

})(Mibew, _);

(function (Mibew, _) {

})(Mibew, _);