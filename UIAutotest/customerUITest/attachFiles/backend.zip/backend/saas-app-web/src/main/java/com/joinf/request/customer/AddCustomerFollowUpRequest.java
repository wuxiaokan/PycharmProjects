package com.joinf.request.customer;

import io.swagger.annotations.ApiModelProperty;

import java.util.Date;
import java.util.List;

/**
 * Description: 客户新增请求对象
 *
 * @author lyj
 * @date 2018年1月5日 下午2:39:26
 */
public class AddCustomerFollowUpRequest {
	
	@ApiModelProperty(value="客户id（如果为空表示是日程）",required=true)
	private Long customerId;
	
	@ApiModelProperty(value="联系人id",required=true)
	private Long contactId;
	
	@ApiModelProperty(value="跟进内容",required=true)
	private String contactContent;
	
	@ApiModelProperty(value="背景颜色",required=true)
	private String bgColor;
	
	@ApiModelProperty(value="周期结束时间",required=true)
	private Date cycleEndDay;
	
	@ApiModelProperty(value=" 周期开始时间",required=true)
	private Date cycleStartDay;
	
	@ApiModelProperty(value="跟进类型:customer,quote,order,email",required=true)
	private String followType;
	
	@ApiModelProperty(value="跟进阶段",required=true)
	private Long flowStep;
	
	@ApiModelProperty(value="跟进方式",required=true)
	private Long flowMethod;
	
	@ApiModelProperty(value="计划跟进时间",required=true)
	private Date planningTime;
	
	@ApiModelProperty(value="重复类型 (day每日、week每周、month每月 ;不重复 为空)",required=true)
	private String repeatCycle;
	
	@ApiModelProperty(value="跟进对象（表id）,如果是客户为空",required=true)
	private String followObject;
	
	@ApiModelProperty(value="附件对象集合",required=true)
	private List<Long> attachmentIdList;

	@ApiModelProperty(value="跟进归属模块 0/客户跟进 1/供应商跟进",required=true)
	private Long flowModel;
	
	@ApiModelProperty(value ="跟进周期ID")
    private Long cycleId;
	
	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public Long getContactId() {
		return contactId;
	}

	public void setContactId(Long contactId) {
		this.contactId = contactId;
	}

	public String getContactContent() {
		return contactContent;
	}

	public void setContactContent(String contactContent) {
		this.contactContent = contactContent;
	}

	public String getBgColor() {
		return bgColor;
	}

	public void setBgColor(String bgColor) {
		this.bgColor = bgColor;
	}

	public Date getCycleEndDay() {
		return cycleEndDay;
	}

	public void setCycleEndDay(Date cycleEndDay) {
		this.cycleEndDay = cycleEndDay;
	}

	public Date getCycleStartDay() {
		return cycleStartDay;
	}

	public void setCycleStartDay(Date cycleStartDay) {
		this.cycleStartDay = cycleStartDay;
	}

	public String getFollowType() {
		return followType;
	}

	public void setFollowType(String followType) {
		this.followType = followType;
	}

	public Date getPlanningTime() {
		return planningTime;
	}

	public void setPlanningTime(Date planningTime) {
		this.planningTime = planningTime;
	}

	public String getRepeatCycle() {
		return repeatCycle;
	}

	public void setRepeatCycle(String repeatCycle) {
		this.repeatCycle = repeatCycle;
	}

	public String getFollowObject() {
		return followObject;
	}

	public void setFollowObject(String followObject) {
		this.followObject = followObject;
	}

	public Long getFlowStep() {
		return flowStep;
	}

	public void setFlowStep(Long flowStep) {
		this.flowStep = flowStep;
	}

	public List<Long> getAttachmentIdList() {
		return attachmentIdList;
	}

	public void setAttachmentIdList(List<Long> attachmentIdList) {
		this.attachmentIdList = attachmentIdList;
	}

	public Long getFlowMethod() {
		return flowMethod;
	}

	public void setFlowMethod(Long flowMethod) {
		this.flowMethod = flowMethod;
	}

	public Long getFlowModel() {
		return flowModel;
	}

	public void setFlowModel(Long flowModel) {
		this.flowModel = flowModel;
	}

	public Long getCycleId() {
		return cycleId;
	}

	public void setCycleId(Long cycleId) {
		this.cycleId = cycleId;
	}
	

}
