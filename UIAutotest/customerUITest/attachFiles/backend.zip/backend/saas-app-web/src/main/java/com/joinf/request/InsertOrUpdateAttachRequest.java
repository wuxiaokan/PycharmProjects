package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

import com.joinf.response.EditDetailResponse;

/**
 * Description: 新增或修改（关联对象例如 供应商修改联系人） 参数
 *
 * @author lyj
 * @date 2017年12月11日 下午7:23:49
 */
public class InsertOrUpdateAttachRequest {

	@ApiModelProperty(value="主键id",required=true)
	private Long id;
	
	@ApiModelProperty(value="关联id(比如修改联系人 对应的供应商id)",required=true)
	private Long attachId ;
	
	@ApiModelProperty(value="参数集合",required=true)
	private List<InsertOrUpdateModel> models;
	
	@ApiModelProperty(value="原始数据",required=true)
	private List<EditDetailResponse> oldValue;

	public List<EditDetailResponse> getOldValue() {
		return oldValue;
	}

	public void setOldValue(List<EditDetailResponse> oldValue) {
		this.oldValue = oldValue;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<InsertOrUpdateModel> getModels() {
		return models;
	}

	public void setModels(List<InsertOrUpdateModel> models) {
		this.models = models;
	}

	public Long getAttachId() {
		return attachId;
	}

	public void setAttachId(Long attachId) {
		this.attachId = attachId;
	}
}
