package com.joinf.interceptor.system;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.joinf.annotations.JoinfInsertOrUpdateLog;
import com.joinf.constants.Customize;
import com.joinf.dto.CustomizeDictDto;
import com.joinf.dto.InsertOrUpdateDto;
import com.joinf.utils.dto.log.LogDataInfoDto;
import com.joinf.dto.LogParam;
import com.joinf.dto.log.LogInsertOrUpdateReturnDto;
import com.joinf.dto.supplier.SupplierDetailDto;
import com.joinf.eslog.IndexLogInfoLogUtils;
import com.joinf.interfaces.CommonManager;
import com.joinf.interfaces.LogInfoEsService;
import com.joinf.response.CustomizeDictResponse;
import com.joinf.response.EditDetailResponse;
import com.joinf.service.CustomizeServiceImpl;
import com.joinf.service.redis.RedisService;
import com.joinf.utils.util.DateFormtContants;
import com.joinf.utils.util.DateUtil;

/**
 * Description: 新增或修改日志处理
 *
 * @author lyj
 * @date 2018年1月12日 上午10:07:05
 */
@Aspect
@Component
public class InsertOrUpdateLogAspect {
	
	@Autowired
	private CommonManager commonManager;
	
	@Autowired
	private RedisService redisService;
	
	@Autowired
	private LogInfoEsService logInfoEsService;
	
	@Autowired
	private IndexLogInfoLogUtils indexLogInfoLogUtils;
	
	/**
	 * 方法执行前
	 * @param jp
	 * @param dto
	 */
	@Before(argNames="dto",value="@annotation(com.joinf.annotations.JoinfInsertOrUpdateLog)&&args(dto,..)")
	public void beforeMethod(JoinPoint jp,InsertOrUpdateDto dto){
		Integer type = 1;//默认修改
		if(dto.getId() == null)//新增
			type = 2;
		JoinfInsertOrUpdateLog joinfLog = getAnnotation(jp);
		String tableName = joinfLog.type().getTableName();
		String moudle = joinfLog.type().getModule();
		Long resourceId = joinfLog.type().getResourceId();
		
		//查询修改前数据参数
		SupplierDetailDto param = new SupplierDetailDto();
		param.setId(dto.getId());
		param.setOperatorId(dto.getSwitchOperatorId());
		param.setCompanyId(dto.getCompanyId());
		param.setRoleId(dto.getRoleId());
		param.setResourceId(resourceId);
		param.setTableName(tableName);
		param.setModule(moudle);
		//日志参数
		LogParam logParam = new LogParam();
		logParam.setCompanyId(dto.getCompanyId());
		logParam.setOperatorId(dto.getSwitchOperatorId());
		logParam.setOperatorName(redisService.queryOperatorName(dto.getCompanyId(), dto.getOperatorId(), dto.getSwitchOperatorId()));;
		logParam.setOperatorTime(DateUtil.format(new Date(), "yyyy-MM-dd'T'HH:mm:ss.SSSXXX"));
		List<LogDataInfoDto> dataInfos = new ArrayList<>();
		LogDataInfoDto dataInfo = new LogDataInfoDto();
		dataInfos.add(dataInfo);
		logParam.setDataInfos(dataInfos);
		if(type == 1){//修改
			logParam.setEventType("update");
			logParam.setOperatorType("编辑");
			
			dataInfo.setEventType("update");
			dataInfo.setEventTypeDes("修改");
		}
		else if(type == 2){//新增
			if(dto.getAttachId() !=null){//如果是关联新增 比如供应商增加联系人
				logParam.setEventType("update");
				logParam.setOperatorType("编辑");
			}else{
				logParam.setEventType("insert");
				logParam.setOperatorType("新增");
			}
			dataInfo.setEventType("insert");
			dataInfo.setEventTypeDes("新增");
		}
		if(tableName.equals(Customize.CustomerEdit.getTableName())){//客户
			//改成前端读取后保存时提及回来
//			if(type ==1)//在修改前保存旧的值
//				dto.setOldValue(customerManager.getCustomerEditArray(param));
			logParam.setObjectId(dto.getId());
			logParam.setTableName(Customize.CustomerEdit.getLogTableName());
			
			dataInfo.setTable(Customize.CustomerEdit.getLogTableName());
			dataInfo.setTableName(Customize.CustomerEdit.getLogTableName());
		}
		else if(tableName.equals(Customize.CustomerContactList.getTableName())){//客户联系人
//			if(type ==1)//在修改前保存旧的值
//				dto.setOldValue(customerContactManager.getCustomerContactEditArray(param));
			logParam.setObjectId(dto.getAttachId());//客户id
			logParam.setTableName(Customize.CustomerEdit.getLogTableName());
			
			dataInfo.setTable(Customize.CustomerContactList.getLogTableName());
			dataInfo.setTableName(Customize.CustomerContactList.getLogTableName());
		}
		else if(tableName.equals(Customize.SupplierList.getTableName())){//供应商
//			if(type ==1)//在修改前保存旧的值
//				logParam.setObjectId(dto.getId());
//			dto.setOldValue(supplierManager.getSupplierEditArray(param));
			logParam.setObjectId(dto.getId());
			logParam.setTableName(Customize.SupplierList.getLogTableName());
			
			dataInfo.setTable(Customize.SupplierList.getLogTableName());
			dataInfo.setTableName(Customize.SupplierList.getLogTableName());
		}
		else if(tableName.equals(Customize.SupplierContactList.getTableName())){//供应商联系人
//			if(type ==1)//在修改前保存旧的值
//				dto.setOldValue(supplierContactManager.getSupplierContactEditArray(param));
			logParam.setObjectId(dto.getAttachId());//供应商id
			logParam.setTableName(Customize.SupplierList.getLogTableName());
			
			dataInfo.setTable(Customize.SupplierContactList.getLogTableName());
			dataInfo.setTableName(Customize.SupplierContactList.getLogTableName());
		}
		else if(tableName.equals(Customize.SupplierBank.getTableName())){//供应商银行
//			if(type ==1)//在修改前保存旧的值
//				dto.setOldValue(supplierContactManager.getSupplierContactEditArray(param));
			logParam.setObjectId(dto.getAttachId());//供应商id
			logParam.setTableName(Customize.SupplierList.getLogTableName());
			
			dataInfo.setTable(Customize.SupplierBank.getLogTableName());
			dataInfo.setTableName(Customize.SupplierBank.getLogTableName());
		}
		else if(tableName.equals(Customize.Product.getTableName())){//产品
//			if(type ==1)//在修改前保存旧的值
//				dto.setOldValue(supplierContactManager.getSupplierContactEditArray(param));
			logParam.setObjectId(dto.getId());//供应商id
			logParam.setTableName(Customize.Product.getLogTableName());
			
			dataInfo.setTable(Customize.Product.getLogTableName());
			dataInfo.setTableName(Customize.Product.getLogTableName());
		//商机
		}else if(tableName.equals(Customize.BusinessEdit.getTableName())){
			logParam.setObjectId(dto.getId());//数据 id(订单、报价、邮件、EDM、商机、跟进等)
			
			logParam.setTableName(Customize.BusinessEdit.getLogTableName());
			
			dataInfo.setTable(Customize.BusinessEdit.getLogTableName());
			dataInfo.setTableName(Customize.BusinessEdit.getLogTableName());
		}
		dto.setLogParam(logParam);
	}
	
	/**
	 * 方法执行后
	 * @param jp
	 * @param result
	 */
	@AfterReturning(returning="result",pointcut="@annotation(com.joinf.annotations.JoinfInsertOrUpdateLog)")
	public void afterMethodInvoke(JoinPoint jp,LogInsertOrUpdateReturnDto result){
		String data = null;
		InsertOrUpdateDto dto = (InsertOrUpdateDto) jp.getArgs()[0];
		JSONObject newValues = result.getNewValues();
		StringBuffer changeStr = new StringBuffer();
		boolean insert = false;
		if(newValues != null&&dto.getOldValue()!=null){//修改数据
			Long id = result.getDataId();
			if(id !=null){
				String columnName = "";
				String columnId = "";
				if(dto.getOldValue() == null) return;
				for(EditDetailResponse detail:dto.getOldValue()){
					if(detail.getOneToMany() == 1||detail.getType() == -1)continue;
					columnId = detail.getId();
					columnId = CustomizeServiceImpl.dealColumn(null,columnId);
					if(columnId.toLowerCase().contains("create")//下次跟进时间和创建人
							|| columnId.toLowerCase().contains("lastfollowtime"))continue;
					String dataDictionary = ""; 
					Integer dateProperty=1;
					if(detail.getCustomizeColumn() !=null){
						columnName = detail.getCustomizeColumn().getColumnName();
						dataDictionary = detail.getCustomizeColumn().getDataDictionary();
						dateProperty = detail.getCustomizeColumn().getProperty();
					}
					else{
						dataDictionary = detail.getCustomizeResourceColumn().getDataDictionary();
						columnName = detail.getCustomizeResourceColumn().getColumnName();
						dateProperty = detail.getCustomizeResourceColumn().getProperty();
					}
					if(newValues.containsKey(columnId)){
						String newValue = newValues.getString(columnId);
						Object originalValue = detail.getOriginalValue();
						if(originalValue == null)
							originalValue= "";
						if(originalValue!=null &&originalValue instanceof Date)
							originalValue = ((Date)originalValue).getTime();
						if(!newValue.equals(String.valueOf(originalValue))){
							if(detail.isAsync()){//异步加载数据
								List<Object> values = new ArrayList<Object>();
								values.add(newValue);
								CustomizeDictDto dictDto = new CustomizeDictDto();
								dictDto.setAddBigDict(false);
								dictDto.setAddDict(false);
								dictDto.setValueIds(values);
								dictDto.setType(detail.getType());
								dictDto.setDataDictionary(dataDictionary);
								dictDto.setOperatorId(dto.getOperatorId());
								dictDto.setCompanyId(dto.getCompanyId());
								CustomizeDictResponse resonse = commonManager.getDictCollection(dictDto);
								if(resonse.getValues() !=null)
									newValue = String.valueOf(resonse.getValues().get(String.valueOf(newValue)));
							}
							else if(detail.getDictionarys()!=null){
								JSONArray array = detail.getDictionarys();
								String[] arrayNewValue = newValue.split(",");
								StringBuffer matchValue = new StringBuffer();
								for(int i=0;i<array.size();i++){
									JSONObject object =array.getJSONObject(i);
									for(int j=0;j< arrayNewValue.length;j++){
										String nv = arrayNewValue[j];
										if(nv.equals(object.getString("id"))){//根据id匹配
											if(object.containsKey("chineseName"))
												matchValue.append(object.getString("chineseName"));
											else
												matchValue.append(object.getString("name"));
											if(j != (arrayNewValue.length-1))
												matchValue.append(",");
											break;
										}
										else if(nv.equals(object.getString("value"))){//根据value匹配
											if(object.containsKey("chineseName"))
												matchValue.append(object.getString("chineseName"));
											else
												matchValue.append(object.getString("name"));
											if(j != (arrayNewValue.length-1))
												matchValue.append(",");
											break;
										}
									}
									if(StringUtils.isNotBlank(matchValue.toString()))
										newValue = matchValue.toString();
								}
							}
							Object oldValue = convetValue(detail.getValue(), detail, dateProperty);
							newValue = (String) convetValue(newValue, detail, dateProperty);
							changeStr.append(columnName);
							changeStr.append(":");
							changeStr.append(oldValue);
							changeStr.append(">");
							changeStr.append(newValue);
							changeStr.append(";");
						}
					}
				}
				data = changeStr.toString();
			}
		}
		else if(result.getInsertValues() != null){//新增
			insert = true;
			StringBuffer inserts = new StringBuffer();
			JSONObject insertValues = result.getInsertValues();
			Iterator<String> iterator = insertValues.keySet().iterator();
			while(iterator.hasNext()){
				String key = iterator.next();
				String value = insertValues.getString(key);
				inserts.append(value);
				if(iterator.hasNext())
					inserts.append("; ");
			}
			data = inserts.toString();
		}
		if(StringUtils.isNotBlank(data)||insert){
			LogParam logParam = dto.getLogParam();
			if(logParam.getObjectId() == null)
			{
				logParam.setObjectId(result.getDataId());
			}
			
			//商机
			if(logParam.getTableName().equals(Customize.BusinessEdit.getTableName())){
				logParam.setBusinessId(logParam.getObjectId());
				logParam.setCid(result.getCustomerId());
			}
			
			logParam.getDataInfos().get(0).setData(data);
			logParam.getDataInfos().get(0).setExtendInfoName(result.getName());
			logParam.setContactId(result.getContactId());
			logParam.setContactName(result.getContactName());
			
			//设置搜索参数
			indexLogInfoLogUtils.setBasicData(logParam.getLog());
			
			logInfoEsService.indexLogInfo(logParam);
		}
	}
	
	/**
	 * 转换值
	 * @param value
	 * @param detail
	 * @param dateProperty
	 * @return
	 */
	private Object convetValue(Object value,EditDetailResponse detail,Integer dateProperty){
		if(value== null ||StringUtils.isBlank(String.valueOf(value)))
			value=" ";
		else if(detail.getType() !=null&&detail.getType().equals(CustomizeServiceImpl.CUSTOMIZE_DATA_TYPE_3)){// 日期
			SimpleDateFormat format = null;
			if(dateProperty== null||dateProperty==1){//当前年月日
				format = new SimpleDateFormat(DateFormtContants.FORMAT_YYYY_MM_DD);
			}
			else if(dateProperty == 2){//当前年月日+时间
				
				format = new SimpleDateFormat(DateFormtContants.FORMAT_YYYY_MM_DD_HH_MM);
			}
			if(format != null){
				Date d;
				if(value instanceof Date){
					d = ((Date)value);
				}
				else
					d = new Date(Long.parseLong(value.toString())); 
				value = format.format(d);
			}
		}
		else if(detail.getType().equals(6) &&("0".equals(String.valueOf(value)))){//处理字典值为0的情况
			value=" ";
		}
		return value;
	}

	/**
	 * 获取注解
	 * @param jp
	 * @return
	 */
	private static JoinfInsertOrUpdateLog getAnnotation(JoinPoint jp){
		Signature signature = jp.getSignature();    
		MethodSignature methodSignature = (MethodSignature)signature;    
		Method targetMethod = methodSignature.getMethod(); 
		return targetMethod.getAnnotation(JoinfInsertOrUpdateLog.class);
	}
}
