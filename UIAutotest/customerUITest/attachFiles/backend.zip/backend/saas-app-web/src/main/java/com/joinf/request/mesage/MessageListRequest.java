package com.joinf.request.mesage;

import java.io.Serializable;

import com.joinf.utils.base.BasePage;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * 消息请求列表对象
 * 
 * @author CyNick
 *
 */
public class MessageListRequest extends BasePage implements Serializable {

	private static final long serialVersionUID = -7217815382180098509L;

	/**
	 * tab 类型 0 全部 1 客户 2 邮件 3 审批 4 营销网站
	 */
	@ApiModelProperty(value = "类型 0 全部 1 客户 2 邮件 3 审批 4 营销网站")
	private Long type;

	public Long getType() {
		return type;
	}

	public void setType(Long type) {
		this.type = type;
	}

}
