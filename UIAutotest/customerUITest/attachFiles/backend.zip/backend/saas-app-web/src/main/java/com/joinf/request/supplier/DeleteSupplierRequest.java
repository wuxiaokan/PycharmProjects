package com.joinf.request.supplier;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * Description: 删除供应商参数
 *
 * @author lyj
 * @date 2017年12月12日 上午10:30:22
 */
public class DeleteSupplierRequest {
	
	@ApiModelProperty(value="删除供应商id集合",required=true)
	private List<Long> supplierIds;

	public List<Long> getSupplierIds() {
		return supplierIds;
	}

	public void setSupplierIds(List<Long> supplierIds) {
		this.supplierIds = supplierIds;
	}

}
