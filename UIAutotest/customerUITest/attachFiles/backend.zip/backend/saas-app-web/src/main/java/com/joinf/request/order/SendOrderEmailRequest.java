package com.joinf.request.order;

import java.util.List;

/**
 * Description: 发送报价邮件
 *
 * @author lyj
 * @date 2018年4月10日 下午3:46:36
 */
public class SendOrderEmailRequest {

	private Long templateId;

	private List<Long> quoteIds;

	private String suffix;

	public Long getTemplateId() {
		return templateId;
	}

	public void setTemplateId(Long templateId) {
		this.templateId = templateId;
	}

	public List<Long> getQuoteIds() {
		return quoteIds;
	}

	public void setQuoteIds(List<Long> quoteIds) {
		this.quoteIds = quoteIds;
	}

	public String getSuffix() {
		return suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

}
