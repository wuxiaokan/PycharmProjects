package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 搜索公司参数
 *
 * @author lyj
 * @date 2018年3月12日 上午10:30:31
 */
public class SearchCompanyRequest {
	
	@ApiModelProperty("关键词")
	private String keywords;
	
	@ApiModelProperty("第几页")
	private Integer pageNum;
	
	@ApiModelProperty("页大小")
	private Integer pageSize;

	public String getKeywords() {
		return keywords;
	}

	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}

	public Integer getPageNum() {
		return pageNum;
	}

	public void setPageNum(Integer pageNum) {
		this.pageNum = pageNum;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

}
