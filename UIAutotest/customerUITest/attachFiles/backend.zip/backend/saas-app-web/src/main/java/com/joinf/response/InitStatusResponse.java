package com.joinf.response;

import io.swagger.annotations.ApiModelProperty;

public class InitStatusResponse {
	
	@ApiModelProperty(value="状态：-1:为初始化1:初始化成功/-2:正在初始化'",required=true)
	private Integer flag;

	public Integer getFlag() {
		return flag;
	}

	public void setFlag(Integer flag) {
		this.flag = flag;
	}
}
