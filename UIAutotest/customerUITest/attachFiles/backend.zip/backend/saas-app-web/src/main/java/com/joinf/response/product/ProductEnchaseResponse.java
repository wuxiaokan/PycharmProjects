package com.joinf.response.product;

import io.swagger.annotations.ApiModelProperty;

public class ProductEnchaseResponse {
	
	@ApiModelProperty(value ="装箱标识")
    private Long id;

    @ApiModelProperty(value ="产品ID")
    private Long productId;

    @ApiModelProperty(value ="基础数据ID(包装单位)")
    private Long packId;

    @ApiModelProperty(value ="每件数量")
    private String decorate;

    @ApiModelProperty(value ="长")
    private String length;

    @ApiModelProperty(value ="宽")
    private String width;

    @ApiModelProperty(value ="高")
    private String height;

    @ApiModelProperty(value ="尺寸描述")
    private String description;

    @ApiModelProperty(value ="单毛重")
    private String grossWeight;

    @ApiModelProperty(value ="单净重")
    private String suttleWeight;

    @ApiModelProperty(value ="体积")
    private String bulk;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Long getPackId() {
		return packId;
	}

	public void setPackId(Long packId) {
		this.packId = packId;
	}

	public String getDecorate() {
		return decorate;
	}

	public void setDecorate(String decorate) {
		this.decorate = decorate;
	}

	public String getLength() {
		return length;
	}

	public void setLength(String length) {
		this.length = length;
	}

	public String getWidth() {
		return width;
	}

	public void setWidth(String width) {
		this.width = width;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getGrossWeight() {
		return grossWeight;
	}

	public void setGrossWeight(String grossWeight) {
		this.grossWeight = grossWeight;
	}

	public String getSuttleWeight() {
		return suttleWeight;
	}

	public void setSuttleWeight(String suttleWeight) {
		this.suttleWeight = suttleWeight;
	}

	public String getBulk() {
		return bulk;
	}

	public void setBulk(String bulk) {
		this.bulk = bulk;
	}


}
