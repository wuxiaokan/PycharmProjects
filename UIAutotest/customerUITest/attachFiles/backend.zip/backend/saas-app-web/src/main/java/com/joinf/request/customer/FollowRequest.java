package com.joinf.request.customer;

import java.io.Serializable;

import com.joinf.utils.base.BasePage;

import io.swagger.annotations.ApiModelProperty;

/**
 * 跟进列表查询参数
 * 
 * @author CyNick
 *
 */
public class FollowRequest extends BasePage implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "跟进归属模块", required = true)
	private Integer flowModel;

	@ApiModelProperty(value = "排序字段")
	private String sortColumn;

	@ApiModelProperty(value = "排序方式")
	private String sortType;

	@ApiModelProperty(value = "是否云搜索")
	private boolean cloudSearch;

	@ApiModelProperty(value = "搜索关键字")
	private String key;

	@ApiModelProperty(value = "搜索的字段，用逗号分隔")
	private String fields;
	
	@ApiModelProperty(value = "1 每客户最新跟进 , 0 全部跟进")
	private String listType;
	
	@ApiModelProperty(value = "0 未执行 1 已执行 2 部分执行")
	private String doneFlag;
	
	public Integer getFlowModel() {
		return flowModel;
	}

	public void setFlowModel(Integer flowModel) {
		this.flowModel = flowModel;
	}

	public String getSortColumn() {
		return sortColumn;
	}

	public void setSortColumn(String sortColumn) {
		this.sortColumn = sortColumn;
	}

	public String getSortType() {
		return sortType;
	}

	public void setSortType(String sortType) {
		this.sortType = sortType;
	}

	public boolean isCloudSearch() {
		return cloudSearch;
	}

	public void setCloudSearch(boolean cloudSearch) {
		this.cloudSearch = cloudSearch;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getFields() {
		return fields;
	}

	public void setFields(String fields) {
		this.fields = fields;
	}

	public String getListType() {
		return listType;
	}

	public void setListType(String listType) {
		this.listType = listType;
	}

	public String getDoneFlag() {
		return doneFlag;
	}

	public void setDoneFlag(String doneFlag) {
		this.doneFlag = doneFlag;
	}

}
