package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 重置密码参数
 *
 * @author lyj
 * @date 2017年12月22日 下午2:03:56
 */
public class ResetPasswordRequest {
	
	@ApiModelProperty(value="用户名",required=true)
	private String loginName;
	
	@ApiModelProperty(value="新密码(base64加密)",required=true)
	private String password;
	
	@ApiModelProperty(value="手机号",required=true)
	private String mobile;
	
	@ApiModelProperty(value="邮箱号",required=true)
	private String email;

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
