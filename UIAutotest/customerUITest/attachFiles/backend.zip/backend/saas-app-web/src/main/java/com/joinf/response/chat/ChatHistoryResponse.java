package com.joinf.response.chat;

import com.alibaba.fastjson.annotation.JSONField;

import io.swagger.annotations.ApiModelProperty;

public class ChatHistoryResponse {
	
	@JSONField(name="threadid")
	@ApiModelProperty("会话id")
	private Integer threadId;
	
	@JSONField(name="username")
	@ApiModelProperty("用户名")
	private String userName;
	
	@ApiModelProperty("来源ip")
	private String remote;
	
	@JSONField(name="agentname")
	@ApiModelProperty("客服名称")
	private String agentName;
	
	@ApiModelProperty("来源网址")
	private String referer;
	
	@ApiModelProperty("会话创建时间（时间戳（秒））")
	@JSONField(name="dtmcreated")
	private Integer dtmCreated;
	
	@ApiModelProperty("聊天记录")
	private String message;
	
	@ApiModelProperty("聊天时长")
	@JSONField(name="chattime")
	private Integer chatTime;
	
	@ApiModelProperty("邮箱")
	private String email;
	
	@ApiModelProperty("客户名称")
	private String customerName;
	
	@ApiModelProperty("客户id")
	private Long customerId;
	
	@ApiModelProperty("客户头像图片")
	private String customerImageUrl;


	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getCustomerImageUrl() {
		return customerImageUrl;
	}

	public void setCustomerImageUrl(String customerImageUrl) {
		this.customerImageUrl = customerImageUrl;
	}

	public Integer getThreadId() {
		return threadId;
	}

	public void setThreadId(Integer threadId) {
		this.threadId = threadId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getRemote() {
		return remote;
	}

	public void setRemote(String remote) {
		this.remote = remote;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	public String getReferer() {
		return referer;
	}

	public void setReferer(String referer) {
		this.referer = referer;
	}

	public Integer getDtmCreated() {
		return dtmCreated;
	}

	public void setDtmCreated(Integer dtmCreated) {
		this.dtmCreated = dtmCreated;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Integer getChatTime() {
		return chatTime;
	}

	public void setChatTime(Integer chatTime) {
		this.chatTime = chatTime;
	}

}
