package com.joinf.response.email;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.joinf.helper.LongJsonDeserializer;
import com.joinf.helper.LongJsonSerializer;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 邮件附件信息
 * @date 2018年1月13日 下午6:29:36
 */
public class EmailAttachmentResponse {
	@JsonSerialize(using = LongJsonSerializer.class)
	@JsonDeserialize(using = LongJsonDeserializer.class)
	@ApiModelProperty(value="id")
    private Long id;
	@ApiModelProperty(value="附件原名")
    private String fileName;
    @ApiModelProperty(value="oss存储key")
    private String fileCode;
    @ApiModelProperty(value="附件大小")
    private Long fileSize;
    @ApiModelProperty(value = "附件后缀", example = "jpg")
    private String fileSuffix;
    @ApiModelProperty(value="访问地址")
    private String url;
    
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public Long getId() {
		return id;
	}
	public String getFileCode() {
		return fileCode;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public void setFileCode(String fileCode) {
		this.fileCode = fileCode;
	}
	public Long getFileSize() {
		return fileSize;
	}
	public String getFileSuffix() {
		return fileSuffix;
	}
	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}
	public void setFileSuffix(String fileSuffix) {
		this.fileSuffix = fileSuffix;
	}
    
    
    
}
