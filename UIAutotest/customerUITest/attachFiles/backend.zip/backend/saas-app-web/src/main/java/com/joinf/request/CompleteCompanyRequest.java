package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

public class CompleteCompanyRequest {
	
	@ApiModelProperty(value="用户中心公司id",required=true)
	private Long centerCompanyId;
	
	@ApiModelProperty(value="用户中心用户id",required=true)
	private Long centerUserId;
	
	@ApiModelProperty(value="联系人",required=true)
	private String contactName;
	
	@ApiModelProperty(value="邮箱",required=true)
	private String email;
	
	@ApiModelProperty(value="手机",required=true)
	private String mobile;
	
	@ApiModelProperty(value="公司名",required=true)
	private String name;
	
	@ApiModelProperty(value="性别",required=true)
	private String sex;
	
	@ApiModelProperty(value="验证码(校验类型=0为空)",required=true)
	private String captcha;
	
	@ApiModelProperty(value="随机码(校验类型=0为空)",required=true)
	private String random;
	
	@ApiModelProperty(value="校验类型：0都不校验，1手机，2邮箱",required=true)
	private Integer checkType;
	
	@ApiModelProperty(value="邀请码",required=true)
	private String invitationCode;
	
	@ApiModelProperty(value ="省份")
    private String province;

    @ApiModelProperty(value ="城市")
    private String city;

    @ApiModelProperty(value ="县区")
    private String area;

    @ApiModelProperty(value ="地址")
    private String address;
    
	public String getInvitationCode() {
		return invitationCode;
	}

	public void setInvitationCode(String invitationCode) {
		this.invitationCode = invitationCode;
	}


	public Long getCenterCompanyId() {
		return centerCompanyId;
	}

	public void setCenterCompanyId(Long centerCompanyId) {
		this.centerCompanyId = centerCompanyId;
	}

	public Long getCenterUserId() {
		return centerUserId;
	}

	public void setCenterUserId(Long centerUserId) {
		this.centerUserId = centerUserId;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getCaptcha() {
		return captcha;
	}

	public void setCaptcha(String captcha) {
		this.captcha = captcha;
	}

	public String getRandom() {
		return random;
	}

	public void setRandom(String random) {
		this.random = random;
	}

	public Integer getCheckType() {
		return checkType;
	}

	public void setCheckType(Integer checkType) {
		this.checkType = checkType;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	

}
