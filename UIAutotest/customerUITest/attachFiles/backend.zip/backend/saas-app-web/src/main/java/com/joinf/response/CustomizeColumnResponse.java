package com.joinf.response;

import java.io.Serializable;

/**
 * Description: 自定义字段返回实体类
 *
 * @author lyj
 * @date 2017年12月5日 下午7:07:05
 */
public class CustomizeColumnResponse implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -462615944534357206L;
	// 字段标志
	private Long id;
	// 是否显示:1/显示
	private Integer isShow;
	// 是否只读:0/否
	private Integer isReadonly;
	// 占用行数
	private Integer rows;
	// 占用列数
	private Integer cols;
	// 顺序
	private Integer sort;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Integer getIsShow() {
		return isShow;
	}
	public void setIsShow(Integer isShow) {
		this.isShow = isShow;
	}
	public Integer getIsReadonly() {
		return isReadonly;
	}
	public void setIsReadonly(Integer isReadonly) {
		this.isReadonly = isReadonly;
	}
	public Integer getRows() {
		return rows;
	}
	public void setRows(Integer rows) {
		this.rows = rows;
	}
	public Integer getCols() {
		return cols;
	}
	public void setCols(Integer cols) {
		this.cols = cols;
	}
	public Integer getSort() {
		return sort;
	}
	public void setSort(Integer sort) {
		this.sort = sort;
	}
	
}
