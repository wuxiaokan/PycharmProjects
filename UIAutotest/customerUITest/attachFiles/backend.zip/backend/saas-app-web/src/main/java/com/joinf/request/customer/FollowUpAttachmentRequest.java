package com.joinf.request.customer;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;

/**
 * 跟进附件
 * @author CyNick
 *
 */
public class FollowUpAttachmentRequest implements Serializable{
	
	private static final long serialVersionUID = 1L;
	 
    @ApiModelProperty(value ="附件名称")
    private String fileName;

    @ApiModelProperty(value ="附件大小(字节)")
    private Long fileSize;

    @ApiModelProperty(value ="文件key")
    private String fileCode;

    @ApiModelProperty(value ="附件类型")
    private String fileSuffix;
    
    
    @ApiModelProperty(value ="附件名称")
    private String name;

    @ApiModelProperty(value ="附件大小(字节)")
    private Long size;

    @ApiModelProperty(value ="文件key")
    private String url;

    @ApiModelProperty(value ="附件类型")
    private String type;
    
    
    

    public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Long getSize() {
		size = fileSize;
		return size;
	}

	public void setSize(Long size) {
		this.size = size;
	}

	public String getFileCode() {
		return fileCode;
	}

	public void setFileCode(String fileCode) {
		this.fileCode = fileCode;
	}

	public String getFileSuffix() {
		return fileSuffix;
	}

	public void setFileSuffix(String fileSuffix) {
		this.fileSuffix = fileSuffix;
	}

	public Long getFileSize() {
		return fileSize;
	}

	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}

	public String getName() {
		name = fileName;
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		url = fileCode;
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getType() {
		type = fileSuffix;
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
    
	
	
	
	
    
}
