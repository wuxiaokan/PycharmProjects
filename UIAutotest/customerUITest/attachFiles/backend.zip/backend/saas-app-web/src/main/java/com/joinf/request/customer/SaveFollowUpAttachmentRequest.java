package com.joinf.request.customer;

import java.io.Serializable;
import java.util.List;

import io.swagger.annotations.ApiModelProperty;

/**
 * 新增跟进附件参数
 * @author CyNick
 *
 */
public class SaveFollowUpAttachmentRequest implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value ="跟进附件集合")
	private List<FollowUpAttachmentRequest> list;

	public List<FollowUpAttachmentRequest> getList() {
		return list;
	}

	public void setList(List<FollowUpAttachmentRequest> list) {
		this.list = list;
	}
	
	
    
}
