package com.joinf.response.email;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zlx
 * @Description: 校验邮箱账号返回对象
 * @date 2018年1月8日 上午10:55:48
 */
public class CheckEmailAccountResponse {
	@ApiModelProperty(value = "反馈类型   -1：错误禁止绑定   0：成功   1：弹框提醒,根据用户选择处理")
	private int type;
	@ApiModelProperty(value = "错误或提醒内容")
	private String message;
	
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
