package com.joinf.config.datasource;

import javax.annotation.Resource;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author zlx
 * @Description: 数据源从库1配置
 * @date 2018年5月30日 下午3:52:26
 */
@Component
@ConfigurationProperties(prefix = "sharding.jdbc.datasource.slave0")
public class DatasourceSlave0Properties {
	@Resource
	private DatasourceProperties common;
	
	private String url;
	private String username;
	private String password;
	
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public DatasourceProperties getCommon() {
		return common;
	}
	public void setCommon(DatasourceProperties common) {
		this.common = common;
	}
	
	
	
	

}
