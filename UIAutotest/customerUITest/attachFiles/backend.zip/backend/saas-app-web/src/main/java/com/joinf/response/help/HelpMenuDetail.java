package com.joinf.response.help;

import io.swagger.annotations.ApiModelProperty;

public class HelpMenuDetail {
	
	@ApiModelProperty("id")
	private Long id;
	
	@ApiModelProperty("菜单id")
	private Long menuId;
	
	@ApiModelProperty("内容路径")
	private String contentUrl;
	
	@ApiModelProperty("内容")
	private String content;
	
	@ApiModelProperty("标题")
	private String title;
	
	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getMenuId() {
		return menuId;
	}

	public void setMenuId(Long menuId) {
		this.menuId = menuId;
	}

	public String getContentUrl() {
		return contentUrl;
	}

	public void setContentUrl(String contentUrl) {
		this.contentUrl = contentUrl;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

}
