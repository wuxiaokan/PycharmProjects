package com.joinf.response.clouddish;

import io.swagger.annotations.ApiModelProperty;

public class CloudDishFolderResponse {
	
	@ApiModelProperty(value ="标识")
    private Long id;

    @ApiModelProperty(value ="企业ID")
    private Long companyId;

    @ApiModelProperty(value ="所属者ID(共享目录为空)")
    private Long operatorId;

    @ApiModelProperty(value ="目录名称")
    private String name;

    @ApiModelProperty(value ="父目录ID")
    private Long parentId;

    @ApiModelProperty(value ="有效标志:0/无效;1/有效")
    private Integer flag;

    @ApiModelProperty(value ="层级")
    private Integer level;

    @ApiModelProperty(value ="0[共享] 1[个人]")
    private Integer type;

    @ApiModelProperty(value ="排序")
    private Integer sort;
    
    @ApiModelProperty(value ="文件夹路径")
    private String path;
    
    @ApiModelProperty(value ="上上级id")
	private Long grandparentId;

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public Long getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(Long operatorId) {
		this.operatorId = operatorId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	public Integer getFlag() {
		return flag;
	}

	public void setFlag(Integer flag) {
		this.flag = flag;
	}

	public Integer getLevel() {
		return level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	public Long getGrandparentId() {
		return grandparentId;
	}

	public void setGrandparentId(Long grandparentId) {
		this.grandparentId = grandparentId;
	}


}
