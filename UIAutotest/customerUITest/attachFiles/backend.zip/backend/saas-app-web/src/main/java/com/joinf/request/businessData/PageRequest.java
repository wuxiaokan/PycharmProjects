package com.joinf.request.businessData;

import java.io.Serializable;

/**
 * 分页请求 base对象
 * @author cuichuanlei
 * @created 2019年2月14日
 */
public class PageRequest implements Serializable{
	
	private static final long serialVersionUID = 8649176426000036498L;

	/** 当前页码 */
	private Integer pageNum;

	/** 当前页显示的数量 */
	private Integer pageSize;

	public Integer getPageNum() {
		return pageNum;
	}

	public void setPageNum(Integer pageNum) {
		this.pageNum = pageNum;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	  /**
     * 构造
     * @param start 起始的数值，从第1条开始。
     * @param size 长度。
     * @return
     */
    public PageRequest initOfStart(int start, int size) {
        this.pageNum = start / size;
        this.pageSize = size;
        return this;
    }

    /**
     * 获取开始的数值
     *
     * @return
     */
    public long getStart() {
        if (pageNum == 0) return 0;
        return pageNum * pageSize;
    }

    /**
     * 获取结束的数值
     *
     * @return
     */
    public long getEnd() {
        return getStart() + pageSize;
    }

}