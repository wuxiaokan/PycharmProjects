package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 获取签名请求
 *
 * @author lyj
 * @date 2017年12月29日 上午10:13:00
 */
public class GetOSSPolicyRequest {

	@ApiModelProperty(value="图片类型：1业务员头像",required=true)
	private Integer type;

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}
}
