package com.joinf;

import java.io.InputStream;
import java.util.Scanner;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

/**
 * Description: 启动加载资源文件
 *
 * @author lyj
 * @date 2017年12月19日 下午8:07:01
 */
@Component
public class LoadPermissionJsonRunner implements CommandLineRunner {
	
	public static JSONObject resourceObject;//用户权限
	
	public static JSONArray toolbarArray;//工具栏设置

	@SuppressWarnings("resource")
	@Override
	public void run(String... args) throws Exception {
		InputStream stram = this.getClass().getResourceAsStream("/static/resource.json");
		Scanner scanner = new Scanner(stram, "UTF-8");
		StringBuffer buffer = new StringBuffer();
		while (scanner.hasNext()) {
			buffer.append(scanner.next());
		}
		resourceObject = JSONObject.parseObject(buffer.toString());
		
		StringBuffer toolBuffer = new StringBuffer();
		InputStream toolbar = this.getClass().getResourceAsStream("/static/DefaultToolbar.json");
		scanner = new Scanner(toolbar, "UTF-8");
		while (scanner.hasNext()) {
			toolBuffer.append(scanner.next());
		}
		toolbarArray = JSONArray.parseArray(toolBuffer.toString());
		
		scanner.close();
	}

}
