package com.joinf.request;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 校验是否超过限制
 *
 * @author lyj
 * @date 2018年3月7日 下午2:20:02
 */
public class CheckNumLimitRequest {
	
	@ApiModelProperty("校验类别：1=客户联系人,2=供应商联系人,3供应商银行,4客户跟进")
	private Integer type;
	
	
	@ApiModelProperty("对象id：例如客户id")
	private Long objectId;


	public Integer getType() {
		return type;
	}


	public void setType(Integer type) {
		this.type = type;
	}


	public Long getObjectId() {
		return objectId;
	}


	public void setObjectId(Long objectId) {
		this.objectId = objectId;
	}

}
