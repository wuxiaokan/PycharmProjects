package com.joinf.response.login;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;


/**
 * Description: 初始化请求返回
 *
 * @author lyj
 * @date 2017年12月18日 下午1:45:49
 */
public class InitResponse {

	@ApiModelProperty(value="企业到期提醒",required=true)
	private CompanyDueDto due;
	
	@ApiModelProperty(value="企业到期信息",required=true)
	private CompanyExpireDto expire;
	
	@ApiModelProperty(value="异地登入信息",required=true)
	private OffsiteMsg offsiteMsg;
	
	@ApiModelProperty(value="当前用户权限代码集合",required=true)
	private List<Integer> resources;
	
	public OffsiteMsg getOffsiteMsg() {
		return offsiteMsg;
	}
	
	public void setOffsiteMsg(OffsiteMsg offsiteMsg) {
		this.offsiteMsg = offsiteMsg;
	}

	public CompanyExpireDto getExpire() {
		return expire;
	}

	public void setExpire(CompanyExpireDto expire) {
		this.expire = expire;
	}

	public CompanyDueDto getDue() {
		return due;
	}

	public void setDue(CompanyDueDto due) {
		this.due = due;
	}

	public List<Integer> getResources() {
		return resources;
	}

	public void setResources(List<Integer> resources) {
		this.resources = resources;
	}

}
