package com.joinf.response.email;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;

/**
 * t_email_tag
 */
public class EmailTagResponse implements Serializable {
    @ApiModelProperty(value ="")
    private Long id;

    @ApiModelProperty(value ="企业ID")
    private Long companyId;

    @ApiModelProperty(value ="所属操作员")
    private Long operatorId;

    @ApiModelProperty(value ="")
    private String content;

    @ApiModelProperty(value ="有效标志:0/无效;1/有效")
    private Integer flag;

    @ApiModelProperty(value ="创建者ID")
    private Long createId;

    @ApiModelProperty(value ="创建时间")
    private Date createTime;

    @ApiModelProperty(value ="更新者ID")
    private Long updateId;

    @ApiModelProperty(value ="更新时间")
    private Date updateTime;

    @ApiModelProperty(value ="颜色")
    private String color;
    
    @ApiModelProperty(value ="是否使用")
    private boolean hasUse;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public Long getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(Long operatorId) {
        this.operatorId = operatorId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getUpdateId() {
        return updateId;
    }

    public void setUpdateId(Long updateId) {
        this.updateId = updateId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color == null ? null : color.trim();
    }

	public boolean isHasUse() {
		return hasUse;
	}

	public void setHasUse(boolean hasUse) {
		this.hasUse = hasUse;
	}
    
    
}