package com.joinf.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.collect.Lists;
import com.joinf.annotations.NeedLogin;
import com.joinf.constant.Constants;
import com.joinf.constants.Customize;
import com.joinf.constants.OrderStatus;
import com.joinf.dto.CheckSuccessDto;
import com.joinf.dto.CompanyDTO;
import com.joinf.dto.DeleteOrderAttachmentDto;
import com.joinf.dto.DownLoadFileParam;
import com.joinf.dto.order.QueryOrderDto;
import com.joinf.dto.quote.QuoteFlowDto;
import com.joinf.dto.supplier.SupplierDetailDto;
import com.joinf.entity.SessionUser;
import com.joinf.entity.generator.CustomizeResourceColumn;
import com.joinf.entity.generator.OrderAttachment;
import com.joinf.entity.generator.OrderProduct;
import com.joinf.interfaces.CustomizeResourceColumnService;
import com.joinf.interfaces.FileService;
import com.joinf.interfaces.order.OrderManager;
import com.joinf.interfaces.order.OrderProudctManager;
import com.joinf.request.IdRequest;
import com.joinf.request.order.DeleteOrderRequest;
import com.joinf.request.order.OrderApprovalRequest;
import com.joinf.request.order.QueryOrderProductRequest;
import com.joinf.request.order.QueryOrderRequest;
import com.joinf.request.order.SendOrderEmailRequest;
import com.joinf.request.order.UploadOrderAttachmentRequest;
import com.joinf.request.quote.BatchUpdateQuoteStatusRequest;
import com.joinf.request.quote.QuoteFlowRequest;
import com.joinf.request.quote.UpdateQuoteStatusRequest;
import com.joinf.response.EditDetailResponse;
import com.joinf.response.QueryOrderResponse;
import com.joinf.response.SuccessResponse;
import com.joinf.response.order.OrderAttachmentResponse;
import com.joinf.response.supplier.QuerySupplierResponse;
import com.joinf.service.redis.RedisService;
import com.joinf.utils.BaseEntityUtils;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.annotations.Permission;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.dto.user.UserInfoDto;
import com.joinf.utils.util.JoinfBeanUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * Description: 订单服务
 *
 * @author lyj
 * @date 2018年1月17日 下午5:09:43
 */
@RestController
@RequestMapping("order")
@Api(tags="订单服务")
public class OrderController {


	@Autowired
	private OrderManager orderManager;
	
	@Autowired
	private OrderProudctManager orderProudctManager;

    @Autowired
    private CustomizeResourceColumnService customizeResourceColumnService;

	@Autowired
	private RedisService redisService;
	@Autowired
	private FileService fileService;
	/**
	 * 查询订单列表
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询订单列表", notes="查询订单列表")
	@ApiImplicitParam(name = "req", value = "查询订单列表请求对象", required = true, dataType = "QueryOrderRequest")
	@PostMapping("queryOrderList")
	@Permission(require="order.list.preview")
	public BaseResponseEntity<QuerySupplierResponse> queryOrderList(HttpServletRequest request,@RequestBody QueryOrderRequest req){
		
		QueryOrderDto dto = new QueryOrderDto();
		JoinfBeanUtils.copyProperties(dto, req);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setRoleId(user.getUser().getRoleId());
		dto.setResourceId(Customize.OrderList.getResourceId());
		dto.setTableName(Customize.OrderList.getTableName());
		dto.setModule(Customize.OrderList.getModule());
		
		QueryOrderResponse data = orderManager.selectOrder(dto);
		BaseResponseEntity<QuerySupplierResponse> entity = new BaseResponseEntity<>();
		entity.setSuccess(true);
		
		List<String> showFileds = new ArrayList<String>();
		showFileds.add("saleContractNo");//订单合同号
		showFileds.add("showStatus");//状态
		showFileds.add("currency");//货币名称
		showFileds.add("contactName");//联系人名称
		showFileds.add("customerName");//客户名称
		showFileds.add("signDate");//签约日期
		showFileds.add("contractAmount");//合同总额
		QuerySupplierResponse querySupplierResponse = orderManager.getOrderListArray(dto, data.getOrders(), showFileds);
		Integer decimalNumber = null;
        List<Long> resourceIds = Lists.newArrayList(34l);
        List<String> columnIds = Lists.newArrayList("contractAmount");
        List<CustomizeResourceColumn> customizeResourceColumnList = customizeResourceColumnService.selectListByResourceIdsAndColumnIds(user.getCompanyId(), resourceIds, columnIds);
        if (!CollectionUtils.isEmpty(customizeResourceColumnList)) {
            decimalNumber = customizeResourceColumnList.get(0).getDecimalNumber();
        }
		CompanyDTO companyDTO = SessionUtils.getCenterCompanyInfo(request);
		Long centerId = companyDTO.getCompanyId();
		boolean aFlag = Constants.SZHX_CENTER_ID.equals(centerId) ;
		boolean bFlag = Constants.SZYS_CENTER_ID.equals(centerId);
		boolean cFlag = Constants.RJF_CENTER_ID.equals(centerId);  // 任竞帆
		boolean dFlag = Constants.FFY_CENTER_ID.equals(centerId);  // ffy
		if (aFlag) {
			//decimalNumber = 5;
		} else if (bFlag) {
			decimalNumber = 2;
		} else if (cFlag) {
			decimalNumber = 2;
		} else if (dFlag) {
			decimalNumber = 4;
		}
		querySupplierResponse.setDecimalNumber(decimalNumber);
		entity.setData(querySupplierResponse);
		entity.setTotalRecords(data.getTotal());
		return entity;
	}
	
	@ApiOperation(value="查询订单明细", notes="查询供应商明细")
	@ApiImplicitParam(name = "req", value = "查询订单明细请求对象", required = true, dataType = "IdRequest")
	@PostMapping("getOrderDetail")
	@Permission(require="order.list.preview")
	public BaseResponseEntity<List<EditDetailResponse>> getSupplierDetail(HttpServletRequest request,@RequestBody IdRequest req){
		SupplierDetailDto dto = new SupplierDetailDto();
		dto.setId(req.getId());
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setRoleId(user.getUser().getRoleId());
		dto.setResourceId(Customize.OrderEdit.getResourceId());
		dto.setTableName(Customize.OrderEdit.getTableName());
		dto.setModule(Customize.OrderEdit.getModule());
	
		List<EditDetailResponse> details = orderManager.getOrderEditArray(dto);
		return BaseEntityUtils.successOne(details);
	}
	
	@ApiOperation(value="查询订单产品明细", notes="查询订单产品明细")
	@ApiImplicitParam(name = "req", value = "查询订单产品明细请求对象", required = true, dataType = "IdRequest")
	@PostMapping("getOrderProductDetail")
	@Permission(require="order.list.edit")
	public BaseResponseEntity<List<EditDetailResponse>> getOrderProductDetail(HttpServletRequest request,@RequestBody IdRequest req){
		SupplierDetailDto dto = new SupplierDetailDto();
		dto.setId(req.getId());
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setRoleId(user.getUser().getRoleId());
		
		dto.setResourceId(Customize.OrderProduct.getResourceId());
		dto.setTableName(Customize.OrderProduct.getTableName());
		dto.setModule(Customize.OrderProduct.getModule());
		
		List<EditDetailResponse> details = orderProudctManager.getOrderProductEditArray(dto);
		return BaseEntityUtils.successOne(details);
	}
	
	
	/**
	 * 查询订单列表
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询订单商品列表", notes="查询商品订单列表")
	@ApiImplicitParam(name = "req", value = "查询商品列表请求对象", required = true, dataType = "QueryOrderProductRequest")
	@PostMapping("queryOrderProductList")
	@Permission(require="order.list.preview")
	public BaseResponseEntity<QuerySupplierResponse> queryOrderProductList(HttpServletRequest request,@RequestBody QueryOrderProductRequest req){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		Long companyId = user.getUser().getCompanyId();
		QueryOrderDto dto = new QueryOrderDto();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(companyId);
		dto.setRoleId(user.getUser().getRoleId());
		dto.setResourceId(Customize.OrderProduct.getResourceId());
		dto.setTableName(Customize.OrderProduct.getTableName());
		dto.setModule(Customize.OrderProduct.getModule());
		
		List<OrderProduct> produts = orderProudctManager.getOrderProducts(req.getOrderId(), companyId);
		BaseResponseEntity<QuerySupplierResponse> entity = new BaseResponseEntity<>();
		entity.setSuccess(true);
		QuerySupplierResponse querySupplierResponse = orderProudctManager.getOrderProductListArray(dto, produts, null);
		Integer decimalNumber = null;
        List<Long> resourceIds = Lists.newArrayList(35l);
        List<String> columnIds = Lists.newArrayList("price");
        List<CustomizeResourceColumn> customizeResourceColumnList = customizeResourceColumnService.selectListByResourceIdsAndColumnIds(user.getCompanyId(), resourceIds, columnIds);
        if (!CollectionUtils.isEmpty(customizeResourceColumnList)) {
            decimalNumber = customizeResourceColumnList.get(0).getDecimalNumber();
        }
		CompanyDTO companyDTO = SessionUtils.getCenterCompanyInfo(request);
		Long centerId = companyDTO.getCompanyId();
		boolean aFlag = Constants.SZHX_CENTER_ID.equals(centerId) ;
		boolean bFlag = Constants.SZYS_CENTER_ID.equals(centerId);
		boolean cFlag = Constants.RJF_CENTER_ID.equals(centerId);  // 任竞帆
		boolean dFlag = Constants.FFY_CENTER_ID.equals(centerId);  // ffy
		if (aFlag) {
			decimalNumber = 5;
		} else if (bFlag) {
			decimalNumber = 2;
		} else if (cFlag) {
			decimalNumber = 2;
		} else if (dFlag) {
			decimalNumber = 5;
		}
		querySupplierResponse.setDecimalNumber(decimalNumber);
		entity.setData(querySupplierResponse);
		return entity;
	}
	
	
	/**
	 * 删除订单
	 * @param req
	 * @return
	 */
	@ApiOperation(value="删除订单", notes="删除订单")
	@ApiImplicitParam(name = "req", value = "删除订单请求对象", required = true, dataType = "OrderApprovalRequest")
	@PostMapping("deleteOrders")
	@Permission(require="order.list.delete")
	public BaseResponseEntity<?> deleteOrders(HttpServletRequest request,@RequestBody OrderApprovalRequest req){
		BaseResponseEntity<?> entity = new BaseResponseEntity<>();
		entity.setSuccess(true);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		orderManager.deleteOrderByIds(user.getSwitchOperatorId(), req.getOrderIds());
		return entity;
	}
	
	@ApiOperation(value="订单提交审批流程", notes="订单提交审批流程")
	@PostMapping("submitOrderApproval")
	@ApiImplicitParam(name = "req", value = "订单提交审批流程请求对象", required = true, dataType = "QuoteFlowRequest")
	@NeedLogin
	@Permission(require="order.approval.flowSubmit")
	public BaseResponseEntity<Integer> submitQuoteApproval(HttpServletRequest request,@RequestBody QuoteFlowRequest req){
		BaseResponseEntity<Integer> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		CheckSuccessDto company = SessionUtils.getCenterUserDto(request);
		entity.setSuccess(true);
		QuoteFlowDto dto = new QuoteFlowDto();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		//新加的参数
		dto.setCenterCompanyId(company.getCompanyId());
		dto.setCenterUserId(company.getUserId());
		dto.setDeviceId(user.getSwitchOperator().getDeviceId());
		
		//切换人管理人员列表
		List<UserInfoDto> list = redisService.getOperatorAssignment(user.getCompanyId(), user.getSwitchOperatorId(),1);	
		UserInfoDto userInfo = list.stream().filter(o -> o.getId().equals(user.getSwitchOperatorId())).findAny().orElse(null);
		dto.setUserName(userInfo.getUserName());
		dto.setTrueName(userInfo.getChineseName());
		
		orderManager.submitOrderFlow(dto);
		entity.setData(orderManager.selectByPrimaryKey(req.getDataId()).getStatus().intValue());
		return entity;
	}
	
	@ApiOperation(value="订单已批退回", notes="订单已批退回")
	@PostMapping("approvedBack")
	@ApiImplicitParam(name = "req", value = "订单已批退回请求对象", required = true, dataType = "UpdateQuoteStatusRequest")
	@NeedLogin
	@Permission(require="order.approval.yipiBack")
	public BaseResponseEntity<Integer> approvedBack(HttpServletRequest request,@RequestBody UpdateQuoteStatusRequest req){
		BaseResponseEntity<Integer> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		CheckSuccessDto company = SessionUtils.getCenterUserDto(request);
		entity.setSuccess(true);
		QuoteFlowDto dto = new QuoteFlowDto();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		//新加的参数
		dto.setCenterCompanyId(company.getCompanyId());
		dto.setCenterUserId(company.getUserId());
		dto.setDeviceId(user.getSwitchOperator().getDeviceId());
		
		//切换人管理人员列表
		List<UserInfoDto> list = redisService.getOperatorAssignment(user.getCompanyId(), user.getSwitchOperatorId(),1);	
		UserInfoDto userInfo = list.stream().filter(o -> o.getId().equals(user.getSwitchOperatorId())).findAny().orElse(null);
		dto.setUserName(userInfo.getUserName());
		dto.setTrueName(userInfo.getChineseName());
			
		entity.setData((int)orderManager.approvedBack(dto).getStatus());
		return entity;
	}
	
	@ApiOperation(value="订单完成退回", notes="订单完成退回")
	@PostMapping("completedBack")
	@ApiImplicitParam(name = "req", value = "订单完成退回请求对象", required = true, dataType = "UpdateQuoteStatusRequest")
	@NeedLogin
	@Permission(require="order.approval.doneBack")
	public BaseResponseEntity<Integer> completedBack(HttpServletRequest request,@RequestBody UpdateQuoteStatusRequest req){
		BaseResponseEntity<Integer> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		entity.setSuccess(true);
		QuoteFlowDto dto = new QuoteFlowDto();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		entity.setData((int)orderManager.orderCompleteToUnComplete(dto).getStatus());
		return entity;
	}
	
	@ApiOperation(value="订单完成", notes="订单完成")
	@PostMapping("quoteComplete")
	@ApiImplicitParam(name = "req", value = "订单完成请求对象", required = true, dataType = "UpdateQuoteStatusRequest")
	@NeedLogin
	@Permission(require="order.approval.complete")
	public BaseResponseEntity<Integer> quoteComplete(HttpServletRequest request,@RequestBody UpdateQuoteStatusRequest req){
		BaseResponseEntity<Integer> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		entity.setSuccess(true);
		QuoteFlowDto dto = new QuoteFlowDto();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		entity.setData((int)orderManager.orderComplete(dto).getStatus());
		return entity;
	}
	
	
	@ApiOperation(value="批量处理订单完成", notes="批量处理订单完成")
	@PostMapping("quoteBatchComplete")
	@ApiImplicitParam(name = "req", value = "批量处理订单完成请求对象", required = true, dataType = "BatchUpdateQuoteStatusRequest")
	@NeedLogin
	@Permission(require="order.approval.complete")
	public BaseResponseEntity<Integer> quoteBatchComplete(HttpServletRequest request,@RequestBody BatchUpdateQuoteStatusRequest req){
		BaseResponseEntity<Integer> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		entity.setSuccess(true);
		for(Long dataId:req.getDataIds()){//校验
			orderManager.checkOrder(user.getCompanyId(), dataId, OrderStatus.Effect.getStatus(),OrderStatus.Complete.getStatus());
		}
		for(Long dataId:req.getDataIds()){
			QuoteFlowDto dto = new QuoteFlowDto();
			dto.setDataId(dataId);
			dto.setContent(req.getContent());
			dto.setCompanyId(user.getCompanyId());
			dto.setOperatorId(user.getOperatorId());
			dto.setSwitchOperatorId(user.getSwitchOperatorId());
			orderManager.orderComplete(dto);
		}
		entity.setData(OrderStatus.Complete.getStatus());
		return entity;
	}
	
	@ApiOperation(value="订单终止", notes="订单终止")
	@PostMapping("orderTerminate")
	@ApiImplicitParam(name = "req", value = "订单终止请求对象", required = true, dataType = "UpdateQuoteStatusRequest")
	@NeedLogin
	@Permission(require="order.approval.termination")
	public BaseResponseEntity<Integer> orderTerminate(HttpServletRequest request,@RequestBody UpdateQuoteStatusRequest req){
		BaseResponseEntity<Integer> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		entity.setSuccess(true);
		QuoteFlowDto dto = new QuoteFlowDto();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		entity.setData((int)orderManager.orderTerminate(dto).getStatus());
		return entity;
	}
	
	@ApiOperation(value="订单重新执行", notes="订单重新执行")
	@PostMapping("orderReExecute")
	@ApiImplicitParam(name = "req", value = "订单重新执行请求对象", required = true, dataType = "UpdateQuoteStatusRequest")
	@NeedLogin
	@Permission(require="order.approval.restart")
	public BaseResponseEntity<Integer> orderReExecute(HttpServletRequest request,@RequestBody UpdateQuoteStatusRequest req){
		BaseResponseEntity<Integer> entity= new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		entity.setSuccess(true);
		QuoteFlowDto dto = new QuoteFlowDto();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		entity.setData((int)orderManager.orderReExecute(dto).getStatus());
		return entity;
	}

	@ApiOperation(value="查询订单附件", notes="查询订单附件")
	@ApiImplicitParam(name = "req", value = "查询订单附件请求对象", required = true, dataType = "IdRequest")
	@PostMapping("getOrderAttachments")
	@Permission(require="order.list.preview")
	public BaseResponseEntity<List<OrderAttachmentResponse>> getOrderAttachments(HttpServletRequest request, @RequestBody IdRequest req){
		BaseResponseEntity<List<OrderAttachmentResponse>> entity = new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);

		entity.setSuccess(true);
		entity.setData(orderManager.getOrderAttachments(req.getId(),user.getCompanyId()));
		return entity;
	}

	@ApiOperation(value="上传订单附件", notes="上传订单附件")
	@ApiImplicitParam(name = "req", value = "上传订单附件请求对象", required = true, dataType = "UploadOrderAttachmentRequest")
	@PostMapping("uploadOrderAttachments")
	@Permission(require="order.list.preview")
	public BaseResponseEntity<SuccessResponse> uploadOrderAttachments(HttpServletRequest request,@RequestBody UploadOrderAttachmentRequest req){
		BaseResponseEntity<SuccessResponse> entity = new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		OrderAttachment attachment = new OrderAttachment();
		JoinfBeanUtils.copyProperties(attachment, req);
		Date date = new Date();
		attachment.setCompanyId(user.getCompanyId());
		attachment.setCreateTime(date);
		attachment.setFlag(1);
		attachment.setUpdateId(user.getSwitchOperatorId());
		attachment.setUpdateTime(date);
		attachment.setCreateId(user.getSwitchOperatorId());
		orderManager.uploadOrderAttachment(attachment);
		entity.setSuccess(true);
		entity.setData(new SuccessResponse(true));
		return entity;
	}

	@ApiOperation(value="删除订单附件", notes="删除订单附件")
	@ApiImplicitParam(name = "req", value = "删除订单附件请求对象", required = true, dataType = "DeleteOrderRequest")
	@PostMapping("deleteOrderAttachments")
	@Permission(require="order.list.delete")
	public BaseResponseEntity<SuccessResponse> deleteOrderAttachments(HttpServletRequest request,@RequestBody DeleteOrderRequest req){
		BaseResponseEntity<SuccessResponse> entity = new BaseResponseEntity<SuccessResponse>();
		DeleteOrderAttachmentDto dto = new DeleteOrderAttachmentDto();

		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setUpdateId(user.getOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setIds(req.getIds());
		orderManager.deleteOrderAttachment(dto);
		entity.setSuccess(true);
		entity.setData(new SuccessResponse(true));
		return entity;
	}
	
	
	
	/**
	 * 发送邮件插入订单模板
	 * @param map
	 * @param request
	 * @return
	 */
	@ApiOperation(value="发送邮件插入订单模板", notes="发送邮件插入订单模板")
	@PostMapping("generateOrder")
	@ApiImplicitParam(name = "req", value = "发送邮件插入订单模板请求对象", required = true, dataType = "SendOrderEmailRequest")
	@NeedLogin
	@Permission(require="product.list.sendemail")
	public BaseResponseEntity<List<String>> getMailInsertProduct(HttpServletRequest request,@RequestBody SendOrderEmailRequest req){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		BaseResponseEntity<List<String>> entity = new BaseResponseEntity<>();
		DownLoadFileParam param = new DownLoadFileParam();
		param.setOperatorId(user.getSwitchOperatorId());
		param.setSuffix(req.getSuffix() == null ? "excel" : req.getSuffix());
		param.setTemplateId(req.getTemplateId());
		param.setType(1);
		entity.setSuccess(true);
		List<String> quoteList = new ArrayList<String>();
		for(Long id : req.getQuoteIds()){
			param.setBusinessIds(String.valueOf(id));
			quoteList.add(fileService.getQuoteReportTemplateData(param));
		}
		entity.setData(quoteList);
		return entity;
	}
}
