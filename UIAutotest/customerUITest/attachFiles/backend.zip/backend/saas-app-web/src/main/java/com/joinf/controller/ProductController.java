package com.joinf.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.alibaba.fastjson.JSONArray;
import com.github.pagehelper.Page;
import com.joinf.annotations.NeedLogin;
import com.joinf.constants.Customize;
import com.joinf.dto.DownLoadFileParam;
import com.joinf.dto.DownLoadShopProductFileParam;
import com.joinf.dto.InsertOrUpdateDto;
import com.joinf.dto.ProductAppListDto;
import com.joinf.dto.ProductGroupDto;
import com.joinf.dto.QueryProductGroupParam;
import com.joinf.dto.QueryShopGroupParam;
import com.joinf.dto.QueryShopProductParam;
import com.joinf.dto.ShopProductInfo;
import com.joinf.dto.product.QueryProductDto;
import com.joinf.dto.product.ShopProductSendMailInfo;
import com.joinf.dto.product.UpdateProductEnchaseDto;
import com.joinf.dto.supplier.SupplierDetailDto;
import com.joinf.entity.SessionUser;
import com.joinf.entity.generator.Product;
import com.joinf.entity.generator.ProductEnchase;
import com.joinf.entity.generator.ProductPicture;
import com.joinf.entity.generator.ShopProductInternationalTrade;
import com.joinf.entity.generator.ShopProductPriceRange;
import com.joinf.exception.AreadyExsitException;
import com.joinf.interfaces.FileService;
import com.joinf.interfaces.ProductManager;
import com.joinf.interfaces.ShopProductManager;
import com.joinf.request.IdRequest;
import com.joinf.request.InsertOrUpdateRequest;
import com.joinf.request.customer.DeleteCustomerRequest;
import com.joinf.request.product.InsertProductPictureRequest;
import com.joinf.request.product.QueryProductEnchaseRequest;
import com.joinf.request.product.QueryProductGroupRequest;
import com.joinf.request.product.QueryProductRequest;
import com.joinf.request.product.QueryShopProductGroupRequest;
import com.joinf.request.product.QueryShopProductRequest;
import com.joinf.request.product.ScanRequest;
import com.joinf.request.product.SendProductEmailRequest;
import com.joinf.request.product.UpdateProductEnchaseRequest;
import com.joinf.request.product.UpdateProductPictureSortRequest;
import com.joinf.response.EditDetailResponse;
import com.joinf.response.product.ProductAttachmentResponse;
import com.joinf.response.product.ProductEnchaseResponse;
import com.joinf.response.product.ShopGroupResponse;
import com.joinf.response.product.ShopProudctResponse;
import com.joinf.response.product.ShopResponse;
import com.joinf.response.supplier.QuerySupplierResponse;
import com.joinf.utils.BaseEntityUtils;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.annotations.Permission;
import com.joinf.utils.annotations.VolumeLimit;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.util.JoinfBeanUtils;
import com.joinf.utils.util.RichTextUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * Description: 产品相关服务
 *
 * @author lyj
 * @date 2018年1月12日 下午4:26:22
 */
@RestController
@RequestMapping("product")
@Api(tags = "产品服务")
public class ProductController {
	
	@Autowired
	private ProductManager productManager;
	
	@Autowired
	private ShopProductManager shopProductManager;
	
	@Autowired
	private FileService fileService;
	
	protected Logger logger = LoggerFactory.getLogger(this.getClass().getName());
	
	
	/**
	 * 查询产品最上层分组
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询公司网店", notes="查询公司网店")
	@PostMapping("queryCompamyShops")
	@NeedLogin
	@Permission(require="product.shop.preview")
	public BaseResponseEntity<List<ShopResponse>> getCompamyShops(HttpServletRequest request){
		BaseResponseEntity<List<ShopResponse>> response = new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		Long companyId = user.getUser().getCompanyId();
		response.setData(shopProductManager.getCompanyShopInfo(companyId));
		response.setSuccess(true);
		return response;
	}
	
	/**
	 * 查询网店产品最上层分组
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询网店产品最上层分组", notes="查询网店产品最上层分组")
	@PostMapping("queryShopProductGroupList")
	@ApiImplicitParam(name = "req", value = "查询网店产品分组请求对象", required = true, dataType = "QueryShopProductGroupRequest")
	@NeedLogin
	public BaseResponseEntity<List<ShopGroupResponse>> queryProductList(HttpServletRequest request,@RequestBody QueryShopProductGroupRequest req){
		BaseResponseEntity<List<ShopGroupResponse>> response = new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		Long companyId = user.getUser().getCompanyId();
		QueryShopGroupParam param = new QueryShopGroupParam();
		param.setCompanyId(companyId);
		param.setRecursion(false);
		param.setParentId(-1l);
		param.setFlag(1);
		param.setShopId(req.getShopId());
		response.setData(shopProductManager.getShopGroups(param));
		response.setSuccess(true);
		return response;
	}
	
	/**
	 * 查询产品
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询网店产品", notes="查询网店产品")
	@PostMapping("queryShopProductList")
	@ApiImplicitParam(name = "req", value = "查询网店产品列表请求对象", required = true, dataType = "QueryShopProductRequest")
	@Permission(require="product.shop.preview")
	@NeedLogin
	public BaseResponseEntity<List<ShopProudctResponse>> queryProductList(HttpServletRequest request,@RequestBody QueryShopProductRequest req){
		BaseResponseEntity<List<ShopProudctResponse>> response = new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		Long companyId = user.getUser().getCompanyId();
		QueryShopProductParam dto = new QueryShopProductParam();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setCompanyId(companyId);
		List<ShopProductInfo> products = shopProductManager.getShopProducts(dto);
		if(req.isPaging()){
			products = ((Page<ShopProductInfo>)products).getResult();
			response.setTotalPage(((Page<ShopProductInfo>)products).getPages());
			response.setTotalRecords(((Page<ShopProductInfo>)products).getTotal());
		}
		response.setData(convertShopProudctInfos(products));
		response.setSuccess(true);
		return response;
	}
	
	/**
	 * 查询产品最上层分组
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询产品最上层分组", notes="查询产品最上层分组")
	@PostMapping("queryProductGroupList")
	@ApiImplicitParam(name = "req", value = "查询产品分组请求对象", required = true, dataType = "QueryProductGroupRequest")
	@NeedLogin
	public BaseResponseEntity<List<ProductGroupDto>> queryProductList(HttpServletRequest request,@RequestBody QueryProductGroupRequest req){
		BaseResponseEntity<List<ProductGroupDto>> response = new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		Long companyId = user.getUser().getCompanyId();
		Long operatorId = user.getSwitchOperatorId();
		QueryProductGroupParam param = new QueryProductGroupParam();
		param.setCompanyId(companyId);
		param.setOperatorId(operatorId);
		param.setType(req.getType());
		param.setParentId(0l);
		response.setData(productManager.getProudctGroupDto(param));
		response.setSuccess(true);
		return response;
	}
	
	@ApiOperation(value="查询网店产品明细", notes="查询产品明细")
	@ApiImplicitParam(name = "req", value = "查询产品明细请求对象", required = true, dataType = "IdRequest")
	@PostMapping("getShopProductDetail")
	public BaseResponseEntity<ShopProductInfo> getShopProductDetail(HttpServletRequest request,@RequestBody IdRequest req){
		BaseResponseEntity<ShopProductInfo> entity = new BaseResponseEntity<ShopProductInfo>();
		entity.setSuccess(true);
		entity.setData(shopProductManager.getShopProductDetial(req.getId()));
		return entity;
	}
	
	/**
	 * 查询产品
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询产品", notes="查询产品")
	@PostMapping("queryProductList1")
	@ApiImplicitParam(name = "req", value = "查询产品列表请求对象", required = true, dataType = "QueryProductRequest")
	@NeedLogin
	@Permission(require="product.list.preview")
	public BaseResponseEntity<List<ProductAppListDto>> queryProductList1(HttpServletRequest request,@RequestBody QueryProductRequest req){
		BaseResponseEntity<List<ProductAppListDto>> response = new BaseResponseEntity<>();
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		Long companyId = user.getCompanyId();
		Long operatorId = user.getSwitchOperatorId();
		QueryProductDto dto = new QueryProductDto();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setCompanyId(companyId);
		dto.setOperatorId(operatorId);
		List<ProductAppListDto> products = productManager.getAppProductList(dto);
		if(req.isPaging()){
			products = ((Page<ProductAppListDto>)products).getResult();
			response.setTotalPage(((Page<ProductAppListDto>)products).getPages());
			response.setTotalRecords(((Page<ProductAppListDto>)products).getTotal());
		}
		response.setData(products);
		response.setSuccess(true);
		return response;
	}
	/**
	 * 查询产品
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询产品", notes="查询产品")
	@PostMapping("queryProductList")
	@ApiImplicitParam(name = "req", value = "查询产品列表请求对象", required = true, dataType = "QueryProductRequest")
	@NeedLogin
	@Permission(require="product.list.preview")
	public BaseResponseEntity<QuerySupplierResponse> queryProductList(HttpServletRequest request,@RequestBody QueryProductRequest req){
		QueryProductDto dto = new QueryProductDto();
		JoinfBeanUtils.copyProperties(dto, req);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setRoleId(user.getUser().getRoleId());
		dto.setResourceId(Customize.Product.getResourceId());
		dto.setTableName(Customize.Product.getTableName());
		dto.setModule(Customize.Product.getModule());
		
		BaseResponseEntity<QuerySupplierResponse> entity = new BaseResponseEntity<>();
		entity.setSuccess(true);
		List<Product> products = productManager.queryProduct(dto);
		if(req.isPaging()){
			products = ((Page<Product>) products).getResult();
			entity.setTotalPage(((Page<Product>) products).getPages());
			entity.setTotalRecords(((Page<Product>) products).getTotal());
		}
		List<String> showFileds = new ArrayList<String>();
		showFileds.add("code");//编码
		showFileds.add("chineseName");//中文
		showFileds.add("englishName");//英文
		showFileds.add("supplier");//供应商
		entity.setData(productManager.getProductListArray(dto, products, showFileds));
		return entity;
	}
	
	@ApiOperation(value="查询产品明细(参数id为空则为新增)", notes="查询产品明细(参数id为空则为新增)")
	@ApiImplicitParam(name = "req", value = "查询产品明细请求对象", required = true, dataType = "IdRequest")
	@PostMapping("getProductDetail")
	@Permission(require="product.list.edit")
	public BaseResponseEntity<List<EditDetailResponse>> getSupplierDetail(HttpServletRequest request,@RequestBody IdRequest req){
		SupplierDetailDto dto = new SupplierDetailDto();
		dto.setId(req.getId());
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setCompanyId(user.getCompanyId());
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setRoleId(user.getRoleId());
		dto.setResourceId(Customize.Product.getResourceId());
		dto.setTableName(Customize.Product.getTableName());
		dto.setModule(Customize.Product.getModule());
		List<EditDetailResponse> details = productManager.getProductEditArray(dto);
		return BaseEntityUtils.successOne(details);
	}
	
	
	@ApiOperation(value="产品修改(参数id为空则为新增)", notes="产品修改(参数id为空则为新增)")
	@ApiImplicitParam(name = "req", value = "产品修改请求对象", required = true, dataType = "InsertOrUpdateRequest")
	@PostMapping("insertProduct")
	@Permission(require="product.list.new")
	@VolumeLimit
	public BaseResponseEntity<Object> insertProduct(HttpServletRequest request,@RequestBody InsertOrUpdateRequest req) throws AreadyExsitException{
		BaseResponseEntity<Object> entity = new BaseResponseEntity<>();
		
		InsertOrUpdateDto dto = new InsertOrUpdateDto();
		dto.setValues(req.getModels());
		dto.setOldValue(req.getOldValue());
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(user.getUser().getCompanyId());
		dto.setId(req.getId());
		dto.setTableName(Customize.Product.getTableName());
		dto.setRoleId(user.getUser().getRoleId());
		entity.setData(productManager.insertOrUpdateProduct(dto).getReturnValue());
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="产品修改(参数id为空则为新增)", notes="产品修改(参数id为空则为新增)")
	@ApiImplicitParam(name = "req", value = "产品修改请求对象", required = true, dataType = "InsertOrUpdateRequest")
	@PostMapping("updateProduct")
	@Permission(require="product.list.edit")
	@VolumeLimit
	public BaseResponseEntity<Long> updateProduct(HttpServletRequest request,@RequestBody InsertOrUpdateRequest req) throws AreadyExsitException{
		BaseResponseEntity<Long> entity = new BaseResponseEntity<>();
		
		InsertOrUpdateDto dto = new InsertOrUpdateDto();
		dto.setValues(req.getModels());
		dto.setOldValue(req.getOldValue());
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		dto.setOperatorId(user.getOperatorId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		dto.setCompanyId(user.getUser().getCompanyId());
		dto.setId(req.getId());
		dto.setTableName(Customize.Product.getTableName());
		dto.setRoleId(user.getUser().getRoleId());
		entity.setData(productManager.insertOrUpdateProduct(dto).getDataId());
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="删除产品", notes="删除产品")
	@ApiImplicitParam(name = "req", value = "删除产品请求对象", required = true, dataType = "DeleteCustomerRequest")
	@PostMapping("deleteProducts")
	@Permission(require="product.list.delete")
	public BaseResponseEntity<?> deleteProducts(HttpServletRequest request,@RequestBody DeleteCustomerRequest req){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		BaseResponseEntity<?> entity = new BaseResponseEntity<>();
		productManager.deleteProducts(req.getIds(),user.getOperatorId(),user.getSwitchOperatorId());
		entity.setSuccess(true);
		return entity;
	}
	
	/**
	 * 包装单位 METER_UNIT type=6
	 * @param request
	 * @param req
	 * @return
	 */
	@ApiOperation(value="查询产品包装信息", notes="查询产品包装信息")
	@ApiImplicitParam(name = "req", value = "查询产品包装信息请求对象", required = true, dataType = "QueryProductEnchaseRequest")
	@PostMapping("getProductEnchaseDetail")
	@Permission(require="product.list.edit")
	public BaseResponseEntity<ProductEnchaseResponse> getProductEnchaseDetail(HttpServletRequest request,@RequestBody QueryProductEnchaseRequest req){
		BaseResponseEntity<ProductEnchaseResponse> entity = new BaseResponseEntity<ProductEnchaseResponse>();
		ProductEnchase enchase = productManager.getProudctEnchase(req.getProudctId());
		if(enchase == null)enchase = new ProductEnchase();
		ProductEnchaseResponse response = new ProductEnchaseResponse();
		JoinfBeanUtils.copyProperties(response, enchase);
		//处理每件数量，为整数时补齐小数位
		if(enchase.getDecorate() != null){
			BigDecimal newDecorate = new BigDecimal(enchase.getDecorate().intValue());
			if(newDecorate.compareTo(enchase.getDecorate()) == 0){
				String decorate = newDecorate.toString() + ".00";
				response.setDecorate(decorate);
			}else{
				response.setDecorate(enchase.getDecorate().toString());
			}
		}
		//长
		if(enchase.getLength() != null){
			BigDecimal newLength = new BigDecimal(enchase.getLength().intValue());
			if(newLength.compareTo(enchase.getLength()) == 0){
				String length = newLength.toString() + ".0";
				response.setLength(length);
			}else{
				response.setLength(enchase.getLength().toString());
			}
		}
		//宽
		if(enchase.getWidth() != null){
			BigDecimal newWidth = new BigDecimal(enchase.getWidth().intValue());
			if(newWidth.compareTo(enchase.getWidth()) == 0){
				String width = newWidth.toString() + ".0";
				response.setWidth(width);
			}else{
				response.setWidth(enchase.getLength().toString());
			}
		}	
		//高
		if(enchase.getHeight() != null){
			BigDecimal newHeight = new BigDecimal(enchase.getHeight().intValue());
			if(newHeight.compareTo(enchase.getHeight()) == 0){
				String height = newHeight.toString() + ".0";
				response.setHeight(height);
			}else{
				response.setHeight(enchase.getHeight().toString());
			}
		}	
		//毛重
		if(enchase.getGrossWeight() != null){
			BigDecimal newWeight = new BigDecimal(enchase.getGrossWeight().intValue());
			if(newWeight.compareTo(enchase.getGrossWeight()) == 0){
				String weight = newWeight.toString() + ".0";
				response.setGrossWeight(weight);
			}else{
				response.setGrossWeight(enchase.getGrossWeight().toString());
			}
		}
		
		//净重
		if(enchase.getSuttleWeight() != null){
			BigDecimal newWeight = new BigDecimal(enchase.getSuttleWeight().intValue());
			if(newWeight.compareTo(enchase.getSuttleWeight()) == 0){
				String weight = newWeight.toString() + ".0";
				response.setSuttleWeight(weight);
			}else{
				response.setSuttleWeight(enchase.getSuttleWeight().toString());
			}
		}	
		//净重
		if(enchase.getBulk() != null){
			BigDecimal newBulk = new BigDecimal(enchase.getBulk().intValue());
			if(newBulk.compareTo(enchase.getBulk()) == 0){
				String bulk = newBulk.toString() + ".0";
				response.setBulk(bulk);
			}else{
				response.setBulk(enchase.getBulk().toString());
			}
		}
		entity.setData(response);
		entity.setSuccess(true);
		return entity;
	}
	
	/**
	 * 包装单位 METER_UNIT type=6
	 * @param request
	 * @param req
	 * @return
	 */
	@ApiOperation(value="产品包装信息修改(参数id为空则为新增)", notes="产品包装信息修改(参数id为空则为新增)")
	@ApiImplicitParam(name = "req", value = "产品包装信息修改信息请求对象", required = true, dataType = "UpdateProductEnchaseRequest")
	@PostMapping("insertOrUpdateProductEnchase")
	@Permission(require="product.list.edit")
	public BaseResponseEntity<?> insertOrUpdateProductEnchase(HttpServletRequest request,@RequestBody UpdateProductEnchaseRequest req){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		BaseResponseEntity<?> entity = new BaseResponseEntity<>();
		UpdateProductEnchaseDto dto = new UpdateProductEnchaseDto();
		JoinfBeanUtils.copyProperties(dto, req);
		dto.setOperatorId(user.getOperatorId());
		dto.setCompanyId(user.getCompanyId());
		dto.setSwitchOperatorId(user.getSwitchOperatorId());
		productManager.insertOrUpdateProductEnchase(dto);
		entity.setSuccess(true);
		return entity;
	}
	
	
	@ApiOperation(value="查询产品图片", notes="查询产品图片")
	@ApiImplicitParam(name = "req", value = "查询产品图片请求对象", required = true, dataType = "QueryProductEnchaseRequest")
	@PostMapping("getProductPictures")
	@Permission(require="product.list.edit")
	public BaseResponseEntity<List<ProductAttachmentResponse>> getProductAttachments(HttpServletRequest request,@RequestBody QueryProductEnchaseRequest req){
		BaseResponseEntity<List<ProductAttachmentResponse>> entity = new BaseResponseEntity<List<ProductAttachmentResponse>>();
		entity.setData(productManager.getProductPictures(req.getProudctId()));
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="删除产品图片", notes="删除产品图片")
	@ApiImplicitParam(name = "req", value = "删除产品图片请求对象", required = true, dataType = "DeleteCustomerRequest")
	@PostMapping("deleteProductPictures")
	@Permission(require="product.list.edit")
	public BaseResponseEntity<?> deleteProductPictures(HttpServletRequest request,@RequestBody DeleteCustomerRequest req){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		BaseResponseEntity<?> entity = new BaseResponseEntity<>();
		productManager.deleteProductPictures(req.getIds(),user.getUser().getId());
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="新增产品图片", notes="新增产品图片")
	@ApiImplicitParam(name = "req", value = "新增产品图片请求对象", required = true, dataType = "InsertProductPictureRequest")
	@PostMapping("insertProductPicture")
	@Permission(require="product.list.edit")
	@VolumeLimit
	public BaseResponseEntity<Long> insertProductPicture(HttpServletRequest request,@RequestBody InsertProductPictureRequest req){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		BaseResponseEntity<Long> entity = new BaseResponseEntity<>();
		ProductPicture picture = new ProductPicture();
		JoinfBeanUtils.copyProperties(picture, req);
		picture.setCompanyId(user.getCompanyId());
		picture.setOperatorId(user.getSwitchOperatorId());
		picture.setUpdateId(user.getOperatorId());
		picture.setUpdateTime(new Date());
		picture.setFlag(1);
		entity.setSuccess(true);
		entity.setData(productManager.insertProductPicture(picture).getId());
		return entity;
	}
	
	@ApiOperation(value="修改产品图片排序", notes="修改产品图片排序")
	@ApiImplicitParam(name = "req", value = "修改产品图片排序请求对象", required = true, dataType = "UpdateProductPictureSortRequest")
	@PostMapping("updateProductPictureSort")
	@Permission(require="product.list.edit")
	public BaseResponseEntity<?> updateProductPictureSort(HttpServletRequest request,@RequestBody UpdateProductPictureSortRequest req){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		List<ProductPicture> pictures = new ArrayList<>();
		ProductPicture picture;
		Date date = new Date();
		for(UpdateProductPictureSortRequest.PictureSort sort:req.getSorts()){
			picture = new ProductPicture();
			picture.setId(sort.getId());
			picture.setSort(sort.getSort());
			picture.setUpdateId(user.getUser().getId());
			picture.setUpdateTime(date);
			pictures.add(picture);
		}
		BaseResponseEntity<?> entity = new BaseResponseEntity<>();
		productManager.updateProductPictureSorts(pictures);
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="选择产品发送邮件", notes="选择产品发送邮件")
	@ApiImplicitParam(name = "req", value = "选择产品发送邮件请求对象", required = true, dataType = "SendProductEmailRequest")
	@PostMapping("getMailInsertProduct")
	@Permission(require="product.list.sendemail")
	public BaseResponseEntity<String> getMailInsertProduct(HttpServletRequest request,@RequestBody SendProductEmailRequest req){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		BaseResponseEntity<String> entity = new BaseResponseEntity<>();
		DownLoadFileParam param = new DownLoadFileParam();
		param.setBusinessIds(StringUtils.join(req.getProductIds(), ","));
		param.setOperatorId(user.getSwitchOperatorId());
		param.setSuffix("html");
		param.setTemplateId(req.getTemplateId());
		param.setType(1);
		entity.setData(RichTextUtil.replaceImgSrc(fileService.getProudctReportTemplateData(param)));
		entity.setSuccess(true);
		return entity;
	}
	
	@ApiOperation(value="选择网店产品发送邮件", notes="选择网店产品发送邮件")
	@ApiImplicitParam(name = "req", value = "选择产品网店发送邮件请求对象", required = true, dataType = "SendProductEmailRequest")
	@PostMapping("getMailInsertShopProduct")
	@Permission(require="product.list.sendemail")
	public BaseResponseEntity<String> getMailInsertShopProduct(HttpServletRequest request,@RequestBody SendProductEmailRequest req){
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		BaseResponseEntity<String> entity = new BaseResponseEntity<>();
		
		ShopProductSendMailInfo info = shopProductManager.getShopProductSendMailInfo(req.getProductIds());
		DownLoadShopProductFileParam param = new DownLoadShopProductFileParam();
		param.setBusinessData(JSONArray.toJSONString(info.getInfos()));
		param.setOperatorId(user.getSwitchOperatorId());
		param.setSuffix("html");
		param.setTemplateId(req.getTemplateId());
		param.setType(1);
		param.setModuleFileCode(info.getMd5Code());
		entity.setData(RichTextUtil.replaceImgSrc(fileService.getShopProudctReportTemplateData(param)));
		entity.setSuccess(true);
		return entity;
	}
	
	/**
	 * 转换网店产品结果集
	 * @param infos
	 * @return
	 */
	private List<ShopProudctResponse> convertShopProudctInfos(List<ShopProductInfo> infos){
		List<ShopProudctResponse> responses = new ArrayList<ShopProudctResponse>();
		ShopProudctResponse response;
		for(ShopProductInfo info:infos){
			StringBuffer price = new StringBuffer();
			String minOrder = "";
			Integer type = 0;
			response = new ShopProudctResponse();
			response.setId(info.getId());
			if(info.getImages() != null&&info.getImages().size() >0)
				response.setUrl(info.getImages().get(0).getUrl());
			if(info.getTrade()!=null){
				ShopProductInternationalTrade trade = info.getTrade();
				if(String.valueOf(trade.getPriceType()).equals("1")){
					type = 1;
					if(trade.getFobCurrency() != null){
						price.append(trade.getFobCurrency());
					}
					if(trade.getFobMinPrice() != null){
						price.append(trade.getFobMinPrice());
					}
					if(trade.getFobMaxPrice() != null){
						price.append("-");
						price.append(trade.getFobMaxPrice());
					}
					
					minOrder = (trade.getMinOrderUnitType() == null?"":trade.getMinOrderUnitType())+" "+(trade.getMinOrderQuantity()==null?"":trade.getMinOrderQuantity());
					if(minOrder.equals(" 0")){//处理全空情况
						minOrder = "";
					}
				}
			}
			else if(info.getPriceRange()!= null&& info.getPriceRange().size()>0&& type ==0){
				for(ShopProductPriceRange range:info.getPriceRange()){
					price.append(range.getPrice());
					price.append(",");
					minOrder += range.getStartQuantity()+",";
				}
			}
			response.setMinOrder(minOrder);
			response.setPrice(price.toString());
			responses.add(response);
			response.setSubject(info.getSubject());
			response.setDescription(info.getDescription());
		}
		return responses;
	}
	
	
	@ApiOperation(value="扫码识别产品明细", notes="扫码识别产品明细")
	@ApiImplicitParam(name = "req", value = "扫码识别产品明细请求对象", required = true, dataType = "IdRequest")
	@PostMapping("scanProductDetail")
	@Permission(require="product.list.edit")
	public BaseResponseEntity<Long> scanProductDetail(HttpServletRequest request,@RequestBody ScanRequest req){
		BaseResponseEntity<Long> entity = new BaseResponseEntity<>(true);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);
		
		logger.info("barCode : {}", req.getData());
		
		if(req.getData() != null && StringUtils.isNotBlank(req.getData())){		
			String barCode = req.getData();
			Product product = productManager.getProductInfoByParam(user.getCompanyId(), user.getSwitchOperatorId(), barCode);
			if(product != null){				
				entity.setData(product.getId());;
			}else{
				entity.setCode(-3);
				entity.setSuccess(false);
				entity.setErrMsg("没有找到匹配的产品");
			}
		}else{
			entity.setCode(-3);
			entity.setSuccess(false);
			entity.setErrMsg("没有找到匹配的产品");
		}
		return entity;
	}
	
}