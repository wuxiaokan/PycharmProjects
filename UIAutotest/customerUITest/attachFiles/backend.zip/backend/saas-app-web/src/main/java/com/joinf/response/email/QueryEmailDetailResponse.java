package com.joinf.response.email;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.joinf.helper.LongJsonDeserializer;
import com.joinf.helper.LongJsonSerializer;

import io.swagger.annotations.ApiModelProperty;


/**
 * 
 * @author zlx
 * @Description: 邮件详情信息
 * @date 2018年1月12日 下午9:02:27
 */
public class QueryEmailDetailResponse implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2105085247053982301L;
	
	@JsonSerialize(using = LongJsonSerializer.class)
	@JsonDeserialize(using = LongJsonDeserializer.class)
	@ApiModelProperty(value = "邮件标识")
    private Long id;
	@ApiModelProperty(value = "邮件主题")
    private String subject = "无主题";
	@ApiModelProperty(value = "是否紧急")
    private boolean urgent;
	@ApiModelProperty(value = "状态  详见邮件状态枚举 ")
    private Integer status;
	@ApiModelProperty(value = "箱子id 详见箱子枚举")
    private Long boxId;
	@ApiModelProperty(value = "邮件发送/接收时间")
    private Date sentDate;
	@ApiModelProperty(value ="发件邮箱账号")
	private String fromMail;
    @ApiModelProperty(value ="收件人")
    private String recipients;
    @ApiModelProperty(value ="抄送人")
    private String cc;
    @ApiModelProperty(value ="密送人")
    private String bc;
	@ApiModelProperty(value ="内部用户(转发)")
	private String inter;
	@ApiModelProperty(value = "是否已读")
    private boolean hasRead;
	@ApiModelProperty(value = "是否包含附件")
    private boolean containAttachment;
	@ApiModelProperty(value = "是否回复")
    private boolean isReply;
	@ApiModelProperty(value = "是否转发")
    private boolean isFw;
	@ApiModelProperty(value = "是否内部转发")
    private boolean isFwIn;
	@ApiModelProperty(value = "是否定时邮件")
    private boolean isTimingSent;
	@ApiModelProperty(value = "是否免回复")
    private boolean avoidReply;
	@ApiModelProperty(value = "是否标星")
	private boolean isAsterisk;
	@ApiModelProperty(value = "追踪类型  0[不需要追踪] 1[需要追踪] 2[已有追踪记录]")
    private int isTrace;
	@ApiModelProperty(value ="[0]:收信 [1]:发信 [2]:导入")
    private int emailType;
	@ApiModelProperty(value = "联系人类型  0[新客户 ] 1[老客户] 2[内部联系人]")
    private int contactType = 0;
	@ApiModelProperty(value = "正文")
    private String content = "";
	
	@ApiModelProperty(value = "邮件回执情况 [0]不处理  [1]已自动发送  [2]需要确定是否发送")
	private int receiptStatus;
	
	@ApiModelProperty(value = "是否可审批")
	private boolean canAudit;
	
	@ApiModelProperty(value = "附件信息")
	private List<EmailAttachmentResponse> attachmentList;
	
	@ApiModelProperty(value = "邮件在列表上所在序号")
	private int rowNum;
	@ApiModelProperty(value="第几页",required=true)
	private int num;
	@ApiModelProperty(value ="标记")
    private String remark;

    @ApiModelProperty(value ="标记id,多个用“，”分割")
    private String tagId;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public boolean isUrgent() {
		return urgent;
	}
	public void setUrgent(boolean urgent) {
		this.urgent = urgent;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Long getBoxId() {
		return boxId;
	}
	public void setBoxId(Long boxId) {
		this.boxId = boxId;
	}
	public Date getSentDate() {
		return sentDate;
	}
	public void setSentDate(Date sentDate) {
		this.sentDate = sentDate;
	}
	public boolean isHasRead() {
		return hasRead;
	}
	public void setHasRead(boolean hasRead) {
		this.hasRead = hasRead;
	}
	public boolean isContainAttachment() {
		return containAttachment;
	}
	public void setContainAttachment(boolean containAttachment) {
		this.containAttachment = containAttachment;
	}
	public boolean getIsReply() {
		return isReply;
	}
	public void setIsReply(boolean isReply) {
		this.isReply = isReply;
	}
	public boolean getIsFw() {
		return isFw;
	}
	public void setIsFw(boolean isFw) {
		this.isFw = isFw;
	}
	public boolean getIsFwIn() {
		return isFwIn;
	}
	public void setIsFwIn(boolean isFwIn) {
		this.isFwIn = isFwIn;
	}
	public boolean getIsTimingSent() {
		return isTimingSent;
	}
	public void setIsTimingSent(boolean isTimingSent) {
		this.isTimingSent = isTimingSent;
	}
	public boolean getAvoidReply() {
		return avoidReply;
	}
	public void setAvoidReply(boolean avoidReply) {
		this.avoidReply = avoidReply;
	}
	public int getIsTrace() {
		return isTrace;
	}
	public void setIsTrace(int isTrace) {
		this.isTrace = isTrace;
	}
	public int getContactType() {
		return contactType;
	}
	public void setContactType(int contactType) {
		this.contactType = contactType;
	}
	public boolean getIsAsterisk() {
		return isAsterisk;
	}
	public void setIsAsterisk(boolean isAsterisk) {
		this.isAsterisk = isAsterisk;
	}
	public String getFromMail() {
		return fromMail;
	}
	public String getRecipients() {
		return recipients;
	}
	public String getCc() {
		return cc;
	}
	public String getBc() {
		return bc;
	}
	public int getEmailType() {
		return emailType;
	}
	public String getContent() {
		return content;
	}
	public void setFromMail(String fromMail) {
		this.fromMail = fromMail;
	}
	public void setRecipients(String recipients) {
		this.recipients = recipients;
	}
	public void setCc(String cc) {
		this.cc = cc;
	}
	public void setBc(String bc) {
		this.bc = bc;
	}
	public void setEmailType(int emailType) {
		this.emailType = emailType;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public List<EmailAttachmentResponse> getAttachmentList() {
		return attachmentList;
	}
	public void setAttachmentList(List<EmailAttachmentResponse> attachmentList) {
		this.attachmentList = attachmentList;
	}
	public int getReceiptStatus() {
		return receiptStatus;
	}
	public void setReceiptStatus(int receiptStatus) {
		this.receiptStatus = receiptStatus;
	}
	public int getRowNum() {
		return rowNum;
	}
	public void setRowNum(int rowNum) {
		this.rowNum = rowNum;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getInter() {
		return inter;
	}
	public void setInter(String inter) {
		this.inter = inter;
	}
	public boolean isCanAudit() {
		return canAudit;
	}
	public void setCanAudit(boolean canAudit) {
		this.canAudit = canAudit;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getTagId() {
		return tagId;
	}
	public void setTagId(String tagId) {
		this.tagId = tagId;
	}
	
	
	
	
}
