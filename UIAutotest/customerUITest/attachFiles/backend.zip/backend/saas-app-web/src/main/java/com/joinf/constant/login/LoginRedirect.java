package com.joinf.constant.login;

/**
 * Description: 登入请求后重定向路径
 *
 * @author lyj
 * @date 2018年2月5日 下午4:59:11
 */
public enum LoginRedirect {
	
	Index("home","首页"),
	CompleteInfo("complete_info","完善信息"),
	InitSystem("init_system","初始化信息"),
	TwoCheck("two_check","二次验证"),
	;
	
	String path;
	
	String comment;
	
	LoginRedirect(String path,String comment){
		this.path = path;
		this.comment = comment;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

}
