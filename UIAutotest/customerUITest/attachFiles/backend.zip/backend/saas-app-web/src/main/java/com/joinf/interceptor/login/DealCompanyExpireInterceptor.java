package com.joinf.interceptor.login;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONObject;
import com.joinf.constant.login.LoginContant;
import com.joinf.constant.system.SysParamContants;
import com.joinf.dto.CompanyDTO;
import com.joinf.dto.OperatorDTO;
import com.joinf.dto.QueryLoginLogDto;
import com.joinf.entity.generator.Company;
import com.joinf.entity.generator.Operator;
import com.joinf.exception.LoginFailException;
import com.joinf.interfaces.CorporationService;
import com.joinf.interfaces.LoginLogService;
import com.joinf.interfaces.SystemParameterService;
import com.joinf.response.login.CompanyDueDto;
import com.joinf.response.login.CompanyExpireDto;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.util.DateUtil;

/**
 * Description: 处理企业过期时间
 *
 * @author lyj
 * @date 2017年12月18日 下午3:36:36
 */
public class DealCompanyExpireInterceptor
		implements HandlerInterceptor {

	@Autowired
	private CorporationService corporationService;

	@Autowired
	private LoginLogService loginLogService;

	@Autowired
	private SystemParameterService systemParameterService;

	/**
	 * 实现方法
	 */
	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		HttpSession session = request.getSession();
		CompanyDTO companyDto = SessionUtils.getCenterCompanyInfo(request);
		OperatorDTO operatorDto = SessionUtils.getCenterOperatorInfo(request);
		if (companyDto == null || operatorDto == null) {
			throw new LoginFailException("登入信息已过期");
		}
		Company company = SessionUtils.getCompanyInfo(request);
		Operator operator = SessionUtils.getOperatorInfo(request);
		if (companyDto == null || operatorDto == null) {
			throw new LoginFailException("登入信息已过期");
		}
		if(StringUtils.isBlank(companyDto.getDisableTime()))return true;
		boolean companyExpire = false;
		Date disableTime = DateUtil.parse(companyDto.getDisableTime(),"yyyy-MM-dd HH:mm:ss");
		// 判断企业是否到期 精确到分
		Date date = new Date();
		// 到期天数 [0]:24小时内到期或者已到期24小时内 已到期了就不计算
		Integer days = null;
		days = DateUtil.daysBetween(disableTime, date);
		if (days != null) {
			if (days.intValue() < 0 || DateUtil.isBefore(disableTime, date)) { // 已到期
				companyExpire = true;
			} else {
				QueryLoginLogDto logDto = new QueryLoginLogDto();
				logDto.setCompanyId(company.getId());
				logDto.setOperatorId(operator.getId());
				int todayLoginCount = loginLogService.isLoginForToday(logDto);
				if (todayLoginCount == 0) { // 今天第一次登录
					String disableDate = DateUtil.getFormatDateMin(disableTime);
					String helpLine = systemParameterService
							.selectByCode(SysParamContants.HELP_LINE); // 全国服务专线
					if (StringUtils.isEmpty(helpLine)) {
						helpLine = "400-881-6668"; // 默认
					}
					String dueRemindDay = systemParameterService
							.selectByCode(SysParamContants.DUE_WARN_CODE); // 到期提醒天数
					if (StringUtils.isEmpty(dueRemindDay)) {
						dueRemindDay = "15"; // 默认15天
					}
					if (days.intValue() <= Integer.valueOf(dueRemindDay)) {// 到期天数小于或等于到期提醒天数
						// 需要判断是否今天就到期了,今天到期提醒{X}小时后正式到期
						boolean isToday = DateUtil.isToday(disableTime, date);
						StringBuffer mess = new StringBuffer();
						if (isToday) {
							mess.append(DateUtil.minsBetween(disableTime, date))
									.append("小时");
						} else if (days.intValue() == 0) { // 24小时内的 明天
							mess.append("1天");
						} else {
							mess.append(days).append("天");
						}

						// 进入到下一个页面需要弹框提醒
						CompanyDueDto dueDto = new CompanyDueDto();
						dueDto.setMess(mess.toString());
						dueDto.setDisableDate(disableDate);
						dueDto.setHelpLine(helpLine);
						session.setAttribute(LoginContant.COMPANY_DUE_INFO,JSONObject.toJSONString(dueDto));
					}
				}
			}
		}
		if (companyExpire) {
			CompanyExpireDto dto = new CompanyExpireDto();
			dto.setOrderStatus(companyDto.getOrderStatus() == null ? 0 : companyDto.getOrderStatus().intValue());// 订购状态
			dto.setExpireDate(DateUtil.format(disableTime));// 设置过期日期
			session.setAttribute(LoginContant.COMPANY_EXPIRE_INFO,JSONObject.toJSONString(dto));
			session.setAttribute(LoginContant.COMPANY_HAS_EXPIRED, true);
		}
		return true;
	}

	/**
	 * 实现方法
	 */
	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub

	}

	/**
	 * 实现方法
	 */
	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub

	}

}
