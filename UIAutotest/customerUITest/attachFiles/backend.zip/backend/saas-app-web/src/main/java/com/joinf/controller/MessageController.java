package com.joinf.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.joinf.annotations.NeedLogin;
import com.joinf.dto.CustomerContactSearchResult;
import com.joinf.dto.MessageDetailRequestDto;
import com.joinf.dto.MsgDetailInfoDto;
import com.joinf.dto.SearchCustomerContactParam;
import com.joinf.dto.SiteMessageDto;
import com.joinf.entity.SessionUser;
import com.joinf.entity.generator.Msg;
import com.joinf.interfaces.CompanyService;
import com.joinf.interfaces.CustomerService;
import com.joinf.interfaces.MsgService;
import com.joinf.interfaces.OperatorService;
import com.joinf.request.MessageDetailRequest;
import com.joinf.request.mesage.MessageListRequest;
import com.joinf.utils.SessionUtils;
import com.joinf.utils.base.BaseResponseEntity;
import com.joinf.utils.dto.user.UserInfoDto;
import com.joinf.utils.util.DateUtil;
import com.joinf.utils.util.JoinfBeanUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * 消息管理
 * 
 * @author CyNick
 *
 */
@RestController
@RequestMapping("/msg")
@Api(tags="消息管理")
public class MessageController {

	@Autowired
	private MsgService msgService;

	@Autowired
	private OperatorService operatorService;

	@Autowired
	private CustomerService customerService;
	@Autowired
	private CompanyService companyService;
	
	/**
	 * 查询年度账单统计数据
	 * 
	 * @param req
	 * @return
	 * @throws Exception 
	 */
	@ApiOperation(value = "查询消息列表", notes = "查询消息列表")
	@ApiImplicitParam(name = "req", value = "查询消息列表", required = true, dataType = "MessageListRequest")
	@PostMapping("getMessageList")
	@NeedLogin
	public BaseResponseEntity<List<Msg>> getMessageList(HttpServletRequest request, @RequestBody MessageListRequest req)
			throws Exception {
		BaseResponseEntity<List<Msg>> entity = new BaseResponseEntity<>(true);
		SessionUser user = SessionUtils.getCurrentUserInfo(request);

		Map<String, Object> map = new HashMap<String, Object>();
		// 公司ID
		map.put("companyId", user.getCompanyId());
		// 切换业务员ID
		map.put("operatorId", user.getSwitchOperatorId());
		map.put("pageStart", req.getNum());
		map.put("pageSize", req.getSize());
		Long type = req.getType();
		
		Long count = 0L;
		List<Msg> msgList = new ArrayList<Msg>();
		if(type != 5){
			if(type != 0){
				map.put("msgType", type);
			}

			// 获取公司下的所有业务员信息
			List<UserInfoDto> list = operatorService.getCompanyAllOperators(user.getCompanyId());

			count = msgService.selectCountByTypeAndOperatorId(map);

			msgList = msgService.selectMsgByTypeAndOperatorId(map);
			msgList.forEach(msg -> {
				String content = msg.getContent();
				int index = content.indexOf("#{loginName_");
				if (index > -1) {
					int m = content.lastIndexOf("}") + 1;
					String loginName = content.substring(index, m);
					Long operatorId = Long.valueOf(loginName.substring(12, loginName.length() - 1));

					for (UserInfoDto us : list) {
						if (us.getId().equals(operatorId)) {
							String userName = us.getUserName();
							String trueName = us.getChineseName();
							content = content.replace(loginName, userName).replace("#{name_" + operatorId + "}", trueName);
							msg.setContent(content);
						}
					}
				}
			});
			
			if(msgList.size() > 0){
				//更新消息为已读
				List<Long> ids = msgList.stream().map(Msg::getId).collect(Collectors.toList());
				msgService.updateHasRead(ids);
			}
		}else{
			// 调用营销网站接口获取数据
			Long centerCompanyId = SessionUtils.getCompanyInfo(request).getCenterCompanyId();
			Long centerOperatorId = user.getSwitchOperator().getCenterUserId();
//			Long centerCompanyId = 39779L;
//			Long centerOperatorId = 134070L;
			
			//获取营销网站数据
			String result = msgService.getMessageLog(centerCompanyId, centerOperatorId);
			JSONObject jsonRes = (JSONObject) JSONObject.parse(result);
			if(jsonRes.getBooleanValue("success")){
				List<SiteMessageDto> siteMess = new ArrayList<SiteMessageDto>();
				JSONObject jsonData = (JSONObject) JSONObject.parse(jsonRes.getString("data"));
				count = jsonData.getLong("total");
				if(count > 0){
					JSONArray arr = jsonData.getJSONArray("list");
					for(Object obj : arr){
						JSONObject data = (JSONObject) JSONObject.toJSON(obj);
						//营销网站数据保存到对象中，方便后面处理
						SiteMessageDto siteMessageDto = JSONObject.toJavaObject(data.getJSONObject("data"), SiteMessageDto.class);
						String time = data.getString("time");
						siteMessageDto.setTime(time);
						siteMess.add(siteMessageDto);
					}
					//用户中心companyid
//					List<Long> centerCompanyIds = siteMess.stream().boxMap(SiteMessageDto::getCenterCompanyId).collect(Collectors.toList()); //营销网站返回数据的用户中心公司id 集合
					List<String> emails = siteMess.stream().map(SiteMessageDto::getEmail).collect(Collectors.toList());						// 营销网站返回数据的 邮箱集合
					
					//获取companyID
//					List<Long> companyIds = companyService.selectByCenterCompanyIds(centerCompanyIds); //获取tms 的 companyId 集合
					List<Long> companyIds = new ArrayList<Long>();
					companyIds.add(user.getCompanyId());
					//1.通过email 查询客户信息,判断是否是已建档客户
					SearchCustomerContactParam sm = new SearchCustomerContactParam();
					sm.setCompanyIds(companyIds);
					sm.setEmails(emails);
					List<CustomerContactSearchResult> customerVoList= customerService.selectCustomerContactByEmails(sm);
					Map<String,Object> cusMap = customerVoList.stream().collect(Collectors.toMap(CustomerContactSearchResult::getEmail, CustomerContactSearchResult -> CustomerContactSearchResult));
					
					for(SiteMessageDto sitMsg : siteMess){
						
						CustomerContactSearchResult cus = (CustomerContactSearchResult) cusMap.get(sitMsg.getEmail());
						//拼接显示数据
						Msg msg = new Msg();
						StringBuffer pushMessage = new StringBuffer();
						// != null  则为已建档、否则为未建档
						if(cus != null){
							pushMessage.append(cus.getContactName());
							pushMessage.append("(");
							pushMessage.append(StringUtils.isEmpty(sitMsg.getCompanyName()) ? cus.getCustomerName() : sitMsg.getCompanyName() );   // 如果公司名称为空，则用客户名称代替
							pushMessage.append(")");
							pushMessage.append(sitMsg.getMsgType() == 1 ? "正在访问你的营销网站(" : "在营销网站(");
							pushMessage.append(sitMsg.getSiteName());
							pushMessage.append(")");
							pushMessage.append(sitMsg.getMsgType() == 2 ? "留言" : "");
						}else{
							pushMessage.append(!StringUtils.isEmpty(sitMsg.getCompanyName()) ? sitMsg.getEmail() :"Guest");
							pushMessage.append("(");
							pushMessage.append(StringUtils.isEmpty(sitMsg.getCompanyName()) ? sitMsg.getEmail() : sitMsg.getCompanyName() );
							pushMessage.append(")");
							pushMessage.append(sitMsg.getMsgType() == 1 ? "正在访问你的营销网站(" : "在营销网站(");
							pushMessage.append(sitMsg.getSiteName());
							pushMessage.append(")");
							pushMessage.append(sitMsg.getMsgType() == 2 ? "留言" : "");
						}
						
						msg.setMsgExplain(sitMsg.getMsgType() == 1 ? "网站访问" : "网站留言" );
						msg.setContent(pushMessage.toString());
						msg.setCreateTime(DateUtil.parse(DateUtil.stampToDate(sitMsg.getTime()), "yyyy-MM-dd HH:mm:ss"));
						msg.setMsgType(5);
						msgList.add(msg);
					}
				}
			}else{
				entity.setSuccess(false);
				entity.setErrMsg(jsonRes.getString("msg"));
			}
		}
		
		entity.setTotalPage((int)(count%req.getSize() == 0 ? count/req.getSize() : count/req.getSize() + 1));
		entity.setTotalRecords(count);
		entity.setData(msgList);
		return entity;
	}
	
	
	/**
	 * 查询消息明细
	 * 
	 * @param req
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value = "查询消息明细", notes = "查询消息明细")
	@ApiImplicitParam(name = "req", value = "查询消息明细", required = true, dataType = "MessageDetailRequest")
	@PostMapping("getMsgDetailListJson")
	@NeedLogin
	public BaseResponseEntity<List<MsgDetailInfoDto>> getMsgDetailListJson(HttpServletRequest request, @RequestBody MessageDetailRequest req)
			throws Exception {
		BaseResponseEntity<List<MsgDetailInfoDto>> entity = new BaseResponseEntity<>(true);
		 
		MessageDetailRequestDto reqDto = JoinfBeanUtils.copyToNewBean(MessageDetailRequestDto.class, req);
		
		int count = msgService.selectMsgDetailCountByMsgId(reqDto.getId());
		
		List<MsgDetailInfoDto> data = msgService.searchMsgDetailListByMsgId(reqDto);
		entity.setTotalRecords(Long.valueOf(count));
		entity.setTotalPage(count%req.getSize() == 0 ? count/req.getSize() : count/req.getSize() + 1);
		entity.setData(data);
		return entity;
	}
}
