package com.joinf.response;

import io.swagger.annotations.ApiModelProperty;

import com.alibaba.fastjson.JSONArray;
import com.joinf.entity.generator.CustomizeColumn;
import com.joinf.entity.generator.CustomizeResourceColumn;

/**
 * Description: 编辑界面返回数据
 *
 * @author lyj
 * @date 2017年12月13日 下午4:08:02
 */
public class EditDetailResponse {
	
	@ApiModelProperty(value="字段结构详细信息--自定义",required=true)
	private CustomizeColumn customizeColumn;
	
	@ApiModelProperty(value="字段结构详细信息--基础字段",required=true)
	private CustomizeResourceColumn customizeResourceColumn;

	@ApiModelProperty(value="字段标志",required=true)
	private String id;
	
	@ApiModelProperty(value="是否显示:1/显示",required=true)
	private Integer isShow;
	
	@ApiModelProperty(value="是否只读:0/否",required=true)
	private Integer isReadonly;
	
	@ApiModelProperty(value="占用行数",required=true)
	private Integer rows;
	
	@ApiModelProperty(value="占用列数",required=true)
	private Integer cols;
	
	@ApiModelProperty(value="顺序",required=true)
	private Integer sort;
	
	@ApiModelProperty(value="类别:'-1权限(是否拥有编辑权限,不显示),数据类型:1/整数;2/小数-金额;3/日期;4/是否;5/图片;6/数据字典;7/客户选择;8/用户选择;9/自定义编码;10/字符;11/百分比;12/产品选择'",required=true)
	private Integer type;
	
	@ApiModelProperty(value="字段对应值",required=true)
	private Object value;
	
	@ApiModelProperty(value="字段原始值",required=true)
	private Object originalValue;
	@ApiModelProperty(value="如果类型为数据字典，则对应相应的基础数据;如果oneToMany=1则显示一个总数",required=true)
	private JSONArray dictionarys;
	
	@ApiModelProperty(value="是否是一对多 0否 1是",required=true)
	private Integer oneToMany = 0;
	
	@ApiModelProperty(value="是否异步加载数据默认false",required=true)
	private  boolean async=false;
	@ApiModelProperty(value="是否强制输入",required=true)
	private Boolean force;
	
	@ApiModelProperty(value = "自定义默认值")
	private String customizeDefaultValue;

	@ApiModelProperty(value = "自定义默认值小数位数")
	private Integer customizeDecimalNumber;

	public boolean isAsync() {
		return async;
	}
	public void setAsync(boolean async) {
		this.async = async;
	}
	public Object getOriginalValue() {
		return originalValue;
	}
	public void setOriginalValue(Object originalValue) {
		this.originalValue = originalValue;
	}
	
	public Integer getOneToMany() {
		return oneToMany;
	}
	public void setOneToMany(Integer oneToMany) {
		this.oneToMany = oneToMany;
	}
	public Object getValue() {
		return value;
	}
	public void setValue(Object value) {
		this.value = value;
	}
	public JSONArray getDictionarys() {
		return dictionarys;
	}
	public void setDictionarys(JSONArray dictionarys) {
		this.dictionarys = dictionarys;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Integer getIsShow() {
		return isShow;
	}
	public void setIsShow(Integer isShow) {
		this.isShow = isShow;
	}
	public Integer getIsReadonly() {
		return isReadonly;
	}
	public void setIsReadonly(Integer isReadonly) {
		this.isReadonly = isReadonly;
	}
	public Integer getRows() {
		return rows;
	}
	public void setRows(Integer rows) {
		this.rows = rows;
	}
	public Integer getCols() {
		return cols;
	}
	public void setCols(Integer cols) {
		this.cols = cols;
	}
	public Integer getSort() {
		return sort;
	}
	public void setSort(Integer sort) {
		this.sort = sort;
	}
	public CustomizeColumn getCustomizeColumn() {
		return customizeColumn;
	}
	public void setCustomizeColumn(CustomizeColumn customizeColumn) {
		this.customizeColumn = customizeColumn;
	}
	public CustomizeResourceColumn getCustomizeResourceColumn() {
		return customizeResourceColumn;
	}
	public void setCustomizeResourceColumn(CustomizeResourceColumn customizeResourceColumn) {
		this.customizeResourceColumn = customizeResourceColumn;
	}

	public Boolean getForce() {
		return force;
	}

	public void setForce(Boolean force) {
		this.force = force;
	}
	public String getCustomizeDefaultValue() {
		return customizeDefaultValue;
	}
	public void setCustomizeDefaultValue(String customizeDefaultValue) {
		this.customizeDefaultValue = customizeDefaultValue;
	}
	public Integer getCustomizeDecimalNumber() {
		return customizeDecimalNumber;
	}
	public void setCustomizeDecimalNumber(Integer customizeDecimalNumber) {
		this.customizeDecimalNumber = customizeDecimalNumber;
	}
	
}
