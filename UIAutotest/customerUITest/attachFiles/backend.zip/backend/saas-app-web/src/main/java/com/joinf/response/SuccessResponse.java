package com.joinf.response;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 是否成功返回对象
 *
 * @author lyj
 * @date 2017年12月12日 上午10:32:47
 */
public class SuccessResponse {
	
	public SuccessResponse(){}
	
	public SuccessResponse(boolean success){
		this.success = success;
	}
	public SuccessResponse(boolean success,String error){
		this.success = success;
		this.error = error;
	}

	@ApiModelProperty(value="是否成功",required=true)
	private boolean success = true;
	
	@ApiModelProperty(value="错误信息",required=true)
	private String error;

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
}
