package com.joinf.response;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;

/**
 * Description: 列表中-自定义显示的列
 *
 * @author lyj
 * @date 2017年12月6日 下午2:56:00
 */
public class CustomizeChildColumn implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -9184125615323939940L;

	@ApiModelProperty(value="名称",required=true)
	private String name;
	
	@ApiModelProperty(value="对应的值",required=true)
	private Object value;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

}
