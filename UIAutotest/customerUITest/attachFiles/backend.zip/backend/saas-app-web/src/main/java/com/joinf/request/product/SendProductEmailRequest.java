package com.joinf.request.product;

import java.util.List;

/**
 * Description: 发送产品邮件
 *
 * @author lyj
 * @date 2018年4月10日 下午3:46:36
 */
public class SendProductEmailRequest {

	private Long templateId;
	
	private List<Long>productIds;

	public Long getTemplateId() {
		return templateId;
	}

	public void setTemplateId(Long templateId) {
		this.templateId = templateId;
	}

	public List<Long> getProductIds() {
		return productIds;
	}

	public void setProductIds(List<Long> productIds) {
		this.productIds = productIds;
	}
}
