package com.joinf.interfaces;

import com.joinf.dto.*;
import com.joinf.entity.generator.BusinessClue;
import com.joinf.entity.generator.BusinessClueDetail;

import java.util.List;


/**
 * 商机-线索接口
 *
 * @author yzq
 * @date 2019-04-15
 */
public interface BusinessClueService {
    /**
     * 获取线索列表
     * @param dto
     * @return
     */
    List<BusinessClueDto> selectBusinessClueByDto(QueryBusinessClueDto dto);

    /**
     * 通过线索id+companyId获取线索
     * @param clueId 线索id
     * @param companyId 企业id
     * @return
     */
    BusinessClueDetailDto selectBusinessClue(Long clueId,Long companyId);

    /**
     * 通过线索id获取线索来源
     * @param clueId 线索id
     * @return
     */
    List<BusinessCLueSourceDto> selectBusinessClueSourceById(Long clueId);

    /**
     * 更新线索状态
     * @param ids
     * @param clueStatus 见：BusinessClueStatusEnum
     * @param companyId
     * @return
     */
    int updateClueStatusByIds(List<Long> ids, int clueStatus, Long companyId);

    /**
     * 通过线索id获取线索
     * @param clueId 线索id
     * @return
     */
    BusinessClueDetailDto selectBusinessClueById(Long clueId);

    /**
     * 通过邮箱+企业id查询商机线索的条数
     * @param email
     * @param companyId
     * @return
     */
    BusinessClue checkBusinessClueByEmailAndComId(String email, Long companyId);

    /**
     * 根据主键更新商机线索
     * @param businessClue
     * @return
     */
    int updateByPrimaryKeySelective(BusinessClue businessClue);

    /**
     * 插入线索基础数据
     * @param businessClue
     * @return
     */
    int insertSelective(BusinessClue businessClue);

    /**
     * 插入线索详情数据
     * @param detail
     * @return
     */
    int insertDetailSelective(BusinessClueDetail detail);

    /**
     * 获取线索处理信息
     * @param clueId
     * @param companyId
     * @return
     */
    List<BusinessClueFilingDto> queryBusinessClueFiling(Long clueId, Long companyId);

    /**
     * 通过ids+企业id获取线索的数据
     * @param ids
     * @param companyId
     * @return
     */
    List<BusinessClue> selectBusinessClueByIds(List<Long> ids, Long companyId);
}
