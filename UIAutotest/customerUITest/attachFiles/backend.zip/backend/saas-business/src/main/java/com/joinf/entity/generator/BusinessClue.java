package com.joinf.entity.generator;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;

/**
 * t_business_clue
 */
public class BusinessClue implements Serializable {
    @ApiModelProperty(value ="ID")
    private Long id;

    @ApiModelProperty(value ="公司ID")
    private Long companyId;

    @ApiModelProperty(value ="操作人ID")
    private Long operatorId;

    @ApiModelProperty(value ="线索名称")
    private String clueName;

    @ApiModelProperty(value ="线索邮箱")
    private String clueEmail;

    @ApiModelProperty(value ="企业信息")
    private String enterpriseInformation;

    @ApiModelProperty(value ="线索类型(0:询盘信息;1:注册会员;2:访问咨询;3:商业数据;优先级显示)")
    private Integer clueType;

    @ApiModelProperty(value ="线索等级:(0:待定;1:一星;2:二星;3:三星;4:四星;5:五星)")
    private Integer clueGrade;

    @ApiModelProperty(value ="线索状态:(0:待处理;1:已处理;2:已忽略)")
    private Integer clueStatus;

    @ApiModelProperty(value ="来源id(推送数据)")
    private Long sourceId;

    @ApiModelProperty(value ="修改人id")
    private Long updateId;

    @ApiModelProperty(value ="创建人id")
    private Long createId;

    @ApiModelProperty(value ="更新日期")
    private Date updateTime;

    @ApiModelProperty(value ="创建日期")
    private Date createTime;

    @ApiModelProperty(value ="有效标志:0/无效;1/有效")
    private Integer flag;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public Long getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(Long operatorId) {
        this.operatorId = operatorId;
    }

    public String getClueName() {
        return clueName;
    }

    public void setClueName(String clueName) {
        this.clueName = clueName == null ? null : clueName.trim();
    }

    public String getClueEmail() {
        return clueEmail;
    }

    public void setClueEmail(String clueEmail) {
        this.clueEmail = clueEmail == null ? null : clueEmail.trim();
    }

    public String getEnterpriseInformation() {
        return enterpriseInformation;
    }

    public void setEnterpriseInformation(String enterpriseInformation) {
        this.enterpriseInformation = enterpriseInformation == null ? null : enterpriseInformation.trim();
    }

    public Integer getClueType() {
        return clueType;
    }

    public void setClueType(Integer clueType) {
        this.clueType = clueType;
    }

    public Integer getClueGrade() {
        return clueGrade;
    }

    public void setClueGrade(Integer clueGrade) {
        this.clueGrade = clueGrade;
    }

    public Integer getClueStatus() {
        return clueStatus;
    }

    public void setClueStatus(Integer clueStatus) {
        this.clueStatus = clueStatus;
    }

    public Long getSourceId() {
        return sourceId;
    }

    public void setSourceId(Long sourceId) {
        this.sourceId = sourceId;
    }

    public Long getUpdateId() {
        return updateId;
    }

    public void setUpdateId(Long updateId) {
        this.updateId = updateId;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }
}