package com.joinf.interfaces;

import com.joinf.dto.QueryBusinessAttachmentDto;
import com.joinf.dto.UpdateBusinessAttachmentDto;
import com.joinf.entity.generator.BusinessAttachment;
import com.joinf.entity.BusinessAttachmentEntity;

import java.util.List;

/**
 * @author zlx
 * @Description: 商机附件接口
 * @date 2019年5月6日 下午7:20:50
 */
public interface BusinessAttachmentService {
	
	/**
	 * 查询商机附件列表
	 * @param queryDto
	 * @return
	 */
	List<BusinessAttachmentEntity> queryBusinessAttachmentListByCondition(QueryBusinessAttachmentDto queryDto);


    /**
     * 插入商机附件信息
     * @param businessAttachment
     * @return
     */
    int insert(BusinessAttachment businessAttachment);
    
    /**
     * 删除商机附件
     * @param deleteDto
     * @return
     */
    int deleteBusinessAttachment(UpdateBusinessAttachmentDto deleteDto);
    
    /**
     * 绑定商机附件
     * @param updateDto
     * @return
     */
    int bindingBusinessAttachment(UpdateBusinessAttachmentDto updateDto);

    
}
