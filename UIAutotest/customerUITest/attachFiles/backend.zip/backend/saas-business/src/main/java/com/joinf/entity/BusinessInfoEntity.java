package com.joinf.entity;

import com.joinf.entity.generator.Business;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * 商机简要信息查看
 *
 * @Author cxi
 * @Date 2019-07-31 19:08
 **/
@Getter
@Setter
public class BusinessInfoEntity extends Business{

    @ApiModelProperty(value ="是否关联：0-未关联， 1-关联")
    private Integer associate;

    @ApiModelProperty(value = "关联ID")
    private Long relId;

    @ApiModelProperty(value = "业务员名称")
    private String operatorName;

    @ApiModelProperty(value = "货币单元名称")
    private String priceUnitName;

    @ApiModelProperty(value ="开始日期")
    private String startDateStr;

    @ApiModelProperty(value ="结单日期")
    private String endDateStr;

    @ApiModelProperty(value ="创建日期")
    private String createTimeStr;

    @ApiModelProperty(value ="预计签单日期")
    private String signDateStr;

    @ApiModelProperty(value ="跟进阶段")
    private String flowStepStr;

}
