package com.joinf.mapper;

import com.joinf.dto.QueryBusinessAttachmentDto;
import com.joinf.dto.UpdateBusinessAttachmentDto;
import com.joinf.entity.BusinessAttachmentEntity;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author zlx
 * @Description: 商机附件Dao
 * @date 2019年5月6日 下午7:33:39
 */
@Mapper
public interface BusinessAttachmentExMapper {
	
	/**
	 * 查询商机附件列表
	 * @param queryDto
	 * @return
	 */
	List<BusinessAttachmentEntity> queryBusinessAttachmentListByCondition(QueryBusinessAttachmentDto queryDto);
	
	
	/**
	 * 删除商机附件
	 * @param deleteDto
	 * @return
	 */
	int deleteBusinessAttachment(UpdateBusinessAttachmentDto deleteDto);
	
	/**
	 * 绑定商机附件
	 * @param updateDto
	 * @return
	 */
	int bindingBusinessAttachment(UpdateBusinessAttachmentDto updateDto);
	
}
