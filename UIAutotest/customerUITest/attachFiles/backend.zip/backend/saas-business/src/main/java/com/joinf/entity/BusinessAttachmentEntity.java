package com.joinf.entity;

import com.joinf.entity.generator.BusinessAttachment;

/**
 * Demo class
 *
 * @author yzq
 * @date 2019-06-04
 */
public class BusinessAttachmentEntity extends BusinessAttachment {
    /**
     * 创建人中文名
     */
    private String createName;

    public String getCreateName() {
        return createName;
    }

    public void setCreateName(String createName) {
        this.createName = createName;
    }
}
