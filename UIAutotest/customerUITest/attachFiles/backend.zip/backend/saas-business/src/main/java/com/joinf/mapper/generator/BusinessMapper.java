package com.joinf.mapper.generator;

import com.joinf.entity.generator.Business;
import org.apache.ibatis.annotations.Mapper;

/**
 * t_business 对应映射文件
 */
@Mapper
public interface BusinessMapper {
    /** 根据主键删除对象 对应映射方法 */
    int deleteByPrimaryKey(Long id);

    /** 插入 对应映射方法 */
    int insert(Business record);

    /** 插入对象(根据属性是否为空) 对应映射方法 */
    int insertSelective(Business record);

    /** 根据主键查询 对应映射方法 */
    Business selectByPrimaryKey(Long id);

    /** 根据主键修改对象信息 对应映射方法 */
    int updateByPrimaryKeySelective(Business record);

    /** 根据主键修改对象信息 对应映射方法 */
    int updateByPrimaryKey(Business record);
}