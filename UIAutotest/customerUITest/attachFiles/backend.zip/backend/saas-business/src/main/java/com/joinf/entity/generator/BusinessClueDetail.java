package com.joinf.entity.generator;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;

/**
 * t_business_clue_detail
 */
public class BusinessClueDetail implements Serializable {
    @ApiModelProperty(value ="ID")
    private Long id;

    @ApiModelProperty(value ="公司id")
    private Long companyId;

    @ApiModelProperty(value ="操作人id")
    private Long operatorId;

    @ApiModelProperty(value ="线索id")
    private Long clueId;

    @ApiModelProperty(value ="线索类型(0:询盘信息;1:注册会员;2:访问咨询;3:商业数据;4:营销邮件)")
    private Integer type;

    @ApiModelProperty(value ="线索内容")
    private String content;

    @ApiModelProperty(value ="来源地址")
    private String url;

    @ApiModelProperty(value ="自定义字段1(网址个数、打开次数、访问次数)")
    private Integer selfCustom1;

    @ApiModelProperty(value ="自定义字段2(邮箱个数、停留时间、点击次数)")
    private Integer selfCustom2;

    @ApiModelProperty(value ="自定义字段3(访问次数)")
    private Integer selfCustom3;

    @ApiModelProperty(value ="更新人")
    private Long updateId;

    @ApiModelProperty(value ="创建人")
    private Long createId;

    @ApiModelProperty(value ="更新时间")
    private Date updateTime;

    @ApiModelProperty(value ="创建时间")
    private Date createTime;

    @ApiModelProperty(value ="有效标志:0/无效;1/有效")
    private Integer flag;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public Long getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(Long operatorId) {
        this.operatorId = operatorId;
    }

    public Long getClueId() {
        return clueId;
    }

    public void setClueId(Long clueId) {
        this.clueId = clueId;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url == null ? null : url.trim();
    }

    public Integer getSelfCustom1() {
        return selfCustom1;
    }

    public void setSelfCustom1(Integer selfCustom1) {
        this.selfCustom1 = selfCustom1;
    }

    public Integer getSelfCustom2() {
        return selfCustom2;
    }

    public void setSelfCustom2(Integer selfCustom2) {
        this.selfCustom2 = selfCustom2;
    }

    public Integer getSelfCustom3() {
        return selfCustom3;
    }

    public void setSelfCustom3(Integer selfCustom3) {
        this.selfCustom3 = selfCustom3;
    }

    public Long getUpdateId() {
        return updateId;
    }

    public void setUpdateId(Long updateId) {
        this.updateId = updateId;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }
}