package com.joinf.dto;

import java.io.Serializable;
import java.util.List;

/**
 * 线索详情
 *
 * @author yzq
 * @date 2019-04-16
 */
public class BusinessClueDetailDto implements Serializable {

    private static final long serialVersionUID = -563632557841499239L;

    /**
     * 线索id
     */
    private Long id;
    /**
     * 名称
     */
    private String clueName;

    /**
     * 邮箱
     */
    private String clueEmail;

    /**
     * 线索名称（名称<邮箱>）
     */
    private String name;

    /**
     * 企业信息
     */
    private String enterpriseInformation;

    /**
     * 线索等级
     */
    private Integer clueGrade;

    /**
     * 线索来源
     */
    private List<BusinessCLueSourceDto> clueSourceResponseList;

    /**
     * 线索状态
     */
    private Integer clueStatus;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEnterpriseInformation() {
        return enterpriseInformation;
    }

    public void setEnterpriseInformation(String enterpriseInformation) {
        this.enterpriseInformation = enterpriseInformation;
    }

    public Integer getClueGrade() {
        return clueGrade;
    }

    public void setClueGrade(Integer clueGrade) {
        this.clueGrade = clueGrade;
    }

    public List<BusinessCLueSourceDto> getClueSourceResponseList() {
        return clueSourceResponseList;
    }

    public void setClueSourceResponseList(List<BusinessCLueSourceDto> clueSourceResponseList) {
        this.clueSourceResponseList = clueSourceResponseList;
    }

    public String getClueName() {
        return clueName;
    }

    public void setClueName(String clueName) {
        this.clueName = clueName;
    }

    public String getClueEmail() {
        return clueEmail;
    }

    public void setClueEmail(String clueEmail) {
        this.clueEmail = clueEmail;
    }

    public Integer getClueStatus() {
        return clueStatus;
    }

    public void setClueStatus(Integer clueStatus) {
        this.clueStatus = clueStatus;
    }
}
