package com.joinf.dto;

/**
 * 商机详情-email dto
 *
 * @author yzq
 * @date 2019-05-10
 */
public class BusinessEmailDto {

    /**
     * 邮箱标识
     */
    private Long id;

    /**
     * 邮箱地址
     */
    private String email;

    /**
     * 发件人邮箱
     */
    private String fromEmail;

    /**
     * 收件人邮箱
     */
    private String recipients;
    /**
     * 邮箱地址
     */
    private String subject;

    /**
     * 操作
     */
    private String lastOperater;


    /**
     * 状态（）
     */
    private String status;

    /**
     * 时间
     */
    private String createTime;

    /**
     * 联系人id
     */
    private Long contactId;

    /**
     * 联系人名称
     */
    private String contactName;

    /**
     * 客户id
     */
    private Long customerId;

    /**
     * 0 收信 1 发信
     */
    private Integer emailType;

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getLastOperater() {
        return lastOperater;
    }

    public void setLastOperater(String lastOperater) {
        this.lastOperater = lastOperater;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getFromEmail() {
        return fromEmail;
    }

    public void setFromEmail(String fromEmail) {
        this.fromEmail = fromEmail;
    }

    public String getRecipients() {
        return recipients;
    }

    public void setRecipients(String recipients) {
        this.recipients = recipients;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getContactId() {
        return contactId;
    }

    public void setContactId(Long contactId) {
        this.contactId = contactId;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public Integer getEmailType() {
        return emailType;
    }

    public void setEmailType(Integer emailType) {
        this.emailType = emailType;
    }
}
