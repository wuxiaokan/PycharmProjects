package com.joinf.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * 商机线索来源
 *
 * @author yzq
 * @date 2019-04-16
 */
public class BusinessCLueSourceDto implements Serializable {

    private static final long serialVersionUID = -944327296923101050L;

    /**
     * 线索来源地址
     */
    private String url;

    /**
     * 线索内容（询盘时使用）
     */
    private String content;

    /**
     * 线索来源时间
     */
    private Date createTime;

    /**
     * 自定义字段1(网址个数/停留时间)
     */
    private Integer selfCustom1;

    /**
     * 自定义字段2(邮箱个数)
     */
    private Integer selfCustom2;

    /**
     * 自定义字段(访问次数)
     */
    private Integer selfCustom3;

    /**
     * 操作员姓名
     */
    private String operatorName;

    /**
     * 操作员id
     */
    private Long operatorId;

    /**
     * 线索类型(0:询盘信息;1:注册会员;2:访问咨询;3:商业数据;4:邮件营销)
     */
    private Integer type;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getSelfCustom1() {
        return selfCustom1;
    }

    public void setSelfCustom1(Integer selfCustom1) {
        this.selfCustom1 = selfCustom1;
    }

    public Integer getSelfCustom2() {
        return selfCustom2;
    }

    public void setSelfCustom2(Integer selfCustom2) {
        this.selfCustom2 = selfCustom2;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getSelfCustom3() {
        return selfCustom3;
    }

    public void setSelfCustom3(Integer selfCustom3) {
        this.selfCustom3 = selfCustom3;
    }

    public Long getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(Long operatorId) {
        this.operatorId = operatorId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
