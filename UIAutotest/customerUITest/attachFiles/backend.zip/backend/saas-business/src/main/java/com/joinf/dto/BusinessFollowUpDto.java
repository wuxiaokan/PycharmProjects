package com.joinf.dto;

/**
 * 商机详情-跟进
 *
 * @author yzq
 * @date 2019-05-09
 */
public class BusinessFollowUpDto {

    /**
     * 操作员
     */
    private String operatorName;

    /**
     *跟进时间
     */
    private String createTime;

    /**
     * 操作员id
     */
    private Long operatorId;

    /**
     *联系内容
     */
    private String contactContent;

    public String getOperatorName() {
        return operatorName;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getContactContent() {
        return contactContent;
    }

    public void setContactContent(String contactContent) {
        this.contactContent = contactContent;
    }

    public Long getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(Long operatorId) {
        this.operatorId = operatorId;
    }
}
