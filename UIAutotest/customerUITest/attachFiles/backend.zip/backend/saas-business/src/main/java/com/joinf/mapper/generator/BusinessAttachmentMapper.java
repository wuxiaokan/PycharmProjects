package com.joinf.mapper.generator;

import com.joinf.entity.generator.BusinessAttachment;
import org.apache.ibatis.annotations.Mapper;

/**
 * t_business_attachment 对应映射文件
 */
@Mapper
public interface BusinessAttachmentMapper {
    /** 根据主键删除对象 对应映射方法 */
    int deleteByPrimaryKey(Long id);

    /** 插入 对应映射方法 */
    int insert(BusinessAttachment record);

    /** 插入对象(根据属性是否为空) 对应映射方法 */
    int insertSelective(BusinessAttachment record);

    /** 根据主键查询 对应映射方法 */
    BusinessAttachment selectByPrimaryKey(Long id);

    /** 根据主键修改对象信息 对应映射方法 */
    int updateByPrimaryKeySelective(BusinessAttachment record);

    /** 根据主键修改对象信息 对应映射方法 */
    int updateByPrimaryKey(BusinessAttachment record);
}