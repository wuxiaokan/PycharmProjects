package com.joinf.entity;

import com.joinf.entity.generator.Business;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * 商机字段
 *
 * @author yzq
 * @date 2019-04-17
 */
public class BusinessEntity extends Business implements Serializable {

    private static final long serialVersionUID = 7806559698302305677L;

    @ApiModelProperty(value = "业务员姓名")
    private String salemanId;

    @ApiModelProperty(value = "关联线索名称")
    private String clueName;

    @ApiModelProperty(value = "邮箱")
    private String email;

    @ApiModelProperty(value = "创建人")
    private String creator;

    public String getClueName() {
        return clueName;
    }

    public void setClueName(String clueName) {
        this.clueName = clueName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSalemanId() {
        return salemanId;
    }

    public void setSalemanId(String salemanId) {
        this.salemanId = salemanId;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }
}
