package com.joinf.dto;

import java.util.List;

/**
 * 保存商机关联-邮件的参数
 *
 * @author yzq
 * @date 2019-05-15
 */
public class SaveBusinessEmailRelDto {

    private Long businessId;

    private List<Long> emailIds;

    private Long companyId;

    private Long operatorId;

    /**
     * 1：订单；2：报价；3：商机
     */
    private Byte type;

    /**
     * 0：系统关联；1：手动关联
     */
    private Byte relationType;

    /**
     * 邮件id
     */
    private Long emailId;

    public Long getBusinessId() {
        return businessId;
    }

    public void setBusinessId(Long businessId) {
        this.businessId = businessId;
    }

    public List<Long> getEmailIds() {
        return emailIds;
    }

    public void setEmailIds(List<Long> emailIds) {
        this.emailIds = emailIds;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public Long getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(Long operatorId) {
        this.operatorId = operatorId;
    }

    public Byte getType() {
        return type;
    }

    public void setType(Byte type) {
        this.type = type;
    }

    public Byte getRelationType() {
        return relationType;
    }

    public void setRelationType(Byte relationType) {
        this.relationType = relationType;
    }

    public Long getEmailId() {
        return emailId;
    }

    public void setEmailId(Long emailId) {
        this.emailId = emailId;
    }

}
