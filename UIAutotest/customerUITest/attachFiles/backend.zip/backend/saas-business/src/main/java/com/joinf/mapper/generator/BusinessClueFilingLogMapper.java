package com.joinf.mapper.generator;

import com.joinf.entity.generator.BusinessClueFilingLog;
import org.apache.ibatis.annotations.Mapper;

/**
 * t_business_clue_filing_log 对应映射文件
 */
@Mapper
public interface BusinessClueFilingLogMapper {
    /** 根据主键删除对象 对应映射方法 */
    int deleteByPrimaryKey(Long id);

    /** 插入 对应映射方法 */
    int insert(BusinessClueFilingLog record);

    /** 插入对象(根据属性是否为空) 对应映射方法 */
    int insertSelective(BusinessClueFilingLog record);

    /** 根据主键查询 对应映射方法 */
    BusinessClueFilingLog selectByPrimaryKey(Long id);

    /** 根据主键修改对象信息 对应映射方法 */
    int updateByPrimaryKeySelective(BusinessClueFilingLog record);

    /** 根据主键修改对象信息 对应映射方法 */
    int updateByPrimaryKey(BusinessClueFilingLog record);
}