package com.joinf.entity;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

/**
 * 商机共享请求参数
 *
 * @author yzq
 * @date 2019-05-14
 */
public class BusinessShareRelEntity implements Serializable {

    private static final long serialVersionUID = 8942212531940074355L;

    @ApiModelProperty(value = "业务员id")
    private Long operatorId;

    @ApiModelProperty(value ="是否只读:0/否;1/是")
    private Byte isView;

    public Long getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(Long operatorId) {
        this.operatorId = operatorId;
    }

    public Byte getIsView() {
        return isView;
    }

    public void setIsView(Byte isView) {
        this.isView = isView;
    }

    @Override
    public String toString() {
        return "BusinessShareRelEntity{" +
                "operatorId=" + operatorId +
                ", isView=" + isView +
                '}';
    }
}
