package com.joinf.entity;

import com.joinf.entity.generator.Business;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * Demo class
 *
 * @author yzq
 * @date 2019-04-23
 */
public class BusinessWithBLOBs extends Business {

    @ApiModelProperty(value ="备注;")
    private String description;

    @ApiModelProperty(value ="标签内容")
    private String tagContent;

    @ApiModelProperty(value = "下属业务员集合")
    private List<Long> operatorIdList;

    @ApiModelProperty(value = "商机id集合")
    private List<Long> idList;

    private static final long serialVersionUID = -821929559691509699L;

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }

    public String getTagContent() {
        return tagContent;
    }

    public void setTagContent(String tagContent) {
        this.tagContent = tagContent == null ? null : tagContent.trim();
    }

    public List<Long> getOperatorIdList() {
        return operatorIdList;
    }

    public void setOperatorIdList(List<Long> operatorIdList) {
        this.operatorIdList = operatorIdList;
    }

    public List<Long> getIdList() {
        return idList;
    }

    public void setIdList(List<Long> idList) {
        this.idList = idList;
    }
}
