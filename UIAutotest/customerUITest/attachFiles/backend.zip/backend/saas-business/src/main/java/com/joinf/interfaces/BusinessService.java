package com.joinf.interfaces;

import com.joinf.dto.BusinessEmailDto;
import com.joinf.dto.BusinessFollowUpDto;
import com.joinf.dto.BusinessOrderDto;
import com.joinf.dto.BusinessProductDto;
import com.joinf.dto.BusinessQuoteDto;
import com.joinf.dto.BusinessReadOnlyDto;
import com.joinf.dto.BusinessShareRelDto;
import com.joinf.dto.DeleteBusinessDto;
import com.joinf.dto.QueryBusinessDetailTableDto;
import com.joinf.dto.QueryBusinessEmailDto;
import com.joinf.dto.QueryBusinessInfoDto;
import com.joinf.dto.QueryBusinessParamDto;
import com.joinf.dto.SaveBusinessEmailRelDto;
import com.joinf.entity.BusinessEntity;
import com.joinf.entity.BusinessInfoEntity;
import com.joinf.entity.BusinessWithBLOBs;
import com.joinf.entity.generator.Business;
import com.joinf.entity.generator.BusinessShareRel;

import java.util.List;

/**
 * 商机接口
 *
 * @author yzq
 * @date 2019-04-17
 */
public interface BusinessService {

    /**
     * 查询商机基本数据
     * @param dto
     * @return
     */
    List<BusinessEntity> selectBusinessByDto(QueryBusinessParamDto dto);

    /**
     * 插入商机基本信息
     * @param business 商机参数
     * @return
     */
    int insert(Business business);

    /**
     * 更新商机
     * @param business
     * @return
     */
    int updateByPrimaryKey(Business business);

    /**
     * 通过主键id查询明细
     * @param id
     * @param companyId
     * @return
     */
    BusinessEntity selectBusinessByIdAndCompanyId(Long id,Long companyId);

    /**
     * 通过主键id查询基础数据
     * @param id
     * @return
     */
    Business selectByPrimaryKey(Long id);


    /**
     * 通过ids查询商机信息
     * @param dto
     * @return
     */
    List<Business> selectBusinessByIdsAndCidAndOid(DeleteBusinessDto dto);

    /**
     * 通过ids+公司更新商机信息
     * @param dto
     * @return
     */
    int updateByIdsAndCompanyId(DeleteBusinessDto dto);

    /**
     * 获取商机-报价
     * @param dto
     * @return
     */
    List<BusinessQuoteDto> selectBusinessQuotes(QueryBusinessDetailTableDto dto);

    /**
     * 获取商机-订单
     * @param dto
     * @return
     */
    List<BusinessOrderDto> selectBusinessOrders(QueryBusinessDetailTableDto dto);

    /**
     * 获取商机-跟进
     * @param dto
     * @return
     */
    List<BusinessFollowUpDto> selectBusinessFollowUps(QueryBusinessDetailTableDto dto);

    /**
     * 获取商机-已关联邮件
     * @param dto
     * @return
     */
    List<BusinessEmailDto> selectBusinessEmailRecord(QueryBusinessDetailTableDto dto);

    /**
     * 获取商机-产品
     * @param dto
     * @return
     */
    List<BusinessProductDto> selectBusinessProducts(QueryBusinessDetailTableDto dto);

    /**
     * 通过商机id+企业id删除商机共享业务员数据
     * @param id
     *  @param companyId
     * @return
     */
    int deleteBusinessShareById(Long id,Long companyId);

    /**
     * 批量增加商机共享操作人
     * @param shareRelList
     */
    void insertBusinessShareBatch(List<BusinessShareRel> shareRelList);

    /**
     * 通过businessId+companyId查询商机的共享操作员
     * @param businessId
     * @param companyId
     * @return
     */
    List<BusinessShareRel> selectBusinessShareByBidAndCid(Long businessId,Long companyId);

    /**
     * 查询商机可关联邮件
     * @param dto
     * @return
     */
    List<BusinessEmailDto> selectBusinessEmailRel(QueryBusinessEmailDto dto);

    /**
     * 保存商机-可关联邮件
     * @param dtoList
     * @return
     */
    int saveBusinessEmailRel(List<SaveBusinessEmailRelDto> dtoList);

    /**
     * 通过条件查询共享商机信息
     * @param dto
     * @return
     */
    List<BusinessShareRel> selectBusinessShareRelByCondition(BusinessReadOnlyDto dto);

    /**
     * 查询企业的所有共享商机信息的对应商机数目，用于判断是否是全共享
     * @param dto
     * @return
     */
    List<BusinessShareRelDto> selectCountBusinessShareByCompanyId(BusinessReadOnlyDto dto);

    /**
     * 通过条件查询商机
     * @param business
     * @return
     */
    List<Business> selectBusinessByCondition(BusinessWithBLOBs business);

    /**
     * 取消关联
     * @param dto
     * @return
     */
    boolean cancelBusinessEmailRel(SaveBusinessEmailRelDto dto);

    /**
     * 关联关系的商机详情
     * @author cxi
     * @date 2019/7/31/031
     * @param dto :
     * @return com.joinf.entity.BusinessInfoEntity
     * @throws
     */
    BusinessInfoEntity getBuisnessInfoById(QueryBusinessInfoDto dto);
}
