package com.joinf.dto;

/**
 * Demo class
 *
 * @author yzq
 * @date 2019-05-15
 */
public class QueryBusinessEmailDto extends PagerDto{

    /**
     * 商机id
     */
    public Long businessId;
    /**
     * 企业id
     */
    private Long companyId;

    /**
     * 邮件类型（0:收信；1:发信）
     */
    private Integer type;

    /**
     * 邮件主题
     */
    private String subject;

    /**
     * 联系人id
     */
    private Long contactId;

    /**
     * 客户id
     */
    private Long customerId;

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public Long getContactId() {
        return contactId;
    }

    public void setContactId(Long contactId) {
        this.contactId = contactId;
    }

    public Long getBusinessId() {
        return businessId;
    }

    public void setBusinessId(Long businessId) {
        this.businessId = businessId;
    }
}
