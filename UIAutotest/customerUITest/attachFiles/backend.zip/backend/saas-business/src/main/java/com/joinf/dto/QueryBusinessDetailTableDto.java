package com.joinf.dto;

/**
 * 查询商机详情-table页的请求参数
 *
 * @author yzq
 * @date 2019-05-10
 */
public class QueryBusinessDetailTableDto extends PagerDto{
    /**
     * 商机id
     */
    private Long businessId;

    /**
     * 企业id
     */
    private Long companyId;

    /**
     * 邮件:0收件;1发件||产品:0订单;1报价;2自定义;||文件:0附件;1邮件附件;2云盘文件
     */
    private Integer type;

    public Long getBusinessId() {
        return businessId;
    }

    public void setBusinessId(Long businessId) {
        this.businessId = businessId;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }
}
