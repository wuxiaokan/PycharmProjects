package com.joinf.dto;

import java.io.Serializable;

/**
 * 查询线索信息列表参数
 *
 * @author yzq
 * @date 2019-04-12
 */
public class QueryBusinessClueDto extends PagerDto implements Serializable {

    private static final long serialVersionUID = -1317291396651198082L;

    /**
     * 公司ID
     */
    private Long companyId;
    /**
     * 业务操作员ID
     */
    private Long operatorId;
    /**
     * 线索等级
     */
    private Integer clueGrade;

    /**
     * 线索来源
     */
    private Integer clueType;

    /**
     * 排序字段
     */
    private String sortColumn;

    /**
     * 排序类别
     */
    private String sortType;

    /**
     * 线索状态
     */
    private Integer clueStatus;

    public Integer getClueGrade() {
        return clueGrade;
    }

    public void setClueGrade(Integer clueGrade) {
        this.clueGrade = clueGrade;
    }

    public Integer getClueType() {
        return clueType;
    }

    public void setClueType(Integer clueType) {
        this.clueType = clueType;
    }

    public String getSortColumn() {
        return sortColumn;
    }

    public void setSortColumn(String sortColumn) {
        this.sortColumn = sortColumn;
    }

    public String getSortType() {
        return sortType;
    }

    public void setSortType(String sortType) {
        this.sortType = sortType;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public Long getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(Long operatorId) {
        this.operatorId = operatorId;
    }

    public Integer getClueStatus() {
        return clueStatus;
    }

    public void setClueStatus(Integer clueStatus) {
        this.clueStatus = clueStatus;
    }
}
