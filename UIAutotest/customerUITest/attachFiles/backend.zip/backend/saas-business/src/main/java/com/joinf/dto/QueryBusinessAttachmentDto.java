package com.joinf.dto;

/**
 * @author zlx
 * @Description: 查询商机附件参数
 * @date 2019年5月6日 下午7:35:48
 */
public class QueryBusinessAttachmentDto {
	
	/**
	 * 企业id
	 */
	private Long companyId;
	
	/**
	 * 商机id
	 */
	private Long businessId;

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public Long getBusinessId() {
		return businessId;
	}

	public void setBusinessId(Long businessId) {
		this.businessId = businessId;
	}

	
	
	
}
