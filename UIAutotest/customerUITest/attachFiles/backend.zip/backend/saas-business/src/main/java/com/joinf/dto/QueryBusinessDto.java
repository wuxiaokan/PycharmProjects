package com.joinf.dto;

import java.io.Serializable;
import java.util.List;

/**
 * 商机列表查询参数
 *
 * @author yzq
 * @date 2019-04-16
 */
public class QueryBusinessDto extends PagerDto implements Serializable {

    private static final long serialVersionUID = 7836297721258922303L;

    /**
     * 公司ID
     */
    private Long companyId;
    /**
     * 业务操作员ID
     */
    private Long operatorId;
    /**
     * 切换用户
     */
    private Long switchOperatorId;
    /**
     * 跟进阶段
     */
    private Long flowStep;

    /**
     * 执行状态
     */
    private Integer status;

    /**
     * 自己和自己的下属业务员id集合
     */
    private List<Long> operatorIdList;

    /**
     * 排序字段
     */
    private String sortColumn;

    /**
     * 排序类别
     */
    private String sortType;

    /**
     * 操作员角色ID
     */
    private Long roleId;
    /**
     * 业务员姓名
     */
    private String operatorName;
    /**
     * 资源id
     */
    private Long resourceId;

    /**
     * 表名
     */
    private String tableName;

    /**
     * 模块名称
     */
    private String module;

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public Long getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(Long operatorId) {
        this.operatorId = operatorId;
    }

    public Long getSwitchOperatorId() {
        return switchOperatorId;
    }

    public void setSwitchOperatorId(Long switchOperatorId) {
        this.switchOperatorId = switchOperatorId;
    }

    public Long getFlowStep() {
        return flowStep;
    }

    public void setFlowStep(Long flowStep) {
        this.flowStep = flowStep;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public List<Long> getOperatorIdList() {
        return operatorIdList;
    }

    public void setOperatorIdList(List<Long> operatorIdList) {
        this.operatorIdList = operatorIdList;
    }

    public String getSortColumn() {
        return sortColumn;
    }

    public void setSortColumn(String sortColumn) {
        this.sortColumn = sortColumn;
    }

    public String getSortType() {
        return sortType;
    }

    public void setSortType(String sortType) {
        this.sortType = sortType;
    }

    public Long getRoleId() {
        return roleId;
    }

    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public Long getResourceId() {
        return resourceId;
    }

    public void setResourceId(Long resourceId) {
        this.resourceId = resourceId;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }
}
