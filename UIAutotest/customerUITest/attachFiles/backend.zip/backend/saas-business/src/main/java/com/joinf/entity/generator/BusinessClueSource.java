package com.joinf.entity.generator;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;

/**
 * t_business_clue_source
 */
public class BusinessClueSource implements Serializable {
    @ApiModelProperty(value ="ID")
    private Long id;

    @ApiModelProperty(value ="线索id")
    private Long clueId;

    @ApiModelProperty(value ="线索类型(0:注册会员;1:询盘信息;2:访问咨询;3:商业数据;)")
    private Integer type;

    @ApiModelProperty(value ="线索内容")
    private String content;

    @ApiModelProperty(value ="来源地址")
    private String url;

    @ApiModelProperty(value ="自定义字段1(网址、回话、访问)")
    private Integer selfCustom1;

    @ApiModelProperty(value ="自定义字段2(邮箱、停留时间、平均停留时间)")
    private Integer selfCustom2;

    @ApiModelProperty(value ="")
    private Long updateId;

    @ApiModelProperty(value ="")
    private Long createId;

    @ApiModelProperty(value ="")
    private Date updateTime;

    @ApiModelProperty(value ="")
    private Date createTime;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getClueId() {
        return clueId;
    }

    public void setClueId(Long clueId) {
        this.clueId = clueId;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url == null ? null : url.trim();
    }

    public Integer getSelfCustom1() {
        return selfCustom1;
    }

    public void setSelfCustom1(Integer selfCustom1) {
        this.selfCustom1 = selfCustom1;
    }

    public Integer getSelfCustom2() {
        return selfCustom2;
    }

    public void setSelfCustom2(Integer selfCustom2) {
        this.selfCustom2 = selfCustom2;
    }

    public Long getUpdateId() {
        return updateId;
    }

    public void setUpdateId(Long updateId) {
        this.updateId = updateId;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}