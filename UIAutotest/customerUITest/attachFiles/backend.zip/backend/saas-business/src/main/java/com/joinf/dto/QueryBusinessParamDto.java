package com.joinf.dto;

import java.io.Serializable;
import java.util.List;

/**
 * 获取商机基本信息的请求参数
 *
 * @author yzq
 * @date 2019-04-17
 */
public class QueryBusinessParamDto extends PagerDto implements Serializable {

    private static final long serialVersionUID = -3526866981502263166L;

    /**
     * 公司ID
     */
    private Long companyId;

    /**
     * 跟进阶段
     */
    private Long flowStep;

    /**
     * 执行状态
     */
    private Integer status;

    /**
     * 自己和自己的下属业务员id集合
     */
    private List<Long> operatorIdList;

    /**
     * 排序字段
     */
    private String sortColumn;

    /**
     * 排序类别
     */
    private String sortType;

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public Long getFlowStep() {
        return flowStep;
    }

    public void setFlowStep(Long flowStep) {
        this.flowStep = flowStep;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public List<Long> getOperatorIdList() {
        return operatorIdList;
    }

    public void setOperatorIdList(List<Long> operatorIdList) {
        this.operatorIdList = operatorIdList;
    }

    public String getSortColumn() {
        return sortColumn;
    }

    public void setSortColumn(String sortColumn) {
        this.sortColumn = sortColumn;
    }

    public String getSortType() {
        return sortType;
    }

    public void setSortType(String sortType) {
        this.sortType = sortType;
    }

}
