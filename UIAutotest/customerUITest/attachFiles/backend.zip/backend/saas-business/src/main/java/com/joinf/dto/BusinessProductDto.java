package com.joinf.dto;

/**
 * 商机详情-产品table返回参数
 *
 * @author yzq
 * @date 2019-05-13
 */
public class BusinessProductDto {

    /**
     * 产品id
     */
    private Long productId;

    /**
     * 产品代码
     */
    private String code;

    /**
     * 英文名称
     */
    private String englishName;


    /**
     * 中文名称
     */
    private String chineseName;

    /**
     * 数量
     */
    private String count;

    /**
     * 金额
     */
    private String usdSum;

    /**
     * 商品图片
     */
    private String pictureCode;

    /**
     * 产品来源:[0]没有产品;[1]产品;[2]网店
     */
    private String productFrom;

    /**
     * 产品图片地址
     */
    private String pictureUrl;

    /**
     * 产品缩略图地址
     */
    private String pictureViewUrl;

    public String getPictureUrl() {
        return pictureUrl;
    }

    public void setPictureUrl(String pictureUrl) {
        this.pictureUrl = pictureUrl;
    }

    public String getPictureViewUrl() {
        return pictureViewUrl;
    }

    public void setPictureViewUrl(String pictureViewUrl) {
        this.pictureViewUrl = pictureViewUrl;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getEnglishName() {
        return englishName;
    }

    public void setEnglishName(String englishName) {
        this.englishName = englishName;
    }

    public String getChineseName() {
        return chineseName;
    }

    public void setChineseName(String chineseName) {
        this.chineseName = chineseName;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getUsdSum() {
        return usdSum;
    }

    public void setUsdSum(String usdSum) {
        this.usdSum = usdSum;
    }

    public String getPictureCode() {
        return pictureCode;
    }

    public void setPictureCode(String pictureCode) {
        this.pictureCode = pictureCode;
    }

    public String getProductFrom() {
        return productFrom;
    }

    public void setProductFrom(String productFrom) {
        this.productFrom = productFrom;
    }
}
