package com.joinf.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * 查询商机信息
 *
 * @Author cxi
 * @Date 2019-07-31 17:19
 **/
@Getter
@Setter
public class QueryBusinessInfoDto extends CompanyAndOperatorIdDto{

    private Long id;

    private Long emailId;
}
