package com.joinf.dto;

/**
 * 商机详情-报价
 *
 * @author yzq
 * @date 2019-05-09
 */
public class BusinessQuoteDto {

    /**
     * 报价id
     */
    private Long id;

    /**
     * 报价单号
     */
    private String code;

    /**
     * 客户名称
     */
    private String customerName;

    /**
     * 合同总额:币种+金额
     */
    private String totalAmount;

    /**
     * 联系人
     */
    private String contactName;

    /**
     * 报价日期
     */
    private String quoteDate;

    /**
     * 币种
     */
    private String currencyName;



    /**
     * 状态（状态:1/草拟;2/待审批;3/修改;4/生效;5/作废）
     */
    private String status;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getQuoteDate() {
        return quoteDate;
    }

    public void setQuoteDate(String quoteDate) {
        this.quoteDate = quoteDate;
    }

    public String getCurrencyName() {
        return currencyName;
    }

    public void setCurrencyName(String currencyName) {
        this.currencyName = currencyName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
