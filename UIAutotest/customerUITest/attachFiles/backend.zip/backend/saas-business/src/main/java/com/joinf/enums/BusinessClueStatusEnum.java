package com.joinf.enums;

/**
 * @author zlx
 * @Description: 线索状态枚举
 * @date 2019年6月10日 下午4:41:40
 */
public enum BusinessClueStatusEnum {
    AWAIT(0,"待处理"),
    PROCESSED(1,"已处理"),
    LOSE(2,"已忽略"),
    REMOVED(3,"已移出");

    private int code;
    private String name;

    BusinessClueStatusEnum(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public int value() {
        return code;
    }

    public static String fromValue(int code)  {
        for(BusinessClueStatusEnum p : BusinessClueStatusEnum.values()) {
            if(p.value() == code) {
                return p.name;
            }
        }
        return null;
    }
}
