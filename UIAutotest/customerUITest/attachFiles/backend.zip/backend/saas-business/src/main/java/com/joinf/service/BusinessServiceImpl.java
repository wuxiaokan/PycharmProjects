package com.joinf.service;

import com.github.pagehelper.PageHelper;
import com.joinf.dto.BusinessEmailDto;
import com.joinf.dto.BusinessFollowUpDto;
import com.joinf.dto.BusinessOrderDto;
import com.joinf.dto.BusinessProductDto;
import com.joinf.dto.BusinessQuoteDto;
import com.joinf.dto.BusinessReadOnlyDto;
import com.joinf.dto.BusinessShareRelDto;
import com.joinf.dto.DeleteBusinessDto;
import com.joinf.dto.QueryBusinessDetailTableDto;
import com.joinf.dto.QueryBusinessEmailDto;
import com.joinf.dto.QueryBusinessInfoDto;
import com.joinf.dto.QueryBusinessParamDto;
import com.joinf.dto.SaveBusinessEmailRelDto;
import com.joinf.entity.BusinessEntity;
import com.joinf.entity.BusinessInfoEntity;
import com.joinf.entity.BusinessWithBLOBs;
import com.joinf.entity.generator.Business;
import com.joinf.entity.generator.BusinessShareRel;
import com.joinf.interfaces.BusinessService;
import com.joinf.mapper.BusinessExMapper;
import com.joinf.mapper.generator.BusinessMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * 商机
 *
 * @author yzq
 * @date 2019-04-17
 */
@Service
public class BusinessServiceImpl implements BusinessService {

    @Resource
    private BusinessExMapper businessExMapper;

    @Resource
    private BusinessMapper businessMapper;

    @Override
    public List<BusinessEntity> selectBusinessByDto(QueryBusinessParamDto dto) {
        if(dto.isPaging()){
            PageHelper.startPage(dto.getNum(), dto.getSize());
        }
        return businessExMapper.selectBusinessByDto(dto);
    }

    @Override
    public int insert(Business business) {
        return businessMapper.insertSelective(business);
    }

    @Override
    public int updateByPrimaryKey(Business business) {
        return businessMapper.updateByPrimaryKeySelective(business);
    }

    @Override
    public BusinessEntity selectBusinessByIdAndCompanyId(Long id,Long companyId) {
        return businessExMapper.selectBusinessByIdAndCompanyId(id, companyId);
    }

    @Override
    public Business selectByPrimaryKey(Long id) {
        return businessMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<Business> selectBusinessByIdsAndCidAndOid(DeleteBusinessDto dto) {
        return businessExMapper.selectBusinessByIdsAndCidAndOid(dto);
    }

    @Override
    public int updateByIdsAndCompanyId(DeleteBusinessDto dto) {
        return businessExMapper.updateByIdsAndCompanyId(dto);
    }

    @Override
    public List<BusinessQuoteDto> selectBusinessQuotes(QueryBusinessDetailTableDto dto) {
        if(dto.isPaging()){
            PageHelper.startPage(dto.getNum(), dto.getSize());
        }
        return businessExMapper.selectBusinessQuotes(dto.getBusinessId(),dto.getCompanyId());
    }

    @Override
    public List<BusinessOrderDto> selectBusinessOrders(QueryBusinessDetailTableDto dto) {
        if(dto.isPaging()){
            PageHelper.startPage(dto.getNum(), dto.getSize());
        }
        return businessExMapper.selectBusinessOrders(dto.getBusinessId(),dto.getCompanyId());
    }

    @Override
    public List<BusinessFollowUpDto> selectBusinessFollowUps(QueryBusinessDetailTableDto dto) {
        if(dto.isPaging()){
            PageHelper.startPage(dto.getNum(), dto.getSize());
        }
        return businessExMapper.selectBusinessFollowUps(dto.getBusinessId(),dto.getCompanyId());
    }

    @Override
    public List<BusinessEmailDto> selectBusinessEmailRecord(QueryBusinessDetailTableDto dto) {
        if(dto.isPaging()){
            PageHelper.startPage(dto.getNum(), dto.getSize());
        }
        return businessExMapper.selectBusinessEmailRecord(dto.getBusinessId(),dto.getCompanyId(),dto.getType());
    }

    @Override
    public List<BusinessProductDto> selectBusinessProducts(QueryBusinessDetailTableDto dto) {
        if(dto.isPaging()){
            PageHelper.startPage(dto.getNum(), dto.getSize());
        }
        List<BusinessProductDto> businessProductDtoList;
        int type = dto.getType();
        long businessId = dto.getBusinessId();
        long companyId = dto.getCompanyId();
        //0订单，//0订单，1报价，2自定义  (自定义先不做，v1)
        switch (type){
            case 0:
                businessProductDtoList = businessExMapper.selectBusinessProductOrders(businessId,companyId);
                break;
            case 1:
                businessProductDtoList = businessExMapper.selectBusinessProductQuotes(businessId,companyId);
                break;
//            case 2:
//                businessProductDtoList=null;
//                break;
            default:
                businessProductDtoList=null;
                break;
        }
        //去掉productId为null的值（sql问题）
        if(null != businessProductDtoList){
            for (int i = 0; i < businessProductDtoList.size(); i++) {
                if(businessProductDtoList.get(i).getProductId() == null){
                    businessProductDtoList.remove(i);
                    i--;
                }
            }
        }
        return businessProductDtoList;
    }

    @Override
    public int deleteBusinessShareById(Long id, Long companyId) {
        return businessExMapper.deleteBusinessShareById(id,companyId);
    }

    @Override
    public void insertBusinessShareBatch(List<BusinessShareRel> shareRelList) {
        businessExMapper.insertBusinessShareBatch(shareRelList);
    }

    @Override
    public List<BusinessShareRel> selectBusinessShareByBidAndCid(Long businessId, Long companyId) {
        return businessExMapper.selectBusinessShareByBidAndCid(businessId,companyId);
    }

    @Override
    public List<BusinessEmailDto> selectBusinessEmailRel(QueryBusinessEmailDto dto) {
        if(dto.isPaging()){
            PageHelper.startPage(dto.getNum(), dto.getSize());
        }
        return businessExMapper.selectBusinessEmailRel(dto);
    }

    @Override
    public int saveBusinessEmailRel(List<SaveBusinessEmailRelDto> dtoList) {
        return businessExMapper.saveBusinessEmailRel(dtoList);
    }

    @Override
    public List<BusinessShareRel> selectBusinessShareRelByCondition(BusinessReadOnlyDto dto) {
        return businessExMapper.selectBusinessShareRelByCondition(dto);
    }

    @Override
    public List<BusinessShareRelDto> selectCountBusinessShareByCompanyId(BusinessReadOnlyDto dto) {
        return businessExMapper.selectCountBusinessShareByCompanyId(dto);
    }

    @Override
    public List<Business> selectBusinessByCondition(BusinessWithBLOBs business) {
        return businessExMapper.selectBusinessByCondition(business);
    }

    @Override
    public boolean cancelBusinessEmailRel(SaveBusinessEmailRelDto dto) {
        return businessExMapper.cancelBusinessEmailRel(dto) > 0;
    }

    @Override
    public BusinessInfoEntity getBuisnessInfoById(QueryBusinessInfoDto dto) {
        return businessExMapper.getBuisnessInfoById(dto);
    }
}
