package com.joinf.dto;

/**
 * 商机详情-订单
 *
 * @author yzq
 * @date 2019-05-09
 */
public class BusinessOrderDto {

    /**
     * 订单id
     */
    private Long id;

    /**
     * 销售合同编号
     */
    private String saleContractNo;

    /**
     * 客户名称
     */
    private String customerName;

    /**
     * 合同总额
     */
    private String contractAmount;

    /**
     * 联系人
     */
    private String contactName;

    /**
     * 签约日期
     */
    private String signDate;

    /**
     * 币种
     */
    private String currency;

    /**
     * 状态:1/草拟;2/待审批;3/修改;4/完成;6/待审批;7/终止;/8生效
     */
    private String status;

    public String getSaleContractNo() {
        return saleContractNo;
    }

    public void setSaleContractNo(String saleContractNo) {
        this.saleContractNo = saleContractNo;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getContractAmount() {
        return contractAmount;
    }

    public void setContractAmount(String contractAmount) {
        this.contractAmount = contractAmount;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getSignDate() {
        return signDate;
    }

    public void setSignDate(String signDate) {
        this.signDate = signDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
