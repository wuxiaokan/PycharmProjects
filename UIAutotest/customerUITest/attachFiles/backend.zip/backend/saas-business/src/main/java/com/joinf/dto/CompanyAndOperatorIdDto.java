package com.joinf.dto;

/**
 * @author zlx
 * @Description: 企业id和业务员id参数
 * @date 2018年1月5日 下午5:21:20
 */
public class CompanyAndOperatorIdDto extends PagerDto{
	/**
	 * 企业id
	 */
	protected Long companyId;
	/**
	 * 业务员id
	 */
	protected Long operatorId;
	
	/**
	 * 登陆业务员id
	 */
	protected Long loginOperatorId;
	
	
	public Long getCompanyId() {
		return companyId;
	}
	public Long getOperatorId() {
		return operatorId;
	}
	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}
	public void setOperatorId(Long operatorId) {
		this.operatorId = operatorId;
	}
	public Long getLoginOperatorId() {
		return loginOperatorId;
	}
	public void setLoginOperatorId(Long loginOperatorId) {
		this.loginOperatorId = loginOperatorId;
	}
	@Override
	public String toString() {
		return "CompanyAndOperatorIdDto [companyId=" + companyId + ", operatorId=" + operatorId + ", loginOperatorId="
				+ loginOperatorId + "]";
	}
	
	
	

}
