package com.joinf.enums;

/**
 * 线索来源类型枚举
 *
 * @author yzq
 * @date 2019-04-16
 */
public enum BusinessClueTypeEnum {
    CLUE_TYPE_ENUM_ENQUIRY(0,"询盘信息"),
    CLUE_TYPE_ENUM_REGISTER(1,"注册会员"),
    CLUE_TYPE_ENUM_VISIT(2,"访问咨询"),
    CLUE_TYPE_ENUM_BUSINESS(3,"商业数据");

    private int code;
    private String name;

    BusinessClueTypeEnum(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public int value() {
        return code;
    }

    public static String fromValue(int code)  {
        for(BusinessClueTypeEnum p : BusinessClueTypeEnum.values()) {
            if(p.value() == code) {
                return p.name;
            }
        }
        return null;
    }
}
