package com.joinf.mapper;

import com.joinf.dto.*;
import com.joinf.entity.generator.BusinessClue;
import com.joinf.entity.generator.BusinessClueFilingLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 商机线索
 *
 * @author yzq
 * @date 2019-04-15
 */
@Mapper
public interface BusinessClueExMapper {
    /**
     * 获取列表
     * @param dto
     * @return
     */
    List<BusinessClueDto> selectBusinessClueByDto(QueryBusinessClueDto dto);

    /**
     * 通过线索id+companyId获取线索
     * @param clueId
     * @param companyId
     * @return
     */
    BusinessClueDetailDto selectBusinessClue(@Param("clueId") Long clueId,@Param("companyId")Long companyId);

    /**
     * 通过线索id获取线索详情
     * @param clueId
     * @return
     */
    List<BusinessCLueSourceDto> selectBusinessClueSourceById(@Param("clueId") Long clueId);

    /**
     * 更新线索状态
     * @param ids
     * @param clueStatus 见：BusinessClueStatusEnum
     * @param companyId
     * @return
     */
    int updateClueStatusByIds(@Param("idList")List<Long> ids, @Param("clueStatus")int clueStatus,@Param("companyId") Long companyId);

    /**
     * 通过线索id获取线索
     * @param clueId
     * @return
     */
    BusinessClueDetailDto selectBusinessClueById(@Param("clueId") Long clueId);

    /**
     * 通过邮箱+企业id获取商机线索的条数
     * @param email
     * @param companyId
     * @return
     */
    BusinessClue checkBusinessClueByEmailAndComId(@Param("email") String email, @Param("companyId") Long companyId);

    /**
     * 获取线索的处理信息
     * @param clueId
     * @param companyId
     * @return
     */
    List<BusinessClueFilingDto> queryBusinessClueFiling(@Param("clueId") Long clueId, @Param("companyId") Long companyId);

    /**
     * 通过ids+企业id查询线索
     * @param ids
     * @param companyId
     * @return
     */
    List<BusinessClue> selectBusinessClueByIds(@Param("idList")List<Long> ids, @Param("companyId") Long companyId);

    /**
     * 根据线索条件查询线索数据
     * @param businessClueFilingLog
     * @return
     */
    int updateBusinessClueFilingLogByClueId(BusinessClueFilingLog businessClueFilingLog);
}
