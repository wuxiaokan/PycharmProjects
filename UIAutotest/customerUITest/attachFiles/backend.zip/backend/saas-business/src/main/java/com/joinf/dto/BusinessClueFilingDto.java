package com.joinf.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * Demo class
 *
 * @author yzq
 * @date 2019-05-07
 */
public class BusinessClueFilingDto implements Serializable {

    private static final long serialVersionUID = 6155384808352054327L;

    /**
     * 线索名称
     */
    private String clueEmail;

    /**
     * 线索企业名称
     */
    private String clueCompanyName;

    /**
     * 处理时间
     */
    private Date createTime;

    /**
     * 处理人
     */
    private String createName;

    /**
     * 处理方式 0:仅添加客户 1:添加客户并新建商机
     */
    private Integer type;

    /**
     * 客户名称
     */
    private String customerName;

    /**
     * 客户编码
     */
    private String customerCode;

    /**
     * 商机名称
     */
    private String businessName;

    /**
     * 商机编码
     */
    private String businessCode;

    /**
     * 分配用户姓名
     */
    private String allocationUserName;

    /**
     * 客户id
     */
    private Long customerId;

    /**
     * 商机id
     */
    private Long businessId;

    /**
     * 创建人
     */
    private Long createId;

    public String getClueEmail() {
        return clueEmail;
    }

    public void setClueEmail(String clueEmail) {
        this.clueEmail = clueEmail;
    }

    public String getClueCompanyName() {
        return clueCompanyName;
    }

    public void setClueCompanyName(String clueCompanyName) {
        this.clueCompanyName = clueCompanyName;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateName() {
        return createName;
    }

    public void setCreateName(String createName) {
        this.createName = createName;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerCode() {
        return customerCode;
    }

    public void setCustomerCode(String customerCode) {
        this.customerCode = customerCode;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public String getBusinessCode() {
        return businessCode;
    }

    public void setBusinessCode(String businessCode) {
        this.businessCode = businessCode;
    }

    public String getAllocationUserName() {
        return allocationUserName;
    }

    public void setAllocationUserName(String allocationUserName) {
        this.allocationUserName = allocationUserName;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public Long getBusinessId() {
        return businessId;
    }

    public void setBusinessId(Long businessId) {
        this.businessId = businessId;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }
}
