package com.joinf.service;

import com.github.pagehelper.PageHelper;
import com.joinf.dto.*;
import com.joinf.entity.generator.BusinessClue;
import com.joinf.entity.generator.BusinessClueDetail;
import com.joinf.interfaces.BusinessClueService;
import com.joinf.mapper.BusinessClueExMapper;
import com.joinf.mapper.generator.BusinessClueDetailMapper;
import com.joinf.mapper.generator.BusinessClueMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 商机线索
 *
 * @author yzq
 * @date 2019-04-15
 */
@Service
public class BusinessClueServiceImpl implements BusinessClueService {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());



    @Autowired
    private BusinessClueExMapper businessClueExMapper;

    @Autowired
    private BusinessClueMapper mapper;

    @Autowired
    private BusinessClueDetailMapper detailMapper;

    @Override
    public List<BusinessClueDto> selectBusinessClueByDto(QueryBusinessClueDto dto) {
        if(dto.isPaging()){
            PageHelper.startPage(dto.getNum(), dto.getSize());
        }
        return businessClueExMapper.selectBusinessClueByDto(dto);
    }

    @Override
    public BusinessClueDetailDto selectBusinessClue(Long clueId,Long companyId) {
        return businessClueExMapper.selectBusinessClue(clueId,companyId);
    }

    @Override
    public List<BusinessCLueSourceDto> selectBusinessClueSourceById(Long clueId) {
        return businessClueExMapper.selectBusinessClueSourceById(clueId);
    }

    @Override
    public int updateClueStatusByIds(List<Long> ids, int clueStatus, Long companyId) {
        return businessClueExMapper.updateClueStatusByIds(ids,clueStatus,companyId);
    }

    @Override
    public BusinessClueDetailDto selectBusinessClueById(Long clueId) {
        return businessClueExMapper.selectBusinessClueById(clueId);

    }

    @Override
    public BusinessClue checkBusinessClueByEmailAndComId(String email, Long companyId) {
        return businessClueExMapper.checkBusinessClueByEmailAndComId(email,companyId);
    }

    @Override
    public int updateByPrimaryKeySelective(BusinessClue businessClue) {
        return mapper.updateByPrimaryKeySelective(businessClue);
    }

    @Override
    public int insertSelective(BusinessClue businessClue) {
        return mapper.insertSelective(businessClue);
    }

    @Override
    public int insertDetailSelective(BusinessClueDetail detail) {
        return detailMapper.insertSelective(detail);
    }

    @Override
    public List<BusinessClueFilingDto> queryBusinessClueFiling(Long clueId, Long companyId) {
        return businessClueExMapper.queryBusinessClueFiling(clueId,companyId);
    }

    @Override
    public List<BusinessClue> selectBusinessClueByIds(List<Long> ids, Long companyId) {
        return businessClueExMapper.selectBusinessClueByIds(ids,companyId);
    }
}
