package com.joinf.service;

import com.joinf.mapper.BusinessClueExMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.joinf.entity.generator.BusinessClueFilingLog;
import com.joinf.interfaces.BusinessClueFilingLogService;
import com.joinf.mapper.generator.BusinessClueFilingLogMapper;

/**
 * 
 * @author zlx
 * @Description: 商机-线索建档日志接口实现
 * @date 2019年4月29日 下午7:20:59
 */
@Service
public class BusinessClueFilingLogServiceImpl implements BusinessClueFilingLogService {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    private BusinessClueFilingLogMapper businessClueFilingLogMapper;

    @Autowired
    private BusinessClueExMapper businessClueExMapper;
    /**
     * 保存线索建档日志
     */
	@Override
	public int insertBusinessClueFilingLog(BusinessClueFilingLog businessClueFilingLog) {
		return this.businessClueFilingLogMapper.insertSelective(businessClueFilingLog);
	}

    @Override
    public int updateBusinessClueFilingLogByClueId(BusinessClueFilingLog businessClueFilingLog) {
        return businessClueExMapper.updateBusinessClueFilingLogByClueId(businessClueFilingLog);
    }
}
