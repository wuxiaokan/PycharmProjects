package com.joinf.entity.generator;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * t_business
 */
public class Business implements Serializable {
    @ApiModelProperty(value ="ID")
    private Long id;

    @ApiModelProperty(value ="公司ID")
    private Long companyId;

    @ApiModelProperty(value ="操作人ID")
    private Long operatorId;

    @ApiModelProperty(value ="共享操作人ID")
    private String operatorIds;

    @ApiModelProperty(value ="线索id")
    private Long clueId;

    @ApiModelProperty(value ="客户ID")
    private Long customerId;

    @ApiModelProperty(value ="客户名称")
    private String customerName;

    @ApiModelProperty(value ="商机名称")
    private String name;

    @ApiModelProperty(value ="商机编码")
    private String code;

    @ApiModelProperty(value ="联系人ID")
    private Long contactId;

    @ApiModelProperty(value ="联系人邮箱")
    private String contactEmail;

    @ApiModelProperty(value ="联系人")
    private String contactName;

    @ApiModelProperty(value ="开始日期")
    private Date startDate;

    @ApiModelProperty(value ="结束日期")
    private Date endDate;

    @ApiModelProperty(value ="执行状态(0:跟进;1:赢单;2:丢单)")
    private Integer status;

    @ApiModelProperty(value ="跟进阶段(0:洽淡;1:询盘;2:报价;3;样品;4:订单;5:成交;)")
    private Long flowStep;

    @ApiModelProperty(value ="修改人ID")
    private Long updateId;

    @ApiModelProperty(value ="修改日期")
    private Date updateTime;

    @ApiModelProperty(value ="创建日期")
    private Date createTime;

    @ApiModelProperty(value ="创建人ID")
    private Long createId;

    @ApiModelProperty(value ="币种")
    private Long priceUnit;

    @ApiModelProperty(value ="目标赢单金额")
    private BigDecimal targetPayment;

    @ApiModelProperty(value ="预计签单日期")
    private Date signDate;

    @ApiModelProperty(value ="预计成功率（百分比）")
    private BigDecimal successRate;

    @ApiModelProperty(value ="需求描述")
    private String description;

    @ApiModelProperty(value ="丢单原因")
    private Long lostOrderCauseId;

    @ApiModelProperty(value ="丢单描述")
    private String lostOrderDescribe;

    @ApiModelProperty(value ="状态：0-删除，1-正常")
    private Integer flag;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public Long getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(Long operatorId) {
        this.operatorId = operatorId;
    }

    public String getOperatorIds() {
        return operatorIds;
    }

    public void setOperatorIds(String operatorIds) {
        this.operatorIds = operatorIds == null ? null : operatorIds.trim();
    }

    public Long getClueId() {
        return clueId;
    }

    public void setClueId(Long clueId) {
        this.clueId = clueId;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName == null ? null : customerName.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code == null ? null : code.trim();
    }

    public Long getContactId() {
        return contactId;
    }

    public void setContactId(Long contactId) {
        this.contactId = contactId;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail == null ? null : contactEmail.trim();
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName == null ? null : contactName.trim();
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Long getFlowStep() {
        return flowStep;
    }

    public void setFlowStep(Long flowStep) {
        this.flowStep = flowStep;
    }

    public Long getUpdateId() {
        return updateId;
    }

    public void setUpdateId(Long updateId) {
        this.updateId = updateId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Long getPriceUnit() {
        return priceUnit;
    }

    public void setPriceUnit(Long priceUnit) {
        this.priceUnit = priceUnit;
    }

    public BigDecimal getTargetPayment() {
        return targetPayment;
    }

    public void setTargetPayment(BigDecimal targetPayment) {
        this.targetPayment = targetPayment;
    }

    public Date getSignDate() {
        return signDate;
    }

    public void setSignDate(Date signDate) {
        this.signDate = signDate;
    }

    public BigDecimal getSuccessRate() {
        return successRate;
    }

    public void setSuccessRate(BigDecimal successRate) {
        this.successRate = successRate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }

    public Long getLostOrderCauseId() {
        return lostOrderCauseId;
    }

    public void setLostOrderCauseId(Long lostOrderCauseId) {
        this.lostOrderCauseId = lostOrderCauseId;
    }

    public String getLostOrderDescribe() {
        return lostOrderDescribe;
    }

    public void setLostOrderDescribe(String lostOrderDescribe) {
        this.lostOrderDescribe = lostOrderDescribe == null ? null : lostOrderDescribe.trim();
    }

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }
}