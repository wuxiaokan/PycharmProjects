package com.joinf.service;

import com.joinf.dto.QueryBusinessAttachmentDto;
import com.joinf.dto.UpdateBusinessAttachmentDto;
import com.joinf.entity.BusinessAttachmentEntity;
import com.joinf.entity.generator.BusinessAttachment;
import com.joinf.interfaces.BusinessAttachmentService;
import com.joinf.mapper.BusinessAttachmentExMapper;
import com.joinf.mapper.generator.BusinessAttachmentMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author zlx
 * @Description: 商机附件
 * @date 2019年5月6日 下午7:22:14
 */
@Service
public class BusinessAttachmentServiceImpl implements BusinessAttachmentService {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    private BusinessAttachmentMapper businessAttachmentMapper;

    @Autowired
    private BusinessAttachmentExMapper businessAttachmentExMapper;

    /**
     * 插入商机附件信息
     */
	@Override
	public int insert(BusinessAttachment businessAttachment) {
		return this.businessAttachmentMapper.insertSelective(businessAttachment);
	}

	/**
	 * 删除商机附件
	 */
	@Override
	public int deleteBusinessAttachment(UpdateBusinessAttachmentDto deleteDto) {
		return businessAttachmentExMapper.deleteBusinessAttachment(deleteDto);
	}

	/**
	 * 绑定商机附件
	 */
	@Override
	public int bindingBusinessAttachment(UpdateBusinessAttachmentDto updateDto) {
		return businessAttachmentExMapper.bindingBusinessAttachment(updateDto);
	}

	/**
	 * 查询商机附件列表
	 */
	@Override
	public List<BusinessAttachmentEntity> queryBusinessAttachmentListByCondition(QueryBusinessAttachmentDto queryDto) {
		return businessAttachmentExMapper.queryBusinessAttachmentListByCondition(queryDto);
	}

}
