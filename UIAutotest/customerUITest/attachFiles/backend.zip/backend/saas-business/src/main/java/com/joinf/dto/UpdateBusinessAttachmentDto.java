package com.joinf.dto;

import java.util.List;

/**
 * @author zlx
 * @Description: 修改商机附件参数
 * @date 2019年5月6日 下午7:30:42
 */
public class UpdateBusinessAttachmentDto extends CompanyAndOperatorIdDto{
	/**
	 * 附件id
	 */
	private Long attachmentId;
	/**
	 * 附件id集合
	 */
	private List<Long> attachmentIdArray;
	/**
	 * 附件id集合,not in使用
	 */
	private List<Long> notAttachmentIdArray;
	/**
	 * 商机id
	 */
	private Long businessId;

	/**
	 * 商机id集合
	 */
	private List<Long> businessIdArray;
	
	
	/**
	 * 邮件附件类型    1：正文 2：附件 3：退信状态文件 4 : 正文中文件
	 */
	private Integer type;

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Long getAttachmentId() {
		return attachmentId;
	}

	public void setAttachmentId(Long attachmentId) {
		this.attachmentId = attachmentId;
	}

	public List<Long> getAttachmentIdArray() {
		return attachmentIdArray;
	}

	public void setAttachmentIdArray(List<Long> attachmentIdArray) {
		this.attachmentIdArray = attachmentIdArray;
	}

	public List<Long> getNotAttachmentIdArray() {
		return notAttachmentIdArray;
	}

	public void setNotAttachmentIdArray(List<Long> notAttachmentIdArray) {
		this.notAttachmentIdArray = notAttachmentIdArray;
	}

	public Long getBusinessId() {
		return businessId;
	}

	public void setBusinessId(Long businessId) {
		this.businessId = businessId;
	}

	public List<Long> getBusinessIdArray() {
		return businessIdArray;
	}

	public void setBusinessIdArray(List<Long> businessIdArray) {
		this.businessIdArray = businessIdArray;
	}
	
	
	

}
