package com.joinf.mapper;

import com.joinf.dto.BusinessEmailDto;
import com.joinf.dto.BusinessFollowUpDto;
import com.joinf.dto.BusinessOrderDto;
import com.joinf.dto.BusinessProductDto;
import com.joinf.dto.BusinessQuoteDto;
import com.joinf.dto.BusinessReadOnlyDto;
import com.joinf.dto.BusinessShareRelDto;
import com.joinf.dto.DeleteBusinessDto;
import com.joinf.dto.QueryBusinessEmailDto;
import com.joinf.dto.QueryBusinessInfoDto;
import com.joinf.dto.QueryBusinessParamDto;
import com.joinf.dto.SaveBusinessEmailRelDto;
import com.joinf.entity.BusinessEntity;
import com.joinf.entity.BusinessInfoEntity;
import com.joinf.entity.BusinessWithBLOBs;
import com.joinf.entity.generator.Business;
import com.joinf.entity.generator.BusinessShareRel;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 商机
 *
 * @author yzq
 * @date 2019-04-17
 */
@Mapper
public interface BusinessExMapper {
    /**
     * 获取商机的基本数据
     * @param dto
     * @return
     */
    List<BusinessEntity> selectBusinessByDto(QueryBusinessParamDto dto);

    /**
     * 通过主键获取商机信息
     * @param id
     * @param companyId
     * @return
     */
    BusinessEntity selectBusinessByIdAndCompanyId(@Param(value = "id") Long id,@Param(value = "companyId") Long companyId);

    /**
     * 通过ids
     * @param dto
     * @return
     */
    List<Business> selectBusinessByIdsAndCidAndOid(DeleteBusinessDto dto);

    /**
     * 通过ids+企业id更新商机
     * @param dto
     * @return
     */
    int updateByIdsAndCompanyId(DeleteBusinessDto dto);

    /**
     * 获取商机-报价
     * @param id
     * @param companyId
     * @return
     */
    List<BusinessQuoteDto> selectBusinessQuotes(@Param("businessId")Long id, @Param("companyId")Long companyId);

    /**
     * 获取商机-订单
     * @param id
     * @param companyId
     * @return
     */
    List<BusinessOrderDto> selectBusinessOrders(@Param("businessId")Long id, @Param("companyId")Long companyId);

    /**
     * 获取商机-跟进
     * @param id
     * @param companyId
     * @return
     */
    List<BusinessFollowUpDto> selectBusinessFollowUps(@Param("businessId")Long id, @Param("companyId")Long companyId);

    /**
     * 获取商机-已关联邮件
     * @param id
     * @param companyId
     * @param type
     * @return
     */
    List<BusinessEmailDto> selectBusinessEmailRecord(@Param("businessId")Long id, @Param("companyId")Long companyId,@Param("emailType") Integer type);

    /**
     * 获取商机-产品-订单
     * @param id
     * @param companyId
     * @return
     */
    List<BusinessProductDto> selectBusinessProductOrders(@Param("businessId")Long id, @Param("companyId")Long companyId);

    /**
     * 获取商机-产品-报价
     * @param id
     * @param companyId
     * @return
     */
    List<BusinessProductDto> selectBusinessProductQuotes(@Param("businessId")Long id, @Param("companyId")Long companyId);

    /**
     * 通过商机id+企业id删除商机共享业务员数据
     * @param id
     * @param companyId
     * @return
     */
    int deleteBusinessShareById(@Param("businessId")Long id, @Param("companyId")Long companyId);

    /**
     * 批量插入商机共享操作员
     * @param shareRelList
     */
    void insertBusinessShareBatch(List<BusinessShareRel> shareRelList);

    /**
     * 通过businessId+companyId查询商机的共享操作员
     * @param businessId
     * @param companyId
     * @return
     */
    List<BusinessShareRel> selectBusinessShareByBidAndCid(@Param("businessId")Long businessId, @Param("companyId")Long companyId);

    /**
     * 查询商机联系人可关联的邮件
     * @param dto
     * @return
     */
    List<BusinessEmailDto> selectBusinessEmailRel(QueryBusinessEmailDto dto);

    /**
     * 保存商机-可关联邮件
     * @param dtoList
     * @return
     */
    int saveBusinessEmailRel(List<SaveBusinessEmailRelDto> dtoList);

    /**
     * 通过条件查询共享商机信息
     * @param dto
     * @return
     */
    List<BusinessShareRel> selectBusinessShareRelByCondition(BusinessReadOnlyDto dto);

    /**
     * 查询企业的所有共享商机信息的对应商机数目，用于判断是否是全共享
     * @param dto
     * @return
     */
    List<BusinessShareRelDto> selectCountBusinessShareByCompanyId(BusinessReadOnlyDto dto);

    /**
     * 通过条件查询商机基本数据
     * @param business
     * @return
     */
    List<Business> selectBusinessByCondition(BusinessWithBLOBs business);

    /**
     * 取消关联邮件
     * @param dto
     * @return
     */
    int cancelBusinessEmailRel(SaveBusinessEmailRelDto dto);

    /**
     * 关联关系的商机详情
     * @author cxi
     * @date 2019/7/31/031
     * @param dto :
     * @return com.joinf.entity.BusinessInfoEntity
     * @throws
     */
    BusinessInfoEntity getBuisnessInfoById(QueryBusinessInfoDto dto);
}
