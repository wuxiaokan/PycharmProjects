package com.joinf.interfaces;

import com.joinf.entity.generator.BusinessClueFilingLog;

/**
 * @author zlx
 * @Description: 商机-线索建档日志接口
 * @date 2019年4月29日 下午7:19:18
 */
public interface BusinessClueFilingLogService {
	
	/**
	 * 保存线索建档日志
	 * @param businessClueFilingLog
	 * @return
	 */
	int insertBusinessClueFilingLog(BusinessClueFilingLog businessClueFilingLog);

	/**
	 * 根据条件更新线索日志数据
	 * @param businessClueFilingLog
	 * @return
	 */
	int updateBusinessClueFilingLogByClueId(BusinessClueFilingLog businessClueFilingLog);
}
