package com.joinf.dto;

import java.util.List;

/**
 * 商机只读权限判断
 *
 * @author yzq
 * @date 2019-05-17
 */
public class BusinessReadOnlyDto {

    private Long businessId;

    private List<Long> businessIds;

    private Long companyId;

    private Long shareId;

    public Long getBusinessId() {
        return businessId;
    }

    public void setBusinessId(Long businessId) {
        this.businessId = businessId;
    }

    public List<Long> getBusinessIds() {
        return businessIds;
    }

    public void setBusinessIds(List<Long> businessIds) {
        this.businessIds = businessIds;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public Long getShareId() {
        return shareId;
    }

    public void setShareId(Long shareId) {
        this.shareId = shareId;
    }
}
