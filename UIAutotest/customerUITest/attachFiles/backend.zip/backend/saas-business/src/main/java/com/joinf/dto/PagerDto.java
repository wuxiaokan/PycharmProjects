package com.joinf.dto;

/**
 * 分页参数Dto
 *
 * @author yzq
 * @date 2019-04-12
 */
public class PagerDto {
    /**
     * 是否分页
     */
    private boolean isPaging;
    /**
     * 当前页
     */
    private Integer num;
    /**
     * 每页显示条数
     */
    private Integer size;

    public boolean isPaging() {
        return isPaging;
    }

    public void setPaging(boolean paging) {
        isPaging = paging;
    }

    public Integer getNum() {
        return num;
    }

    public void setNum(Integer num) {
        this.num = num;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }
}
