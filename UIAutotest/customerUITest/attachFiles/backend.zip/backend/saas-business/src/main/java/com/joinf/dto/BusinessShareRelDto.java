package com.joinf.dto;

import java.io.Serializable;

/**
 * 商机共享信息
 *
 * @author yzq
 * @date 2019-05-22
 */
public class BusinessShareRelDto implements Serializable {

    private static final long serialVersionUID = 1176726762210649729L;

    /**
     * 商机id数目
     */
    private Integer countBusinessId;

    /**
     * 商机id
     */
    private Long businessId;

    /**
     * 企业id
     */
    private Long companyId;

    /**
     * 该公司下业务员的数目
     */
    private Integer countOperator;

    public Integer getCountBusinessId() {
        return countBusinessId;
    }

    public void setCountBusinessId(Integer countBusinessId) {
        this.countBusinessId = countBusinessId;
    }

    public Long getBusinessId() {
        return businessId;
    }

    public void setBusinessId(Long businessId) {
        this.businessId = businessId;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public Integer getCountOperator() {
        return countOperator;
    }

    public void setCountOperator(Integer countOperator) {
        this.countOperator = countOperator;
    }
}
