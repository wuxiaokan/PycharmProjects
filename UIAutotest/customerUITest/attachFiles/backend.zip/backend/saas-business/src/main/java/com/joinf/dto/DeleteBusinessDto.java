package com.joinf.dto;

import java.io.Serializable;
import java.util.List;

/**
 * 商机删除dto
 *
 * @author yzq
 * @date 2019-04-30
 */
public class DeleteBusinessDto implements Serializable {

    private static final long serialVersionUID = 9180948449957032534L;

    /**
     * 商机id
     */
    private Long id;

    private Long companyId;

    private Long operatorId;

    private Long customerId;

    /**
     * 商机id集合
     */
    private List<Long> ids;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public Long getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(Long operatorId) {
        this.operatorId = operatorId;
    }

    public List<Long> getIds() {
        return ids;
    }

    public void setIds(List<Long> ids) {
        this.ids = ids;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }
}
