package com.joinf.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * 商机-线索Dto
 *
 * @author yzq
 * @date 2019-04-15
 */
public class BusinessClueDto implements Serializable {

    private static final long serialVersionUID = -2494193266268076720L;

    /**
     * 线索标识
     */
    private Long id;

    /**
     * 线索名称
     */
    private String clueName;

    /**
     * 线索邮箱
     */
    private String clueEmail;

    /**
     * 线索名称<线索邮箱>
     */
    private String name;

    /**
     * 企业信息
     */
    private String enterpriseInformation;

    /**
     * 线索等级
     */
    private Integer clueGrade;

    /**
     * 线索来源
     */
    private Integer clueType;

    /**
     * 线索状态
     */
    private Integer clueStatus;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 推送时间
     */
    private Date createTime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getClueName() {
        return clueName;
    }

    public void setClueName(String clueName) {
        this.clueName = clueName;
    }

    public String getClueEmail() {
        return clueEmail;
    }

    public void setClueEmail(String clueEmail) {
        this.clueEmail = clueEmail;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEnterpriseInformation() {
        return enterpriseInformation;
    }

    public void setEnterpriseInformation(String enterpriseInformation) {
        this.enterpriseInformation = enterpriseInformation;
    }

    public Integer getClueGrade() {
        return clueGrade;
    }

    public void setClueGrade(Integer clueGrade) {
        this.clueGrade = clueGrade;
    }

    public Integer getClueType() {
        return clueType;
    }

    public void setClueType(Integer clueType) {
        this.clueType = clueType;
    }

    public Integer getClueStatus() {
        return clueStatus;
    }

    public void setClueStatus(Integer clueStatus) {
        this.clueStatus = clueStatus;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
