package com.joinf.dto;

import java.io.Serializable;

/**
 * 商机-线索-jms-dto
 *
 * @author yzq
 * @date 2019-05-06
 */
public class BusinessClueJmsDto implements Serializable {

    private static final long serialVersionUID = 580641634751771521L;

    /**
     * 企业id
     */
    private String companyId;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 企业名称
     */
    private String companyName;

    /**
     * 来源id
     */
    private String id;

    /**
     * 线索名称
     */
    private String name;

    /**
     * 推送的客户端
     */
    private String pushClient;

    /**
     * 站点名称
     */
    private String siteName;

    /**
     * 推送的业务员ID号
     */
    private String mustPushOp;

    /**
     * 消息型类(1=询盘，2=访问，没什么用了)
     */
    private String msgType;

    /**
     * 推送时间
     */
    private String date;

    /**
     * 访问URL
     */
    private String accessUrl;

    /**
     * 询盘内容
     */
    private String content;

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPushClient() {
        return pushClient;
    }

    public void setPushClient(String pushClient) {
        this.pushClient = pushClient;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public String getMustPushOp() {
        return mustPushOp;
    }

    public void setMustPushOp(String mustPushOp) {
        this.mustPushOp = mustPushOp;
    }

    public String getMsgType() {
        return msgType;
    }

    public void setMsgType(String msgType) {
        this.msgType = msgType;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getAccessUrl() {
        return accessUrl;
    }

    public void setAccessUrl(String accessUrl) {
        this.accessUrl = accessUrl;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "BusinessClueJmsDto{" +
                "companyId='" + companyId + '\'' +
                ", email='" + email + '\'' +
                ", companyName='" + companyName + '\'' +
                ", id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", pushClient='" + pushClient + '\'' +
                ", siteName='" + siteName + '\'' +
                ", mustPushOp='" + mustPushOp + '\'' +
                ", msgType='" + msgType + '\'' +
                ", date='" + date + '\'' +
                ", accessUrl='" + accessUrl + '\'' +
                ", content='" + content + '\'' +
                '}';
    }
}
