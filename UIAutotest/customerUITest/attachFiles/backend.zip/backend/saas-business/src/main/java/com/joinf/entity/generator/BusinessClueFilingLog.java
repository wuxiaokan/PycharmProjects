package com.joinf.entity.generator;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;

/**
 * t_business_clue_filing_log
 */
public class BusinessClueFilingLog implements Serializable {
    @ApiModelProperty(value ="ID")
    private Long id;

    @ApiModelProperty(value ="公司ID")
    private Long companyId;

    @ApiModelProperty(value ="线索id")
    private Long clueId;

    @ApiModelProperty(value ="线索邮箱")
    private String clueEmail;

    @ApiModelProperty(value ="线索企业名称")
    private String clueCompanyName;

    @ApiModelProperty(value ="客户ID")
    private Long customerId;

    @ApiModelProperty(value ="客户名称")
    private String customerName;

    @ApiModelProperty(value ="客户编码")
    private String customerCode;

    @ApiModelProperty(value ="商机id")
    private Long businessId;

    @ApiModelProperty(value ="商机名称")
    private String businessName;

    @ApiModelProperty(value ="商机编码")
    private String businessCode;

    @ApiModelProperty(value ="分配用户id")
    private Long allocationUserId;

    @ApiModelProperty(value ="分配用户姓名")
    private String allocationUserName;

    @ApiModelProperty(value ="修改人ID")
    private Long updateId;

    @ApiModelProperty(value ="修改日期")
    private Date updateTime;

    @ApiModelProperty(value ="创建日期")
    private Date createTime;

    @ApiModelProperty(value ="创建人ID")
    private Long createId;

    @ApiModelProperty(value ="处理方式 0:仅添加客户 1:添加客户并新建商机")
    private Integer type;

    @ApiModelProperty(value ="状态：0-删除，1-正常")
    private Integer flag;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public Long getClueId() {
        return clueId;
    }

    public void setClueId(Long clueId) {
        this.clueId = clueId;
    }

    public String getClueEmail() {
        return clueEmail;
    }

    public void setClueEmail(String clueEmail) {
        this.clueEmail = clueEmail == null ? null : clueEmail.trim();
    }

    public String getClueCompanyName() {
        return clueCompanyName;
    }

    public void setClueCompanyName(String clueCompanyName) {
        this.clueCompanyName = clueCompanyName == null ? null : clueCompanyName.trim();
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName == null ? null : customerName.trim();
    }

    public String getCustomerCode() {
        return customerCode;
    }

    public void setCustomerCode(String customerCode) {
        this.customerCode = customerCode == null ? null : customerCode.trim();
    }

    public Long getBusinessId() {
        return businessId;
    }

    public void setBusinessId(Long businessId) {
        this.businessId = businessId;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName == null ? null : businessName.trim();
    }

    public String getBusinessCode() {
        return businessCode;
    }

    public void setBusinessCode(String businessCode) {
        this.businessCode = businessCode == null ? null : businessCode.trim();
    }

    public Long getAllocationUserId() {
        return allocationUserId;
    }

    public void setAllocationUserId(Long allocationUserId) {
        this.allocationUserId = allocationUserId;
    }

    public String getAllocationUserName() {
        return allocationUserName;
    }

    public void setAllocationUserName(String allocationUserName) {
        this.allocationUserName = allocationUserName == null ? null : allocationUserName.trim();
    }

    public Long getUpdateId() {
        return updateId;
    }

    public void setUpdateId(Long updateId) {
        this.updateId = updateId;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }
}