package com.joinf.entity.generator;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;

/**
 * t_business_share_rel
 */
public class BusinessShareRel implements Serializable {
    @ApiModelProperty(value ="商机共享权限标识")
    private Long id;

    @ApiModelProperty(value ="企业ID")
    private Long companyId;

    @ApiModelProperty(value ="商机ID")
    private Long businessId;

    @ApiModelProperty(value ="共享操作员ID")
    private Long shareId;

    @ApiModelProperty(value ="是否只读:0/否;1/是")
    private Byte isView;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public Long getBusinessId() {
        return businessId;
    }

    public void setBusinessId(Long businessId) {
        this.businessId = businessId;
    }

    public Long getShareId() {
        return shareId;
    }

    public void setShareId(Long shareId) {
        this.shareId = shareId;
    }

    public Byte getIsView() {
        return isView;
    }

    public void setIsView(Byte isView) {
        this.isView = isView;
    }
}